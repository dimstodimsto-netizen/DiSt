#!/usr/bin/env node
'use strict';

/*
 * Локален сървър за "Заявки за ремонт — Логистика Варна".
 *
 * - Съхранява данните в SQLite база (data/zayavki.db) на този компютър.
 * - Обслужва уеб страницата (public/index.html) през HTTP.
 * - Всеки друг компютър в същата мрежа може да отвори приложението през
 *   браузър, като въведе адреса на ТОЗИ компютър (виж съобщението при
 *   стартиране).
 * - Работи изцяло офлайн (не изисква интернет), с изключение на функцията
 *   за изпращане на имейл известия (Outlook), която по естеството си
 *   изисква връзка с интернет само в момента на изпращане.
 *
 * Изисква Node.js 24.0+ (препоръчително: последната LTS версия от
 * https://nodejs.org). Не са нужни никакви допълнителни инсталации
 * (npm install) — всичко е вградено в самия Node.js.
 */

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { spawn, spawnSync } = require('node:child_process');
const { URL } = require('node:url');
const zlib = require('node:zlib');
const { sendSmtpMail } = require('./smtp-mail');
const { createRecordsRoutes } = require('./records-routes');
const { createLoginBackgroundRoutes } = require('./login-background');
const { createKvRoutes } = require('./kv-routes');
const { createUsersModule, createUsersRoutes } = require('./users');
const { createKvStore } = require('./kv-store');
const { createWarehouseModule } = require('./warehouse');
const { createRecordsModule } = require('./records');
const { createHttpHelpers } = require('./http-helpers');
const { createUpdateModule } = require('./update');
const { createBackupModule } = require('./backup');
const { createRestartModule } = require('./restart');
const { createSystemRoutes } = require('./system-routes');
const { createMaintenanceMaterialsRoutes } = require('./maintenance-materials-routes');
const { createRequiredMaterialsRoutes } = require('./required-materials-routes');
const { createAdminRoutes } = require('./admin-routes');
const { createSystemLogModule } = require('./system-log');
const {
  createMaterialsReportRoutes,
  reportDatePartsServer,
  reportRecordDateParts,
  parseRepairMaterialsServer,
  parseReportQuantityServer,
  formatReportQuantityServer,
  buildMaterialsReportServer
} = require('./reports-materials');

let DatabaseSync;
try {
  ({ DatabaseSync } = require('node:sqlite'));
} catch (e) {
  console.error('');
  console.error('❌ Тази версия на Node.js няма вградена поддръжка на SQLite.');
  console.error('   Моля, инсталирайте най-новата версия на Node.js (LTS) от:');
  console.error('   https://nodejs.org');
  console.error('   и стартирайте отново START.bat / "node server.js".');
  console.error('');
  process.exit(1);
}

const {
  VERIFICATION_PERIOD_DAYS,
  VERIFICATION_WARNING_DAY,
  VERIFICATION_LOCK_DAY,
  VERIFICATION_INITIAL_CODE
} = require('./config');

const PORT = process.env.PORT ? Number(process.env.PORT) : 3000;
const LISTEN_HOST = (process.env.LISTEN_HOST || '0.0.0.0').trim() || '0.0.0.0';
const SERVER_STARTED_AT = Date.now();
const APP_VERSION = 'DiSt-2.0';
const ROOT_DIR = path.resolve(__dirname, "..");
const PUBLIC_DIR = path.join(ROOT_DIR, 'public');
const DATA_DIR = path.join(ROOT_DIR, 'data');
const DB_PATH = path.join(DATA_DIR, 'zayavki.db');
const PID_PATH = path.join(ROOT_DIR, 'server.pid');
const MAIL_SCRIPT_PATH = path.join(ROOT_DIR, 'scripts', 'send-outlook-mail.ps1');

// ---- Версия на UI-кода (index.html + js/app.js) ----
// Използва се от desktop клиента (client.html вътре в ZayavkiClient.exe),
// за да разбере, че сървърът поднася НОВ код и да презареди вградения
// <iframe> автоматично — вместо да остане с вече зареден стар JS в паметта
// с дни наред, докато потребителят сам не рестартира приложението.
// Без това, поправки на клиентска логика (напр. заключване на бутона
// "Редактирай" за заявители) стигат веднага до браузър потребителите
// (нова навигация = чисто зареждане), но НЕ и до вече отворени desktop
// клиенти, чийто iframe е зареден само веднъж при свързване и остава
// такъв, докато връзката не прекъсне.
let UI_VERSION = '0';
function computeUiVersion() {
  try {
    const hash = crypto.createHash('sha1');
    function walk(dir, baseRel) {
      if (!fs.existsSync(dir)) return;
      for (const name of fs.readdirSync(dir)) {
        const full = path.join(dir, name);
        const rel = baseRel ? path.join(baseRel, name) : name;
        let st;
        try { st = fs.statSync(full); } catch (_) { continue; }
        if (st.isDirectory()) {
          if (name === 'lib') {
            try {
              for (const entry of fs.readdirSync(full)) {
                const libFile = path.join(full, entry);
                try {
                  const libStat = fs.statSync(libFile);
                  if (libStat.isFile()) hash.update(String(rel).replace(/\\/g, '/') + '/' + entry + ':' + libStat.size + ':' + libStat.mtimeMs + '\n');
                } catch (_) {}
              }
            } catch (_) {}
            continue;
          }
          walk(full, rel);
        } else if (/\.(html|js|css)$/i.test(name)) {
          hash.update(String(rel).replace(/\\/g, '/') + '\0');
          hash.update(fs.readFileSync(full));
        }
      }
    }
    walk(PUBLIC_DIR, '');
    UI_VERSION = hash.digest('hex').slice(0, 12);
  } catch (e) {
    UI_VERSION = String(Date.now());
  }
}
computeUiVersion();

// Създаване на директориите, ако не съществуват
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(path.join(ROOT_DIR, 'scripts'))) fs.mkdirSync(path.join(ROOT_DIR, 'scripts'), { recursive: true });

// Създаване на PowerShell скрипта за Outlook, ако не съществува
// Ensure Outlook mail script is present and up to date (v2).
(function ensureMailScript() {
  const marker = '# DiSt-mail-script-v2';
  let needWrite = true;
  try {
    if (fs.existsSync(MAIL_SCRIPT_PATH)) {
      const cur = fs.readFileSync(MAIL_SCRIPT_PATH, 'utf8');
      if (cur.includes('DiSt-mail-script-v2')) needWrite = false;
    }
  } catch (_) {}
  if (!needWrite) return;
  const psScript = `# DiSt-mail-script-v2
# Silent email via Microsoft Outlook COM. JSON: {to, subject, body}
param([Parameter(Mandatory=$true)][string]$JsonPath)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
try {
  if (-not (Test-Path -LiteralPath $JsonPath)) { throw "Data file not found: $JsonPath" }
  $raw = Get-Content -LiteralPath $JsonPath -Raw -Encoding UTF8
  $data = $raw | ConvertFrom-Json
  if (-not $data.to) { throw "No recipient (to) specified." }
  $outlook = $null
  try { $outlook = [Runtime.InteropServices.Marshal]::GetActiveObject('Outlook.Application') } catch {
    try { $outlook = New-Object -ComObject Outlook.Application } catch {
      throw "Cannot start Outlook COM. Install Outlook desktop and sign in. Detail: $($_.Exception.Message)"
    }
  }
  try { $ns = $outlook.GetNamespace('MAPI'); $ns.Logon($null, $null, $false, $false) | Out-Null } catch {}
  $mail = $outlook.CreateItem(0)
  $mail.To = [string]$data.to
  $mail.Subject = [string]$data.subject
  $mail.Body = [string]$data.body
  $mail.Send()
  Start-Sleep -Milliseconds 800
  Write-Output 'OK'
  exit 0
} catch {
  $msg = $_.Exception.Message
  if (-not $msg) { $msg = "$_" }
  [Console]::Error.WriteLine($msg)
  exit 1
}
`;
  // UTF-8 BOM so Windows PowerShell 5.1 parses the file correctly
  fs.writeFileSync(MAIL_SCRIPT_PATH, '\uFEFF' + psScript, 'utf8');
})();

const db = new DatabaseSync(DB_PATH);
try {
  // WAL: четенията не блокират записите. При restore изтрийте -wal/-shm (RESTORE.txt).
  db.exec('PRAGMA busy_timeout = 5000;');
  db.exec('PRAGMA synchronous = NORMAL;');
  let mode = '';
  try {
    db.exec('PRAGMA journal_mode = WAL;');
  } catch (e1) {
    console.error('⚠ PRAGMA journal_mode=WAL:', e1 && e1.message ? e1.message : e1);
  }
  try {
    const row = db.prepare('PRAGMA journal_mode').get();
    if (row) {
      mode = String(row.journal_mode != null ? row.journal_mode : Object.values(row)[0] || '').toLowerCase();
    }
  } catch (_) {}
  if (mode !== 'wal') {
    try { db.exec('PRAGMA journal_mode = WAL;'); } catch (_) {}
    try {
      const row2 = db.prepare('PRAGMA journal_mode').get();
      if (row2) mode = String(row2.journal_mode != null ? row2.journal_mode : Object.values(row2)[0] || '').toLowerCase();
    } catch (_) {}
  }
  if (mode === 'wal') {
    console.log('ℹ️  SQLite: journal_mode=WAL, busy_timeout=5000');
  } else {
    console.error('⚠ SQLite journal_mode="' + (mode || '?') + '" (очаквано wal). Проверете правата върху data\\.');
  }
} catch (e) {
  console.error('⚠ PRAGMA WAL/busy_timeout не успя:', e && e.message ? e.message : e);
}
db.exec(`
  CREATE TABLE IF NOT EXISTS kv (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS sessions (
    token     TEXT PRIMARY KEY,
    user_id   TEXT NOT NULL,
    username  TEXT NOT NULL,
    name      TEXT NOT NULL DEFAULT '',
    role      TEXT NOT NULL,
    expires_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS system_log (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    ts        INTEGER NOT NULL,
    level     TEXT NOT NULL DEFAULT 'info',
    category  TEXT NOT NULL DEFAULT 'system',
    message   TEXT NOT NULL,
    username  TEXT NOT NULL DEFAULT '',
    ip        TEXT NOT NULL DEFAULT '',
    meta      TEXT NOT NULL DEFAULT ''
  );
`);
try {
  db.exec('CREATE INDEX IF NOT EXISTS idx_system_log_ts ON system_log(ts DESC)');
  db.exec('CREATE INDEX IF NOT EXISTS idx_system_log_category ON system_log(category)');
} catch (e) {}






const stmtGet = db.prepare('SELECT value FROM kv WHERE key = ?');
const stmtUpsert = db.prepare(
  'INSERT INTO kv (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value'
);
const stmtDelete = db.prepare('DELETE FROM kv WHERE key = ?');
const stmtListPrefix = db.prepare('SELECT key, value FROM kv WHERE key LIKE ? ESCAPE \'\\\'');

const stmtSessionUpsert = db.prepare(
  `INSERT INTO sessions (token, user_id, username, name, role, expires_at)
   VALUES (?, ?, ?, ?, ?, ?)
   ON CONFLICT(token) DO UPDATE SET
     user_id = excluded.user_id,
     username = excluded.username,
     name = excluded.name,
     role = excluded.role,
     expires_at = excluded.expires_at`
);
const stmtSessionGet = db.prepare('SELECT token, user_id, username, name, role, expires_at FROM sessions WHERE token = ?');
const stmtSessionDelete = db.prepare('DELETE FROM sessions WHERE token = ?');
const stmtSessionDeleteExpired = db.prepare('DELETE FROM sessions WHERE expires_at IS NOT NULL AND expires_at <= ?');
const stmtSessionAll = db.prepare('SELECT token, user_id, username, name, role, expires_at FROM sessions');

const kvStore = createKvStore({ stmtGet, stmtUpsert, stmtDelete, stmtListPrefix });
const { kvGet, kvSet, kvDelete, kvListByPrefix, isSecretKvKey, kvReadAllowedForRole } = kvStore;

// ---- Миграция: „Чака материали“ → „Изчаква материали“ (еднократно) ----
(function migrateStatusIzchakraMateriali() {
  const OLD = 'Чака материали';
  const NEW = 'Изчаква материали';
  try {
    if (kvGet('system:migratedStatusIzchakra') === '1') return;
    let changed = 0;
    // settings:statusList
    try {
      const raw = kvGet('settings:statusList');
      if (raw) {
        const arr = JSON.parse(raw);
        if (Array.isArray(arr) && arr.some(s => s === OLD)) {
          kvSet('settings:statusList', JSON.stringify(arr.map(s => (s === OLD ? NEW : s))));
          changed++;
        }
      }
    } catch (_) {}
    // records
    try {
      const idxRaw = kvGet('records-index');
      const ids = idxRaw ? JSON.parse(idxRaw) : [];
      if (Array.isArray(ids)) {
        for (const id of ids) {
          const key = 'record:' + id;
          const raw = kvGet(key);
          if (!raw) continue;
          let rec;
          try { rec = JSON.parse(raw); } catch (_) { continue; }
          if (rec && rec.status === OLD) {
            rec.status = NEW;
            kvSet(key, JSON.stringify(rec));
            changed++;
          }
        }
      }
    } catch (_) {}
    kvSet('system:migratedStatusIzchakra', '1');
    if (changed) {
      try { console.log('ℹ️  Миграция статус → „Изчаква материали“: ' + changed + ' записа.'); } catch (_) {}
    }
  } catch (e) {
    try { console.error('Миграция статус не успя:', e && e.message); } catch (_) {}
  }
})();

const userSecurity = createUsersModule({ crypto, kvGet, kvSet, kvDelete });
const { hashPasswordPBKDF2, hashPasswordLegacySha256, safeEqualHex, verifyUserPassword, hashPasswordPBKDF2Async, verifyUserPasswordAsync, getUserIdsServer, getUserByIdServer, getAllUsersServer, getUserByUsernameServer, sanitizeObserverMenus, observerMenusForUser, saveUserServer, DEFAULT_OBSERVER_MENUS, getClientIp, checkLoginLock, registerLoginFailure, registerLoginSuccess, getLoginLockSnapshot } = userSecurity;

const warehouseModule = createWarehouseModule({ kvGet, kvSet, getUserByIdServer, getUserByUsernameServer });
const { ownStrukturaOf, normalizeStrukturaName, whRecordVisibleToUser, materialNameSetFromKv, migrateWhMaterialTypes } = warehouseModule;

function formatLocalDateTimeSeconds(d) {
  const dt = d instanceof Date ? d : (d ? new Date(d) : new Date());
  if (Number.isNaN(dt.getTime())) return String(d || '');
  const pad = (n) => String(n).padStart(2, '0');
  return pad(dt.getDate()) + '.' + pad(dt.getMonth() + 1) + '.' + dt.getFullYear() +
    ' ' + pad(dt.getHours()) + ':' + pad(dt.getMinutes()) + ':' + pad(dt.getSeconds());
}
let recordsModule = null;
const backupModule = createBackupModule({ fs, path, os, crypto, spawnSync, ROOT_DIR, DATA_DIR, DB_PATH, db, DatabaseSync, kvGet, kvListByPrefix, getRecordsIndexSafe: () => recordsModule ? recordsModule.getRecordsIndexSafe() : [], getUserIdsServer, APP_VERSION });
const { sha256File, copyDirRecursiveForBackup, snapshotDatabaseTo, verifyDatabaseFile, getBackupMetadata, writeBackupManifest, extractZipToDirForVerification, verifyBackupZip, createZipFromDirectory, createDownloadableBackup, cleanupOldServerFiles } = backupModule;
recordsModule = createRecordsModule({ db, kvGet, kvSet, kvDelete, formatLocalDateTimeSeconds, getUserByIdServer, getUserByUsernameServer, reportDatePartsServer, cleanupOldServerFiles });
const { withTransaction, parseJsonOrNull, getRecordServer, normalizeRecordInput, getNextRecordIdTx, advanceNextRecordId, getRecordsIndexSafe, createRecordServer, updateRecordServer, markRecordsSeenServer, deleteRecordServer, listRecordsServer, cleanupOrphanRecordsServer } = recordsModule;








// ---------- Начални примерни данни (само при съвсем първо стартиране) ----------
const SEED_DATA = [
  {"id":"1","datetime":"24.07.2025 11:56","korpus":"СТАЦИОНАР","etaz":"5","struktura":"ИКО","lokacia":"511","vid":"Крушка","zabelezka":"Над мивката","zayavitel":"Ангелова","status":"","dataIzp":"1900-08-20","izpalnitel":"","komentar":""},
  {"id":"2","datetime":"24.07.2025 12:11","korpus":"СТАЦИОНАР","etaz":"5","struktura":"ИКО","lokacia":"стая 523","vid":"Теч в банята","zabelezka":"До душ батерията","zayavitel":"Кунчева","status":"Изпълнена","dataIzp":"2025-06-10","izpalnitel":"Тодор Тодоров","komentar":""},
  {"id":"3","datetime":"24.07.2025 12:24","korpus":"СТАЦИОНАР","etaz":"5","struktura":"ИКО","lokacia":"532","vid":"Ремонт","zabelezka":"","zayavitel":"м.с. Бончева","status":"","dataIzp":"","izpalnitel":"","komentar":""},
  {"id":"4","datetime":"24.07.2025 12:25","korpus":"СТАЦИОНАР","etaz":"5","struktura":"ИКО","lokacia":"566","vid":"Счупен прозорец","zabelezka":"В стаята","zayavitel":"м.с. Йовчева","status":"Изчаква материали","dataIzp":"1912-07-01","izpalnitel":"Тодор Тодоров","komentar":""},
  {"id":"5","datetime":"24.07.2025 12:26","korpus":"СТАЦИОНАР","etaz":"5","struktura":"ИКО","lokacia":"стая 528","vid":"Преместване на мебели в мазата","zabelezka":"","zayavitel":"Кунчев","status":"Друго","dataIzp":"","izpalnitel":"Николай Радославов","komentar":""},
  {"id":"6","datetime":"24.07.2025 12:41","korpus":"СТАЦИОНАР","etaz":"5","struktura":"ИКО","lokacia":"543","vid":"rg","zabelezka":"cg","zayavitel":"gfh","status":"","dataIzp":"","izpalnitel":"","komentar":""},
  {"id":"7","datetime":"24.07.2025 14:41","korpus":"АДМИНИСТРАЦИЯ","etaz":"2","struktura":"АДМИНИСТРАЦИЯ","lokacia":"Деловодство","vid":"Балатум","zabelezka":"","zayavitel":"Янчева","status":"","dataIzp":"","izpalnitel":"","komentar":""}
];

if (kvGet('records-index') === null) {
  const ids = [];
  for (const rec of SEED_DATA) {
    kvSet('record:' + rec.id, JSON.stringify(rec));
    ids.push(rec.id);
  }
  kvSet('records-index', JSON.stringify(ids));
  console.log('ℹ️  Заредени са ' + ids.length + ' примерни начални заявки (само при първо стартиране).');
}

// ---------- Начален администраторски акаунт (само при съвсем първо стартиране) ----------
if (kvGet('users-index') === null) {
  const defaultSalt = crypto.randomBytes(16).toString('hex');
  const defaultPassword = crypto.randomBytes(12).toString('hex'); // случайна временна парола
  const defaultHash = crypto.createHash('sha256').update(defaultSalt + ':' + defaultPassword, 'utf8').digest('hex');
  const adminUser = {
    id: 'u_default_admin',
    username: 'admin',
    role: 'admin',
    salt: defaultSalt,
    passwordHash: defaultHash
  };
  kvSet('user:' + adminUser.id, JSON.stringify(adminUser));
  kvSet('users-index', JSON.stringify([adminUser.id]));
  // Пишем временните данни за вход във файл в data/, за да не ги показваме в конзолата
  try {
    const infoPath = path.join(DATA_DIR, 'initial_admin_credentials.txt');
    fs.writeFileSync(infoPath, `username: admin\npassword: ${defaultPassword}\nPlease change the password after first login.\n`, { encoding: 'utf8' });
    console.log('ℹ️  Създаден е начален администраторски акаунт (само при първо стартиране).');
    console.log('     Временните данни за вход са записани в: ' + infoPath);
    console.log('     Моля влезте и сменете паролата веднага.');
  } catch (e) {
    console.log('ℹ️  Създаден е начален администраторски акаунт (само при първо стартиране).');
    console.log('     Потребител: admin');
    console.log('     Парола:     ' + defaultPassword);
    console.log('     (Внимание: паролата е показана защото не можа да бъде записана в data/.)');
  }
}

// ---------------------- Автентикация (сървърна страна) ----------------------



// ---- Модул: верификация (server/verification.js) ----
const {
  initializeVerification,
  getLicenseContact,
  getVerificationState,
  checkVerificationCodeOnly,
  verifyProgramCode,
  changeVerificationCode,
  computeInstallFingerprint
} = require('./verification').createVerificationModule({
  kvGet,
  kvSet,
  ROOT_DIR,
  VERIFICATION_PERIOD_DAYS,
  VERIFICATION_WARNING_DAY,
  VERIFICATION_LOCK_DAY,
  VERIFICATION_INITIAL_CODE,
  hashPasswordPBKDF2,
  writeSystemLog: function () {
    // writeSystemLog се дефинира по-надолу; при първо извикване вече е налично
    return writeSystemLog.apply(null, arguments);
  }
});














/** Менюта, които админът може да включи за роля „Наблюдател“. */





// ---- Защита на чувствителни KV ключове (v1.1) ----
// /api/kv-list преди филтрираше по ТЪРСЕНИЯ префикс ("user...") вместо по
// върнатите ключове — заявка с prefix=u или prefix=us връщаше всички user:*
// записи (salt + хеш на парола) и system:verification:codeHash/codeSalt.



// Заявител/наблюдател вижда заявки за материали само на своята структура
// (същото правило вече важи за record:/records-index; тук липсваше за wh:).



// ---- Сесии: виж init след sendJSON (Фаза 2б) ----


const systemLogModule = createSystemLogModule({ db });
function writeSystemLog() {
  return systemLogModule.writeSystemLog.apply(null, arguments);
}
function getLastCrashLog(limit) {
  return systemLogModule.getLastCrashLog(limit);
}

// ---- Ограничаване на опитите за вход (защита от груба атака) ----





module.exports = {
  http, fs, path, os, crypto, spawn, spawnSync, URL, zlib,
  sendSmtpMail, createRecordsRoutes, createLoginBackgroundRoutes, createKvRoutes,
  createUsersModule, createUsersRoutes, createKvStore, createWarehouseModule,
  createRecordsModule, createHttpHelpers, createUpdateModule, createBackupModule,
  createRestartModule, createSystemRoutes, createMaintenanceMaterialsRoutes,
  createRequiredMaterialsRoutes, createAdminRoutes, createSystemLogModule,
  createMaterialsReportRoutes, reportDatePartsServer, reportRecordDateParts,
  parseRepairMaterialsServer, parseReportQuantityServer, formatReportQuantityServer,
  buildMaterialsReportServer, DatabaseSync,
  VERIFICATION_PERIOD_DAYS, VERIFICATION_WARNING_DAY, VERIFICATION_LOCK_DAY,
  VERIFICATION_INITIAL_CODE, PORT, LISTEN_HOST, SERVER_STARTED_AT, APP_VERSION,
  ROOT_DIR, PUBLIC_DIR, DATA_DIR, DB_PATH, PID_PATH, MAIL_SCRIPT_PATH,
  UI_VERSION, computeUiVersion, db,
  stmtGet, stmtUpsert, stmtDelete, stmtListPrefix, stmtSessionUpsert, stmtSessionGet,
  stmtSessionDelete, stmtSessionDeleteExpired, stmtSessionAll,
  kvStore, kvGet, kvSet, kvDelete, kvListByPrefix, isSecretKvKey, kvReadAllowedForRole,
  userSecurity, hashPasswordPBKDF2, hashPasswordLegacySha256, safeEqualHex,
  verifyUserPassword, hashPasswordPBKDF2Async, verifyUserPasswordAsync,
  getUserIdsServer, getUserByIdServer, getAllUsersServer, getUserByUsernameServer,
  sanitizeObserverMenus, observerMenusForUser, saveUserServer, DEFAULT_OBSERVER_MENUS,
  getClientIp, checkLoginLock, registerLoginFailure, registerLoginSuccess, getLoginLockSnapshot,
  warehouseModule, ownStrukturaOf, normalizeStrukturaName, whRecordVisibleToUser,
  materialNameSetFromKv, migrateWhMaterialTypes,
  recordsModule, withTransaction, parseJsonOrNull, getRecordServer, normalizeRecordInput,
  getNextRecordIdTx, advanceNextRecordId, getRecordsIndexSafe, createRecordServer,
  updateRecordServer, markRecordsSeenServer, deleteRecordServer, listRecordsServer,
  cleanupOrphanRecordsServer, backupModule, sha256File, copyDirRecursiveForBackup,
  snapshotDatabaseTo, verifyDatabaseFile, getBackupMetadata, writeBackupManifest,
  extractZipToDirForVerification, verifyBackupZip, createZipFromDirectory,
  createDownloadableBackup, cleanupOldServerFiles, systemLogModule, writeSystemLog, getLastCrashLog,
  initializeVerification, getLicenseContact, getVerificationState,
  checkVerificationCodeOnly, verifyProgramCode, changeVerificationCode,
  computeInstallFingerprint, formatLocalDateTimeSeconds
};
