/**
 * technicians-ui.js — app.js modularization phase 3
 * Табло техници.
 * Load AFTER app.js.
 */

let __techFilterMode = 'all';
let __techActiveCache = [];

function updateTechQuickChipsUI(counts) {
  const setTxt = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = String(v); };
  setTxt('techChipAll', counts.all);
  setTxt('techChipUrgent', counts.urgent);
  setTxt('techChipNotStarted', counts.notStarted);
  setTxt('techChipInProgress', counts.inProgress);
  setTxt('techChipDone', counts.done);
  const bar = document.getElementById('techQuickBar');
  if (bar) {
    bar.querySelectorAll('[data-tech-chip]').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-tech-chip') === __techFilterMode);
    });
  }
}

function renderTechRowsFromCache() {
  const tbody = document.getElementById('techTableBody');
  if (!tbody) return;
  const qEl = document.getElementById('techQuickSearch');
  const query = qEl ? qEl.value.trim().toLowerCase() : '';

  const filtered = __techActiveCache.filter(rec => {
    if (__techFilterMode === 'urgent' && !isUrgentActive(rec)) return false;
    if (__techFilterMode === 'notStarted' && rec.status === 'Изпълнява се') return false;
    if (__techFilterMode === 'inProgress' && rec.status !== 'Изпълнява се') return false;
    if (query) {
      const hay = [
        rec.id, rec.datetime, rec.lokacia, rec.vid, rec.korpus,
        rec.etaz, rec.struktura, rec.zayavitel, rec.status, rec.zabelezka
      ].map(v => String(v == null ? '' : v)).join(' ').toLowerCase();
      if (!hay.includes(query)) return false;
    }
    return true;
  });

  tbody.innerHTML = '';
  if (!filtered.length) {
    tbody.innerHTML = '<tr><td colspan="11" class="hint">Няма активни заявки по зададения филтър.</td></tr>';
    return;
  }

  const fragment = document.createDocumentFragment();
  filtered.forEach(rec => {
    const isUrgent = isUrgentActive(rec);
    const rowClass = isUrgent ? 'urgent-row' : '';
    const urgentBadge = isUrgent ? '<span class="urgent-badge">🚨</span>' : '';

    const tr = document.createElement('tr');
    tr.className = rowClass;
    const recIdStr = String(rec.id);
    const noteText = String(rec.zabelezka || '').trim();
    const noteShort = noteText.length > 120 ? (noteText.slice(0, 117) + '…') : noteText;
    tr.style.cursor = 'pointer';
    tr.title = 'Кликнете за преглед / редакция';
    tr.innerHTML = `
      <td data-label="ID">${urgentBadge}${escapeHtml(recIdStr)}</td>
      <td data-label="Дата">${escapeHtml(rec.datetime ? rec.datetime.split(' ')[0] : '')}</td>
      <td data-label="Час">${escapeHtml(rec.datetime ? rec.datetime.split(' ')[1] || '' : '')}</td>
      <td data-label="Локация">${escapeHtml(rec.lokacia)}</td>
      <td data-label="Вид ремонт">${escapeHtml(rec.vid)}</td>
      <td data-label="Корпус">${escapeHtml(rec.korpus)}</td>
      <td data-label="Етаж">${escapeHtml(rec.etaz)}</td>
      <td data-label="Структура">${escapeHtml(rec.struktura)}</td>
      <td data-label="Заявител">${escapeHtml(rec.zayavitel)}</td>
      <td data-label="Статус"><span class="status-badge ${statusClass(rec.status)}">${escapeHtml(rec.status || '—')}</span></td>
      <td data-label="Забележка" class="tech-note-cell" title="${escapeHtml(noteText)}">
        <span class="tech-note-text" style="display:inline-block;max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;vertical-align:middle;">${escapeHtml(noteShort || '—')}</span>
      </td>
    `;
    tr.addEventListener('click', function (e) {
      if (e.target && (e.target.closest && e.target.closest('button'))) return;
      openRecord(recIdStr);
    });
    fragment.appendChild(tr);
  });
  tbody.appendChild(fragment);
}

function parseTechDateParts(rawVal) {
  const raw = String(rawVal || '').trim();
  if (!raw) return null;
  const dmY = raw.match(/^(\d{1,2})\.(\d{1,2})\.(\d{4})/);
  if (dmY) {
    const m = Number(dmY[2]);
    const y = Number(dmY[3]);
    if (m >= 1 && m <= 12 && y >= 2000) return { year: y, month: m };
  }
  const iso = raw.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (iso) {
    const y = Number(iso[1]);
    const m = Number(iso[2]);
    if (m >= 1 && m <= 12 && y >= 2000) return { year: y, month: m };
  }
  const d = (typeof parseStamp === 'function' ? parseStamp(raw) : null) || new Date(raw);
  if (d && !isNaN(d.getTime())) {
    return { year: d.getFullYear(), month: d.getMonth() + 1 };
  }
  return null;
}

function isCompletedInCurrentMonth(rec, nowDate) {
  if (!rec || rec.status !== 'Изпълнена') return false;
  const now = nowDate || new Date();
  const curYear = now.getFullYear();
  const curMonth = now.getMonth() + 1;

  const rawDataIzp = String(rec.dataIzp || rec.data_izp || '').trim();
  if (rawDataIzp) {
    const p = parseTechDateParts(rawDataIzp);
    return !!(p && p.year === curYear && p.month === curMonth);
  }

  if (Array.isArray(rec.history) && rec.history.length) {
    for (let i = rec.history.length - 1; i >= 0; i--) {
      const h = rec.history[i];
      if (!h) continue;
      const p = parseTechDateParts(h.at || h.date || h.ts);
      if (p) return p.year === curYear && p.month === curMonth;
    }
  }

  const pDt = parseTechDateParts(rec.datetime);
  return !!(pDt && pDt.year === curYear && pDt.month === curMonth);
}

// ============================================================
//  РЕНДИРАНЕ НА ТАБЛО ЗА ТЕХНИЦИ
// ============================================================
async function renderTechniciansTable(opts) {
  // opts.softRefresh = true → без пълен invalidate (за авто-обновяване)
  const soft = !!(opts && opts.softRefresh);
  if (!soft) {
    invalidateRecordsCache();
  }

  const tbody = document.getElementById('techTableBody');
  if (!tbody) return;
  // При soft refresh НЕ чистим таблицата — избягва мигане
  if (!soft) {
    setContentLoading(tbody, '<tr><td colspan="11" class="hint">Зареждане...</td></tr>', false);
  } else {
    ensureDimLoadingStyle();
    tbody.classList.add('dim-loading');
    const lu = document.getElementById('techLastUpdate');
    if (lu) lu.textContent = 'Обновяване...';
  }

  const mySeq = (++__techRenderSeq);
  try {
    let recs = [];
    // Предпочитаме един batch API вместо N+1 заявки
    try {
      const r = await authFetch('/api/records?pageSize=500&page=1');
      if (r.ok) {
        const data = await r.json();
        if (data && Array.isArray(data.records)) {
          recs = data.records.slice();
          const totalPages = Math.min(20, Math.max(1, Number(data.pages) || 1));
          if (totalPages > 1) {
            const rest = [];
            for (let p = 2; p <= totalPages; p++) {
              rest.push(
                authFetch('/api/records?pageSize=500&page=' + p)
                  .then(rp => rp.ok ? rp.json() : null)
                  .then(dp => (dp && Array.isArray(dp.records) ? dp.records : []))
                  .catch(() => [])
              );
            }
            const extraBatches = await Promise.all(rest);
            extraBatches.forEach(batch => { recs = recs.concat(batch); });
          }
        }
      }
    } catch (_) {}
    if (!recs.length) {
      const idx = await getIndex();
      const fetched = await Promise.all((idx || []).map(id => getRecord(id).catch(() => null)));
      recs = fetched.filter(Boolean);
    }
    if (mySeq !== __techRenderSeq) return; // остарял soft refresh

    // Сортиране по дата (най-новите първи)
    recs.sort((a, b) => {
      const dateA = parseStamp(a.datetime) || new Date(0);
      const dateB = parseStamp(b.datetime) || new Date(0);
      return dateB - dateA;
    });

    if (!recs.length) {
      __techActiveCache = [];
      tbody.classList.remove('dim-loading');
      tbody.innerHTML = '<tr><td colspan="11" class="hint">Няма подадени заявки за ремонт.</td></tr>';
      document.getElementById('techNewCount').textContent = '0';
      document.getElementById('techInProgressCount').textContent = '0';
      document.getElementById('techDoneCount').textContent = '0';
      updateTechQuickChipsUI({ all: 0, urgent: 0, notStarted: 0, inProgress: 0, done: 0 });
      document.getElementById('techLastUpdate').textContent = 'Последно обновяване: ' + new Date().toLocaleTimeString('bg-BG');
      return;
    }

    let newCount = 0;
    let inProgressCount = 0;
    let notStartedCount = 0;
    let urgentCount = 0;
    let doneCount = 0;
    const nowForMonth = new Date();
    const unseenIds = [];
    const activeList = [];

    recs.forEach(rec => {
      const isUrgent = isUrgentActive(rec);
      const isUnresolved = !rec.status || rec.status === 'Не е изпълнена' || rec.status === 'Изпълнява се';
      const isDone = rec.status === 'Изпълнена';

      const isHiddenFromTech = !!rec.hiddenFromTech;
      if (!isHiddenFromTech && isUnresolved && !rec.seen) newCount++;
      if (!isHiddenFromTech && rec.status === 'Изпълнява се') inProgressCount++;
      if (isDone && isCompletedInCurrentMonth(rec, nowForMonth)) doneCount++;

      // Събираме невидени — маркираме с един batch заявки в края (не по една)
      if (!isHiddenFromTech && isUnresolved && !rec.seen) {
        unseenIds.push(String(rec.id));
        rec.seen = true; // локално за UI / броячи
      }

      if (isDone || rec.hiddenFromTech) return;
      if (isUrgent) urgentCount++;
      if (rec.status !== 'Изпълнява се') notStartedCount++;
      activeList.push(rec);
    });

    __techActiveCache = activeList;
    tbody.classList.remove('dim-loading');
    updateTechQuickChipsUI({
      all: activeList.length,
      urgent: urgentCount,
      notStarted: notStartedCount,
      inProgress: inProgressCount,
      done: doneCount
    });
    renderTechRowsFromCache();

    // Един batch към сървъра вместо N × saveRecord
    if (unseenIds.length) {
      markRecordsSeenBatch(unseenIds);
    }

    document.getElementById('techNewCount').textContent = newCount;
    document.getElementById('techInProgressCount').textContent = inProgressCount;
    document.getElementById('techDoneCount').textContent = doneCount;
    document.getElementById('techLastUpdate').textContent = 'Последно обновяване: ' + new Date().toLocaleTimeString('bg-BG');

  } catch (e) {
    console.error(e);
    tbody.classList.remove('dim-loading');
    tbody.innerHTML = '<tr><td colspan="11" class="hint">Грешка при зареждане на заявките.</td></tr>';
  }
}

document.getElementById('btnTechRefresh').addEventListener('click', function() {
  renderTechniciansTable();
});

const __techQuickBarEl = document.getElementById('techQuickBar');
if (__techQuickBarEl) {
  __techQuickBarEl.addEventListener('click', function (e) {
    const btn = e.target && e.target.closest ? e.target.closest('[data-tech-chip]') : null;
    if (!btn) return;
    __techFilterMode = btn.getAttribute('data-tech-chip') || 'all';
    __techQuickBarEl.querySelectorAll('[data-tech-chip]').forEach(el => {
      el.classList.toggle('active', el === btn);
    });
    renderTechRowsFromCache();
  });
}

const __techQuickSearchEl = document.getElementById('techQuickSearch');
if (__techQuickSearchEl) {
  let __techSearchDebounce = null;
  __techQuickSearchEl.addEventListener('input', function () {
    clearTimeout(__techSearchDebounce);
    __techSearchDebounce = setTimeout(renderTechRowsFromCache, 180);
  });
}

/* window exports */
try {
  if (typeof renderTechniciansTable==='function') window.renderTechniciansTable=renderTechniciansTable;
} catch(_){}
