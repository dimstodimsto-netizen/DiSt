const warehouseFilterState = AppState.bind(['__kvCache','__kvCacheLoaded']);
async function renderMonthlyPanel(opts) {
  const soft = (typeof isSoftRefreshOpts === 'function') ? isSoftRefreshOpts(opts) : !!(opts && opts.softRefresh);
  const tbody = document.getElementById('monthlyBody');
  if (!tbody) return;
  if (typeof setContentLoading === 'function') {
    setContentLoading(tbody, '<tr><td colspan="6" class="hint">Зареждане...</td></tr>', soft);
  } else if (!soft) {
    tbody.innerHTML = '<tr><td colspan="6" class="hint">Зареждане...</td></tr>';
  }

  const filterInput = document.getElementById('monthlyStrukturaFilter');
  if (filterInput) {
    if (currentRole !== 'admin' && currentUserStruktura) {
      filterInput.value = currentUserStruktura;
      filterInput.disabled = true;
      filterInput.style.background = 'var(--locked-bg)';
    } else {
      filterInput.disabled = false;
      filterInput.style.background = '';
    }
  }

  try {
    // Директно от API — без year/month параметри (филтрираме локално)
    const res = await authFetch('/api/records?page=1&pageSize=500');
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const data = await res.json();
    let recs = Array.isArray(data.records) ? data.records.slice() : [];
    const pages = Math.max(1, Number(data.pages) || 1);
    for (let p = 2; p <= pages && p <= 15; p++) {
      const r2 = await authFetch('/api/records?page=' + p + '&pageSize=500');
      if (!r2.ok) break;
      const d2 = await r2.json();
      (d2.records || []).forEach(function (rec) { recs.push(rec); });
    }

    // Кеш
    try {
      recs.forEach(function (rec) {
        if (rec && rec.id != null && typeof warehouseFilterState.__kvCache !== 'undefined') {
          warehouseFilterState.__kvCache.set('record:' + rec.id, JSON.stringify(rec));
        }
      });
      if (typeof warehouseFilterState.__kvCacheLoaded !== 'undefined') warehouseFilterState.__kvCacheLoaded = true;
    } catch (_) {}

    const now = new Date();
    const curY = now.getFullYear();
    const curM = now.getMonth(); // 0-11

    function recDate(r) {
      if (typeof parseStamp === 'function') {
        const d = parseStamp(r.datetime);
        if (d && !Number.isNaN(d.getTime())) return d;
      }
      // fallback DD.MM.YYYY
      const m = String(r.datetime || '').match(/^(\d{1,2})\.(\d{1,2})\.(\d{4})/);
      if (m) return new Date(Number(m[3]), Number(m[2]) - 1, Number(m[1]));
      return null;
    }

    let filtered = recs.filter(function (r) {
      const d = recDate(r);
      return d && d.getFullYear() === curY && d.getMonth() === curM;
    });

    const filter = filterInput ? String(filterInput.value || '').trim().toLowerCase() : '';
    if (filter) {
      filtered = filtered.filter(function (r) {
        return String(r.struktura || '').toLowerCase().indexOf(filter) !== -1;
      });
    }

    filtered.sort(function (a, b) {
      const da = recDate(a) || new Date(0);
      const db = recDate(b) || new Date(0);
      return db - da;
    });

    tbody.innerHTML = '';
    if (!filtered.length) {
      tbody.innerHTML = '<tr><td colspan="6" class="hint">Няма заявки за текущия месец' +
        (recs.length ? ' (общо от сървъра: ' + recs.length + ')' : '') + '.</td></tr>';
      return;
    }

    filtered.forEach(function (rec) {
      const isUrgent = typeof isUrgentActive === 'function' && isUrgentActive(rec);
      const tr = document.createElement('tr');
      if (isUrgent) tr.className = 'urgent-row';
      const badge = isUrgent ? '<span class="urgent-badge">🚨</span>' : '';
      const sc = typeof statusClass === 'function' ? statusClass(rec.status) : '';
      tr.innerHTML =
        '<td style="padding:6px 8px;">' + badge + escapeHtml(rec.id) + '</td>' +
        '<td style="padding:6px 8px;">' + escapeHtml(rec.datetime ? String(rec.datetime).split(' ')[0] : '') + '</td>' +
        '<td style="padding:6px 8px;">' + escapeHtml(rec.datetime ? (String(rec.datetime).split(' ')[1] || '') : '') + '</td>' +
        '<td style="padding:6px 8px;">' + escapeHtml(rec.lokacia || '') + '</td>' +
        '<td style="padding:6px 8px;">' + escapeHtml(rec.vid || '') + '</td>' +
        '<td style="padding:6px 8px;"><span class="status-badge ' + sc + '">' + escapeHtml(rec.status || '—') + '</span></td>';
      tr.style.cursor = 'pointer';
      tr.onclick = function () { if (typeof openRecord === 'function') openRecord(rec.id); };
      tbody.appendChild(tr);
    });
  } catch (e) {
    console.error('renderMonthlyPanel', e);
    tbody.innerHTML = '<tr><td colspan="6" class="hint">Грешка при зареждане: ' + escapeHtml(e.message || e) + '</td></tr>';
  }
}




// ============================================================
//  РЕНДИРАНЕ НА МОИТЕ ЗАЯВКИ
// ============================================================
async function renderMyRequests(opts) {
  const soft = (typeof isSoftRefreshOpts === 'function') ? isSoftRefreshOpts(opts) : !!(opts && opts.softRefresh);
  const tbody = document.getElementById('myRequestsBody');
  const info = document.getElementById('myRequestsInfo');
  if (!tbody) return;
  if (typeof setContentLoading === 'function') {
    setContentLoading(tbody, '<tr><td colspan="7" class="hint">Зареждане...</td></tr>', soft);
  } else if (!soft) {
    tbody.innerHTML = '<tr><td colspan="7" class="hint">Зареждане...</td></tr>';
  }

  try {
    const res = await authFetch('/api/records?page=1&pageSize=500');
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const data = await res.json();
    let all = Array.isArray(data.records) ? data.records.slice() : [];
    const pages = Math.max(1, Number(data.pages) || 1);
    for (let p = 2; p <= pages && p <= 15; p++) {
      const r2 = await authFetch('/api/records?page=' + p + '&pageSize=500');
      if (!r2.ok) break;
      const d2 = await r2.json();
      (d2.records || []).forEach(function (rec) { all.push(rec); });
    }

    try {
      all.forEach(function (rec) {
        if (rec && rec.id != null && typeof warehouseFilterState.__kvCache !== 'undefined') {
          warehouseFilterState.__kvCache.set('record:' + rec.id, JSON.stringify(rec));
        }
      });
      if (typeof warehouseFilterState.__kvCacheLoaded !== 'undefined') warehouseFilterState.__kvCacheLoaded = true;
    } catch (_) {}

    // Заявител: същата структура (сървърът вече филтрира; допълнително локално)
    if (currentRole === 'submitter' && currentUserStruktura) {
      const want = String(currentUserStruktura).trim().toLowerCase();
      all = all.filter(function (r) {
        return String(r.struktura || '').trim().toLowerCase() === want;
      });
    }

    function recDate(r) {
      if (typeof parseStamp === 'function') {
        const d = parseStamp(r.datetime);
        if (d && !Number.isNaN(d.getTime())) return d;
      }
      const m = String(r.datetime || '').match(/^(\d{1,2})\.(\d{1,2})\.(\d{4})/);
      if (m) return new Date(Number(m[3]), Number(m[2]) - 1, Number(m[1]));
      return null;
    }

    const years = Array.from(new Set(all.map(function (r) {
      const d = recDate(r);
      return d ? String(d.getFullYear()) : null;
    }).filter(Boolean))).sort();
    const godinaSel = document.getElementById('myReqFilterGodina');
    if (godinaSel) {
      const prevGodina = godinaSel.value;
      godinaSel.innerHTML = '<option value="">Всички</option>' +
        years.map(function (y) { return '<option value="' + y + '">' + y + '</option>'; }).join('');
      try { godinaSel.value = prevGodina; } catch (_) {}
    }

    const godina = godinaSel ? godinaSel.value : '';
    const mesecEl = document.getElementById('myReqFilterMesec');
    const mesec = mesecEl ? mesecEl.value : '';
    const dataFilterRaw = (document.getElementById('myReqFilterData') || {}).value || '';
    let filterY = 0, filterM = 0, filterD = 0;
    if (dataFilterRaw && String(dataFilterRaw).trim()) {
      let m = String(dataFilterRaw).trim().match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
      if (m) { filterD = Number(m[1]); filterM = Number(m[2]); filterY = Number(m[3]); }
      else {
        m = String(dataFilterRaw).trim().match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
        if (m) { filterY = Number(m[1]); filterM = Number(m[2]); filterD = Number(m[3]); }
      }
    }

    const recs = all.filter(function (r) {
      const d = recDate(r);
      if (!d) return false;
      if (godina && String(d.getFullYear()) !== godina) return false;
      if (mesec && String(d.getMonth() + 1) !== String(Number(mesec))) return false;
      if (filterY) {
        if (d.getFullYear() !== filterY || (d.getMonth() + 1) !== filterM || d.getDate() !== filterD) return false;
      }
      return true;
    });

    recs.sort(function (a, b) {
      return (recDate(b) || 0) - (recDate(a) || 0);
    });

    if (info) info.textContent = 'Показани: ' + recs.length + ' от ' + all.length;

    tbody.innerHTML = '';
    if (!recs.length) {
      tbody.innerHTML = '<tr><td colspan="7" class="hint">Няма заявки' +
        (all.length ? ' за избраните филтри (заредени: ' + all.length + ')' : '') + '.</td></tr>';
      return;
    }

    recs.forEach(function (rec) {
      const d = recDate(rec);
      const isUrgent = typeof isUrgentActive === 'function' && isUrgentActive(rec);
      const tr = document.createElement('tr');
      if (isUrgent) tr.className = 'urgent-row';
      const badge = isUrgent ? '<span class="urgent-badge">🚨</span>' : '';
      const sc = typeof statusClass === 'function' ? statusClass(rec.status) : '';
      tr.innerHTML =
        '<td data-label="ID" style="padding:6px 8px;">' + badge + escapeHtml(rec.id) + '</td>' +
        '<td data-label="Дата" style="padding:6px 8px;">' + escapeHtml(d ? (String(d.getDate()).padStart(2,'0') + '.' + String(d.getMonth()+1).padStart(2,'0') + '.' + d.getFullYear()) : (rec.datetime || '')) + '</td>' +
        '<td data-label="Час" style="padding:6px 8px;">' + escapeHtml(rec.datetime && String(rec.datetime).split(' ')[1] ? String(rec.datetime).split(' ')[1] : '') + '</td>' +
        '<td data-label="Структура" style="padding:6px 8px;">' + escapeHtml(rec.struktura || '') + '</td>' +
        '<td data-label="Локация" style="padding:6px 8px;">' + escapeHtml(rec.lokacia || '') + '</td>' +
        '<td data-label="Вид" style="padding:6px 8px;">' + escapeHtml(rec.vid || '') + '</td>' +
        '<td data-label="Статус" style="padding:6px 8px;"><span class="status-badge ' + sc + '">' + escapeHtml(rec.status || '—') + '</span></td>';
      tr.style.cursor = 'pointer';
      tr.onclick = function () { if (typeof openRecord === 'function') openRecord(rec.id); };
      tbody.appendChild(tr);
    });
  } catch (e) {
    console.error('renderMyRequests', e);
    tbody.innerHTML = '<tr><td colspan="7" class="hint">Грешка: ' + escapeHtml(e.message || e) + '</td></tr>';
  }
}



['myReqFilterGodina','myReqFilterMesec'].forEach(id => {
  const el = document.getElementById(id);
  if (el) el.addEventListener('change', () => renderMyRequests());
});

var __myReqCal = { y: 0, m: 0 };
function closeMyReqFilterCal() {
  const pop = document.getElementById('myReqFilterCalPop');
  if (pop) pop.style.display = 'none';
}
function setMyReqFilterDate(ddmmYYYY) {
  const hidden = document.getElementById('myReqFilterData');
  const label = document.getElementById('myReqFilterDataLabel');
  if (hidden) hidden.value = ddmmYYYY || '';
  if (label) {
    label.textContent = ddmmYYYY || 'дд.мм.гггг';
    label.style.color = ddmmYYYY ? 'var(--ink)' : 'var(--ink-soft)';
  }
}
function renderMyReqFilterCal() {
  const title = document.getElementById('myReqCalTitle');
  const days = document.getElementById('myReqCalDays');
  if (!title || !days) return;
  const months = ['Януари','Февруари','Март','Април','Май','Юни','Юли','Август','Септември','Октомври','Ноември','Декември'];
  const y = __myReqCal.y, m = __myReqCal.m;
  title.textContent = months[m] + ' ' + y;
  const first = new Date(y, m, 1);
  let startPad = first.getDay() - 1;
  if (startPad < 0) startPad = 6;
  const dim = new Date(y, m + 1, 0).getDate();
  const selected = (typeof dataIzpToParts === 'function')
    ? dataIzpToParts((document.getElementById('myReqFilterData') || {}).value)
    : null;
  const today = new Date();
  days.innerHTML = '';
  for (let i = 0; i < startPad; i++) {
    const cell = document.createElement('div');
    cell.style.cssText = 'height:32px;';
    days.appendChild(cell);
  }
  for (let d = 1; d <= dim; d++) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.textContent = String(d);
    const isSel = selected && selected.yyyy === y && selected.mm === (m + 1) && selected.dd === d;
    const isToday = today.getFullYear() === y && today.getMonth() === m && today.getDate() === d;
    btn.style.cssText = 'height:32px;border:1px solid ' + (isSel ? 'var(--accent,#2f6fed)' : 'transparent') +
      ';border-radius:6px;background:' + (isSel ? 'var(--accent-soft,#e8f0fe)' : (isToday ? '#f3f6f9' : 'transparent')) +
      ';cursor:pointer;font-size:13px;font-weight:' + (isSel || isToday ? '700' : '500') + ';color:var(--ink,#222);';
    btn.addEventListener('click', function() {
      const val = String(d).padStart(2,'0') + '.' + String(m + 1).padStart(2,'0') + '.' + y;
      setMyReqFilterDate(val);
      closeMyReqFilterCal();
      renderMyRequests();
    });
    days.appendChild(btn);
  }
}
function openMyReqFilterCal() {
  const pop = document.getElementById('myReqFilterCalPop');
  if (!pop) return;
  const parts = (typeof dataIzpToParts === 'function')
    ? dataIzpToParts((document.getElementById('myReqFilterData') || {}).value)
    : null;
  const now = new Date();
  __myReqCal.y = parts ? parts.yyyy : now.getFullYear();
  __myReqCal.m = parts ? (parts.mm - 1) : now.getMonth();
  renderMyReqFilterCal();
  pop.style.display = 'block';
}
(function wireMyReqDateFilter() {
  const btn = document.getElementById('btnMyReqFilterData');
  const pop = document.getElementById('myReqFilterCalPop');
  if (!btn || !pop || btn._myReqCalWired) return;
  btn._myReqCalWired = true;
  btn.addEventListener('click', function(e) {
    e.preventDefault();
    e.stopPropagation();
    if (pop.style.display === 'block') closeMyReqFilterCal();
    else openMyReqFilterCal();
  });
  const prev = document.getElementById('myReqCalPrev');
  const next = document.getElementById('myReqCalNext');
  const todayBtn = document.getElementById('myReqCalToday');
  const clearBtn = document.getElementById('myReqCalClear');
  if (prev) prev.addEventListener('click', function(e) {
    e.preventDefault(); e.stopPropagation();
    __myReqCal.m -= 1;
    if (__myReqCal.m < 0) { __myReqCal.m = 11; __myReqCal.y -= 1; }
    renderMyReqFilterCal();
  });
  if (next) next.addEventListener('click', function(e) {
    e.preventDefault(); e.stopPropagation();
    __myReqCal.m += 1;
    if (__myReqCal.m > 11) { __myReqCal.m = 0; __myReqCal.y += 1; }
    renderMyReqFilterCal();
  });
  if (todayBtn) todayBtn.addEventListener('click', function(e) {
    e.preventDefault(); e.stopPropagation();
    const n = new Date();
    const val = String(n.getDate()).padStart(2,'0') + '.' + String(n.getMonth()+1).padStart(2,'0') + '.' + n.getFullYear();
    setMyReqFilterDate(val);
    closeMyReqFilterCal();
    renderMyRequests();
  });
  if (clearBtn) clearBtn.addEventListener('click', function(e) {
    e.preventDefault(); e.stopPropagation();
    setMyReqFilterDate('');
    closeMyReqFilterCal();
    renderMyRequests();
  });
  document.addEventListener('click', function(e) {
    if (!pop || pop.style.display !== 'block') return;
    if (pop.contains(e.target) || btn.contains(e.target)) return;
    closeMyReqFilterCal();
  });
})();

document.getElementById('btnMyReqClearFilters').addEventListener('click', () => {
  document.getElementById('myReqFilterGodina').value = '';
  document.getElementById('myReqFilterMesec').value = '';
  setMyReqFilterDate('');
  closeMyReqFilterCal();
  renderMyRequests();
});

// ============================================================
//  РЕНДИРАНЕ НА ЗАЯВКИ ЗА САНитарНИ МАТЕРИАЛИ (СКЛАД)
// ============================================================
// Състояние на филтрите за двата специализирани списъка в Склад.
const warehouseRequestFilters = {
  sanitary: { godina: '', mesec: '', struktura: '', status: '' },
  office:   { godina: '', mesec: '', struktura: '', status: '' }
};

function populateWarehouseRequestFilters(type, records) {
  const prefix = type === 'sanitary' ? 'whSanitary' : 'whOffice';
  const state = warehouseRequestFilters[type];
  const years = [...new Set(records.map(r => String(r.godina || '').trim()).filter(Boolean))]
    .sort((a, b) => Number(b) - Number(a));
  const structures = [...new Set(records.map(r => String(r.struktura || '').trim()).filter(Boolean))]
    .sort((a, b) => a.localeCompare(b, 'bg'));

  const yearEl = document.getElementById(prefix + 'FilterGodina');
  const monthEl = document.getElementById(prefix + 'FilterMesec');
  const structureEl = document.getElementById(prefix + 'FilterStruktura');
  const statusEl = document.getElementById(prefix + 'FilterStatus');

  const fill = (el, options, firstText) => {
    const current = el.value;
    el.innerHTML = '<option value="">' + firstText + '</option>' +
      options.map(o => '<option value="' + escapeHtml(o.value) + '">' + escapeHtml(o.text) + '</option>').join('');
    if (options.some(o => o.value === current)) el.value = current;
  };

  fill(yearEl, years.map(y => ({ value: y, text: y })), 'Всички години');
  fill(monthEl, WH_MONTH_NAMES.slice(1).map((name, i) => ({ value: String(i + 1), text: name })), 'Всички месеци');
  fill(structureEl, structures.map(s => ({ value: s, text: s })), 'Всички структури');

  // Ако избрана стойност вече не съществува, връщаме филтъра към „всички“.
  if (yearEl.value !== state.godina) yearEl.value = state.godina && years.includes(state.godina) ? state.godina : '';
  if (monthEl.value !== state.mesec) monthEl.value = state.mesec || '';
  if (structureEl.value !== state.struktura) structureEl.value = state.struktura && structures.includes(state.struktura) ? state.struktura : '';
  statusEl.value = state.status || '';
}

function filterWarehouseRequestRecords(records, type) {
  const f = warehouseRequestFilters[type];
  return records.filter(rec => {
    if (f.godina && String(rec.godina || '') !== f.godina) return false;
    if (f.mesec && String(parseInt(rec.mesec, 10)) !== String(parseInt(f.mesec, 10))) return false;
    if (f.struktura && String(rec.struktura || '') !== f.struktura) return false;
    if (f.status && String(rec.status || '') !== f.status) return false;
    return true;
  });
}

function updateWarehouseQuickChipsUI(type, records) {
  const prefix = type === 'sanitary' ? 'whSanitary' : 'whOffice';
  const f = warehouseRequestFilters[type];
  const base = (records || []).filter(rec => {
    if (f.godina && String(rec.godina || '') !== f.godina) return false;
    if (f.mesec && String(parseInt(rec.mesec, 10)) !== String(parseInt(f.mesec, 10))) return false;
    if (f.struktura && String(rec.struktura || '') !== f.struktura) return false;
    return true;
  });
  let pending = 0, done = 0;
  base.forEach(rec => {
    if (rec.status === 'izpalnena' || rec.status === 'Изпълнена') done++;
    else pending++;
  });
  const setTxt = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = String(val); };
  setTxt(prefix + 'ChipAll', base.length);
  setTxt(prefix + 'ChipPending', pending);
  setTxt(prefix + 'ChipDone', done);
  const bar = document.getElementById(prefix + 'QuickBar');
  if (bar) {
    bar.querySelectorAll('[data-wh-status]').forEach(btn => {
      btn.classList.toggle('active', (btn.getAttribute('data-wh-status') || '') === (f.status || ''));
    });
  }
}

function bindWarehouseRequestFilters(type) {
  const prefix = type === 'sanitary' ? 'whSanitary' : 'whOffice';
  const state = warehouseRequestFilters[type];
  [
    ['Godina', 'godina'],
    ['Mesec', 'mesec'],
    ['Struktura', 'struktura'],
    ['Status', 'status']
  ].forEach(([suffix, key]) => {
    const el = document.getElementById(prefix + 'Filter' + suffix);
    if (!el || el.dataset.whFilterBound === '1') return;
    el.dataset.whFilterBound = '1';
    el.addEventListener('change', () => {
      state[key] = el.value;
      // Филтрирането е изцяло локално върху кешираните заявки.
      if (type === 'sanitary') renderWarehouseSanitaryTable({ fromFilter: true });
      else renderWarehouseOfficeTable({ fromFilter: true });
    });
  });

  const quickBar = document.getElementById(prefix + 'QuickBar');
  if (quickBar && quickBar.dataset.whFilterBound !== '1') {
    quickBar.dataset.whFilterBound = '1';
    quickBar.addEventListener('click', (e) => {
      const btn = e.target && e.target.closest ? e.target.closest('[data-wh-status]') : null;
      if (!btn) return;
      state.status = btn.getAttribute('data-wh-status') || '';
      const statusSel = document.getElementById(prefix + 'FilterStatus');
      if (statusSel) statusSel.value = state.status;
      if (type === 'sanitary') renderWarehouseSanitaryTable({ fromFilter: true });
      else renderWarehouseOfficeTable({ fromFilter: true });
    });
  }

  const clearBtn = document.getElementById(type === 'sanitary' ? 'btnClearWhSanitaryFilters' : 'btnClearWhOfficeFilters');
  if (clearBtn && clearBtn.dataset.whFilterBound !== '1') {
    clearBtn.dataset.whFilterBound = '1';
    clearBtn.addEventListener('click', () => {
      state.godina = '';
      state.mesec = '';
      state.struktura = '';
      state.status = '';
      ['Godina','Mesec','Struktura','Status'].forEach(suffix => {
        const el = document.getElementById(prefix + 'Filter' + suffix);
        if (el) el.value = '';
      });
      if (type === 'sanitary') renderWarehouseSanitaryTable({ fromFilter: true });
      else renderWarehouseOfficeTable({ fromFilter: true });
    });
  }
}

// ============================================================
//  РЕНДИРАНЕ НА ЗАЯВКИ ЗА САНитарНИ МАТЕРИАЛИ (СКЛАД)
// ============================================================
