/**
 * role-auth-ui.js — app.js modularization step D
 * Роли, табове по роля, applyRoleUI, login/logout.
 * Load AFTER app.js and session-auth.js (uses session helpers, CURRENT_USER_KEY, switchTab, …).
 */
const roleAuthState = AppState.bind(['currentRole','currentUsername','currentUserFullName','currentUserStruktura','currentUserStrukturaLocked','currentUserKorpus','currentUserEtazhi','currentUserAllowedMenus','pendingRoleType','authToken','sessionExpiresAt','sessionExpiryTimer','techAutoRefresh']);


// ---- Роли и табове ----
function tabsForRole(role, allowedMenus) {
  if (role === 'submitter') return ['submit','myRequests','myMaterials','warehouse'];
  if (role === 'observer') return normalizeObserverMenus(allowedMenus != null ? allowedMenus : roleAuthState.currentUserAllowedMenus);
  if (role === 'technician') return ['technicians','objects','requiredMaterials'];
  if (role === 'warehouse') return ['warehouseSanitaryRequests','warehouseOfficeRequests','sanitaryMaterialsList','officeMaterialsList'];
  if (role === 'admin') return ['submit','search','all','materialsReport','whMaterialsReport','technicians','objects','warehouse','warehouseSanitaryRequests','warehouseOfficeRequests','sanitaryMaterialsList','officeMaterialsList','server','users','logs','agent','materialLocks','maintenanceMaterials','requiredMaterials'];
  return [];
}

function applyStrukturaLockUI() {
  const sel = document.getElementById('sStruktura');
  const other = document.getElementById('sStrukturaOther');
  if (!sel || !other) return;
  const roleLocks = (roleAuthState.currentRole === 'submitter' || roleAuthState.currentRole === 'observer');
  const locked = roleLocks && (roleAuthState.currentUserStrukturaLocked !== false);
  const hint = document.getElementById('sStrukturaLockHint');
  sel.disabled = locked;
  other.disabled = locked;
  sel.style.background = locked ? 'var(--locked-bg)' : '';
  other.style.background = locked ? 'var(--locked-bg)' : '';
  sel.title = locked ? 'Структурата е зададена от потребителския профил.' : '';
  if (hint) {
    hint.style.display = locked ? '' : 'none';
    hint.textContent = locked ? 'Структурата е заключена от профила.' : '';
  }
}

function applyUserKorpusEtazUI() {
  const korpusSel = document.getElementById('sKorpus');
  const korpusOther = document.getElementById('sKorpusOther');
  if (korpusSel) {
    const hasKorpus = !!(roleAuthState.currentUserKorpus && String(roleAuthState.currentUserKorpus).trim());
    if (hasKorpus) {
      setSelectValueWithFallback($('sKorpus'), $('sKorpusOther'), String(roleAuthState.currentUserKorpus).trim());
      korpusSel.disabled = true;
      if (korpusOther) { korpusOther.disabled = true; korpusOther.style.background = 'var(--locked-bg)'; }
      korpusSel.style.background = 'var(--locked-bg)';
      korpusSel.title = 'Корпусът е зададен от потребителския профил.';
    } else {
      korpusSel.disabled = false;
      if (korpusOther) { korpusOther.disabled = false; korpusOther.style.background = ''; }
      korpusSel.style.background = '';
      korpusSel.title = '';
    }
  }
  const etazEl0 = document.getElementById('sEtaz');
  if (etazEl0) {
    const floors = Array.isArray(roleAuthState.currentUserEtazhi) ? roleAuthState.currentUserEtazhi.filter(Boolean) : [];
    if (floors.length) {
      if (etazEl0.tagName === 'INPUT') {
        const sel = document.createElement('select');
        sel.id = 'sEtaz';
        etazEl0.parentNode.replaceChild(sel, etazEl0);
      }
      const sel = document.getElementById('sEtaz');
      if (sel && sel.tagName === 'SELECT') {
        const cur = sel.value;
        sel.innerHTML = '<option value="">— изберете —</option>' +
          floors.map(function (f) {
            return '<option value="' + escapeHtml(f) + '">' + escapeHtml(f) + '</option>';
          }).join('');
        if (floors.length === 1) {
          sel.value = floors[0];
          sel.disabled = true;
          sel.style.background = 'var(--locked-bg)';
          sel.title = 'Етажът е зададен от потребителския профил.';
        } else {
          sel.disabled = false;
          sel.style.background = '';
          sel.title = '';
          if (cur && floors.indexOf(cur) >= 0) sel.value = cur;
        }
      }
    } else {
      let el = document.getElementById('sEtaz');
      if (el && el.tagName === 'SELECT') {
        const inp = document.createElement('input');
        inp.type = 'text';
        inp.id = 'sEtaz';
        el.parentNode.replaceChild(inp, el);
        el = inp;
      }
      if (el) {
        el.disabled = false;
        el.style.background = '';
        el.title = '';
      }
    }
  }
}

function applyRoleUI(role, username, fullName, struktura, allowedMenus, profileOpts) {
  const navigationIdentityChanged = roleAuthState.currentRole !== role || roleAuthState.currentUsername !== username;
  if (navigationIdentityChanged) resetMenuNavigationHistory();
  roleAuthState.currentRole = role;
  roleAuthState.currentUsername = username;
  roleAuthState.currentUserFullName = fullName || '';
  roleAuthState.currentUserStruktura = struktura || '';
  profileOpts = profileOpts || {};
  if (Object.prototype.hasOwnProperty.call(profileOpts, 'strukturaLocked')) {
    roleAuthState.currentUserStrukturaLocked = !(profileOpts.strukturaLocked === false || profileOpts.strukturaLocked === 0 || profileOpts.strukturaLocked === '0' || profileOpts.strukturaLocked === 'false');
  } else if (profileOpts && (profileOpts.korpus || (profileOpts.etazhi && profileOpts.etazhi.length))) {
    roleAuthState.currentUserStrukturaLocked = true;
  }
  // иначе запазваме предишната стойност на roleAuthState.currentUserStrukturaLocked
  if (Object.prototype.hasOwnProperty.call(profileOpts, 'korpus')) {
    roleAuthState.currentUserKorpus = profileOpts.korpus ? String(profileOpts.korpus) : '';
  }
  if (Object.prototype.hasOwnProperty.call(profileOpts, 'etazhi')) {
    roleAuthState.currentUserEtazhi = Array.isArray(profileOpts.etazhi) ? profileOpts.etazhi.map(String).filter(Boolean) : [];
  }
  if (role === 'observer') {
    roleAuthState.currentUserAllowedMenus = normalizeObserverMenus(allowedMenus);
  } else {
    roleAuthState.currentUserAllowedMenus = null;
  }
  
  const zEl = document.getElementById('sZayavitel');
  if (zEl) zEl.value = roleAuthState.currentUserFullName;
  
  // АВТОМАТИЧНО ПОПЪЛВАНЕ НА СТРУКТУРАТА
  if (roleAuthState.currentUserStruktura && document.getElementById('sStruktura')) {
    setSelectValueWithFallback($('sStruktura'), $('sStrukturaOther'), roleAuthState.currentUserStruktura);
  }
  applyStrukturaLockUI();
  applyUserKorpusEtazUI();
  
  const allowed = tabsForRole(role);
  document.getElementById('tabSubmit').style.display = allowed.includes('submit') ? '' : 'none';
  document.getElementById('tabMyRequests').style.display = allowed.includes('myRequests') ? '' : 'none';
  document.getElementById('tabMyMaterials').style.display = allowed.includes('myMaterials') ? '' : 'none';
  document.getElementById('tabRequiredMaterials').style.display = allowed.includes('requiredMaterials') ? '' : 'none';
  document.getElementById('tabSearch').style.display = allowed.includes('search') ? '' : 'none';
  document.getElementById('tabAll').style.display = allowed.includes('all') ? '' : 'none';
  document.getElementById('tabMaterialsReport').style.display = allowed.includes('materialsReport') ? '' : 'none';
  document.getElementById('tabTechnicians').style.display = allowed.includes('technicians') ? '' : 'none';
  const objectsDropdown = document.getElementById('tabObjectsDropdown');
  if (objectsDropdown) objectsDropdown.style.display = allowed.includes('objects') ? '' : 'none';
  // Show warehouse dropdown only for roles that can submit warehouse requests
  document.getElementById('tabWarehouseDropdown').style.display = (role === 'submitter' || role === 'admin' || (role === 'observer' && allowed.includes('warehouse'))) ? '' : 'none';
  // materialsList вече не се използва за администратор - само специализираните списъци
  document.getElementById('tabMaterialsList').style.display = 'none';
  // Групирани склад табове в падащо „Склад — управление“ — САМО за администратор.
  // За другите роли (Склад, Наблюдател) същите табове се връщат в основния ред
  // като плоски бутони — за тях това са единствените/основните им табове и не
  // трябва да се крият зад допълнително кликане.
  const whMgmtKeys = ['warehouseSanitaryRequests','warehouseOfficeRequests','sanitaryMaterialsList','officeMaterialsList','whMaterialsReport'];
  const whMgmtIds = ['tabWarehouseSanitaryRequests','tabWarehouseOfficeRequests','tabSanitaryMaterialsList','tabOfficeMaterialsList','tabWhMaterialsReport'];
  const itemVis = {
    tabWarehouseSanitaryRequests: 'warehouseSanitaryRequests',
    tabWarehouseOfficeRequests: 'warehouseOfficeRequests',
    tabSanitaryMaterialsList: 'sanitaryMaterialsList',
    tabOfficeMaterialsList: 'officeMaterialsList',
    tabWhMaterialsReport: 'whMaterialsReport'
  };
  const whMgmtDrop = document.getElementById('tabWarehouseMgmtDropdown');
  const whMgmtContent = document.getElementById('warehouseMgmtDropdownContent');
  const mainTabsEl = document.getElementById('mainTabs');
  const useWhDropdown = (role === 'admin');
  if (whMgmtDrop) whMgmtDrop.style.display = (useWhDropdown && whMgmtKeys.some(k => allowed.includes(k))) ? '' : 'none';
  whMgmtIds.forEach(function (id) {
    const el = document.getElementById(id);
    if (!el) return;
    if (useWhDropdown) {
      if (whMgmtContent && el.parentElement !== whMgmtContent) {
        el.classList.remove('tab');
        el.classList.add('dropdown-item');
        whMgmtContent.appendChild(el);
      }
    } else if (mainTabsEl && whMgmtDrop && el.parentElement !== mainTabsEl) {
      el.classList.remove('dropdown-item');
      el.classList.add('tab');
      mainTabsEl.insertBefore(el, whMgmtDrop);
    }
    el.style.display = allowed.includes(itemVis[id]) ? '' : 'none';
  });
  try {
    const obsRO = (role === 'observer');
    ['btnAddSanitaryMaterial','btnImportSanitaryMaterials','btnTemplateSanitaryMaterials',
     'btnAddOfficeMaterial','btnImportOfficeMaterials','btnTemplateOfficeMaterials',
     'newSanitaryMaterialCode','newSanitaryMaterialName','newSanitaryMaterialMerka',
     'newOfficeMaterialCode','newOfficeMaterialName','newOfficeMaterialMerka'].forEach(function (id) {
      const el = document.getElementById(id);
      if (!el) return;
      if (obsRO) {
        el.style.display = 'none';
        if (el.tagName === 'INPUT') el.disabled = true;
      } else {
        el.style.display = '';
        if (el.tagName === 'INPUT') el.disabled = false;
      }
    });
    [document.getElementById('sanitaryMaterialsListCard'), document.getElementById('officeMaterialsListCard')].forEach(function (card) {
      if (!card) return;
      const rows = card.querySelectorAll(':scope > div[style*="display:flex"]');
      rows.forEach(function (row, i) { if (i < 2) row.style.display = obsRO ? 'none' : 'flex'; });
    });
  } catch (_) {}

  document.getElementById('btnNewObject').style.display = role === 'admin' ? '' : 'none';
  document.getElementById('objectExportWrap').style.display = role === 'admin' ? '' : 'none';
  document.getElementById('tabServer').style.display = allowed.includes('server') ? '' : 'none';
  document.getElementById('tabUsers').style.display = allowed.includes('users') ? '' : 'none';
  const tabLogsBtn = document.getElementById('tabLogs');
  if (tabLogsBtn) tabLogsBtn.style.display = allowed.includes('logs') ? '' : 'none';
  const tabAgentBtn = document.getElementById('tabAgent');
  if (tabAgentBtn) tabAgentBtn.style.display = allowed.includes('agent') ? '' : 'none';
  const adminDrop = document.getElementById('tabAdminDropdown');
  if (adminDrop) adminDrop.style.display = (role === 'admin') ? '' : 'none';
  document.getElementById('roleBadge').textContent = (username ? username + ' — ' : '') + (ROLE_NAMES[role] || '') + (struktura ? ' (' + struktura + ')' : '');
  if (role === 'admin') {
    try { window.checkUncleanShutdownBanner(); } catch (_) {}
    try {
      // Сутрешен / дневен преглед: всичко наред или 1–2 предупреждения
      if (typeof window.maybeShowAgentMorningDigest === 'function') {
        setTimeout(function () { window.maybeShowAgentMorningDigest(); }, 400);
      }
    } catch (_) {}
  }
  else { const ub = document.getElementById('uncleanShutdownBanner'); if (ub) ub.style.display = 'none'; }
  if (isShortSessionRole(role)) {
    installSubmitterActivityListeners();
    startSessionCountdownTicker();
  } else {
    stopSessionCountdownTicker();
  }
  try { startHeartbeat(); } catch (_) {}

  // Standalone режим (?openRecord= в URL): подготвяме UI преди показване.
  const pendingOpenId = (typeof URLSearchParams !== 'undefined')
    ? new URLSearchParams(location.search).get('openRecord')
    : null;
  if (pendingOpenId && !inPlaceRecordView) {
    standaloneRecordMode = true;
    document.getElementById('mainTabs').style.display = 'none';
    document.getElementById('appHeader').style.display = 'none';
    const aw = document.getElementById('appWrap');
    if (aw) aw.classList.remove('has-sidebar');
    document.querySelectorAll('#appWrap > .card').forEach(card => {
      if (card.id !== 'recordCard') card.style.display = 'none';
    });
  } else if (!inPlaceRecordView) {
    // Нормален режим — гарантираме, че хедърът и табовете са видими
    // (след in-place преглед на заявка може да са били скрити).
    try {
      const mainTabs = document.getElementById('mainTabs');
      if (mainTabs) mainTabs.style.display = '';
      const appHeader = document.getElementById('appHeader');
      if (appHeader) appHeader.style.display = '';
      const aw = document.getElementById('appWrap');
      const useSidebar = (role === 'admin' || role === 'technician' || role === 'warehouse' || (role === 'observer' && allowed.length >= 5));
      if (aw) aw.classList.toggle('has-sidebar', !!useSidebar);
    } catch (_) {}
  }

  try { document.body.dataset.role = role || ''; } catch (_) {}
  const loginInfoPanel = document.getElementById('loginInfoPanel');
  if (loginInfoPanel) loginInfoPanel.style.display = 'none';
  document.getElementById('roleGate').style.display = 'none';
  try { document.documentElement.classList.remove('standalone-open'); } catch (_) {}
  refreshVerificationStatus();
  document.getElementById('appWrap').style.display = '';
  
  // Hide session-expired banner if present
  const sb = document.getElementById('sessionExpiredBanner');
  if (sb) sb.style.display = 'none';
  
  getAudioCtx();
  checkUnseenRequests();

  if (pendingOpenId && !inPlaceRecordView) {
    document.title = 'Заявка #' + pendingOpenId + ' — DiSt';
  } else if (!inPlaceRecordView) {
    switchTab(allowed[0], { historyMode: navigationIdentityChanged ? 'push' : 'replace' });
  }
  
  // Зареждане на фонова снимка след успешен логин
  loadLoginBackground();
}

async function logoutRole() {
  stopHeartbeat();
  stopSessionCountdownTicker();
  const tokenToLogout = loadSessionToken();
  let logoutResponse = null;
  if (tokenToLogout || roleAuthState.authToken) {
    try {
      const headers = { 'Content-Type': 'application/json' };
      if (tokenToLogout && tokenToLogout !== 'cookie-session') headers['Authorization'] = 'Bearer ' + tokenToLogout;
      logoutResponse = await fetch('/api/auth/logout', {
        method: 'POST', headers: headers, body: '{}', credentials: 'same-origin',
        keepalive: true, cache: 'no-store'
      });
    } catch (_) {}
  }

  clearAllClientSideAuthData();
  try { localStorage.clear(); } catch (_) {}
  try { sessionStorage.clear(); } catch (_) {}
  roleAuthState.currentRole = null;
  roleAuthState.currentUsername = null;
  resetMenuNavigationHistory();
  roleAuthState.currentUserFullName = null;
  roleAuthState.currentUserStruktura = null;
  roleAuthState.pendingRoleType = null;
  stopAlertSound();
  roleAuthState.sessionExpiresAt = null;
  if (roleAuthState.sessionExpiryTimer) { clearTimeout(roleAuthState.sessionExpiryTimer); roleAuthState.sessionExpiryTimer = null; }
  if (roleAuthState.techAutoRefresh) { try { clearInterval(roleAuthState.techAutoRefresh); } catch (_) {} roleAuthState.techAutoRefresh = null; }

  const b = document.getElementById('sessionExpiredBanner');
  if (b) b.style.display = 'none';
  document.getElementById('loginUsername').value = '';
  document.getElementById('loginPassword').value = '';
  document.getElementById('loginError').style.display = 'none';
  const zEl = document.getElementById('sZayavitel');
  if (zEl) zEl.value = '';
  if (document.getElementById('sStruktura')) {
    setSelectValueWithFallback($('sStruktura'), $('sStrukturaOther'), '');
    $('sStruktura').disabled = false;
    $('sStrukturaOther').disabled = false;
    $('sStruktura').style.background = '';
    $('sStrukturaOther').style.background = '';
  }
  const awReset = document.getElementById('appWrap');
  if (awReset) {
    awReset.classList.remove('has-sidebar');
    awReset.style.display = 'none';
  }
  try { delete document.body.dataset.role; } catch (_) {}
  document.getElementById('roleGate').style.display = 'flex';
  try { showRoleSelectStep(); } catch (_) {}
  // Известяваме desktop Client (ако сме в iframe), че сесията е приключена.
  try {
    if (window.parent && window.parent !== window) {
      window.parent.postMessage({ type: 'zayavki-logged-out' }, '*');
    }
  } catch (_) {}
  // Винаги пълен reload към чист екран за вход (без старо SPA състояние).
  try {
    window.location.replace('/?logout=' + Date.now());
  } catch (_) {
    try { window.location.reload(); } catch (__) {}
  }
}
function showRoleSelectStep() {
  // Единен вход — без избор на роля
  roleAuthState.pendingRoleType = null;
  const loginStep = document.getElementById('loginStep');
  if (loginStep) loginStep.style.display = 'block';
  const roleStep = document.getElementById('roleSelectStep');
  if (roleStep) roleStep.style.display = 'none';
  const title = document.getElementById('loginStepTitle');
  if (title) title.textContent = 'Вход';
  loadLoginBackground();
  setTimeout(function () {
    const u = document.getElementById('loginUsername');
    if (u) u.focus();
  }, 30);
}

function requestRoleLogin(role) {
  // Оставено за съвместимост — директно показва формата за вход
  roleAuthState.pendingRoleType = null;
  showRoleSelectStep();
}

function showLoginError(msg) {
  const el = document.getElementById('loginError');
  el.textContent = msg;
  el.style.display = 'block';
}

async function attemptLogin() {
  const username = document.getElementById('loginUsername').value;
  const password = document.getElementById('loginPassword').value;
  document.getElementById('loginError').style.display = 'none';
  if (!username.trim() || !password) { showLoginError('Моля, въведете потребителско име и парола.'); return; }


  const btn = document.getElementById('btnLogin');
  btn.disabled = true; btn.textContent = 'Влизане...';
  try {
    const r = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify({ username: username.trim(), password })
    });


    const data = await r.json();

    if (!r.ok || !data.ok) {
      showLoginError(data.error || 'Грешно потребителско име или парола.');
      return;
    }
    // Ролята идва от профила на потребителя — без предварителен избор
    // Реален session token (Bearer) + cookie — двойна автентикация за Client iframe
    saveSessionToken(data.token || 'cookie-session');
    // За заявител винаги стартираме чист 30-мин inactivity таймер локално
    // (сървърният sliding от фонови заявки не трябва да го удължава).
    if (isShortSessionRole(data.role)) {
      roleAuthState.sessionExpiresAt = Date.now() + SUBMITTER_SESSION_TTL_MS_CLIENT;
    } else {
      roleAuthState.sessionExpiresAt = data.expiresAt ?? null;
    }
    scheduleSessionExpiry();
    startSessionCountdownTicker();
    installSubmitterActivityListeners();
    try {
      localStorage.setItem(CURRENT_USER_KEY, data.username);
    } catch(e){}
    notifyParentSession(data.token && data.token !== 'cookie-session' ? data.token : null);
    roleAuthState.pendingRoleType = null;
    const b = document.getElementById('sessionExpiredBanner');
    if (b) b.style.display = 'none';
    applyRoleUI(data.role, data.username, data.name, data.struktura, data.allowedMenus, { strukturaLocked: data.strukturaLocked, korpus: data.korpus, etazhi: data.etazhi });
    openPendingRecordFromUrl();
  } catch(e) {
    console.error('❌ Грешка при вход:', e);
    showLoginError('Няма връзка със сървъра. Опитайте отново.');
  } finally {
    btn.disabled = false; btn.textContent = 'Вход';
  }
}

// ---- EVENT LISTENERS ЗА ЛОГИН СИСТЕМАТА ----
document.getElementById('btnLogin').addEventListener('click', attemptLogin);
document.getElementById('btnLogoutRole').addEventListener('click', logoutRole);

// ---- ENTER KEY ФУНКЦИОНАЛНОСТ ЗА ЛОГИН ----
document.getElementById('loginUsername').addEventListener('keypress', function(e) {
  if (e.key === 'Enter') {
    e.preventDefault();
    document.getElementById('loginPassword').focus();
  }
});

document.getElementById('loginPassword').addEventListener('keypress', function(e) {
  if (e.key === 'Enter') {
    e.preventDefault();
    attemptLogin();
  }
});

/* window exports */
try {
  window.tabsForRole = tabsForRole;
  window.applyStrukturaLockUI = applyStrukturaLockUI;
  window.applyUserKorpusEtazUI = applyUserKorpusEtazUI;
  window.applyRoleUI = applyRoleUI;
  window.logoutRole = logoutRole;
  window.showRoleSelectStep = showRoleSelectStep;
  window.requestRoleLogin = requestRoleLogin;
  window.showLoginError = showLoginError;
  window.attemptLogin = attemptLogin;
} catch (_) {}
