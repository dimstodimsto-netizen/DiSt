/**
 * repair-request-form-ui.js — app.js modularization phase 3
 * Форма за ремонтна заявка + вложени материали по заявка.
 * Load AFTER app.js.
 */
const requestFormState = AppState.bind(['currentId','editing','allTableState']);


function parseRepairMaterials(value) {
  if (Array.isArray(value)) return value.map(m => ({name: String(m?.name ?? m?.vid ?? ''), merka: String(m?.merka ?? ''), kolichestvo: String(m?.kolichestvo ?? m?.quantity ?? '')})).filter(m => m.name || m.merka || m.kolichestvo);
  const raw = String(value || '').trim();
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) return parseRepairMaterials(parsed);
  } catch(e) {}
  return raw.split(/\r?\n|;/).map(x => x.trim()).filter(Boolean).map(x => ({name:x, merka:'', kolichestvo:''}));
}
function getFMaterialSuggestionsList() {
  let list = document.getElementById('fMaintenanceMaterialSuggestions');
  if (!list) {
    list = document.createElement('datalist');
    list.id = 'fMaintenanceMaterialSuggestions';
    document.body.appendChild(list);
  }
  return list;
}
function updateFMaterialSuggestions(catalog) {
  const list = getFMaterialSuggestionsList();
  const sorted = [...catalog].filter(m => m && m.name).sort((a, b) => a.name.localeCompare(b.name, 'bg', { sensitivity: 'base' }));
  list.replaceChildren(...sorted.map(m => {
    const option = document.createElement('option');
    option.value = m.name;
    return option;
  }));
}
async function addFMaterialRow(data) {
  data = data || {};
  let catalog = [];
  try { catalog = await getMaintenanceMaterials(); updateFMaterialSuggestions(catalog); } catch (e) { console.warn('Каталогът за материали за поддръжка не е зареден:', e); }
  const rowId = 'fmatrow' + (fMaterialRowSeq++);
  const tr = document.createElement('tr');
  tr.id = rowId;
  tr.style.borderBottom = '1px solid var(--line)';
  const nameCell = document.createElement('td'); nameCell.style.padding = '4px 6px';
  const name = document.createElement('input'); name.type = 'text'; name.className = 'f-mat-name'; name.style.margin = '0';
  name.setAttribute('list', 'fMaintenanceMaterialSuggestions');
  name.setAttribute('autocomplete', 'off');
  name.placeholder = 'Изберете или въведете материал...';
  name.value = data.name || '';
  nameCell.appendChild(name);
  const unitCell = document.createElement('td'); unitCell.style.padding = '4px 6px';
  const unit = document.createElement('input'); unit.type = 'text'; unit.className = 'f-mat-merka'; unit.style.margin = '0'; unit.placeholder = 'бр./м/кг';
  unit.value = data.merka || '';
  unitCell.appendChild(unit);
  const applyCatalogUnit = function() {
    const selected = catalog.find(m => String(m.name).localeCompare(name.value.trim(), undefined, { sensitivity: 'accent' }) === 0);
    if (selected) unit.value = selected.merka || '';
    else if (!name.value.trim()) unit.value = '';
  };
  name.addEventListener('input', applyCatalogUnit);
  name.addEventListener('change', applyCatalogUnit);
  name.addEventListener('focus', async function() {
    try { catalog = await getMaintenanceMaterials(); updateFMaterialSuggestions(catalog); } catch (e) { console.warn('Подсказките за материали не са заредени:', e); }
  });
  const qtyCell = document.createElement('td'); qtyCell.style.padding = '4px 6px';
  const qty = document.createElement('input'); qty.type = 'text'; qty.className = 'f-mat-qty'; qty.style.margin = '0'; qty.value = data.kolichestvo || ''; qtyCell.appendChild(qty);
  const actionCell = document.createElement('td'); actionCell.style.padding = '4px 6px'; actionCell.style.textAlign = 'center';
  const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'ghost f-mat-remove'; remove.style.cssText = 'padding:4px 8px;font-size:12px;color:#c0392b;'; remove.textContent = '✕';
  remove.addEventListener('click', () => tr.remove()); actionCell.appendChild(remove);
  tr.append(nameCell, unitCell, qtyCell, actionCell);
  $('fMaterialsTableBody').appendChild(tr);
}
function readFMaterials() {
  return Array.from($('fMaterialsTableBody').querySelectorAll('tr')).map(tr => ({
    name: tr.querySelector('.f-mat-name')?.value.trim() || '',
    merka: tr.querySelector('.f-mat-merka')?.value.trim() || '',
    kolichestvo: tr.querySelector('.f-mat-qty')?.value.trim() || ''
  })).filter(m => m.name || m.merka || m.kolichestvo);
}
async function fillFMaterials(value) {
  $('fMaterialsTableBody').innerHTML = '';
  const mats = parseRepairMaterials(value);
  if (mats.length) {
    for (const material of mats) await addFMaterialRow(material);
  } else {
    await addFMaterialRow();
  }
}

// ---- ФУНКЦИИ ЗА РАБОТА С ФОРМА ЗА ЗАЯВКА ----

/** Нормализира дата към дд.мм.гггг (български формат). */
function formatDataIzpDisplay(raw) {
  const v = String(raw == null ? '' : raw).trim();
  if (!v) return '';
  // вече дд.мм.гггг или д.м.гггг
  let m = v.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})$/);
  if (m) {
    const dd = Number(m[1]), mm = Number(m[2]), yyyy = Number(m[3]);
    if (dd >= 1 && dd <= 31 && mm >= 1 && mm <= 12 && yyyy >= 1900 && yyyy <= 2100) {
      return String(dd).padStart(2, '0') + '.' + String(mm).padStart(2, '0') + '.' + yyyy;
    }
  }
  // ISO гггг-мм-дд (от input type=date)
  m = v.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (m) {
    const yyyy = Number(m[1]), mm = Number(m[2]), dd = Number(m[3]);
    if (dd >= 1 && dd <= 31 && mm >= 1 && mm <= 12) {
      return String(dd).padStart(2, '0') + '.' + String(mm).padStart(2, '0') + '.' + yyyy;
    }
  }
  // Date parse fallback (внимателно)
  const d = new Date(v);
  if (!isNaN(d.getTime()) && d.getFullYear() >= 1900 && d.getFullYear() <= 2100) {
    return String(d.getDate()).padStart(2, '0') + '.' + String(d.getMonth() + 1).padStart(2, '0') + '.' + d.getFullYear();
  }
  return v;
}

/** Валидира и връща дд.мм.гггг или празен низ; хвърля при невалидна дата. */
function normalizeDataIzpInput(raw) {
  const v = String(raw == null ? '' : raw).trim();
  if (!v) return '';
  const formatted = formatDataIzpDisplay(v);
  const m = String(formatted).match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
  if (!m) throw new Error('Невалидна дата на изпълнение. Ползвайте формат дд.мм.гггг');
  const dd = Number(m[1]), mm = Number(m[2]), yyyy = Number(m[3]);
  const d = new Date(yyyy, mm - 1, dd);
  if (d.getFullYear() !== yyyy || d.getMonth() !== mm - 1 || d.getDate() !== dd) {
    throw new Error('Невалидна дата на изпълнение. Ползвайте формат дд.мм.гггг');
  }
  return formatted;
}



function dataIzpToParts(raw) {
  const disp = formatDataIzpDisplay(raw);
  const m = String(disp).match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
  if (!m) return null;
  return { dd: Number(m[1]), mm: Number(m[2]), yyyy: Number(m[3]) };
}

var __dataIzpCal = { y: 0, m: 0 }; // m = 0..11

function closeDataIzpCalendar() {
  const pop = document.getElementById('dataIzpCalendarPop');
  if (pop) pop.style.display = 'none';
}

function openDataIzpCalendar() {
  const textEl = document.getElementById('fDataIzp');
  const pop = document.getElementById('dataIzpCalendarPop');
  const btn = document.getElementById('btnDataIzpCalendar');
  if (!pop || !btn) return;
  if (textEl && textEl.disabled) {
    toast('Натиснете „Редактирай“, за да промените датата.');
    return;
  }
  if (btn.disabled) {
    toast('Натиснете „Редактирай“, за да промените датата.');
    return;
  }
  const parts = dataIzpToParts(textEl && textEl.value);
  const now = new Date();
  __dataIzpCal.y = parts ? parts.yyyy : now.getFullYear();
  __dataIzpCal.m = parts ? (parts.mm - 1) : now.getMonth();
  renderDataIzpCalendar();
  pop.style.display = 'block';
}

function renderDataIzpCalendar() {
  const title = document.getElementById('dataIzpCalTitle');
  const days = document.getElementById('dataIzpCalDays');
  if (!title || !days) return;
  const months = ['Януари','Февруари','Март','Април','Май','Юни','Юли','Август','Септември','Октомври','Ноември','Декември'];
  const y = __dataIzpCal.y;
  const m = __dataIzpCal.m;
  title.textContent = months[m] + ' ' + y;

  const first = new Date(y, m, 1);
  // Monday-first: getDay() Sun=0 -> convert
  let startPad = first.getDay() - 1;
  if (startPad < 0) startPad = 6;
  const dim = new Date(y, m + 1, 0).getDate();
  const selected = dataIzpToParts((document.getElementById('fDataIzp') || {}).value);
  const today = new Date();

  days.innerHTML = '';
  for (let i = 0; i < startPad; i++) {
    const cell = document.createElement('div');
    cell.style.cssText = 'height:32px;';
    days.appendChild(cell);
  }
  for (let d = 1; d <= dim; d++) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.textContent = String(d);
    const isSel = selected && selected.yyyy === y && selected.mm === (m + 1) && selected.dd === d;
    const isToday = today.getFullYear() === y && today.getMonth() === m && today.getDate() === d;
    btn.style.cssText = 'height:32px;border:1px solid ' + (isSel ? 'var(--accent,#2f6fed)' : 'transparent') +
      ';border-radius:6px;background:' + (isSel ? 'var(--accent-soft,#e8f0fe)' : (isToday ? '#f3f6f9' : 'transparent')) +
      ';cursor:pointer;font-size:13px;font-weight:' + (isSel || isToday ? '700' : '500') + ';color:var(--ink,#222);';
    btn.addEventListener('click', function() {
      const dd = String(d).padStart(2, '0');
      const mm = String(m + 1).padStart(2, '0');
      const el = document.getElementById('fDataIzp');
      if (el) el.value = dd + '.' + mm + '.' + y;
      closeDataIzpCalendar();
    });
    days.appendChild(btn);
  }
}

function wireDataIzpPicker() {
  const textEl = document.getElementById('fDataIzp');
  const btn = document.getElementById('btnDataIzpCalendar');
  const pop = document.getElementById('dataIzpCalendarPop');
  if (!textEl || !btn || !pop) return;
  if (textEl._dataIzpWired) return;
  textEl._dataIzpWired = true;

  btn.addEventListener('click', function(e) {
    e.preventDefault();
    e.stopPropagation();
    if (pop.style.display === 'block') closeDataIzpCalendar();
    else openDataIzpCalendar();
  });

  const prev = document.getElementById('dataIzpCalPrev');
  const next = document.getElementById('dataIzpCalNext');
  const todayBtn = document.getElementById('dataIzpCalToday');
  const clearBtn = document.getElementById('dataIzpCalClear');
  if (prev) prev.addEventListener('click', function(e) {
    e.preventDefault(); e.stopPropagation();
    __dataIzpCal.m -= 1;
    if (__dataIzpCal.m < 0) { __dataIzpCal.m = 11; __dataIzpCal.y -= 1; }
    renderDataIzpCalendar();
  });
  if (next) next.addEventListener('click', function(e) {
    e.preventDefault(); e.stopPropagation();
    __dataIzpCal.m += 1;
    if (__dataIzpCal.m > 11) { __dataIzpCal.m = 0; __dataIzpCal.y += 1; }
    renderDataIzpCalendar();
  });
  if (todayBtn) todayBtn.addEventListener('click', function(e) {
    e.preventDefault(); e.stopPropagation();
    const n = new Date();
    textEl.value = String(n.getDate()).padStart(2,'0') + '.' + String(n.getMonth()+1).padStart(2,'0') + '.' + n.getFullYear();
    closeDataIzpCalendar();
  });
  if (clearBtn) clearBtn.addEventListener('click', function(e) {
    e.preventDefault(); e.stopPropagation();
    textEl.value = '';
    closeDataIzpCalendar();
  });

  document.addEventListener('click', function(e) {
    if (!pop || pop.style.display !== 'block') return;
    if (pop.contains(e.target) || btn.contains(e.target) || e.target === textEl) return;
    closeDataIzpCalendar();
  });

  textEl.addEventListener('blur', function() {
    const v = String(textEl.value || '').trim();
    if (!v) return;
    try { textEl.value = normalizeDataIzpInput(v); }
    catch (err) { toast('Дата на изпълнение: ползвайте дд.мм.гггг'); }
  });
}

async function fillForm(rec) {
  document.getElementById('fID').value = rec.id || '';
  document.getElementById('fDateTime').value = rec.datetime || '';
  setSelectValueWithFallback($('fKorpus'), $('fKorpusOther'), rec.korpus || '');
  document.getElementById('fEtaz').value = rec.etaz || '';
  setSelectValueWithFallback($('fStruktura'), $('fStrukturaOther'), rec.struktura || '');
  document.getElementById('fLokacia').value = rec.lokacia || '';
  document.getElementById('fVid').value = rec.vid || '';
  document.getElementById('fZayavitel').value = rec.zayavitel || '';
  document.getElementById('fZabelezka').value = rec.zabelezka || '';
  document.getElementById('fStatus').value = rec.status || '';
  document.getElementById('fUrgent').checked = rec.urgent === true;
  document.getElementById('fDataIzp').value = formatDataIzpDisplay(rec.dataIzp || '');
  closeDataIzpCalendar();
  wireDataIzpPicker();
  setSelectValueWithFallback($('fIzpalnitel'), $('fIzpalnitelOther'), rec.izpalnitel || '');
  await fillFMaterials(rec.materiali);
  document.getElementById('fKomentar').value = rec.komentar || '';
  
  // История — САМО администратор, след бутон „История“ (по подразбиране скрита)
  const historyWrap = document.getElementById('fHistoryWrap');
  const historyEl = document.getElementById('fHistory');
  const btnHist = document.getElementById('btnToggleHistory');
  if (historyWrap) {
    historyWrap.style.display = 'none';
    historyWrap.setAttribute('data-open', '0');
  }
  if (historyEl) historyEl.innerHTML = '';
  if (btnHist) {
    if (currentRole === 'admin') {
      btnHist.style.display = '';
      btnHist.textContent = 'История';
      const entries = Array.isArray(rec.history) ? rec.history.slice() : [];
      btnHist.onclick = function () {
        const wrap = document.getElementById('fHistoryWrap');
        const el = document.getElementById('fHistory');
        if (!wrap || !el) return;
        const open = wrap.getAttribute('data-open') === '1';
        if (open) {
          wrap.style.display = 'none';
          wrap.setAttribute('data-open', '0');
          btnHist.textContent = 'История';
          return;
        }
        if (!entries.length) {
          el.innerHTML = '<span style="color:#5c6b7a;">Няма записани събития за тази заявка.</span>';
        } else {
          el.innerHTML = entries.slice().reverse().map(function (h) {
            const at = escapeHtml(String((h && h.at) || '—'));
            const by = escapeHtml(String((h && h.by) || '—'));
            const action = escapeHtml(String((h && h.action) || '—'));
            return '<div style="padding:3px 0;border-bottom:1px solid #eef1f4;"><b>' + at + '</b> · ' + by + '<br><span style="color:#5c6b7a;">' + action + '</span></div>';
          }).join('');
        }
        wrap.style.display = '';
        wrap.setAttribute('data-open', '1');
        btnHist.textContent = 'Скрий историята';
      };
    } else {
      btnHist.style.display = 'none';
      btnHist.onclick = null;
    }
  }
  try { updateHideFromTechButton(rec); } catch (_) {}
}

function readForm() {
  return {
    id: document.getElementById('fID').value,
    datetime: document.getElementById('fDateTime').value,
    korpus: getSelectValueWithFallback($('fKorpus'), $('fKorpusOther')),
    etaz: document.getElementById('fEtaz').value,
    struktura: getSelectValueWithFallback($('fStruktura'), $('fStrukturaOther')),
    lokacia: document.getElementById('fLokacia').value,
    vid: document.getElementById('fVid').value,
    zayavitel: document.getElementById('fZayavitel').value,
    zabelezka: document.getElementById('fZabelezka').value,
    status: document.getElementById('fStatus').value,
    urgent: document.getElementById('fUrgent').checked,
    dataIzp: formatDataIzpDisplay(document.getElementById('fDataIzp').value),
    izpalnitel: getSelectValueWithFallback($('fIzpalnitel'), $('fIzpalnitelOther')),
    materiali: JSON.stringify(readFMaterials()),
    komentar: document.getElementById('fKomentar').value
  };
}

// Полета, попълнени от ЗАЯВИТЕЛЯ при подаване на заявката - технически
// потребител никога не трябва да може да ги променя, дори в режим
// "Редактиране" (само тези, свързани с изпълнението, остават негови).
const SUBMITTER_FIELDS = ['fID','fDateTime','fKorpus','fKorpusOther','fEtaz','fStruktura','fStrukturaOther',
                          'fLokacia','fVid','fZayavitel','fZabelezka','fUrgent'];
// Полета, свързани с изпълнението - технически потребител ги редактира.
const TECHNICIAN_FIELDS = ['fStatus','fDataIzp','btnDataIzpCalendar','fIzpalnitel','fIzpalnitelOther','fKomentar'];

function setLocked(locked) {
  const isAdmin = currentRole === 'admin';
  SUBMITTER_FIELDS.forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    // За технически потребител тези полета остават заключени дори при
    // "Редактиране" - само администратор може да ги променя.
    const fieldLocked = locked || !isAdmin;
    el.disabled = fieldLocked;
    el.style.background = fieldLocked ? 'var(--locked-bg)' : '';
  });
  const materialControls = document.querySelectorAll('#fMaterialsTableBody input, #fMaterialsTableBody select, #fMaterialsTableBody button');
  materialControls.forEach(el => { el.disabled = locked; el.style.background = locked ? 'var(--locked-bg)' : ''; });
  const addMatBtn = $('btnAddFMaterialRow'); if (addMatBtn) addMatBtn.disabled = locked;
  TECHNICIAN_FIELDS.forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    el.disabled = locked;
    el.style.background = locked ? 'var(--locked-bg)' : '';
  });

  const canEditExisting = currentRole === 'admin' || currentRole === 'technician';
  const btnEditEl = document.getElementById('btnEdit');
  const btnSaveEl = document.getElementById('btnSave');
  const btnCloseBottom = document.getElementById('btnCloseRecordBottom');
  // Редактирай ↔ Запиши (сменят се на едно и също място в реда)
  if (btnEditEl) {
    btnEditEl.style.display = (locked && canEditExisting) ? '' : 'none';
    btnEditEl.textContent = 'Редактирай';
    btnEditEl.className = 'record-edit-btn';
    btnEditEl.disabled = false;
  }
  if (btnSaveEl) {
    btnSaveEl.style.display = (!locked && canEditExisting) ? '' : 'none';
    btnSaveEl.textContent = 'Запиши';
    btnSaveEl.className = 'primary';
    btnSaveEl.disabled = false;
  }
  // Затвори — винаги видим, винаги с този надпис, винаги активен
  if (btnCloseBottom) {
    btnCloseBottom.style.display = '';
    btnCloseBottom.textContent = 'Затвори';
    btnCloseBottom.disabled = false;
    btnCloseBottom.className = 'ghost';
  }
  // Администраторът може да изтрива заявката и в режим преглед (не само при редакция).
  const btnDelete = document.getElementById('btnDelete');
  if (btnDelete) {
    btnDelete.style.display = isAdmin ? '' : 'none';
    btnDelete.style.color = isAdmin ? '#c0392b' : '';
  }
  const btnHide = document.getElementById('btnHideFromTech');
  if (btnHide && !isAdmin) {
    btnHide.style.display = 'none';
  }
}


async function closeRecordAndReturnToList(opts) {
  const mutated = !!(opts && opts.mutated === true);
  closeDataIzpCalendar();
  if (typeof inPlaceRecordView !== 'undefined' && inPlaceRecordView) {
    restoreMainUiAfterRecordView();
    if (mutated) {
      if (currentTab === 'technicians') {
        try { await renderTechniciansTable({ softRefresh: true }); } catch (_) {}
      } else if (currentTab === 'all') {
        try { await renderAllTable({ softRefresh: true }); } catch (_) {}
      } else if (currentTab === 'myRequests') {
        try { await renderMyRequests({ softRefresh: true }); } catch (_) {}
      } else if (currentTab === 'submit') {
        try { await renderMonthlyPanel({ softRefresh: true }); } catch (_) {}
      }
    }
    return;
  }
  if (typeof standaloneRecordMode !== 'undefined' && standaloneRecordMode) {
    try { window.close(); } catch (_) {}
    return;
  }
  const card = document.getElementById('recordCard');
  if (card) {
    card.style.display = 'none';
    card.classList.remove('record-drawer');
  }
  const backdrop = document.getElementById('recordDrawerBackdrop');
  if (backdrop) backdrop.style.display = 'none';
  try { document.body.classList.remove('drawer-open'); } catch (_) {}
  requestFormState.currentId = null;
  requestFormState.editing = false;
  if (mutated) {
    if (currentTab === 'technicians') {
      try { await renderTechniciansTable({ softRefresh: true }); } catch (_) {}
    } else if (currentTab === 'all') {
      try { await renderAllTable({ softRefresh: true }); } catch (_) {}
    } else if (currentTab === 'myRequests') {
      try { await renderMyRequests({ softRefresh: true }); } catch (_) {}
    }
  }
}

window.closeRecordCard = function(opts) {
  closeRecordAndReturnToList(opts);
};

// ---- EVENT LISTENERS ЗА БУТОНИТЕ В ФОРМАТА ----
document.getElementById('btnEdit').addEventListener('click', function() {
  // Класическо: отключване на позволените полета; бутонът се сменя със „Запиши“
  requestFormState.editing = true;
  setLocked(false);
});

const btnCloseBottom = document.getElementById('btnCloseRecordBottom');
if (btnCloseBottom) {
  btnCloseBottom.addEventListener('click', function() {
    closeRecordAndReturnToList();
  });
}

// Незабавно обновяване на таблото при промяна от друг прозорец/таб.
window.addEventListener('message', function(e) {
  if (e.origin !== window.location.origin) return;
  if (!e.data || e.data.type !== 'zayavki-record-changed') return;
  if (currentTab === 'technicians') renderTechniciansTable();
});

window.addEventListener('storage', function(e) {
  if (e.key !== 'zayavki_record_changed' || !e.newValue) return;
  if (currentTab === 'technicians') renderTechniciansTable();
});

$('btnAddFMaterialRow').addEventListener('click', async () => { await addFMaterialRow(); });


try { wireDataIzpPicker(); } catch (_) {}
async function saveCurrentRecordAndClose() {
  if (!requestFormState.currentId) return false;

  let rec;
  try {
    rec = readForm();
  } catch (e) {
    toast('❌ ' + (e.message || e));
    return false;
  }

  // За техник при запис на изпълнение са задължителни:
  // Статус, Дата на изпълнение и Изпълнител.
  if (currentRole === 'technician') {
    const missing = [];
    if (!String(rec.status || '').trim()) missing.push('Статус');
    if (!String(rec.dataIzp || '').trim()) missing.push('Дата на изпълнение');
    else {
      try { rec.dataIzp = normalizeDataIzpInput(rec.dataIzp); }
      catch (e) { missing.push('Дата на изпълнение (дд.мм.гггг)'); }
    }
    if (!String(rec.izpalnitel || '').trim()) missing.push('Изпълнител');

    if (missing.length) {
      toast('❌ Моля, попълнете: ' + missing.join(', ') + '.');
      return false;
    }
  }

  const oldRec = await getRecord(requestFormState.currentId);
  if (!oldRec) {
    toast('❌ Заявката не е намерена.');
    return false;
  }
  // Запазваме флагове, които не са във формата
  if (oldRec.hiddenFromTech) rec.hiddenFromTech = true;
  if (oldRec.seen) rec.seen = oldRec.seen;
  if (oldRec.history) rec.history = oldRec.history;

  addHistoryEntry(rec, 'Редакция');

  try {
    await saveRecord(rec);

    const changeMessage = {
      type: 'zayavki-record-changed',
      id: String(rec.id),
      status: rec.status || '',
      at: Date.now()
    };
    try {
      if (window.opener && !window.opener.closed) {
        window.opener.postMessage(changeMessage, window.location.origin);
      }
    } catch (e) {}
    try {
      localStorage.setItem('zayavki_record_changed', JSON.stringify(changeMessage));
      localStorage.removeItem('zayavki_record_changed');
    } catch (e) {}

    toast('✅ Заявката е обновена.');
    requestFormState.editing = false;
    await closeRecordAndReturnToList({ mutated: true });
    return true;
  } catch (e) {
    console.error(e);
    toast('❌ Грешка при запис.');
    return false;
  }
}

document.getElementById('btnSave').addEventListener('click', async function() {
  await saveCurrentRecordAndClose();
});

/** Изтриване на заявка за ремонт — само администратор. Работи от формата и от списъците. */


function updateHideFromTechButton(rec) {
  const btn = document.getElementById('btnHideFromTech');
  if (!btn) return;
  if (currentRole !== 'admin' || !rec) {
    btn.style.display = 'none';
    btn.onclick = null;
    return;
  }
  btn.style.display = '';
  const id = String(rec.id || '');
  if (rec.hiddenFromTech) {
    btn.textContent = '📤 Върни в панел „За техници“';
    btn.style.color = '#1e7e34';
    btn.onclick = function () { restoreRepairToTechPanel(id); };
  } else {
    btn.textContent = '📥 Снеми от панел „За техници“';
    btn.style.color = '#8e44ad';
    btn.onclick = function () { hideRepairFromTechPanel(id); };
  }
}

window.hideRepairFromTechPanel = async function(id) {
  if (currentRole !== 'admin') { toast('Само администратор може да снема заявки от панела.'); return false; }
  if (!(await confirmDialog('Снемане на заявка №' + id + ' от панела „За техници“?\n\nСтатусът НЯМА да се промени на „Изпълнена“. Заявката остава в системата и в „Всички заявки“. Само администратор може да я върне в панела.'))) return false;
  try {
    const rec = await getRecord(id);
    if (!rec) { toast('❌ Заявката не е намерена.'); return false; }
    rec.hiddenFromTech = true;
    try { addHistoryEntry(rec, 'Снета от панел „За техници“ (админ)'); } catch (_) {}
    await saveRecord(rec);
    try { if (typeof invalidateRecordsCache === 'function') invalidateRecordsCache(); } catch (_) {}
    toast('✅ Заявка №' + id + ' е снета от панела „За техници“.');
    try { await renderTechniciansTable(); } catch (_) {}
    try {
      if (Array.isArray(requestFormState.allTableState && requestFormState.allTableState.records)) {
        const ix = requestFormState.allTableState.records.findIndex(r => r && String(r.id) === String(id));
        if (ix >= 0) requestFormState.allTableState.records[ix].hiddenFromTech = true;
        requestFormState.allTableState.filtered = applyAllFilters(requestFormState.allTableState.records);
        renderAllTableRows();
      }
    } catch (_) {}
    return true;
  } catch (e) {
    console.error(e);
    toast('❌ Грешка: ' + (e.message || e));
    return false;
  }
};

window.restoreRepairToTechPanel = async function(id) {
  if (currentRole !== 'admin') { toast('Само администратор може да връща заявки в панела.'); return false; }
  try {
    const rec = await getRecord(id);
    if (!rec) { toast('❌ Заявката не е намерена.'); return false; }
    rec.hiddenFromTech = false;
    try { addHistoryEntry(rec, 'Върната в панел „За техници“ (админ)'); } catch (_) {}
    await saveRecord(rec);
    try { if (typeof invalidateRecordsCache === 'function') invalidateRecordsCache(); } catch (_) {}
    toast('✅ Заявка №' + id + ' е върната в панела „За техници“.');
    try { await renderTechniciansTable(); } catch (_) {}
    try {
      if (Array.isArray(requestFormState.allTableState && requestFormState.allTableState.records)) {
        const ix = requestFormState.allTableState.records.findIndex(r => r && String(r.id) === String(id));
        if (ix >= 0) requestFormState.allTableState.records[ix].hiddenFromTech = false;
        requestFormState.allTableState.filtered = applyAllFilters(requestFormState.allTableState.records);
        renderAllTableRows();
      }
    } catch (_) {}
    return true;
  } catch (e) {
    console.error(e);
    toast('❌ Грешка: ' + (e.message || e));
    return false;
  }
};

window.deleteRepairRequest = async function(id, opts) {
  opts = opts || {};
  if (currentRole !== 'admin') {
    toast('Само администратор може да изтрива заявки.');
    return false;
  }
  const targetId = id != null && id !== '' ? String(id) : (requestFormState.currentId ? String(requestFormState.currentId) : '');
  if (!targetId) return false;
  if (!opts.skipConfirm) {
    if (!(await confirmDialog('Сигурни ли сте, че искате да изтриете заявка № ' + targetId + '?'))) return false;
  }
  try {
    await deleteRecord(targetId);
    toast('✅ Заявката е изтрита.');
    if (requestFormState.currentId && String(requestFormState.currentId) === targetId) {
      closeRecordCard({ mutated: false });
    }
    invalidateRecordsCache();
    if (currentTab === 'technicians') renderTechniciansTable();
    else if (currentTab === 'all') renderAllTable();
    else if (currentTab === 'submit') renderMonthlyPanel();
    else if (currentTab === 'myRequests') renderMyRequests();
    return true;
  } catch (e) {
    console.error(e);
    toast('❌ Грешка при изтриване: ' + (e.message || e));
    return false;
  }
};

document.getElementById('btnDelete').addEventListener('click', async function() {
  await window.deleteRepairRequest(requestFormState.currentId);
});

document.getElementById('btnCloseRecord').addEventListener('click', closeRecordCard);

/* window exports */
try {
  if (typeof addFMaterialRow==='function') window.addFMaterialRow=addFMaterialRow;
  if (typeof closeDataIzpCalendar==='function') window.closeDataIzpCalendar=closeDataIzpCalendar;
  if (typeof closeRecordAndReturnToList==='function') window.closeRecordAndReturnToList=closeRecordAndReturnToList;
  if (typeof dataIzpToParts==='function') window.dataIzpToParts=dataIzpToParts;
  if (typeof deleteRepairRequest==='function') window.deleteRepairRequest=deleteRepairRequest;
  if (typeof fillFMaterials==='function') window.fillFMaterials=fillFMaterials;
  if (typeof fillForm==='function') window.fillForm=fillForm;
  if (typeof formatDataIzpDisplay==='function') window.formatDataIzpDisplay=formatDataIzpDisplay;
  if (typeof getFMaterialSuggestionsList==='function') window.getFMaterialSuggestionsList=getFMaterialSuggestionsList;
  if (typeof hideRepairFromTechPanel==='function') window.hideRepairFromTechPanel=hideRepairFromTechPanel;
  if (typeof normalizeDataIzpInput==='function') window.normalizeDataIzpInput=normalizeDataIzpInput;
  if (typeof openDataIzpCalendar==='function') window.openDataIzpCalendar=openDataIzpCalendar;
  if (typeof parseRepairMaterials==='function') window.parseRepairMaterials=parseRepairMaterials;
  if (typeof readFMaterials==='function') window.readFMaterials=readFMaterials;
  if (typeof readForm==='function') window.readForm=readForm;
  if (typeof renderDataIzpCalendar==='function') window.renderDataIzpCalendar=renderDataIzpCalendar;
  if (typeof restoreRepairToTechPanel==='function') window.restoreRepairToTechPanel=restoreRepairToTechPanel;
  if (typeof saveCurrentRecordAndClose==='function') window.saveCurrentRecordAndClose=saveCurrentRecordAndClose;
  if (typeof setLocked==='function') window.setLocked=setLocked;
  if (typeof updateFMaterialSuggestions==='function') window.updateFMaterialSuggestions=updateFMaterialSuggestions;
  if (typeof updateHideFromTechButton==='function') window.updateHideFromTechButton=updateHideFromTechButton;
  if (typeof wireDataIzpPicker==='function') window.wireDataIzpPicker=wireDataIzpPicker;
} catch(_){}
