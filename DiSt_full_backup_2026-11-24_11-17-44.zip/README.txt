DiSt 2.0 — КУМУЛАТИВНО ОБНОВЛЕНИЕ (UI/UX + VERIFY_BACKUP + SMOKE TESTS + VERSION SYNC)
Версия: 2026.11.23-dist-2.0.2 (APP_VERSION: DiSt-2.0, package.json: 2.0.0, Node.js >=24.0.0)

КАКВО ПРОМЕНЯ
- Версии и заглавие: синхронизирани package.json (2.0.0, engines.node >=24.0.0), server/bootstrap.js (APP_VERSION = DiSt-2.0, коментар Node.js 24.0+), заглавието в таба на браузъра („DiSt v2.0“ в index.html, app.js, menu-nav-ui.js) и темата на тестовия имейл (settings-routes.js).
- Меню „Подаване на заявка“: уточнен текст („Моля изпращайте всяка една дейност в отделна заявка, не ги обобщавайте.“).
- CSS токени: базовите :root променливи са консолидирани единствено в public/css/main.css (премахнато дублиране в ui-polish-v4.css).
- scripts/smoke-tests.js: добавени проверки на /api/records, /api/kv-list?prefix=wh:, /api/kv/wh-index, /api/admin/agent/report и /api/admin/agent/run (при admin вход).
- scripts/VERIFY_BACKUP.bat: автоматичен smoke test след ZIP проверка (поддържа --skip-smoke за офлайн проверка).
- scripts/RECOVERY_CHECKLIST.txt: документирани VERIFY_BACKUP.js, VERIFY_BACKUP.bat и smoke-tests.js.
- server/maintenance-materials-routes.js: актуален нормален timestamp.
- Включва всички UI/UX подобрения от Етап 1–3.2 (едноредов „Код“ в материалите, „Изпълнени заявки за месеца“, компактни редове, Drawer, SVG икони и мобилен Card изглед).

ПРИЛАГАНЕ НА ТЕСТОВА / ПРОДУКТИВНА СИСТЕМА
1. Направете пълен бекъп.
2. Администратор → Обновяване на програмата → качете ZIP пакета и го приложете.
3. Рестартирайте DiSt сървъра (изисква се рестарт заради промените в server/bootstrap.js).
4. Отворете клиента наново (при стар кеш — Ctrl+F5).
5. По желание проверете бекъп + работещия сървър с scripts\VERIFY_BACKUP.bat "път\до\архив.zip".
