#!/usr/bin/env node
'use strict';
/**
 * Кратки проверки след ъпдейт / рестарт.
 *   node scripts/smoke-tests.js
 *   set SMOKE_BASE=http://127.0.0.1:3000
 *   set SMOKE_USER=admin
 *   set SMOKE_PASS=...
 */
const BASE = (process.env.SMOKE_BASE || 'http://127.0.0.1:3000').replace(/\/$/, '');
const USER = process.env.SMOKE_USER || '';
const PASS = process.env.SMOKE_PASS || '';
let passed = 0, failed = 0;
function ok(name) { passed++; console.log('  OK  ' + name); }
function fail(name, err) { failed++; console.log('  FAIL ' + name + ' — ' + err); }
async function req(path, opts) {
  opts = opts || {};
  const headers = Object.assign({ Accept: 'application/json' }, opts.headers || {});
  if (opts.body && !headers['Content-Type']) headers['Content-Type'] = 'application/json';
  const res = await fetch(BASE + path, {
    method: opts.method || 'GET',
    headers,
    body: opts.body,
    redirect: 'manual'
  });
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch (_) {}
  return { res, text, json };
}
async function main() {
  console.log('DiSt smoke → ' + BASE);
  try {
    const r = await req('/api/server-info');
    if (r.res.status === 200 && r.json) ok('server-info');
    else fail('server-info', 'status ' + r.res.status);
  } catch (e) { fail('server-info', e.message); }
  try {
    const r = await req('/api/system/verification-status');
    if (r.res.status === 200 && r.json) ok('verification-status');
    else fail('verification-status', 'status ' + r.res.status);
  } catch (e) { fail('verification-status', e.message); }
  try {
    const r = await req('/');
    if (/<script[^>]+src=["'][^"']*xlsx\.full\.min\.js/.test(r.text || '')) {
      fail('lazy-xlsx', 'xlsx still eagerly loaded in index');
    } else ok('lazy-xlsx');
  } catch (e) { fail('index', e.message); }
  if (!USER || !PASS) {
    console.log('\n(Auth пропуснати — задайте SMOKE_USER / SMOKE_PASS)');
    console.log('Резултат: ' + passed + ' OK, ' + failed + ' FAIL');
    process.exit(failed ? 1 : 0);
  }
  let token = null;
  try {
    const r = await req('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username: USER, password: PASS })
    });
    if (r.res.status === 200 && r.json && (r.json.token || r.json.ok)) {
      token = r.json.token;
      ok('login');
    } else if (r.res.status === 500) {
      fail('login', 'HTTP 500 — ' + ((r.json && r.json.error) || r.text.slice(0, 80)));
    } else {
      fail('login', (r.json && r.json.error) || ('status ' + r.res.status));
    }
  } catch (e) { fail('login', e.message); }
  const auth = token ? { Authorization: 'Bearer ' + token } : {};
  if (token) {
    let role = '';
    try {
      const r = await req('/api/auth/me', { headers: auth });
      if (r.res.status === 200) {
        role = (r.json && r.json.role) || '';
        ok('auth/me (' + (role || 'ok') + ')');
      } else fail('auth/me', 'status ' + r.res.status);
    } catch (e) { fail('auth/me', e.message); }
    try {
      const r = await req('/api/records?page=1&pageSize=10', { headers: auth });
      if (r.res.status === 200 && r.json && Array.isArray(r.json.records)) ok('records (' + r.json.records.length + ')');
      else fail('records', 'status ' + r.res.status);
    } catch (e) { fail('records', e.message); }
    try {
      const r = await req('/api/kv-list?prefix=' + encodeURIComponent('wh:'), { headers: auth });
      if (r.res.status === 200 && Array.isArray(r.json)) ok('warehouse-kv-list (' + r.json.length + ')');
      else fail('warehouse-kv-list', 'status ' + r.res.status);
    } catch (e) { fail('warehouse-kv-list', e.message); }
    try {
      const r = await req('/api/kv/wh-index', { headers: auth });
      if (r.res.status === 200 || r.res.status === 404) ok('warehouse-index (' + r.res.status + ')');
      else fail('warehouse-index', 'status ' + r.res.status);
    } catch (e) { fail('warehouse-index', e.message); }
    try {
      const r = await req('/api/maintenance-materials', { headers: auth });
      if (r.res.status === 200 || r.res.status === 403) ok('maintenance-materials (' + r.res.status + ')');
      else fail('maintenance-materials', 'status ' + r.res.status);
    } catch (e) { fail('maintenance-materials', e.message); }
    try {
      const r = await req('/api/admin/agent/report', { headers: auth });
      if (role === 'admin') {
        if (r.res.status === 200 && r.json && r.json.ok) ok('agent/report');
        else fail('agent/report', 'status ' + r.res.status);
      } else {
        if (r.res.status === 200 || r.res.status === 403) ok('agent/report (' + r.res.status + ')');
        else fail('agent/report', 'status ' + r.res.status);
      }
    } catch (e) { fail('agent/report', e.message); }
    if (role === 'admin') {
      try {
        const r = await req('/api/admin/agent/run', { method: 'POST', headers: auth, body: '{}' });
        if (r.res.status === 200 && r.json && r.json.ok && r.json.report && r.json.report.summary) {
          ok('agent/run (' + r.json.report.summary.overall + ')');
        } else fail('agent/run', 'status ' + r.res.status);
      } catch (e) { fail('agent/run', e.message); }
    }
    try {
      const r = await req('/api/auth/logout', { method: 'POST', headers: auth, body: '{}' });
      if (r.res.status === 200) ok('logout');
      else fail('logout', 'status ' + r.res.status);
    } catch (e) { fail('logout', e.message); }
  }
  console.log('\nРезултат: ' + passed + ' OK, ' + failed + ' FAIL');
  process.exit(failed ? 1 : 0);
}
main().catch(function (e) { console.error(e); process.exit(2); });
