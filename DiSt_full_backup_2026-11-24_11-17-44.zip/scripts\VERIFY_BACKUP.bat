@echo off
setlocal
cd /d "%~dp0.."
if "%~1"=="" (
  echo Usage: VERIFY_BACKUP.bat "data\backups\DiSt_full_backup_YYYY-MM-DD_HH-MM-SS.zip" [--skip-smoke]
  exit /b 2
)
echo [1/2] Verifying backup archive integrity...
node "%~dp0VERIFY_BACKUP.js" "%~1"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" exit /b %RC%
if /i "%~2"=="--skip-smoke" goto :skip_smoke

echo.
echo [2/2] Running end-to-end smoke tests...
node "%~dp0smoke-tests.js"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" goto :smoke_failed
echo RESULT: ALL CHECKS OK (ZIP + Smoke)
exit /b 0

:skip_smoke
echo [2/2] Smoke test skipped (--skip-smoke).
exit /b 0

:smoke_failed
echo FAILED: Smoke test failed. Ensure DiSt server is started/restarted ^(or pass --skip-smoke for offline ZIP check^).
exit /b %RC%
