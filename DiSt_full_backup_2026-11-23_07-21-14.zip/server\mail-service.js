'use strict';

function createMailService(deps) {
  const { fs, path, os, spawn, DATA_DIR, MAIL_SCRIPT_PATH, kvGet, writeSystemLog, sendSmtpMail } = deps;// ---- Изпращане на имейл чрез Outlook ----
function getNotifyEmails() {
  try {
    const raw = kvGet('settings:notifyEmails');
    if (!raw) return [];
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr.map(s => String(s).trim()).filter(Boolean) : [];
  } catch (e) {
    return [];
  }
}

/** Имейл известия: по подразбиране ИЗКЛЮЧЕНИ (освен settings:emailNotifyEnabled=1). */
function isEmailNotifyEnabled() {
  try {
    const v = kvGet('settings:emailNotifyEnabled');
    if (v == null || v === '') return false;
    const t = String(v).trim().toLowerCase();
    return t === '1' || t === 'true' || t === 'on' || t === 'yes';
  } catch (_) {
    return false;
  }
}

function mailOneLine(value) {
  return String(value == null ? '' : value).replace(/[\r\n]+/g, ' ').trim();
}

function getSmtpSettings() {
  const host = String(kvGet('settings:smtpHost') || '').trim();
  const port = parseInt(kvGet('settings:smtpPort') || '587', 10) || 587;
  const mode = String(kvGet('settings:smtpMode') || 'starttls').trim().toLowerCase() || 'starttls';
  const user = String(kvGet('settings:smtpUser') || '').trim();
  const pass = String(kvGet('settings:smtpPass') || '');
  const from = String(kvGet('settings:smtpFrom') || user || '').trim();
  const transport = String(kvGet('settings:mailTransport') || 'auto').trim().toLowerCase() || 'auto';
  // По подразбиране ИЗКЛЮЧЕНО — сертификатът на SMTP хоста винаги се проверява.
  // Включва се само ако администраторът изрично го поиска (вътрешен сървър със самоподписан сертификат).
  const tlsInsecure = String(kvGet('settings:smtpTlsInsecure') || '') === '1';
  return { host, port, mode, user, pass, from, transport, tlsInsecure };
}

function isSmtpConfigured() {
  const s = getSmtpSettings();
  return !!(s.host && s.from);
}

/** Единен изпращач: SMTP (ако е настроен) или Outlook COM. */
async function sendMail(toEmails, subject, body) {
  const s = getSmtpSettings();
  const preferSmtp = s.transport === 'smtp' || (s.transport === 'auto' && isSmtpConfigured());
  const preferOutlook = s.transport === 'outlook' || (s.transport === 'auto' && !isSmtpConfigured());

  if (preferSmtp && isSmtpConfigured()) {
    const result = await sendSmtpMail({
      host: s.host,
      port: s.port,
      mode: s.mode,
      user: s.user,
      pass: s.pass,
      from: s.from,
      to: toEmails,
      subject,
      body,
      tlsInsecure: s.tlsInsecure
    });
    if (result && result.ok) return result;
    if (s.transport === 'auto' && fs.existsSync(MAIL_SCRIPT_PATH)) {
      try {
        writeSystemLog('warn', 'email', 'SMTP неуспешен, fallback Outlook: ' + (result && result.error ? result.error : ''));
      } catch (_) {}
      const o = await sendOutlookMail(toEmails, subject, body);
      if (o && o.ok) return Object.assign({}, o, { transport: 'outlook-fallback', smtpError: result && result.error });
      return result || o;
    }
    return result || { ok: false, error: 'SMTP неуспешен.' };
  }

  if (preferOutlook || s.transport === 'outlook' || s.transport === 'auto') {
    return sendOutlookMail(toEmails, subject, body);
  }
  return { ok: false, error: 'Няма конфигуриран SMTP и Outlook не е избран.' };
}


function notifyNewRepairRequest(rec) {
  if (!rec) {
    writeSystemLog('warn', 'email', 'notifyNewRepairRequest: липсва запис');
    return;
  }
  if (!isEmailNotifyEnabled()) {
    // Изключено — без error в системния лог
    return;
  }
  const emails = getNotifyEmails();
  if (!emails.length) {
    writeSystemLog('info', 'email', 'Заявка №' + (rec.id || '?') + ' — няма зададени имейл адреси (пропуск).');
    return;
  }
  const urgent = !!rec.urgent;
  const id = mailOneLine(rec.id || '?');
  const lokacia = mailOneLine(rec.lokacia);
  const subject = (urgent ? 'СПЕШНА ЗАЯВКА №' : 'Нова заявка за ремонт №') + id + (lokacia ? ' — ' + lokacia : '');
  const bodyText =
    (urgent ? 'ТОВА Е СПЕШНА ЗАЯВКА!\n\n' : '') +
    'Постъпи нова заявка за ремонт:\n\n' +
    'ID: ' + (rec.id || '') + '\n' +
    'Дата/час: ' + (rec.datetime || '') + '\n' +
    'Корпус: ' + (rec.korpus || '') + '\n' +
    'Етаж: ' + (rec.etaz || '') + '\n' +
    'Структура: ' + (rec.struktura || '') + '\n' +
    'Локация: ' + (rec.lokacia || '') + '\n' +
    'Вид на заявка: ' + (rec.vid || '') + '\n' +
    'Забележка: ' + (rec.zabelezka || '') + '\n' +
    'Заявител: ' + (rec.zayavitel || '') + '\n\n' +
    '— Изпратено автоматично от системата за заявки за ремонт.';
  writeSystemLog('info', 'email', 'Опит за изпращане на известие за заявка №' + id + ' → ' + emails.join(', '));
  sendMail(emails, subject, bodyText).then(result => {
    if (result && result.ok) {
      writeSystemLog('info', 'email', 'Изпратено известие за заявка №' + id + ' до ' + emails.join(', '));
    } else {
      const err = (result && result.error) || 'неизвестна грешка';
      console.error('⚠ Неуспешно изпращане на имейл известие:', err);
      writeSystemLog('error', 'email', 'Неуспешно изпращане за заявка №' + id + ': ' + err);
    }
  }).catch(e => {
    writeSystemLog('error', 'email', 'Изключение при изпращане за заявка №' + id + ': ' + (e && e.message ? e.message : e));
  });
}

function translateMailError(raw) {
  const t = String(raw || '').trim();
  if (!t) return 'Неизвестна грешка при изпращане през Outlook.';
  const low = t.toLowerCase();
  if (low.includes('cannot start outlook') || low.includes('com class factory') || low.includes('800401f3') || low.includes('80040154')) {
    return 'Outlook не може да се стартира. Инсталирайте Microsoft Outlook (десктоп) на компютъра със сървъра и влезте в пощенски профил.';
  }
  if (low.includes('operation aborted') || low.includes('rpc') || low.includes('0x80010001')) {
    return 'Outlook е зает или не отговаря. Затворете диалози в Outlook и опитайте отново. Препоръка: дръжте Outlook отворен на сървъра.';
  }
  if (low.includes('profile') || low.includes('logon') || low.includes('mapi')) {
    return 'Няма конфигуриран Outlook профил. Отворете Outlook веднъж, влезте в акаунта и опитайте пак.';
  }
  if (low.includes('not found') && low.includes('data file')) {
    return 'Вътрешна грешка: временният файл за имейла липсва.';
  }
  return t;
}

function logMailEvent(ok, detail) {
  const d = String(detail || '').replace(/[\r\n]+/g, ' ');
  try {
    const line = new Date().toISOString() + (ok ? ' OK ' : ' FAIL ') + d + '\n';
    fs.appendFileSync(path.join(DATA_DIR, 'mail-log.txt'), line, 'utf8');
  } catch (e) {
    try { console.error('mail-log write failed:', e.message); } catch (_) {}
  }
  try {
    const isSkip = /^skip:/i.test(d);
    // 'skip:' = имейлите не са настроени — информационен запис, не грешка.
    writeSystemLog(ok || isSkip ? 'info' : 'warn', 'email', d);
  } catch (_) {}
}

function sendOutlookMail(toEmails, subject, body) {
  return new Promise((resolve) => {
    const toStr = (Array.isArray(toEmails) ? toEmails : [toEmails]).filter(Boolean).join(';');
    if (!toStr) { resolve({ ok: false, error: 'Няма зададени получатели.' }); return; }
    if (!fs.existsSync(MAIL_SCRIPT_PATH)) {
      resolve({ ok: false, error: 'Липсва scripts/send-outlook-mail.ps1' });
      return;
    }
    const tmpFile = path.join(os.tmpdir(), 'dist_mail_' + Date.now() + '_' + Math.random().toString(36).slice(2) + '.json');
    try {
      fs.writeFileSync(tmpFile, JSON.stringify({ to: toStr, subject, body }), 'utf8');
    } catch (e) {
      resolve({ ok: false, error: 'Неуспешен запис на временен файл: ' + e.message });
      return;
    }

    let finished = false;
    const finish = (result) => {
      if (finished) return;
      finished = true;
      try { fs.unlinkSync(tmpFile); } catch (e) {}
      if (result && result.ok) logMailEvent(true, 'to=' + toStr);
      else logMailEvent(false, (result && result.error) || 'unknown');
      resolve(result);
    };

    let ps;
    try {
      // Prefer Windows PowerShell; Outlook COM is most reliable there.
      ps = spawn('powershell.exe', [
        '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass',
        '-File', MAIL_SCRIPT_PATH, '-JsonPath', tmpFile
      ], {
        windowsHide: true,
        env: { ...process.env, POWERSHELL_TELEMETRY_OPTOUT: '1' }
      });
    } catch (e) {
      finish({ ok: false, error: 'Неуспешно стартиране на PowerShell: ' + e.message });
      return;
    }

    let stderr = '';
    let stdout = '';
    ps.stdout.on('data', d => { stdout += d.toString(); });
    ps.stderr.on('data', d => { stderr += d.toString(); });
    ps.on('close', code => {
      if (code === 0) finish({ ok: true });
      else {
        const raw = (stderr || stdout || '').trim() || ('PowerShell завърши с код ' + code);
        finish({ ok: false, error: translateMailError(raw) });
      }
    });
    ps.on('error', err => finish({ ok: false, error: translateMailError(err.message) }));

    setTimeout(() => finish({ ok: false, error: 'Изтече време за изчакване (30 сек). Проверете дали Outlook е инсталиран и отворен.' }), 30000);
  });
}
  return { getNotifyEmails, isEmailNotifyEnabled, mailOneLine, getSmtpSettings, isSmtpConfigured, sendMail, notifyNewRepairRequest, translateMailError, logMailEvent, sendOutlookMail };
}

module.exports = { createMailService };