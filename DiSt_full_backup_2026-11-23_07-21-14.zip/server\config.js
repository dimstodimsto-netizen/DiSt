'use strict';
const path = require('node:path');
const ROOT_DIR = path.resolve(__dirname, '.');

module.exports = Object.freeze({
  ROOT_DIR,
  PORT: process.env.PORT ? Number(process.env.PORT) : 3000,
  PUBLIC_DIR: path.join(ROOT_DIR, 'public'),
  DATA_DIR: path.join(ROOT_DIR, 'data'),
  DB_PATH: path.join(ROOT_DIR, 'data', 'zayavki.db'),
  PID_PATH: path.join(ROOT_DIR, 'server.pid'),
  MAIL_SCRIPT_PATH: path.join(ROOT_DIR, 'scripts', 'send-outlook-mail.ps1'),
  VERIFICATION_PERIOD_DAYS: 60,
  VERIFICATION_WARNING_DAY: 50,
  VERIFICATION_LOCK_DAY: 65,
  VERIFICATION_INITIAL_CODE: process.env.DIST_VERIFICATION_CODE || 'DiSt-60-2026'
});
