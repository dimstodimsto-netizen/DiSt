/**
 * materials-dropdown-ui.js — dropdown списъци + налични материали (helpers)
 * Load AFTER app.js (needs $). Uses S, authFetch, escapeHtml, dropdown* state.
 */
const MATERIALS_KEY = 'available_materials';
const SANITARY_MATERIALS_KEY = 'available_sanitary_materials';
const OFFICE_MATERIALS_KEY = 'available_office_materials';

var DEFAULT_STATUS_LIST = [
  'Не е изпълнена',
  'Изпълнява се',
  'Изчаква материали',
  'За докладна',
  'Изпълнена'
];

// ---- Dropdown списъци ----
function populateSelectWithOptions(selectEl, list) {
  if (!selectEl) return;
  selectEl.innerHTML = '<option value="">— изберете —</option>' +
    list.map(v => '<option value="' + escapeHtml(v) + '">' + escapeHtml(v) + '</option>').join('') +
    '<option value="__other__">+ Друго (ново)...</option>';
}

function refreshKorpusStrukturaSelects() {
  ['sKorpus','fKorpus'].forEach(id => populateSelectWithOptions($(id), dropdownCorpusList));
  ['sStruktura','fStruktura','whStruktura'].forEach(id => populateSelectWithOptions($(id), dropdownStrukturaList));
  populateSelectWithOptions($('fIzpalnitel'), dropdownTechnicianList);
  // Статуси на заявки за ремонт — без "+ Друго" в края на служебния списък
  const statusList = (dropdownStatusList && dropdownStatusList.length) ? dropdownStatusList : DEFAULT_STATUS_LIST;
  const fStatus = $('fStatus');
  if (fStatus) {
    const cur = fStatus.value;
    fStatus.innerHTML = statusList.map(v => '<option value="' + escapeHtml(v) + '">' + escapeHtml(v) + '</option>').join('');
    if (cur && statusList.includes(cur)) fStatus.value = cur;
    else if (cur) {
      // запазваме текуща стойност, ако не е в списъка
      fStatus.innerHTML += '<option value="' + escapeHtml(cur) + '">' + escapeHtml(cur) + '</option>';
      fStatus.value = cur;
    }
  }
  const allStatusFilter = $('allStatusFilter');
  if (allStatusFilter) {
    const curF = allStatusFilter.value;
    allStatusFilter.innerHTML = '<option value="">Всички статуси</option>' +
      statusList.map(v => '<option value="' + escapeHtml(v) + '">' + escapeHtml(v) + '</option>').join('');
    if (curF) allStatusFilter.value = curF;
  }
  const allStrukturaFilter = $('allStrukturaFilter');
  if (allStrukturaFilter) {
    const curS = allStrukturaFilter.value;
    allStrukturaFilter.innerHTML = '<option value="">Всички структури</option>' +
      dropdownStrukturaList.map(v => '<option value="' + escapeHtml(v) + '">' + escapeHtml(v) + '</option>').join('');
    if (curS) allStrukturaFilter.value = curS;
  }
  const uEl = $('newUserStruktura');
  if (uEl) {
    uEl.innerHTML = '<option value="">— без —</option>' +
      dropdownStrukturaList.map(v => '<option value="' + escapeHtml(v) + '">' + escapeHtml(v) + '</option>').join('');
  }
}


/** Добавя полето за статуси в Сървър → падащи менюта, ако липсва в HTML. */
function ensureStatusListInputUI() {
  if (document.getElementById('statusListInput')) return;
  const tech = document.getElementById('technicianListInput');
  if (!tech || !tech.parentElement) return;
  const wrap = document.createElement('div');
  wrap.className = 'field';
  wrap.style.marginTop = '12px';
  wrap.innerHTML =
    '<label>Статуси на заявки за ремонт (по един на ред)</label>' +
    '<textarea id="statusListInput" rows="6" placeholder="напр.\\nНе е изпълнена\\nИзпълнява се\\nИзчаква материали\\nЗа докладна\\nИзпълнена\\nДруго"></textarea>' +
    '<div class="hint" style="margin-top:6px;">Тези стойности се показват в полето „Статус“ при редакция на заявка и във филтъра „Всички заявки“.</div>';
  tech.parentElement.insertAdjacentElement('afterend', wrap);
}

async function loadDropdownSettings() {
  try {
    const r = (typeof authFetch === 'function')
      ? await authFetch('/api/dropdown-settings')
      : await fetch('/api/dropdown-settings', { credentials: 'same-origin' });
    if (r.ok) {
      const data = await r.json();
      dropdownCorpusList = Array.isArray(data.corpus) ? data.corpus : [];
      dropdownStrukturaList = Array.isArray(data.struktura) ? data.struktura : [];
      dropdownTechnicianList = Array.isArray(data.technicians) ? data.technicians : [];
      dropdownStatusList = Array.isArray(data.statuses) && data.statuses.length
        ? data.statuses
        : DEFAULT_STATUS_LIST.slice();
    } else {
      console.warn('loadDropdownSettings HTTP', r.status);
    }
  } catch (e) {
    console.warn('loadDropdownSettings:', e);
  }
  if (!dropdownStatusList.length) dropdownStatusList = DEFAULT_STATUS_LIST.slice();
  refreshKorpusStrukturaSelects();
  ensureStatusListInputUI();
}

function setSelectValueWithFallback(selectEl, otherInputEl, value) {
  if (!selectEl) return;
  if (!value) {
    selectEl.value = '';
    if (otherInputEl) { otherInputEl.style.display = 'none'; otherInputEl.value = ''; }
    return;
  }
  const has = Array.from(selectEl.options).some(o => o.value === value);
  if (has) {
    selectEl.value = value;
    if (otherInputEl) { otherInputEl.style.display = 'none'; otherInputEl.value = ''; }
  } else {
    selectEl.value = '__other__';
    if (otherInputEl) { otherInputEl.style.display = ''; otherInputEl.value = value; }
  }
}

function getSelectValueWithFallback(selectEl, otherInputEl) {
  if (!selectEl) return '';
  if (selectEl.value === '__other__') {
    if (otherInputEl) return otherInputEl.value.trim();
    return '';
  }
  return selectEl.value;
}

function wireOtherToggle(selectId, otherId) {
  $(selectId).addEventListener('change', () => {
    const other = $(otherId);
    if ($(selectId).value === '__other__') { 
      if (other) { other.style.display = ''; other.value = ''; other.focus(); }
    } else {
      if (other) { other.style.display = 'none'; other.value = ''; }
    }
  });
}

// ---- Материали ----

/** true само ако вече имаме клиентска сесия/роля — иначе KV ще върне 401 */
function hasClientSessionForKv() {
  try {
    if (typeof currentRole !== 'undefined' && currentRole) return true;
    if (typeof sessionState !== 'undefined' && sessionState && sessionState.currentRole) return true;
    if (typeof loadSessionToken === 'function') {
      var t = loadSessionToken();
      if (t) return true;
    }
  } catch (_) {}
  return false;
}

async function getAvailableMaterials() {
  if (!hasClientSessionForKv()) return [];

  try {
    const r = await S.get(MATERIALS_KEY);
    if (!r || !r.value) return [];
    const parsed = JSON.parse(r.value);
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    var msg = String(e && e.message || e || '');
    if (/HTTP 401|Unauthorized/i.test(msg)) return [];
    console.error('Грешка при зареждане на материали:', e);
    return [];
  }
}

async function saveAvailableMaterials(list) {
  await S.set(MATERIALS_KEY, JSON.stringify(list));
}

// ---- Санитарни материали ----
async function getAvailableSanitaryMaterials() {
  if (!hasClientSessionForKv()) return [];

  try {
    const r = await S.get(SANITARY_MATERIALS_KEY);
    if (!r || !r.value) return [];
    const parsed = JSON.parse(r.value);
    return Array.isArray(parsed) ? parsed : [];
  } catch(e) {
    console.error('Грешка при зареждане на санитарни материали:', e);
    return [];
  }
}

async function saveAvailableSanitaryMaterials(list) {
  await S.set(SANITARY_MATERIALS_KEY, JSON.stringify(list));
}

// ---- Канцеларски материали ----
async function getAvailableOfficeMaterials() {
  if (!hasClientSessionForKv()) return [];

  try {
    const r = await S.get(OFFICE_MATERIALS_KEY);
    if (!r || !r.value) return [];
    const parsed = JSON.parse(r.value);
    return Array.isArray(parsed) ? parsed : [];
  } catch(e) {
    console.error('Грешка при зареждане на канцеларски материали:', e);
    return [];
  }
}

async function saveAvailableOfficeMaterials(list) {
  await S.set(OFFICE_MATERIALS_KEY, JSON.stringify(list));
}


window.MATERIALS_KEY = MATERIALS_KEY;
window.SANITARY_MATERIALS_KEY = SANITARY_MATERIALS_KEY;
window.OFFICE_MATERIALS_KEY = OFFICE_MATERIALS_KEY;
window.DEFAULT_STATUS_LIST = DEFAULT_STATUS_LIST;
window.populateSelectWithOptions = populateSelectWithOptions;
window.refreshKorpusStrukturaSelects = refreshKorpusStrukturaSelects;
window.ensureStatusListInputUI = ensureStatusListInputUI;
window.loadDropdownSettings = loadDropdownSettings;
window.setSelectValueWithFallback = setSelectValueWithFallback;
window.getSelectValueWithFallback = getSelectValueWithFallback;
window.wireOtherToggle = wireOtherToggle;
window.hasClientSessionForKv = hasClientSessionForKv;
window.getAvailableMaterials = getAvailableMaterials;
window.saveAvailableMaterials = saveAvailableMaterials;
window.getAvailableSanitaryMaterials = getAvailableSanitaryMaterials;
window.saveAvailableSanitaryMaterials = saveAvailableSanitaryMaterials;
window.getAvailableOfficeMaterials = getAvailableOfficeMaterials;
window.saveAvailableOfficeMaterials = saveAvailableOfficeMaterials;
