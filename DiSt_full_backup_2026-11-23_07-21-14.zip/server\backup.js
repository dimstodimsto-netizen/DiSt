'use strict';

/** Backup snapshots, manifest verification, ZIP packaging and retention. */
function createBackupModule({ fs, path, os, crypto, spawnSync, ROOT_DIR, DATA_DIR, DB_PATH, db, DatabaseSync, kvGet, kvListByPrefix, getRecordsIndexSafe, getUserIdsServer, APP_VERSION }) {
/** Пълен бекъп + проверка за възстановимост. */
function sha256File(filePath) {
  const hash = crypto.createHash('sha256');
  const fd = fs.openSync(filePath, 'r');
  try {
    const buf = Buffer.allocUnsafe(1024 * 1024);
    let n = 0;
    do {
      n = fs.readSync(fd, buf, 0, buf.length, null);
      if (n > 0) hash.update(buf.subarray(0, n));
    } while (n > 0);
  } finally {
    fs.closeSync(fd);
  }
  return hash.digest('hex');
}

function copyDirRecursiveForBackup(src, dest) {
  if (!fs.existsSync(src)) return 0;
  let count = 0;
  const st = fs.lstatSync(src);
  if (st.isSymbolicLink()) throw new Error('Символни връзки не се архивират: ' + src);
  if (!st.isDirectory()) {
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.copyFileSync(src, dest);
    return 1;
  }
  fs.mkdirSync(dest, { recursive: true });
  const entries = fs.readdirSync(src);
  for (const name of entries) {
    if (name === '.' || name === '..') continue;
    if (/^(node_modules|\.git)$/i.test(name)) continue;
    if (/\.(map|log)$/i.test(name)) continue;
    const from = path.join(src, name);
    const to = path.join(dest, name);
    const entSt = fs.lstatSync(from);
    if (entSt.isSymbolicLink()) throw new Error('Символни връзки не се архивират: ' + from);
    if (entSt.isDirectory()) count += copyDirRecursiveForBackup(from, to);
    else if (entSt.isFile()) {
      fs.copyFileSync(from, to);
      count++;
    } else throw new Error('Неподдържан файлов тип при архивиране: ' + from);
  }
  return count;
}

// Консистентен snapshot на живата база. Ако VACUUM INTO не е наличен,
// използваме файлово копие само като последен fallback.
function snapshotDatabaseTo(dest) {
  try { if (fs.existsSync(dest)) fs.unlinkSync(dest); } catch (_) {}
  try {
    db.prepare('VACUUM INTO ?').run(dest);
  } catch (e) {
    try { fs.unlinkSync(dest); } catch (_) {}
    fs.copyFileSync(DB_PATH, dest);
  }
  try {
    const copy = new DatabaseSync(dest);
    try { copy.exec('DELETE FROM sessions'); } finally { copy.close(); }
  } catch (_) {}
}

function verifyDatabaseFile(dbPath) {
  const result = { ok: false, integrity: null, tables: [], size: 0, error: null };
  try {
    result.size = fs.statSync(dbPath).size;
    const testDb = new DatabaseSync(dbPath, { readOnly: true });
    try {
      const integrity = testDb.prepare('PRAGMA integrity_check').get();
      result.integrity = integrity && (integrity.integrity_check || integrity['integrity_check']) || null;
      result.tables = testDb.prepare("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").all().map(r => r.name);
      result.ok = String(result.integrity).toLowerCase() === 'ok' && result.tables.includes('kv') && result.tables.includes('system_log');
    } finally {
      testDb.close();
    }
  } catch (e) {
    result.error = e.message || String(e);
  }
  return result;
}

function getBackupMetadata() {
  let records = 0, users = 0, warehouse = 0;
  try { records = getRecordsIndexSafe().length; } catch (_) {}
  try { users = getUserIdsServer().length; } catch (_) {}
  try {
    const raw = kvGet('wh-index');
    const arr = raw ? JSON.parse(raw) : [];
    warehouse = Array.isArray(arr) ? arr.length : 0;
  } catch (_) {}
  return {
    application: APP_VERSION,
    createdAt: new Date().toISOString(),
    host: os.hostname(),
    platform: process.platform,
    node: process.version,
    records,
    users,
    warehouse,
    database: 'SQLite',
    databasePath: 'zayavki.db'
  };
}

function writeBackupManifest(stageDir, stamp, dependencyCheck) {
  const files = [];
  function walk(dir, relBase) {
    for (const name of fs.readdirSync(dir)) {
      const full = path.join(dir, name);
      const rel = relBase ? path.join(relBase, name) : name;
      const st = fs.statSync(full);
      if (st.isDirectory()) walk(full, rel);
      else files.push({ path: rel.replace(/\\/g, '/'), size: st.size, sha256: sha256File(full) });
    }
  }
  walk(stageDir, '');
  const manifest = {
    format: 'DiSt-Recovery-1',
    backupId: stamp,
    ...getBackupMetadata(),
    dependencyCheck: dependencyCheck || null,
    files
  };
  fs.writeFileSync(path.join(stageDir, 'backup-manifest.json'), JSON.stringify(manifest, null, 2), 'utf8');
  return manifest;
}

function extractZipToDirForVerification(zipPath, destDir) {
  fs.mkdirSync(destDir, { recursive: true });
  if (process.platform === 'win32') {
    const psCmd = "Expand-Archive -LiteralPath '" + zipPath.replace(/'/g, "''") + "' -DestinationPath '" + destDir.replace(/'/g, "''") + "' -Force";
    const ps = spawnSync('powershell.exe', [
      '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', psCmd
    ], { windowsHide: true, encoding: 'utf8', timeout: 180000 });
    if (ps.status !== 0) throw new Error('Expand-Archive failed: ' + String(ps.stderr || ps.stdout || ps.status).slice(0, 500));
    return;
  }
  const unzip = spawnSync('unzip', ['-o', '-q', zipPath, '-d', destDir], { encoding: 'utf8', timeout: 180000 });
  if (unzip.status !== 0) throw new Error('unzip failed: ' + String(unzip.stderr || unzip.stdout || unzip.status).slice(0, 500));
}

function runDependencyCheck() {
  const script = path.join(ROOT_DIR, 'scripts', 'depcheck.js');
  if (!fs.existsSync(script)) throw new Error('Липсва scripts\\depcheck.js. Не може да се създаде backup без проверка на зависимостите.');
  const run = spawnSync(process.execPath, [script, '--json'], {
    cwd: ROOT_DIR, windowsHide: true, encoding: 'utf8', timeout: 30000, maxBuffer: 2 * 1024 * 1024
  });
  if (run.error || run.status !== 0) {
    throw new Error('Проверката на зависимостите е неуспешна: ' + String(run.stderr || run.stdout || (run.error && run.error.message) || run.status).slice(0, 1200));
  }
  let result;
  try { result = JSON.parse(run.stdout || '{}'); } catch (_) { throw new Error('depcheck.js върна невалиден JSON резултат.'); }
  if (!result || result.ok !== true) throw new Error('depcheck.js откри проблеми: ' + JSON.stringify(result && result.errors || []));
  return {
    ok: true,
    scannedFiles: Number(result.scannedFiles) || 0,
    references: Number(result.references) || 0,
    externalPackages: Array.isArray(result.externalPackages) ? result.externalPackages : [],
    checkedAt: new Date().toISOString()
  };
}

function verifyBackupZip(zipPath) {
  const tmp = path.join(DATA_DIR, 'backups', '_verify_' + Date.now() + '_' + Math.random().toString(16).slice(2));
  const result = { ok: false, zip: path.basename(zipPath), sha256: null, database: null, manifest: null, error: null };
  try {
    result.sha256 = sha256File(zipPath);
    extractZipToDirForVerification(zipPath, tmp);
    const manifestPath = path.join(tmp, 'backup-manifest.json');
    if (!fs.existsSync(manifestPath)) throw new Error('Липсва backup-manifest.json.');
    const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
    result.manifest = { format: manifest.format, backupId: manifest.backupId, files: Array.isArray(manifest.files) ? manifest.files.length : 0 };
    if (manifest.format !== 'DiSt-Recovery-1' || !Array.isArray(manifest.files)) throw new Error('Невалиден manifest.');
    const expectedPaths = new Set();
    for (const item of manifest.files) {
      if (!item || typeof item.path !== 'string' || item.path.includes('\\') || item.path.startsWith('/') || item.path.split('/').some(part => !part || part === '.' || part === '..')) {
        throw new Error('Небезопасен път във manifest: ' + (item && item.path));
      }
      const key = item.path.toLowerCase();
      if (expectedPaths.has(key)) throw new Error('Дублиран файл във manifest: ' + item.path);
      expectedPaths.add(key);
      const fp = path.join(tmp, ...item.path.split('/'));
      if (!fs.existsSync(fp) || !fs.statSync(fp).isFile()) throw new Error('Липсва файл от manifest: ' + item.path);
      const st = fs.statSync(fp);
      if (Number(item.size) !== st.size) throw new Error('Грешен размер: ' + item.path);
      if (sha256File(fp) !== item.sha256) throw new Error('SHA-256 mismatch: ' + item.path);
    }
    const actualPaths = [];
    function collectActual(dir, relBase) {
      for (const name of fs.readdirSync(dir)) {
        const full = path.join(dir, name);
        const rel = relBase ? relBase + '/' + name : name;
        const st = fs.lstatSync(full);
        if (st.isSymbolicLink()) throw new Error('Архивът съдържа символна връзка: ' + rel);
        if (st.isDirectory()) collectActual(full, rel);
        else if (st.isFile()) { if (rel !== 'backup-manifest.json') actualPaths.push(rel); }
        else throw new Error('Архивът съдържа неподдържан файл: ' + rel);
      }
    }
    collectActual(tmp, '');
    if (actualPaths.length !== expectedPaths.size) throw new Error('Manifest-ът не описва всички файлове в архива.');
    for (const rel of actualPaths) if (!expectedPaths.has(rel.toLowerCase())) throw new Error('Файлът не е описан в manifest: ' + rel);
    if (manifest.dependencyCheck) {
      const depcheckPath = path.join(tmp, 'scripts', 'depcheck.js');
      if (!fs.existsSync(depcheckPath)) throw new Error('Manifest-ът декларира depcheck, но скриптът липсва в архива.');
      const dep = spawnSync(process.execPath, [depcheckPath, '--json'], {
        cwd: tmp, windowsHide: true, encoding: 'utf8', timeout: 30000, maxBuffer: 2 * 1024 * 1024
      });
      if (dep.error || dep.status !== 0) throw new Error('depcheck върху разархивираното копие е неуспешен: ' + String(dep.stderr || dep.stdout || (dep.error && dep.error.message) || dep.status).slice(0, 1000));
      let depResult;
      try { depResult = JSON.parse(dep.stdout || '{}'); } catch (_) { throw new Error('depcheck в архива върна невалиден JSON.'); }
      if (!depResult || depResult.ok !== true) throw new Error('depcheck откри липсващи зависимости в самия архив.');
      result.dependencyCheck = { ok: true, scannedFiles: depResult.scannedFiles, references: depResult.references };
    }
    const sidecarPath = zipPath + '.sha256';
    if (fs.existsSync(sidecarPath)) {
      const sidecar = fs.readFileSync(sidecarPath, 'utf8').trim();
      const match = sidecar.match(/^([a-f0-9]{64})\s+(.+)$/i);
      if (!match || match[2].trim() !== path.basename(zipPath) || match[1].toLowerCase() !== result.sha256) {
        throw new Error('Външният SHA-256 файл липсва/не съвпада с ZIP архива.');
      }
      result.sidecar = true;
    } else result.sidecar = false;
    const dbPath = path.join(tmp, 'zayavki.db');
    if (!fs.existsSync(dbPath)) throw new Error('Липсва zayavki.db.');
    result.database = verifyDatabaseFile(dbPath);
    if (!result.database.ok) throw new Error('Проверката на SQLite базата е неуспешна: ' + (result.database.error || result.database.integrity));
    result.ok = true;
  } catch (e) {
    result.error = e.message || String(e);
  } finally {
    try { fs.rmSync(tmp, { recursive: true, force: true }); } catch (_) {}
  }
  return result;
}


/** Създава ZIP от директория. Избягва бъга на Compress-Archive с LastWriteTime/DateTimeOffset. */
function createZipFromDirectory(stageDir, zipPath) {
  try { if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath); } catch (_) {}
  const stageEsc = String(stageDir).replace(/'/g, "''");
  const zipEsc = String(zipPath).replace(/'/g, "''");

  if (process.platform === 'win32') {
    // 1) Нормализира timestamps в диапазон, валиден за ZIP (1980–2100)
    // 2) ZipFile.CreateFromDirectory — по-стабилен от Compress-Archive
    const psCmd =
      "Add-Type -AssemblyName System.IO.Compression.FileSystem; " +
      "$stage = '" + stageEsc + "'; $zip = '" + zipEsc + "'; " +
      "Get-ChildItem -LiteralPath $stage -Recurse -Force | ForEach-Object { " +
      "  try { $y = $_.LastWriteTime.Year; if ($y -lt 1980 -or $y -gt 2100) { $_.LastWriteTime = [DateTime]::Now } } catch {} " +
      "}; " +
      "if (Test-Path -LiteralPath $zip) { Remove-Item -LiteralPath $zip -Force }; " +
      "[System.IO.Compression.ZipFile]::CreateFromDirectory($stage, $zip); " +
      "if (-not (Test-Path -LiteralPath $zip)) { throw 'ZipFile.CreateFromDirectory produced no file' }";
    const ps = spawnSync('powershell.exe', [
      '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', psCmd
    ], { windowsHide: true, encoding: 'utf8', timeout: 180000 });
    if (ps.status === 0 && fs.existsSync(zipPath) && fs.statSync(zipPath).size > 100) {
      return;
    }
    const err1 = String(ps.stderr || ps.stdout || ('status=' + ps.status)).slice(0, 400);
    // Fallback: tar.exe (Windows 10+)
    const tar = spawnSync('tar.exe', ['-a', '-c', '-f', zipPath, '-C', stageDir, '.'], {
      windowsHide: true, encoding: 'utf8', timeout: 180000
    });
    if (tar.status === 0 && fs.existsSync(zipPath) && fs.statSync(zipPath).size > 100) {
      return;
    }
    throw new Error('ZIP create failed. ZipFile: ' + err1 + ' | tar: ' + String(tar.stderr || tar.stdout || tar.status).slice(0, 200));
  }

  // Linux/mac (тестови среди): системният zip
  const z = spawnSync('zip', ['-r', '-q', zipPath, '.'], {
    cwd: stageDir, encoding: 'utf8', timeout: 180000
  });
  if (z.status !== 0 || !fs.existsSync(zipPath) || fs.statSync(zipPath).size <= 100) {
    throw new Error('zip failed: ' + String(z.stderr || z.stdout || z.status).slice(0, 400));
  }
}

function createDownloadableBackup(options) {
  options = options || {};
  if (!fs.existsSync(DB_PATH)) {
    const err = new Error('Базата данни не е намерена.');
    err.status = 404;
    throw err;
  }
  // Dependency audit is a required pre-flight gate for every new full backup.
  const dependencyCheck = runDependencyCheck();
  const backupDir = path.join(DATA_DIR, 'backups');
  if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });
  const now = new Date();
  const stamp = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0') + '-' + String(now.getDate()).padStart(2, '0') + '_' +
    String(now.getHours()).padStart(2, '0') + '-' + String(now.getMinutes()).padStart(2, '0') + '-' + String(now.getSeconds()).padStart(2, '0');

  const dbCopy = path.join(backupDir, 'zayavki_backup_' + stamp + '.db');
  snapshotDatabaseTo(dbCopy);
  const dbCheck = verifyDatabaseFile(dbCopy);
  if (!dbCheck.ok) throw new Error('Новият DB backup не премина integrity_check: ' + (dbCheck.error || dbCheck.integrity));

  const settingsExport = {};
  const settingKeys = ['settings:notifyEmails','settings:emailNotifyEnabled','settings:corpusList','settings:strukturaList','settings:technicianList','settings:statusList','settings:materialLocks','available_materials','available_sanitary_materials','available_office_materials','maintenance_materials'];
  for (const k of settingKeys) {
    try { const v = kvGet(k); if (v != null) { try { settingsExport[k] = JSON.parse(v); } catch (_) { settingsExport[k] = v; } } } catch (_) {}
  }
  // Keep the monthly order-planning tables in the supplemental settings export as well as the full SQLite backup.
  try {
    for (const row of kvListByPrefix('required-materials:')) {
      try { settingsExport[row.key] = JSON.parse(row.value); } catch (_) { settingsExport[row.key] = row.value; }
    }
  } catch (_) {}
  const settingsPath = path.join(backupDir, 'settings_export_' + stamp + '.json');
  fs.writeFileSync(settingsPath, JSON.stringify(settingsExport, null, 2), 'utf8');

  const restoreLines = [
    'DiSt — ВЪЗСТАНОВЯВАНЕ НА СИСТЕМАТА (Recovery-1)',
    '=================================================',
    '',
    '1. СПРЕТЕ сървъра преди възстановяване.',
    '2. До ZIP архива трябва да има sidecar файл със същото име плюс .sha256.',
    '   Пример: DiSt_full_backup_YYYY-MM-DD_HH-MM-SS.zip.sha256',
    '3. Разархивирайте ZIP в отделна временна папка и проверете целостта:',
    '   node scripts\\VERIFY_BACKUP.js "пълен-път-към-архива.zip"',
    '   Скриптът проверява manifest, всички файлове, SHA-256, sidecar (ако е наличен) и SQLite.',
    '4. За възстановяване на данните копирайте zayavki.db в data\\zayavki.db.',
    '5. За възстановяване на програмата копирайте server.js, public\\, server\\ и scripts\\.',
    '6. НЕ заменяйте node\\ и logs\\. Не заменяйте data\\ освен zayavki.db.',
    '7. Стартирайте сървъра и отворете /api/admin/health.',
    '',
    'ПРЕДИ ПУСКАНЕ:',
    '- На възстановената база изпълнете scripts\\VERIFY_DATABASE.bat.',
    '- Изпълнете scripts\\DEPCHECK.bat за статична проверка на модулните зависимости.',
    '- Проверете броя заявки/потребители спрямо backup-manifest.json.',
    '',
    'Backup ID: ' + stamp,
    'Създаден: ' + new Date().toISOString(),
    'Тип: ' + (options.source || 'manual')
  ];
  const restorePath = path.join(backupDir, 'RESTORE_' + stamp + '.txt');
  fs.writeFileSync(restorePath, restoreLines.join('\n'), 'utf8');

  const zipName = 'DiSt_full_backup_' + stamp + '.zip';
  const zipPath = path.join(backupDir, zipName);
  const stageDir = path.join(backupDir, '_stage_' + stamp);
  try {
    if (fs.existsSync(stageDir)) fs.rmSync(stageDir, { recursive: true, force: true });
    fs.mkdirSync(stageDir, { recursive: true });
    fs.copyFileSync(dbCopy, path.join(stageDir, 'zayavki.db'));
    fs.copyFileSync(settingsPath, path.join(stageDir, 'settings_export.json'));
    fs.copyFileSync(restorePath, path.join(stageDir, 'RESTORE.txt'));
    // Required root-level application files are copied explicitly; optional launchers are copied when present.
    const rootFiles = ['server.js','package.json','README.txt','Zayavki.exe','START.bat','START_SERVER.bat','START_HIDDEN.vbs','STOP_SERVER.bat','WATCHDOG.bat','INSTALL_WATCHDOG_TASK.bat','ico.ico'];
    for (const file of rootFiles) {
      const source = path.join(ROOT_DIR, file);
      if (!fs.existsSync(source)) {
        if (file === 'server.js') throw new Error('Липсва задължителният файл server.js.');
        continue;
      }
      const st = fs.lstatSync(source);
      if (!st.isFile() || st.isSymbolicLink()) throw new Error('Невалиден root файл за архивиране: ' + file);
      fs.copyFileSync(source, path.join(stageDir, file));
    }
    for (const dir of ['public','server','scripts']) {
      const source = path.join(ROOT_DIR, dir);
      if (!fs.existsSync(source) || !fs.lstatSync(source).isDirectory()) throw new Error('Липсва задължителната директория за архивиране: ' + dir);
      copyDirRecursiveForBackup(source, path.join(stageDir, dir));
    }
    writeBackupManifest(stageDir, stamp, dependencyCheck);

    createZipFromDirectory(stageDir, zipPath);
    const verification = verifyBackupZip(zipPath);
    if (!verification.ok) throw new Error('Пълният backup не премина проверката: ' + verification.error);
    const sidecar = zipPath + '.sha256';
    fs.writeFileSync(sidecar, verification.sha256 + '  ' + zipName + '\r\n', 'utf8');
    const sidecarVerification = verifyBackupZip(zipPath);
    if (!sidecarVerification.ok || !sidecarVerification.sidecar) {
      throw new Error('Пълният backup не премина проверката на външния SHA-256 файл: ' + (sidecarVerification.error || 'sidecar missing'));
    }
    const manifest = JSON.parse(fs.readFileSync(path.join(stageDir, 'backup-manifest.json'), 'utf8'));
    fs.writeFileSync(path.join(backupDir, 'backup-manifest_' + stamp + '.json'), JSON.stringify(manifest, null, 2), 'utf8');
    return { path: zipPath, fileName: zipName, size: fs.statSync(zipPath).size, stamp, format: 'zip', verified: true, sha256: verification.sha256, sidecarVerified: true, dependencyCheck, database: dbCheck };
  } finally {
    try { fs.rmSync(stageDir, { recursive:true, force:true }); } catch (_) {}
    try { fs.unlinkSync(settingsPath); } catch (_) {}
    try { fs.unlinkSync(restorePath); } catch (_) {}
    try { fs.unlinkSync(dbCopy); } catch (_) {}
  }
}

/** Изтрива стари ъпдейт-бекъпи и излишни файлове; пази последните N. */
function cleanupOldServerFiles(opts) {
  opts = opts || {};
  const keepUpdateDirs = opts.keepUpdateDirs != null ? opts.keepUpdateDirs : 3;
  const keepDbBackups = opts.keepDbBackups != null ? opts.keepDbBackups : 30;
  const removed = [];
  const errors = [];

  // data/update-backups — директории по време
  try {
    const ub = path.join(DATA_DIR, 'update-backups');
    if (fs.existsSync(ub)) {
      const dirs = fs.readdirSync(ub)
        .map(name => ({ name, full: path.join(ub, name) }))
        .filter(d => {
          try { return fs.statSync(d.full).isDirectory(); } catch (_) { return false; }
        })
        .map(d => {
          let mtime = 0;
          try { mtime = fs.statSync(d.full).mtimeMs; } catch (_) {}
          return { ...d, mtime };
        })
        .sort((a, b) => b.mtime - a.mtime);
      dirs.slice(keepUpdateDirs).forEach(d => {
        try {
          fs.rmSync(d.full, { recursive: true, force: true });
          removed.push('update-backups/' + d.name);
        } catch (e) {
          errors.push('update-backups/' + d.name + ': ' + (e.message || e));
        }
      });
    }
  } catch (e) {
    errors.push('update-backups: ' + (e.message || e));
  }

  // data/backups — стари .db / .zip бекъпи
  try {
    const bd = path.join(DATA_DIR, 'backups');
    if (fs.existsSync(bd)) {
      const files = fs.readdirSync(bd)
        .filter(n => /\\.(db|zip)$/i.test(n) && /backup|zayavki/i.test(n))
        .map(name => {
          const full = path.join(bd, name);
          let mtime = 0;
          try { mtime = fs.statSync(full).mtimeMs; } catch (_) {}
          return { name, full, mtime };
        })
        .sort((a, b) => b.mtime - a.mtime);
      files.slice(keepDbBackups).forEach(f => {
        try {
          fs.unlinkSync(f.full);
          removed.push('backups/' + f.name);
          for (const extra of [f.name + '.sha256']) {
            try { fs.unlinkSync(path.join(bd, extra)); } catch (_) {}
          }
          const m = f.name.match(/^DiSt_full_backup_(.+)\.zip$/i);
          if (m) { try { fs.unlinkSync(path.join(bd, 'backup-manifest_' + m[1] + '.json')); } catch (_) {} }
        } catch (e) {
          errors.push('backups/' + f.name + ': ' + (e.message || e));
        }
      });
    }
  } catch (e) {
    errors.push('backups: ' + (e.message || e));
  }

  // public.zip в корена (стар артефакт)
  try {
    const pz = path.join(ROOT_DIR, 'public.zip');
    if (fs.existsSync(pz)) {
      fs.unlinkSync(pz);
      removed.push('public.zip');
    }
  } catch (e) {
    errors.push('public.zip: ' + (e.message || e));
  }

  // Временни / остарели .txt .log .tmp в data/ и корена (без критични файлове)
  const KEEP_TXT = new Set([
    'initial_admin_credentials.txt',
    'server-heartbeat.txt'
  ]);
  const TEMP_RE = /^(dist_logs_|mail-log|crash|debug|temp|tmp|restore_|RESTORE_)/i;
  const TEMP_EXT = /\.(txt|log|tmp|bak|old)$/i;

  function tryUnlink(full, label) {
    try {
      if (!fs.existsSync(full)) return;
      const st = fs.statSync(full);
      if (!st.isFile()) return;
      fs.unlinkSync(full);
      removed.push(label);
    } catch (e) {
      errors.push(label + ': ' + (e.message || e));
    }
  }

  try {
    // data/ — остарели логове и текстови артефакти
    if (fs.existsSync(DATA_DIR)) {
      for (const name of fs.readdirSync(DATA_DIR)) {
        const lower = name.toLowerCase();
        if (KEEP_TXT.has(lower) || KEEP_TXT.has(name)) continue;
        if (name === 'zayavki.db' || name === 'zayavki.db-wal' || name === 'zayavki.db-shm') continue;
        if (name === 'backups' || name === 'update-backups') continue;
        const full = path.join(DATA_DIR, name);
        let st;
        try { st = fs.statSync(full); } catch (_) { continue; }
        if (!st.isFile()) continue;
        const ageDays = (Date.now() - st.mtimeMs) / (24 * 60 * 60 * 1000);
        const isTempName = TEMP_RE.test(name) || /^mail-log/i.test(name) || /^dist_logs/i.test(name);
        const isOldExt = TEMP_EXT.test(name) && ageDays >= 7;
        // mail-log.txt — винаги ротация ако > 2 MB или по-стар от 14 дни
        if (/^mail-log/i.test(name)) {
          if (st.size > 2 * 1024 * 1024 || ageDays >= 14) tryUnlink(full, 'data/' + name);
          continue;
        }
        if (isTempName || isOldExt) {
          tryUnlink(full, 'data/' + name);
        }
      }
    }
  } catch (e) {
    errors.push('data temp: ' + (e.message || e));
  }

  try {
    // Корен на инсталацията — dist_logs_*.txt, *.tmp, стари RESTORE_*.txt
    if (fs.existsSync(ROOT_DIR)) {
      for (const name of fs.readdirSync(ROOT_DIR)) {
        if (name === 'server.js' || name === 'package.json' || name === 'Zayavki.exe') continue;
        if (name === 'node' || name === 'public' || name === 'server' || name === 'scripts' || name === 'data') continue;
        const full = path.join(ROOT_DIR, name);
        let st;
        try { st = fs.statSync(full); } catch (_) { continue; }
        if (!st.isFile()) continue;
        if (/^dist_logs_/i.test(name) || /\.(tmp|log)$/i.test(name) || /^RESTORE_.*\.txt$/i.test(name)) {
          tryUnlink(full, name);
        }
      }
    }
  } catch (e) {
    errors.push('root temp: ' + (e.message || e));
  }

  return { removed, removedCount: removed.length, errors };
}


/** Зарежда имена на материали от KV списък (масив от string или {name,code}). */

  return { sha256File, copyDirRecursiveForBackup, snapshotDatabaseTo, verifyDatabaseFile, getBackupMetadata, writeBackupManifest, extractZipToDirForVerification, runDependencyCheck, verifyBackupZip, createZipFromDirectory, createDownloadableBackup, cleanupOldServerFiles };
}
module.exports = { createBackupModule };
