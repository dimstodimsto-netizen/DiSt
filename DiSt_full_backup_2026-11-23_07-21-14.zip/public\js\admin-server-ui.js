// DiSt remote administration UI module; loaded after app.js.

window.dismissUncleanShutdownBanner = function dismissUncleanShutdownBanner() {
  const el = document.getElementById('uncleanShutdownBanner');
  if (el) el.style.display = 'none';
  try { sessionStorage.setItem('dist_unclean_banner_dismissed', '1'); } catch (_) {}
};

async function checkUncleanShutdownBanner() {
  if (currentRole !== 'admin' || !authToken) return;
  try {
    if (sessionStorage.getItem('dist_unclean_banner_dismissed') === '1') return;
  } catch (_) {}
  try {
    const r = await authFetch('/api/admin/stability-alert');
    if (!r.ok) return;
    const d = await r.json().catch(() => ({}));
    if (!d.show) return;
    const el = document.getElementById('uncleanShutdownBanner');
    const tx = document.getElementById('uncleanShutdownBannerText');
    if (!el) return;
    let when = '';
    if (d.lastUncleanShutdown) {
      when = formatDisplayDateTime(d.lastUncleanShutdown.atIso || d.lastUncleanShutdown.at);
      if (d.lastUncleanShutdown.heartbeat) {
        when += ' · ' + (typeof formatHeartbeatLine === 'function'
          ? formatHeartbeatLine(d.lastUncleanShutdown.heartbeat)
          : String(d.lastUncleanShutdown.heartbeat));
      }
    }
    const n24 = d.uncleanShutdowns24h != null ? d.uncleanShutdowns24h : '—';
    if (tx) {
      tx.textContent = '⚠ Сървърът е бил спрян ненормално' +
        (when ? ' (последно: ' + when + ')' : '') +
        '. За 24ч: ' + n24 + ' запис(а). Проверете Лог / Диагностика / IT.';
    }
    el.style.display = 'block';
  } catch (_) {}
}

async function refreshRemoteHealth() {
  const el = document.getElementById('remoteHealthStatus');
  if (!el) return;
  el.textContent = 'Зареждане...';
  try {
    const r = await authFetch('/api/admin/health');
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || ('HTTP ' + r.status));
    const lastBak = d.backups && d.backups.last
      ? (d.backups.last.name + ' (' + formatBytes(d.backups.last.size) + ', ' + new Date(d.backups.last.mtime).toLocaleString('bg-BG') + ')')
      : 'няма';
    const update = d.lastAppliedUpdate && typeof d.lastAppliedUpdate === 'object' ? d.lastAppliedUpdate : null;
    const lastUpdateText = update
      ? ((update.version || (Array.isArray(update.files) && update.files.length ? 'файлове: ' + update.files.slice(0, 3).join(', ') + (update.files.length > 3 ? '…' : '') : 'версията не е записана')) + ' · ' +
        (update.appliedAt ? new Date(update.appliedAt).toLocaleString('bg-BG') : 'времето не е записано') +
        (update.appliedBy ? ' · ' + update.appliedBy : ''))
      : 'няма запис';
    const email = d.emailNotifyEnabled === true ? 'включени' : (d.emailNotifyEnabled === false ? 'изключени' : '—');
    el.innerHTML =
      '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:8px 16px;">' +
      '<div><b>Статус</b><br>✅ Онлайн</div>' +
      '<div><b>Uptime</b><br>' + escapeHtml(formatUptime(d.uptimeSec)) + '</div>' +
      (d.startedAt ? '<div><b>Старт</b><br>' + escapeHtml(formatDisplayDateTime(d.startedAt)) + '</div>' : '') +
      '<div><b>PID / порт</b><br>' + escapeHtml(String(d.pid)) + ' / ' + escapeHtml(String(d.port)) + '</div>' +
      '<div><b>Node</b><br>' + escapeHtml(String(d.node || '')) + '</div>' +
      '<div><b>Последно приложено обновление</b><br>' + escapeHtml(lastUpdateText) + '</div>' +
      '<div><b>База</b><br>' + escapeHtml(formatBytes(d.db && d.db.size)) + '</div>' +
      '<div><b>Заявки / материали / потребители</b><br>' +
        escapeHtml(String((d.counts && d.counts.records) || 0)) + ' / ' +
        escapeHtml(String((d.counts && d.counts.warehouse) || 0)) + ' / ' +
        escapeHtml(String((d.counts && d.counts.users) || 0)) + '</div>' +
      '<div><b>Бекъпи на сървъра</b><br>' + escapeHtml(String((d.backups && d.backups.count) || 0)) + ' · проверени: ' + escapeHtml(String((d.backups && d.backups.verifiedCount) || 0)) + '<br>последен: ' + escapeHtml(lastBak) + '</div>' +
      '<div><b>Имейл известия</b><br>' + escapeHtml(email) + '</div>' +
      '<div><b>Предупреждения/грешки (24ч)</b><br>' + escapeHtml(String((d.logs && d.logs.warningsAndErrors24h) || 0)) + '</div>' +
      '<div><b>Памет (RSS)</b><br>' + escapeHtml(formatBytes(d.memory && d.memory.rss)) + '</div>' +
      (d.uncleanShutdowns24h != null ? '<div><b>Unclean (24ч)</b><br>' + escapeHtml(String(d.uncleanShutdowns24h)) + '</div>' : '') +
      '</div>' +
      '<div class="hint" style="margin-top:8px;">Обновено: ' + escapeHtml(new Date().toLocaleString('bg-BG')) + '</div>';

    // Видима кутия „Стабилност“ под бутоните
    const stabEl = document.getElementById('stabilityStatusPanel');
    if (stabEl) {
      const n24 = d.uncleanShutdowns24h != null ? d.uncleanShutdowns24h : 0;
      const lu = d.lastUncleanShutdown;
      let luStr = '—';
      if (lu) {
        luStr = formatDisplayDateTime(lu.atIso || lu.at);
        if (lu.heartbeat) luStr += ' · ' + String(lu.heartbeat).slice(0, 60);
      }
      const color = n24 > 0 ? '#c62828' : '#2e7d32';
      stabEl.innerHTML =
        '<div style="font-weight:700;margin-bottom:6px;">📊 Стабилност (C.2)</div>' +
        '<div>Unclean shutdowns за 24ч: <b style="color:' + color + ';">' + escapeHtml(String(n24)) + '</b></div>' +
        '<div style="margin-top:4px;">Последен unclean: <b>' + escapeHtml(luStr) + '</b></div>' +
        '<div style="margin-top:4px;" class="hint">Uptime: ' + escapeHtml(formatUptime(d.uptimeSec)) +
        ' · PID: ' + escapeHtml(String(d.pid)) +
        ' · Старт: ' + escapeHtml(formatDisplayDateTime(d.startedAt)) + '</div>';
    }
  } catch (e) {
    el.textContent = '❌ ' + networkErrorMessage(e);
    const stabEl = document.getElementById('stabilityStatusPanel');
    if (stabEl) stabEl.textContent = '❌ ' + networkErrorMessage(e);
  }
}


async function runRemoteDiagnostics() {
  const box = document.getElementById('remoteDiagnosticsResult');
  if (box) {
    box.style.display = 'block';
    box.textContent = 'Диагностика...';
  }
  try {
    const r = await authFetch('/api/admin/diagnostics');
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || ('HTTP ' + r.status));
    const crashes = (d.recentCrashes || []).map(function (c) {
      return '  • ' + formatDisplayDateTime(c.time || c.ts) + ' [' + (c.level || '') + '/' + (c.category || '') + '] ' + (c.message || '');
    }).join('\n') || '  (няма)';
    const lu = d.lastUncleanShutdown || (d.stability && d.stability.lastUncleanShutdown);
    let uncleanLine = 'Последен unclean shutdown: —';
    if (lu) {
      uncleanLine = 'Последен unclean shutdown: ' + formatDisplayDateTime(lu.atIso || lu.at);
      if (lu.heartbeat) uncleanLine += ' | heartbeat: ' + String(lu.heartbeat).slice(0, 80);
    }
    const n24 = (d.uncleanShutdowns24h != null) ? d.uncleanShutdowns24h
      : (d.stability && d.stability.uncleanShutdowns24h != null ? d.stability.uncleanShutdowns24h : '—');
    const text =
      'СТАТУС: онлайн\n' +
      'Порт: ' + d.port + '  PID: ' + d.pid + '  Uptime: ' + formatUptime(d.uptimeSec) + '\n' +
      'База: ' + formatBytes(d.dbSize) + '\n' +
      'Последен успешен старт: ' + formatDisplayDateTime(d.lastSuccessfulStart) + '\n' +
      'Последна заявка за рестарт: ' + formatDisplayDateTime(d.lastRestartRequest) + '\n' +
      uncleanLine + '\n' +
      'Unclean shutdowns (24ч): ' + n24 + '\n' +
      'WH без office/sanitary materialType: ' + (d.whRecordsMissingMaterialType != null ? d.whRecordsMissingMaterialType : '—') + '\n' +
      'Памет RSS: ' + formatBytes(d.memory && d.memory.rss) + '\n' +
      'Watchdog: ' + (d.watchdogHint || '') + '\n\n' +
      'Последни грешки/crash:\n' + crashes;
    if (box) box.textContent = text;
    toast('✅ Диагностиката е готова');
  } catch (e) {
    const msg = (typeof networkErrorMessage === 'function') ? networkErrorMessage(e) : String(e.message || e);
    if (box) box.textContent = '❌ ' + msg;
    toast('❌ Диагностика: ' + msg);
  }
}

async function runRemoteDepcheck() {
  const button = document.getElementById('btnRunDepcheck');
  const box = document.getElementById('remoteDepcheckResult');
  if (button) button.disabled = true;
  if (box) { box.style.display = 'block'; box.textContent = '⏳ Стартиране на DEPCHECK.bat на сървъра...'; }
  try {
    const r = await authFetch('/api/admin/run-depcheck', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || ('HTTP ' + r.status) + (d.output ? '\n' + d.output : ''));
    const text =
      'СТАТУС: ' + (d.ok ? 'УСПЕШНО' : 'НЕУСПЕШНО') + '\n' +
      'Код на завършване: ' + (d.exitCode == null ? 'няма' : d.exitCode) + '\n' +
      'Начало: ' + formatDisplayDateTime(d.startedAt) + '\n' +
      'Край: ' + formatDisplayDateTime(d.completedAt) + '\n\n' +
      (d.output || '(скриптът не върна текст)');
    if (box) box.textContent = text;
    toast(d.ok ? '✅ DEPCHECK завърши успешно' : '❌ DEPCHECK откри проблем');
  } catch (e) {
    const msg = (typeof networkErrorMessage === 'function') ? networkErrorMessage(e) : String(e.message || e);
    if (box) box.textContent = '❌ ' + msg;
    toast('❌ DEPCHECK: ' + msg);
  } finally {
    if (button) button.disabled = false;
  }
}

async function migrateWhMaterialTypesRemote() {
  if (!(await confirmDialog('Да се попълни materialType (office/sanitary) за стари заявки за материали без тип?\nСъществуващите office/sanitary няма да се пипат.'))) return;
  const box = document.getElementById('remoteDiagnosticsResult');
  if (box) {
    box.style.display = 'block';
    box.textContent = 'Миграция...';
  }
  try {
    const r = await authFetch('/api/admin/migrate-wh-types', { method: 'POST' });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || ('HTTP ' + r.status));
    const msg = 'Обновени: ' + (d.updatedCount || 0) +
      ', пропуснати: ' + ((d.skipped && d.skipped.length) || 0) +
      ', неясни: ' + ((d.ambiguous && d.ambiguous.length) || 0);
    if (box) {
      box.textContent = 'Миграция materialType\n' + msg + '\n\n' +
        (d.updated || []).slice(0, 40).map(function (u) { return u.id + ' → ' + u.materialType; }).join('\n');
    }
    toast('✅ ' + msg);
  } catch (e) {
    const msg = (typeof networkErrorMessage === 'function') ? networkErrorMessage(e) : String(e.message || e);
    if (box) box.textContent = '❌ ' + msg;
    toast('❌ Миграция: ' + msg);
  }
}

async function exportRemoteLogs() {
  try {
    const r = await authFetch('/api/admin/logs-export?limit=800');
    if (!r.ok) {
      let err = 'HTTP ' + r.status;
      try { const j = await r.json(); if (j.error) err = j.error; } catch (_) {}
      throw new Error(err);
    }
    const blob = await r.blob();
    const disp = r.headers.get('Content-Disposition') || '';
    let name = 'dist_logs.txt';
    const m = /filename="?([^";]+)"?/i.exec(disp);
    if (m) name = m[1];
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    toast('✅ Логовете са изтеглени');
  } catch (e) {
    toast('❌ Експорт на логове: ' + (e.message || e));
  }
}

async function refreshRemoteBackupsList() {
  const box = document.getElementById('remoteBackupsList');
  if (!box) return;
  box.style.display = 'block';
  box.innerHTML = '<div class="hint">Зареждане на бекъпи...</div>';
  try {
    const r = await authFetch('/api/admin/backups');
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || ('HTTP ' + r.status));
    const files = Array.isArray(d.backups) ? d.backups : [];
    if (!files.length) {
      box.innerHTML = '<div class="hint">Няма файлове в data/backups/.</div>';
      return;
    }
    let html = '<table style="width:100%;border-collapse:collapse;font-size:12px;"><thead><tr style="text-align:left;border-bottom:1px solid var(--line);">' +
      '<th style="padding:4px 6px;">Файл</th><th style="padding:4px 6px;">Размер</th><th style="padding:4px 6px;">Дата</th><th style="padding:4px 6px;">Действия</th></tr></thead><tbody>';
    files.forEach(f => {
      const isZip = /\.zip$/i.test(f.name);
      html += '<tr style="border-bottom:1px solid var(--line);">' +
        '<td style="padding:4px 6px;word-break:break-all;">' + escapeHtml(f.name) + (isZip ? ' <span style="font-weight:600;">' + (f.verified ? '✅' : '⚠') + '</span>' : '') + '</td>' +
        '<td style="padding:4px 6px;">' + escapeHtml(formatBytes(f.size)) + '</td>' +
        '<td style="padding:4px 6px;">' + escapeHtml(new Date(f.mtime).toLocaleString('bg-BG')) + '</td>' +
        '<td style="padding:4px 6px;white-space:nowrap;">' +
          (isZip ? '<button type="button" class="ghost remote-bak-verify" data-name="' + escapeHtml(f.name) + '" style="margin:0 4px 0 0;padding:2px 8px;font-size:12px;">✓</button>' : '') +
          '<button type="button" class="ghost remote-bak-dl" data-name="' + escapeHtml(f.name) + '" style="margin:0 4px 0 0;padding:2px 8px;font-size:12px;">⬇</button>' +
          (isZip && f.verified ? '<button type="button" class="ghost remote-bak-sha" data-name="' + escapeHtml(f.name) + '" title="Изтегли SHA-256 файла" style="margin:0 4px 0 0;padding:2px 8px;font-size:12px;">SHA</button>' : '') +
          '<button type="button" class="ghost remote-bak-delete" data-name="' + escapeHtml(f.name) + '" title="Изтрий бекъпа от сървъра" aria-label="Изтрий бекъпа ' + escapeHtml(f.name) + '" style="margin:0;padding:2px 8px;font-size:12px;color:#c0392b;">Х</button>' +
        '</td></tr>';
    });
    html += '</tbody></table>';
    box.innerHTML = html;
    box.querySelectorAll('.remote-bak-verify').forEach(btn => {
      btn.addEventListener('click', async () => {
        const name = btn.getAttribute('data-name');
        if (!name) return;
        btn.disabled = true;
        try {
          const r2 = await authFetch('/api/admin/backup-verify?name=' + encodeURIComponent(name));
          const d2 = await r2.json().catch(() => ({}));
          if (!r2.ok || !d2.ok) throw new Error(d2.error || 'Проверката е неуспешна.');
          toast('✅ Backup-ът е валиден и SQLite базата е проверена.');
          await refreshRemoteBackupsList();
        } catch (e) {
          toast('❌ Проверка: ' + (e.message || e));
        } finally { btn.disabled = false; }
      });
    });
    box.querySelectorAll('.remote-bak-dl').forEach(btn => {
      btn.addEventListener('click', async () => {
        const name = btn.getAttribute('data-name');
        if (!name) return;
        try {
          const r2 = await authFetch('/api/admin/backups/' + encodeURIComponent(name));
          if (!r2.ok) throw new Error('HTTP ' + r2.status);
          const blob = await r2.blob();
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url; a.download = name;
          document.body.appendChild(a); a.click(); a.remove();
          setTimeout(() => URL.revokeObjectURL(url), 2000);
          toast('✅ Изтеглен: ' + name);
        } catch (e) {
          toast('❌ ' + (e.message || e));
        }
      });
    });
    box.querySelectorAll('.remote-bak-sha').forEach(btn => {
      btn.addEventListener('click', async () => {
        const name = btn.getAttribute('data-name');
        if (!name) return;
        btn.disabled = true;
        try {
          const r2 = await authFetch('/api/admin/backup-sha256?name=' + encodeURIComponent(name));
          if (!r2.ok) {
            const d2 = await r2.json().catch(() => ({}));
            throw new Error(d2.error || ('HTTP ' + r2.status));
          }
          const blob = await r2.blob();
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url; a.download = name + '.sha256';
          document.body.appendChild(a); a.click(); a.remove();
          setTimeout(() => URL.revokeObjectURL(url), 2000);
          toast('✅ Изтеглен SHA-256 файл за: ' + name);
        } catch (e) {
          toast('❌ SHA-256: ' + (e.message || e));
        } finally { btn.disabled = false; }
      });
    });
    box.querySelectorAll('.remote-bak-delete').forEach(btn => {
      btn.addEventListener('click', async () => {
        const name = btn.getAttribute('data-name');
        if (!name || !(await confirmDialog('Да се изтрие ли бекъпът „' + name + '“ от сървъра? Това действие не може да се отмени.'))) return;
        btn.disabled = true;
        try {
          const response = await authFetch('/api/admin/backups/' + encodeURIComponent(name), { method: 'DELETE' });
          const result = await response.json().catch(() => ({}));
          if (!response.ok) throw new Error(result.error || ('HTTP ' + response.status));
          toast('✅ Бекъпът е изтрит от сървъра: ' + name);
          await refreshRemoteBackupsList();
          await refreshRemoteHealth();
        } catch (e) {
          toast('❌ Грешка при изтриване на бекъпа: ' + (e.message || e));
          btn.disabled = false;
        }
      });
    });
  } catch (e) {
    box.innerHTML = '<div class="hint">Грешка: ' + escapeHtml(e.message || String(e)) + '</div>';
  }
}


async function downloadSystemBackup() {
  const status = document.getElementById('backupDownloadStatus');
  const resultEl = document.getElementById('backupDownloadResult');
  const btn = document.getElementById('btnDownloadBackup');
  if (status) status.textContent = 'Подготовка на бекъп...';
  if (resultEl) { resultEl.style.display = 'none'; resultEl.textContent = ''; }
  if (btn) btn.disabled = true;
  try {
    const r = await authFetch('/api/admin/backup', { method: 'GET' });
    if (!r.ok) {
      let errMsg = 'HTTP ' + r.status;
      try {
        const j = await r.json();
        if (j && j.error) errMsg = j.error;
      } catch (_) {}
      throw new Error(errMsg);
    }
    const disp = r.headers.get('Content-Disposition') || '';
    let fileName = 'zayavki_backup.db';
    const m = /filename="?([^";]+)"?/i.exec(disp);
    if (m) fileName = m[1];
    const blob = await r.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    const sizeKb = Math.round(blob.size / 1024);
    if (status) status.textContent = 'Готово (' + sizeKb + ' KB).';
    if (resultEl) {
      resultEl.style.display = 'block';
      resultEl.textContent = 'Бекъпът е изтеглен: ' + fileName + ' (' + sizeKb + ' KB).\nСъдържа zayavki.db, server.js, public/, server/ и инструкции.\nПроверка: SQLite integrity + SHA-256 + manifest = OK. Копие е записано и в data/backups/ на сървъра.';
    }
    toast('✅ Бекъпът е изтеглен');
  } catch (e) {
    if (status) status.textContent = '';
    if (resultEl) {
      resultEl.style.display = 'block';
      resultEl.textContent = 'Грешка: ' + (e.message || e);
    }
    toast('Неуспешен бекъп: ' + (e.message || e));
  } finally {
    if (btn) btn.disabled = false;
  }
}

async function restartServerFromAdmin() {
  const status = document.getElementById('restartServerStatus');
  const resultEl = document.getElementById('restartServerResult');
  const phraseEl = document.getElementById('restartConfirmPhrase');
  const phrase = phraseEl ? String(phraseEl.value || '').trim() : '';
  if (phrase.toUpperCase() !== 'RESTART') {
    toast('Въведете RESTART в полето за потвърждение.');
    if (phraseEl) phraseEl.focus();
    return;
  }
  if (!(await confirmDialog('Отдалечен рестарт:\n\nАко рестартът се провали, сървърът може да остане СПРЯН до ръчно пускане от IT (или WATCHDOG).\n\nПродължавате ли?'))) {
    return;
  }
  if (status) status.textContent = 'Изпращане на команда...';
  if (resultEl) { resultEl.style.display = 'none'; resultEl.textContent = ''; }
  const btn = document.getElementById('btnRestartServer');
  if (btn) btn.disabled = true;
  try {
    const r = await authFetch('/api/admin/restart', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ confirm: true, phrase: 'RESTART' })
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.error || ('HTTP ' + r.status));
    const msg = (data && data.message) || 'Сървърът се рестартира. Изчакайте 3–5 секунди и презаредете страницата.';
    if (status) status.textContent = 'Рестартът е заявен...';
    if (resultEl) {
      resultEl.style.display = 'block';
      resultEl.textContent = msg;
    }
    toast('🔄 Сървърът се рестартира...');
    // Опитваме се да дочакаме връщането на сървъра
    let attempts = 0;
    const waitBack = async () => {
      attempts++;
      try {
        const hr = await fetch('/api/server-info', { cache: 'no-store' });
        if (hr.ok) {
          if (status) status.textContent = 'Сървърът е отново онлайн.';
          if (resultEl) {
            resultEl.style.display = 'block';
            resultEl.textContent = 'Сървърът се рестартира успешно. Презаредете страницата (F5), ако връзката не се възстанови сама.';
          }
          toast('✅ Сървърът е отново онлайн');
          if (btn) btn.disabled = false;
          return;
        }
      } catch (_) {}
      if (attempts < 30) setTimeout(waitBack, 1000);
      else {
        if (status) status.textContent = 'Изчакайте и натиснете F5.';
        if (btn) btn.disabled = false;
      }
    };
    setTimeout(waitBack, 2000);
  } catch (e) {
    if (status) status.textContent = '';
    if (resultEl) {
      resultEl.style.display = 'block';
      resultEl.textContent = 'Грешка: ' + (e.message || e);
    }
    toast('Неуспешен рестарт: ' + (e.message || e));
    if (btn) btn.disabled = false;
  }
}

async function applyProgramUpdateFromFile() {
  const input = document.getElementById('updateZipInput');
  const status = document.getElementById('updateStatus');
  const resultEl = document.getElementById('updateResult');
  if (!input || !input.files || !input.files[0]) {
    toast('Изберете ZIP файл за обновяване.');
    return;
  }
  const file = input.files[0];
  if (!/\.zip$/i.test(file.name) && file.type !== 'application/zip' && file.type !== 'application/x-zip-compressed') {
    toast('Моля, изберете .zip файл.');
    return;
  }
  if (file.size > 80 * 1024 * 1024) {
    toast('Файлът е твърде голям (макс. 80 MB).');
    return;
  }
  if (!(await confirmDialog('Сигурни ли сте, че искате да приложите обновлението?\n\nЩе се направи бекъп на заменените файлове.'))) return;

  if (status) status.textContent = 'Качване и прилагане...';
  if (resultEl) { resultEl.style.display = 'none'; resultEl.textContent = ''; }

  try {
    const buf = await file.arrayBuffer();
    const bytes = new Uint8Array(buf);
    let binary = '';
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) {
      binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
    }
    const zipBase64 = btoa(binary);
    const r = await authFetch('/api/admin/update', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ zipBase64 })
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) {
      throw new Error(data.error || ('Грешка ' + r.status));
    }
    const lines = [];
    lines.push('Обновлението е приложено успешно.');
    lines.push('Файлове: ' + (data.applied || []).length);
    if ((data.applied || []).length) lines.push('  • ' + data.applied.join('\n  • '));
    if ((data.deleted || []).length) {
      lines.push('Изтрити: ' + data.deleted.length);
      lines.push('  • ' + data.deleted.join('\n  • '));
    }
    if (data.backupDir) lines.push('Бекъп: ' + data.backupDir);
    if (data.restartRequired) {
      lines.push('');
      lines.push('⚠ Променен е сървърният код. Рестартирайте сървъра (затворете Zayavki.exe и го стартирайте отново), за да влязат всички промени.');
    } else {
      lines.push('');
      lines.push('Презаредете страницата / Client-а (Ctrl+F5), за да видите новия интерфейс.');
    }
    if (resultEl) {
      resultEl.style.display = 'block';
      resultEl.textContent = lines.join('\n');
    }
    if (status) status.textContent = 'Готово';
    toast('Обновлението е приложено.');
    input.value = '';
  } catch (e) {
    if (status) status.textContent = '';
    if (resultEl) {
      resultEl.style.display = 'block';
      resultEl.textContent = 'Грешка: ' + (e.message || e);
    }
    toast('Неуспешно обновление: ' + (e.message || e));
  }
}

async function renderLogsTab() {
  const tbody = document.getElementById('logsTableBody');
  const status = document.getElementById('logsStatus');
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="6" class="hint" style="padding:16px;">Зареждане...</td></tr>';
  if (status) status.textContent = '';

  const category = (document.getElementById('logFilterCategory') || {}).value || '';
  const level = (document.getElementById('logFilterLevel') || {}).value || '';
  const q = (document.getElementById('logFilterQ') || {}).value || '';
  const params = new URLSearchParams();
  params.set('limit', '300');
  if (category) params.set('category', category);
  if (level) params.set('level', level);
  if (q) params.set('q', q);

  try {
    const r = await authFetch('/api/admin/logs?' + params.toString());
    if (!r.ok) {
      const err = await r.json().catch(() => ({}));
      tbody.innerHTML = '<tr><td colspan="6" style="padding:16px;color:var(--danger);">' + escapeHtml(err.error || ('Грешка ' + r.status)) + '</td></tr>';
      return;
    }
    const data = await r.json();
    const logs = data.logs || [];
    if (!logs.length) {
      tbody.innerHTML = '<tr><td colspan="6" class="hint" style="padding:16px;">Няма записи.</td></tr>';
      if (status) status.textContent = '0 записа';
      return;
    }
    const levelColor = { info: '#2e7d32', warn: '#e65100', error: '#c62828' };
    tbody.innerHTML = logs.map(row => {
      const time = (typeof formatDisplayDateTime === 'function')
        ? formatDisplayDateTime(row.ts)
        : (function () { const d = new Date(row.ts); return isNaN(d.getTime()) ? String(row.ts) : d.toLocaleString('bg-BG'); })();
      const col = levelColor[row.level] || '#333';
      return '<tr style="border-bottom:1px solid var(--line);">' +
        '<td style="padding:7px 10px;white-space:nowrap;color:var(--ink-soft);">' + escapeHtml(time) + '</td>' +
        '<td style="padding:7px 10px;font-weight:600;color:' + col + ';">' + escapeHtml(row.level || '') + '</td>' +
        '<td style="padding:7px 10px;">' + escapeHtml(row.category || '') + '</td>' +
        '<td style="padding:7px 10px;max-width:420px;word-break:break-word;">' + escapeHtml(row.message || '') + '</td>' +
        '<td style="padding:7px 10px;">' + escapeHtml(row.username || '') + '</td>' +
        '<td style="padding:7px 10px;white-space:nowrap;">' + escapeHtml(row.ip || '') + '</td>' +
        '</tr>';
    }).join('');
    if (status) status.textContent = logs.length + ' записа';
  } catch (e) {
    tbody.innerHTML = '<tr><td colspan="6" style="padding:16px;color:var(--danger);">Грешка при зареждане: ' + escapeHtml(String(e.message || e)) + '</td></tr>';
  }
}

async function renderServerTab() {
  const autoAddresses = document.getElementById('serverAutoAddresses');
  autoAddresses.innerHTML = '<div class="hint">Зареждане...</div>';

  try {
    const r = await fetch('/api/server-info');
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const data = await r.json();
    
    autoAddresses.innerHTML = '';
    
    if (data.addresses && data.addresses.length) {
      data.addresses.forEach(ip => {
        const div = document.createElement('div');
        div.style.cssText = 'margin-bottom:8px;';
        div.innerHTML = `
          <a href="http://${ip}:${data.port}" target="_blank" style="color:var(--accent);text-decoration:none;font-weight:600;">
            http://${ip}:${data.port}
          </a>
          <button class="ghost" style="margin-left:8px;padding:4px 8px;font-size:12px;" onclick="copyToClipboard('http://${ip}:${data.port}')">📋 Копирай</button>
        `;
        autoAddresses.appendChild(div);
      });
    } else {
      autoAddresses.innerHTML = '<div class="hint">Не са открити мрежови адреси.</div>';
    }
    
    // Показване на hostname
    const hostnameDiv = document.createElement('div');
    hostnameDiv.style.cssText = 'margin-top:8px;font-size:12px;color:var(--ink-soft);';
    hostnameDiv.textContent = 'Hostname: ' + (data.hostname || '—');
    autoAddresses.appendChild(hostnameDiv);
    
  } catch (e) {
    console.error(e);
    autoAddresses.innerHTML = '<div class="hint">Грешка при зареждане на сървърната информация.</div>';
  }

  // Мрежови credentials (полетата може да липсват в по-стар HTML)
  try {
    renderCustomServerAddresses();
    const netAuth = (typeof getNetworkAuth === 'function') ? getNetworkAuth() : null;
    const nu = document.getElementById('networkAuthUsername');
    const np = document.getElementById('networkAuthPassword');
    const ns = document.getElementById('networkAuthStatus');
    if (nu) nu.value = (netAuth && netAuth.username) || '';
    if (np) np.value = (netAuth && netAuth.password) || '';
    if (ns) ns.textContent = netAuth ? 'Запазени данни за достъп на този компютър.' : '';
  } catch (e) {
    console.warn('network auth UI:', e);
  }

  try { await refreshRemoteHealth(); } catch (_) {}
  try { if (typeof refreshAdminSessionsPanel === 'function') refreshAdminSessionsPanel(); } catch (_) {}

  // Информационен панел на екрана за вход
  try { await loadLoginInfoPanelSettings(); } catch (_) {}

  // Имейл известия
  try {
    const r2 = await authFetch('/api/notify-settings');
    if (r2.ok) {
      const d2 = await r2.json();
      const ne = document.getElementById('notifyEmailsInput');
      if (ne) ne.value = Array.isArray(d2.emails) ? d2.emails.join(', ') : '';
      const en = document.getElementById('emailNotifyEnabled');
      if (en) en.checked = d2.enabled === true;
      const setv = (id, v) => { const el = document.getElementById(id); if (el) el.value = v != null ? v : ''; };
      setv('mailTransportSelect', d2.mailTransport || 'auto');
      setv('smtpModeSelect', d2.smtpMode || 'starttls');
      setv('smtpHostInput', d2.smtpHost || '');
      setv('smtpPortInput', d2.smtpPort != null ? d2.smtpPort : 587);
      setv('smtpUserInput', d2.smtpUser || '');
      setv('smtpFromInput', d2.smtpFrom || '');
      const pp = document.getElementById('smtpPassInput');
      if (pp) { pp.value = ''; pp.placeholder = d2.smtpPassSet ? '(зададена — празно = без промяна)' : '(празно = без промяна)'; }
    }
  } catch (e) { /* оставяме полето празно */ }
  const nes = document.getElementById('notifyEmailStatus');
  if (nes) nes.textContent = '';

  // Падащи менюта — ВИНАГИ се зареждат, независимо от грешки по-горе
  try {
    await loadDropdownSettings();
    ensureStatusListInputUI();
    const setVal = (id, arr) => {
      const el = document.getElementById(id);
      if (el) el.value = (arr && arr.length ? arr : []).join('\n');
    };
    setVal('corpusListInput', dropdownCorpusList);
    setVal('strukturaListInput', dropdownStrukturaList);
    setVal('technicianListInput', dropdownTechnicianList);
    setVal('statusListInput', dropdownStatusList.length ? dropdownStatusList : DEFAULT_STATUS_LIST);
    const dls = document.getElementById('dropdownListsStatus');
    if (dls) dls.textContent = '';
  } catch (e) {
    console.error('Грешка при зареждане на падащите списъци:', e);
  }

  try {
    await loadLoginBackground();
  } catch (e) {
    console.warn('login background:', e);
  }

  try {
    await loadVerificationInfo();
  } catch (e) {
    console.warn('verification info:', e);
  }
}


window.refreshRemoteHealth = refreshRemoteHealth;
window.runRemoteDiagnostics = runRemoteDiagnostics;
window.runRemoteDepcheck = runRemoteDepcheck;
window.migrateWhMaterialTypesRemote = migrateWhMaterialTypesRemote;
window.exportRemoteLogs = exportRemoteLogs;
window.refreshRemoteBackupsList = refreshRemoteBackupsList;
window.downloadSystemBackup = downloadSystemBackup;
window.restartServerFromAdmin = restartServerFromAdmin;
window.applyProgramUpdateFromFile = applyProgramUpdateFromFile;
window.renderLogsTab = renderLogsTab;
window.renderServerTab = renderServerTab;
window.checkUncleanShutdownBanner = checkUncleanShutdownBanner;

document.getElementById('btnRefreshLogs')?.addEventListener('click', () => renderLogsTab());
document.getElementById('btnApplyUpdate')?.addEventListener('click', () => applyProgramUpdateFromFile());
document.getElementById('btnRunDepcheck')?.addEventListener('click', () => runRemoteDepcheck());
document.getElementById('btnRestartServer')?.addEventListener('click', () => restartServerFromAdmin());
document.getElementById('btnDownloadBackup')?.addEventListener('click', () => downloadSystemBackup());
document.getElementById('btnRemoteHealthRefresh')?.addEventListener('click', () => refreshRemoteHealth());
document.getElementById('btnRemoteDiagnostics')?.addEventListener('click', () => runRemoteDiagnostics());
document.getElementById('btnRemoteMigrateWh')?.addEventListener('click', () => migrateWhMaterialTypesRemote());
document.getElementById('btnRemoteLogsExport')?.addEventListener('click', () => exportRemoteLogs());
document.getElementById('btnRemoteBackupsRefresh')?.addEventListener('click', () => refreshRemoteBackupsList());
document.getElementById('logFilterCategory')?.addEventListener('change', () => renderLogsTab());
document.getElementById('logFilterLevel')?.addEventListener('change', () => renderLogsTab());
let _logQTimer = null;
document.getElementById('logFilterQ')?.addEventListener('input', () => {
  clearTimeout(_logQTimer);
  _logQTimer = setTimeout(() => renderLogsTab(), 350);
});

