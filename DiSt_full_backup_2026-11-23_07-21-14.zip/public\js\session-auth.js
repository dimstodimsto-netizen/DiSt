// Изнесена сесийна и удостоверяваща логика. Зарежда се преди app.js.
const sessionState = AppState.bind(['authToken','currentRole','sessionExpiresAt','sessionExpiryTimer','pendingUserActivity','suppressSessionTouch','currentUsername','__kvCache','__kvCacheLoaded']);
var sessionCountdownTimer = null;

// ---- Authentication ----
// Сесиите се поддържат от HttpOnly cookie, издадено от сървъра.
// Не се пазят пароли или authentication token-и в localStorage.
function clearLegacyAuthStorage() {
  try {
    localStorage.removeItem('zayavki_networkAuth');
    localStorage.removeItem('zayavki_authToken');
    
  } catch (_) {}
}
clearLegacyAuthStorage();

const SUBMITTER_SESSION_TTL_MS_CLIENT = 30 * 60 * 1000;
/** Роли с кратка сесия (30 мин) и хронометър: заявител + наблюдател */
function isShortSessionRole(role) {
  return role === 'submitter' || role === 'observer';
}

const SESSION_CURRENT_USER_KEY = 'zayavki_currentUsername';
const SESSION_TOKEN_KEY = 'zayavki_session_token';

function saveSessionToken(token) {
  sessionState.authToken = token || null;
  try {
    if (token && token !== 'cookie-session') sessionStorage.setItem(SESSION_TOKEN_KEY, token);
    else if (!token) sessionStorage.removeItem(SESSION_TOKEN_KEY);
  } catch (_) {}
}

function loadSessionToken() {
  if (sessionState.authToken && sessionState.authToken !== 'cookie-session') return sessionState.authToken;
  try {
    const t = sessionStorage.getItem(SESSION_TOKEN_KEY);
    if (t) { sessionState.authToken = t; return t; }
  } catch (_) {}
  return sessionState.authToken;
}

function clearSessionToken() {
  sessionState.authToken = null;
  try { sessionStorage.clear(); } catch (_) {}
  try { localStorage.removeItem('zayavki_authToken'); } catch (_) {}
  notifyParentSession(null);
}

/** Известява desktop Client (client.html), за да може при X да направи logout. */
function notifyParentSession(token) {
  try {
    if (window.parent && window.parent !== window) {
      window.parent.postMessage({
        type: 'zayavki-session',
        token: token || null,
        originHint: location.origin
      }, '*');
    }
  } catch (_) {}
}

/** Локално изчистване на auth данни (без сървърен logout). */
function clearAllClientSideAuthData() {
  clearSessionToken();
  try { localStorage.removeItem(SESSION_CURRENT_USER_KEY); } catch (_) {}
  try { localStorage.removeItem('zayavki_authToken'); } catch (_) {}
  try { localStorage.removeItem('zayavki_networkAuth'); } catch (_) {}
  try { localStorage.removeItem('dist_kv_cache'); } catch (_) {}
  try { sessionStorage.clear(); } catch (_) {}
  try {
    if (typeof sessionState.__kvCache !== 'undefined' && sessionState.__kvCache && typeof sessionState.__kvCache.clear === 'function') {
      sessionState.__kvCache.clear();
    }
    sessionState.__kvCacheLoaded = false;
  } catch (_) {}
}

function touchLocalSessionExpiry() {
  if (!sessionState.authToken) return;
  // За admin/техник/склад срокът идва от сървъра (до 12 ч, sliding там).
  // Локално удължаваме само заявител (30 мин неактивност).
  if (!isShortSessionRole(sessionState.currentRole)) return;
  sessionState.sessionExpiresAt = Date.now() + SUBMITTER_SESSION_TTL_MS_CLIENT;
  scheduleSessionExpiry();
  updateSessionCountdownDisplay();
}

/** Форматира милисекунди като ММ:СС (или ЧЧ:ММ:СС ако > 1 ч). */
function formatRemainingMs(ms) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const pad = n => String(n).padStart(2, '0');
  if (h > 0) return pad(h) + ':' + pad(m) + ':' + pad(s);
  return pad(m) + ':' + pad(s);
}

/** Гарантира, че DOM елементът за брояча съществува (работи и без промяна на index.html). */
function ensureSessionCountdownEl() {
  let wrap = document.getElementById('sessionCountdown');
  if (wrap) return wrap;
  wrap = document.createElement('div');
  wrap.id = 'sessionCountdown';
  wrap.title = 'Оставащо време до автоматичен изход при бездействие (30 мин)';
  wrap.innerHTML = '⏱ Сесия: <span id="sessionCountdownValue">—</span>';
  wrap.style.cssText = [
    'display:none',
    'font-size:14px',
    'font-weight:700',
    'padding:6px 12px',
    'border-radius:8px',
    'background:#d4edda',
    'color:#155724',
    'border:2px solid #28a745',
    'font-variant-numeric:tabular-nums',
    'letter-spacing:0.03em',
    'box-shadow:0 1px 4px rgba(0,0,0,0.12)',
    'white-space:nowrap'
  ].join(';');
  // Опитваме се да го сложим до roleBadge; иначе в appHeader; иначе fixed горе вдясно
  const badge = document.getElementById('roleBadge');
  const header = document.getElementById('appHeader');
  if (badge && badge.parentElement) {
    badge.parentElement.insertBefore(wrap, badge.nextSibling);
  } else if (header) {
    header.appendChild(wrap);
  } else {
    wrap.style.position = 'fixed';
    wrap.style.top = '10px';
    wrap.style.right = '12px';
    wrap.style.zIndex = '2000';
    document.body.appendChild(wrap);
  }
  return wrap;
}

function updateSessionCountdownDisplay() {
  const wrap = ensureSessionCountdownEl();
  let val = document.getElementById('sessionCountdownValue');
  if (!val) {
    wrap.innerHTML = '⏱ Сесия: <span id="sessionCountdownValue">—</span>';
    val = document.getElementById('sessionCountdownValue');
  }
  if (!isShortSessionRole(sessionState.currentRole) || !sessionState.authToken || sessionState.sessionExpiresAt == null) {
    wrap.style.display = 'none';
    return;
  }
  const remaining = Number(sessionState.sessionExpiresAt) - Date.now();
  wrap.style.display = 'inline-block';
  if (remaining <= 0) {
    val.textContent = '00:00';
    wrap.style.background = '#f8d7da';
    wrap.style.color = '#721c24';
    wrap.style.borderColor = '#dc3545';
    return;
  }
  val.textContent = formatRemainingMs(remaining);
  if (remaining <= 5 * 60 * 1000) {
    wrap.style.background = '#f8d7da';
    wrap.style.color = '#721c24';
    wrap.style.borderColor = '#dc3545';
  } else if (remaining <= 10 * 60 * 1000) {
    wrap.style.background = '#fff3cd';
    wrap.style.color = '#856404';
    wrap.style.borderColor = '#ffc107';
  } else {
    wrap.style.background = '#d4edda';
    wrap.style.color = '#155724';
    wrap.style.borderColor = '#28a745';
  }
}

function startSessionCountdownTicker() {
  if (sessionCountdownTimer) { clearInterval(sessionCountdownTimer); sessionCountdownTimer = null; }
  ensureSessionCountdownEl();
  updateSessionCountdownDisplay();
  sessionCountdownTimer = setInterval(() => {
    updateSessionCountdownDisplay();
    if (isShortSessionRole(sessionState.currentRole) && sessionState.authToken && sessionState.sessionExpiresAt != null && Date.now() >= Number(sessionState.sessionExpiresAt)) {
      handleSessionExpired();
    }
  }, 1000);
}

function stopSessionCountdownTicker() {
  if (sessionCountdownTimer) { clearInterval(sessionCountdownTimer); sessionCountdownTimer = null; }
  const wrap = document.getElementById('sessionCountdown');
  if (wrap) wrap.style.display = 'none';
}

/** Реална потребителска активност → нулира 30-мин таймера само за заявител. */
let __lastActivityTouchAt = 0;
function onUserActivityForSession() {
  if (!isShortSessionRole(sessionState.currentRole) || !sessionState.authToken) return;
  const now = Date.now();
  // Не по-често от веднъж на 20 сек
  if (now - __lastActivityTouchAt < 20000) return;
  __lastActivityTouchAt = now;
  sessionState.pendingUserActivity = true;
  touchLocalSessionExpiry();
}

function installSubmitterActivityListeners() {
  if (window.__submitterActivityInstalled) return;
  window.__submitterActivityInstalled = true;
  const opts = { capture: true, passive: true };
  document.addEventListener('pointerdown', onUserActivityForSession, opts);
  document.addEventListener('keydown', onUserActivityForSession, opts);
}

function networkErrorMessage(err) {
  const m = String((err && err.message) || err || '');
  if (/failed to fetch|networkerror|load failed|network request failed/i.test(m)) {
    return 'Няма връзка със сървъра (Failed to fetch). Проверете дали сървърът работи и дали адресът/мрежата са достъпни.';
  }
  return m || 'Неизвестна мрежова грешка';
}

function authFetch(url, options) {
  options = options || {};
  options.headers = Object.assign({}, options.headers || {});
  if (!options.cache) options.cache = 'no-store';
  if (options.credentials === undefined) options.credentials = 'same-origin';
  // Bearer token — работи в Client iframe/WebView2, когато HttpOnly cookie не се праща
  const token = loadSessionToken();
  if (token && token !== 'cookie-session' && !options.headers['Authorization'] && !options.headers['authorization']) {
    options.headers['Authorization'] = 'Bearer ' + token;
  }
  // Улавяме флага В МОМЕНТА на заявката (не по-късно, в .then) — и го пращаме
  // към сървъра с хедър, за да НЕ плъзга той реалната сесия в базата. Преди
  // суспендирането спираше само локалния хронометър в браузъра — сървърът
  // продължаваше да подновява сесията на всеки фонов poll, затова отворен таб
  // я държеше вечно "жива" (виждаше се в панел "Активни сесии").
  const isBackgroundRequest = sessionState.suppressSessionTouch;
  if (isBackgroundRequest) options.headers['X-Background-Refresh'] = '1';
  // Реална потребителска активност (клик/клавиатура) — единственото, което
  // удължава 30-мин сесия на заявител/наблюдател на сървъра.
  const sendActivity = sessionState.pendingUserActivity && isShortSessionRole(sessionState.currentRole);
  if (sendActivity) {
    options.headers['X-User-Activity'] = '1';
    sessionState.pendingUserActivity = false;
  }
  return fetch(url, options).then(response => {
    if (response.status === 401 && sessionState.currentRole) {
      handleSessionExpired('server_401');
    }
    // Локалният хронометър се удължава САМО от onUserActivityForSession,
    // не от произволен успешен API отговор (иначе отворен таб = вечна сесия).
    return response;
  }).catch(err => {
    const e = new Error(networkErrorMessage(err));
    e.cause = err;
    throw e;
  });
}


// ---- Heartbeat: сървърът знае кой е онлайн (PC изключен → офлайн след ~3 мин) ----
let heartbeatTimer = null;
const HEARTBEAT_INTERVAL_MS = 60 * 1000;

function stopHeartbeat() {
  if (heartbeatTimer) {
    clearInterval(heartbeatTimer);
    heartbeatTimer = null;
  }
}

async function sendHeartbeatOnce() {
  if (!sessionState.authToken && !loadSessionToken()) return;
  try {
    const res = await authFetch('/api/auth/heartbeat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: '{}',
      cache: 'no-store'
    });
    if (res.status === 401) {
      stopHeartbeat();
      if (sessionState.currentRole) handleSessionExpired('heartbeat_401');
      return;
    }
  } catch (_) { /* мрежата е паднала — сървърът ще маркира офлайн */ }
}

function startHeartbeat() {
  stopHeartbeat();
  sendHeartbeatOnce();
  heartbeatTimer = setInterval(sendHeartbeatOnce, HEARTBEAT_INTERVAL_MS);
}

function handleSessionExpired(reason) {
  if (!sessionState.authToken && !sessionState.currentRole) return; // already cleared
  if (sessionState.sessionExpiryTimer) { clearTimeout(sessionState.sessionExpiryTimer); sessionState.sessionExpiryTimer = null; }
  stopHeartbeat();
  stopSessionCountdownTicker();
  const wasUser = sessionState.currentUsername || '';
  const wasRole = sessionState.currentRole || '';
  sessionState.sessionExpiresAt = null;
  // Best-effort: сървърът ще логне ttl_expired при следваща проверка; тук чистим cookie
  try {
    const headers = { 'Content-Type': 'application/json' };
    const t = loadSessionToken();
    if (t && t !== 'cookie-session') headers['Authorization'] = 'Bearer ' + t;
    fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin', headers, body: '{}', cache: 'no-store' }).catch(function () {});
  } catch (_) {}
  clearSessionToken();
  try { localStorage.removeItem(SESSION_CURRENT_USER_KEY);  } catch (_) {}
  sessionState.currentRole = null;
  sessionState.currentUsername = null;
  toast('⏰ Сесията ви е изтекла. Моля, влезте отново.', 'error');
  const b = document.getElementById('sessionExpiredBanner');
  if (b) b.style.display = 'block';
  try {
    if (typeof showRoleSelectStep === 'function') showRoleSelectStep();
  } catch (_) {}
  try { console.info('session expired', wasUser, wasRole, reason || 'local_timer'); } catch (_) {}
}



// ---- Автоматичен вход чрез cookie и/или запазен Bearer token ----
async function autoLogin() {
  loadSessionToken();
  try {
    const r = await authFetch('/api/auth/me');
    if (r.ok) {
      const data = await r.json();
      if (!sessionState.authToken || sessionState.authToken === 'cookie-session') {
        saveSessionToken(sessionState.authToken || 'cookie-session');
      }
      // Заявител: винаги локален 30-мин inactivity таймер (не взимаме удължен срок от сървъра)
      if (isShortSessionRole(data.role)) {
        sessionState.sessionExpiresAt = Date.now() + SUBMITTER_SESSION_TTL_MS_CLIENT;
      } else {
        sessionState.sessionExpiresAt = data.expiresAt ?? null;
      }
      scheduleSessionExpiry();
      try { localStorage.setItem(SESSION_CURRENT_USER_KEY, data.username);  } catch (_) {}
      const t = loadSessionToken();
      notifyParentSession(t && t !== 'cookie-session' ? t : null);
      const b = document.getElementById('sessionExpiredBanner');
      if (b) b.style.display = 'none';
      applyRoleUI(data.role, data.username, data.name, data.struktura, data.allowedMenus, { strukturaLocked: data.strukturaLocked, korpus: data.korpus, etazhi: data.etazhi });
      if (isShortSessionRole(data.role)) {
        startSessionCountdownTicker();
        installSubmitterActivityListeners();
      }
      openPendingRecordFromUrl();
      return;
    }
  } catch (e) {
  }
  clearSessionToken();
  // Няма валидна сесия — показваме нормалния login UI (и при standalone URL).
  try { document.documentElement.classList.remove('standalone-open'); } catch (_) {}
  const loading = document.getElementById('standaloneLoading');
  if (loading) loading.style.display = 'none';
  showRoleSelectStep();
  loginStateResolved = true;
  renderLoginInfoPanel();
}



function scheduleSessionExpiry() {
  if (sessionState.sessionExpiryTimer) { clearTimeout(sessionState.sessionExpiryTimer); sessionState.sessionExpiryTimer = null; }
  if (!sessionState.authToken || sessionState.sessionExpiresAt === null || sessionState.sessionExpiresAt === undefined) return;
  const delay = Math.max(0, Number(sessionState.sessionExpiresAt) - Date.now());
  sessionState.sessionExpiryTimer = setTimeout(() => {
    if (sessionState.authToken) handleSessionExpired();
  }, delay + 250);
}

async function checkSessionValidity() {
  if (!sessionState.authToken) return;
  if (sessionState.sessionExpiresAt !== null && sessionState.sessionExpiresAt !== undefined && Date.now() >= Number(sessionState.sessionExpiresAt)) {
    handleSessionExpired();
    return;
  }
  try {
    // ?peek=1 + суров fetch — не удължава сесията на сървъра.
    const headers = {};
    const token = loadSessionToken();
    if (token && token !== 'cookie-session') headers['Authorization'] = 'Bearer ' + token;
    const r = await fetch('/api/auth/me?peek=1', { cache: 'no-store', credentials: 'same-origin', headers });
    if (r.status === 401) {
      handleSessionExpired();
    } else if (r.ok) {
      const data = await r.json();
      const serverExp = data.expiresAt == null ? null : Number(data.expiresAt);
      if (isShortSessionRole(sessionState.currentRole)) {
        // Заявител/наблюдател: локалният таймер за бездействие е водещ.
        // Сървърът може да е удължен от фонови заявки — НЕ приемаме по-дълъг срок.
        // Приемаме само ако сървърът казва, че сесията вече е по-къса (или липсва).
        if (serverExp != null && sessionState.sessionExpiresAt != null && serverExp < Number(sessionState.sessionExpiresAt)) {
          sessionState.sessionExpiresAt = serverExp;
          scheduleSessionExpiry();
        } else if (sessionState.sessionExpiresAt == null && serverExp != null) {
          sessionState.sessionExpiresAt = serverExp;
          scheduleSessionExpiry();
        }
        // иначе запазваме локалния inactivity deadline
      } else {
        // Staff: следваме сървъра
        sessionState.sessionExpiresAt = serverExp;
        scheduleSessionExpiry();
      }
      updateSessionCountdownDisplay();
    }
  } catch (e) {
    console.error('❌ Грешка при проверка на сесията:', e);
  }
}

