'use strict';

/**
 * Модул: верификация / лиценз на инсталацията.
 * Фаза 1 модулност — изнесено от server.js без промяна на поведението.
 */

const crypto = require('node:crypto');
const os = require('node:os');
const path = require('node:path');

function createVerificationModule(deps) {
  const {
    kvGet,
    kvSet,
    ROOT_DIR,
    VERIFICATION_PERIOD_DAYS,
    VERIFICATION_WARNING_DAY,
    VERIFICATION_LOCK_DAY,
    VERIFICATION_INITIAL_CODE,
    hashPasswordPBKDF2,
    writeSystemLog
  } = deps;

  const VERIFICATION_LAST_KEY = 'system:verification:lastAt';
  const VERIFICATION_LAST_SEEN_KEY = 'system:verification:lastSeenAt';
  const VERIFICATION_CODE_HASH_KEY = 'system:verification:codeHash';
  const VERIFICATION_CODE_SALT_KEY = 'system:verification:codeSalt';
  const VERIFICATION_FP_KEY = 'system:verification:fingerprint';
  const VERIFICATION_ACTIVATED_KEY = 'system:verification:activated';

  function verificationHash(code, salt) {
    return hashPasswordPBKDF2(String(code), salt);
  }

  function computeInstallFingerprint() {
    try {
      const host = String(os.hostname() || 'unknown');
      const root = String(path.resolve(ROOT_DIR));
      return crypto.createHash('sha256').update(host + '|' + root, 'utf8').digest('hex');
    } catch (_) {
      return crypto.createHash('sha256').update(String(ROOT_DIR), 'utf8').digest('hex');
    }
  }

  function initializeVerification() {
    const now = Date.now();
    const currentFp = computeInstallFingerprint();

    if (kvGet(VERIFICATION_ACTIVATED_KEY) === null) {
      if (kvGet(VERIFICATION_LAST_KEY) !== null) {
        kvSet(VERIFICATION_ACTIVATED_KEY, '1');
        if (kvGet(VERIFICATION_FP_KEY) === null) kvSet(VERIFICATION_FP_KEY, currentFp);
        console.log('ℹ️  Верификация: съществуващата инсталация е маркирана като активирана.');
      } else {
        kvSet(VERIFICATION_ACTIVATED_KEY, '0');
        kvSet(VERIFICATION_LAST_KEY, String(now));
        kvSet(VERIFICATION_LAST_SEEN_KEY, String(now));
        kvSet(VERIFICATION_FP_KEY, currentFp);
        console.log('ℹ️  Нова инсталация: нужна е първоначална верификация с код.');
      }
    }

    if (kvGet(VERIFICATION_LAST_KEY) === null) kvSet(VERIFICATION_LAST_KEY, String(now));
    if (kvGet(VERIFICATION_LAST_SEEN_KEY) === null) kvSet(VERIFICATION_LAST_SEEN_KEY, String(now));
    if (kvGet(VERIFICATION_FP_KEY) === null) kvSet(VERIFICATION_FP_KEY, currentFp);

    if (kvGet(VERIFICATION_CODE_HASH_KEY) === null || kvGet(VERIFICATION_CODE_SALT_KEY) === null) {
      const salt = crypto.randomBytes(16).toString('hex');
      kvSet(VERIFICATION_CODE_SALT_KEY, salt);
      kvSet(VERIFICATION_CODE_HASH_KEY, verificationHash(VERIFICATION_INITIAL_CODE, salt));
      console.log('ℹ️  Инициализиран е верификационен код/период.');
    }
  }

  function getLicenseContact() {
    try {
      const v = kvGet('settings:licenseContact');
      if (v == null || v === '') {
        return 'Оторизирана инсталация — за активация или поддръжка се свържете с автора на системата.';
      }
      return String(v);
    } catch (_) {
      return 'Оторизирана инсталация — свържете се с автора на системата.';
    }
  }

  function getVerificationState(updateLastSeen = true) {
    initializeVerification();
    const now = Date.now();
    const lastAt = Number(kvGet(VERIFICATION_LAST_KEY)) || now;
    const lastSeen = Number(kvGet(VERIFICATION_LAST_SEEN_KEY)) || now;
    const activated = String(kvGet(VERIFICATION_ACTIVATED_KEY) || '0') === '1';
    const storedFp = String(kvGet(VERIFICATION_FP_KEY) || '');
    const currentFp = computeInstallFingerprint();
    const fingerprintMismatch = !!(storedFp && storedFp !== currentFp);

    const clockRollback = now + 5 * 60 * 1000 < lastSeen;
    if (updateLastSeen && now > lastSeen) kvSet(VERIFICATION_LAST_SEEN_KEY, String(now));

    const elapsedDays = Math.floor(Math.max(0, now - lastAt) / 86400000);
    const daysRemaining = Math.max(0, VERIFICATION_PERIOD_DAYS - elapsedDays);
    const warning = activated && !fingerprintMismatch && elapsedDays >= VERIFICATION_WARNING_DAY;
    const expired = elapsedDays >= VERIFICATION_LOCK_DAY;

    let lockReason = null;
    if (!activated) lockReason = 'not_activated';
    else if (fingerprintMismatch) lockReason = 'install_mismatch';
    else if (clockRollback) lockReason = 'clock_rollback';
    else if (expired) lockReason = 'verification_expired';

    return {
      elapsedDays: activated ? elapsedDays : 0,
      daysRemaining: activated && !fingerprintMismatch ? daysRemaining : 0,
      periodDays: VERIFICATION_PERIOD_DAYS,
      warning,
      locked: !!lockReason,
      lockReason,
      activated,
      fingerprintMismatch,
      installId: currentFp.slice(0, 12),
      licenseContact: getLicenseContact(),
      lastVerificationAt: new Date(lastAt).toISOString(),
      nextVerificationAt: new Date(lastAt + VERIFICATION_PERIOD_DAYS * 86400000).toISOString(),
      lockAt: new Date(lastAt + VERIFICATION_LOCK_DAY * 86400000).toISOString()
    };
  }

  function checkVerificationCodeOnly(code) {
    initializeVerification();
    const salt = kvGet(VERIFICATION_CODE_SALT_KEY);
    const stored = kvGet(VERIFICATION_CODE_HASH_KEY);
    if (!salt || !stored) return false;
    const actual = verificationHash(String(code || ''), salt);
    try {
      if (actual.length !== stored.length) return false;
      return crypto.timingSafeEqual(Buffer.from(actual, 'hex'), Buffer.from(stored, 'hex'));
    } catch (_) {
      return false;
    }
  }

  function verifyProgramCode(code) {
    if (!checkVerificationCodeOnly(code)) return false;
    const now = Date.now();
    kvSet(VERIFICATION_LAST_KEY, String(now));
    kvSet(VERIFICATION_LAST_SEEN_KEY, String(now));
    kvSet(VERIFICATION_ACTIVATED_KEY, '1');
    kvSet(VERIFICATION_FP_KEY, computeInstallFingerprint());
    try {
      writeSystemLog('info', 'system', 'Успешна верификация на програмата (активиране/обновяване на период).');
    } catch (_) {}
    return true;
  }

  function changeVerificationCode(currentCode, newCode) {
    initializeVerification();
    if (!checkVerificationCodeOnly(currentCode)) return { ok: false, error: 'Текущият верификационен код е грешен.' };
    const nc = String(newCode || '').trim();
    if (nc.length < 8) return { ok: false, error: 'Новият код трябва да е поне 8 символа.' };
    if (nc === String(currentCode || '').trim()) return { ok: false, error: 'Новият код трябва да е различен от текущия.' };
    const salt = crypto.randomBytes(16).toString('hex');
    kvSet(VERIFICATION_CODE_SALT_KEY, salt);
    kvSet(VERIFICATION_CODE_HASH_KEY, verificationHash(nc, salt));
    try {
      writeSystemLog('warn', 'system', 'Верификационният код е сменен от администратор.');
    } catch (_) {}
    return { ok: true };
  }

  return {
    initializeVerification,
    getLicenseContact,
    getVerificationState,
    checkVerificationCodeOnly,
    verifyProgramCode,
    changeVerificationCode,
    computeInstallFingerprint
  };
}

module.exports = { createVerificationModule };
