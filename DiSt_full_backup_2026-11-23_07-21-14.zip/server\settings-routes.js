'use strict';

/** Settings and public server metadata endpoints. */
function createSettingsRoutes(deps) {
  const {
    addCORS, sendJSON, getLanIPs, PORT, os, getUiVersion,
    getVerificationState, requireAdmin, readJsonFromRequest,
    kvGet, kvSet, getSmtpSettings, getNotifyEmails,
    isEmailNotifyEnabled, isSmtpConfigured, writeSystemLog, sendMail
  } = deps;

  function handleServerInfoRoute(req, res, pathname) {
    if (pathname !== '/api/server-info' || req.method !== 'GET') return false;
    addCORS(res);
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    sendJSON(res, 200, {
      port: PORT,
      addresses: getLanIPs(),
      hostname: os.hostname(),
      uiVersion: getUiVersion()
    });
    return true;
  }

  function handleVerificationGate(res, pathname) {
    const publicApiPaths = [
      '/api/system/verification-status', '/api/system/verify',
      '/api/system/unlock', '/api/system/change-verification-code',
      '/api/system/license-contact', '/api/auth/login', '/api/auth/logout',
      '/api/auth/me', '/api/login-info-panel'
    ];
    if (!pathname.startsWith('/api/') || publicApiPaths.includes(pathname)) return false;
    const verification = getVerificationState(true);
    if (!verification.locked) return false;
    sendJSON(res, 423, {
      error: 'Програмата е заключена до въвеждане на валиден верификационен код от администратор.',
      code: 'VERIFICATION_REQUIRED',
      verification
    });
    return true;
  }

  async function handleLoginInfoPanelRoute(req, res, pathname) {
    if (pathname !== '/api/login-info-panel') return false;
    if (req.method === 'GET') {
      const enabled = kvGet('settings:loginInfoPanelEnabled') === '1';
      const content = String(kvGet('settings:loginInfoPanelContent') || '').slice(0, 5000);
      addCORS(res);
      sendJSON(res, 200, { enabled, content });
      return true;
    }
    if (req.method === 'PUT') {
      const admin = requireAdmin(req, res);
      if (!admin) return true;
      const body = await readJsonFromRequest(req, res);
      if (!body) return true;
      const content = String(body.content == null ? '' : body.content).replace(/\r\n?/g, '\n');
      if (content.length > 5000) {
        sendJSON(res, 413, { error: 'Съдържанието на информационния панел не може да надвишава 5000 символа.' });
        return true;
      }
      const enabled = body.enabled === true || body.enabled === 1 || body.enabled === '1';
      kvSet('settings:loginInfoPanelEnabled', enabled ? '1' : '0');
      kvSet('settings:loginInfoPanelContent', content);
      try { writeSystemLog('info', 'settings', 'Настройки на информационния панел за вход са обновени', { enabled, contentLength: content.length, username: admin.username || '' }); } catch (_) {}
      sendJSON(res, 200, { ok: true, enabled, content });
      return true;
    }
    return false;
  }

  async function handleDropdownSettingsRoute(req, res, pathname) {
    if (pathname !== '/api/dropdown-settings') return false;
    if (req.method === 'GET') {
      let corpus = [], struktura = [], technicians = null, statuses = null;
      try { corpus = JSON.parse(kvGet('settings:corpusList') || '[]'); } catch (_) {}
      try { struktura = JSON.parse(kvGet('settings:strukturaList') || '[]'); } catch (_) {}
      try { technicians = JSON.parse(kvGet('settings:technicianList') || 'null'); } catch (_) {}
      try { statuses = JSON.parse(kvGet('settings:statusList') || 'null'); } catch (_) {}
      if (!Array.isArray(technicians)) {
        technicians = [
          'Иван Иванов', 'Николай Радославов', 'Тодор Тодоров', 'Михаил Михайлов',
          'Тодор Николов', 'Владимир Неделчев', 'Атанас Томов', 'Здравко Жеков',
          'Николай Стайков', 'инж. Николай Танчев', 'Янко Янков', 'Николай Дончев',
          'Енчо Енчев', 'Деян Дянков'
        ];
        kvSet('settings:technicianList', JSON.stringify(technicians));
      }
      if (!Array.isArray(statuses) || !statuses.length) {
        statuses = ['Не е изпълнена', 'Изпълнява се', 'Изчаква материали', 'За докладна', 'Изпълнена', 'Друго'];
        kvSet('settings:statusList', JSON.stringify(statuses));
      }
      sendJSON(res, 200, {
        corpus: Array.isArray(corpus) ? corpus : [],
        struktura: Array.isArray(struktura) ? struktura : [],
        technicians,
        statuses
      });
      return true;
    }
    if (req.method === 'PUT') {
      if (!requireAdmin(req, res)) return true;
      const parsedBody = await readJsonFromRequest(req, res);
      if (!parsedBody) return true;
      const corpus = Array.isArray(parsedBody.corpus) ? parsedBody.corpus.map(s => String(s).trim()).filter(Boolean) : [];
      const struktura = Array.isArray(parsedBody.struktura) ? parsedBody.struktura.map(s => String(s).trim()).filter(Boolean) : [];
      const technicians = Array.isArray(parsedBody.technicians) ? parsedBody.technicians.map(s => String(s).trim()).filter(Boolean) : [];
      const statuses = Array.isArray(parsedBody.statuses) ? parsedBody.statuses.map(s => String(s).trim()).filter(Boolean) : [];
      kvSet('settings:corpusList', JSON.stringify(corpus));
      kvSet('settings:strukturaList', JSON.stringify(struktura));
      kvSet('settings:technicianList', JSON.stringify(technicians));
      if (statuses.length) kvSet('settings:statusList', JSON.stringify(statuses));
      sendJSON(res, 200, { corpus, struktura, technicians, statuses: statuses.length ? statuses : undefined });
      return true;
    }
    return false;
  }

  async function handleNotifySettingsRoute(req, res, pathname) {
    if (pathname !== '/api/notify-settings') return false;
    if (req.method === 'GET') {
      if (!requireAdmin(req, res)) return true;
      const smtp = getSmtpSettings();
      sendJSON(res, 200, {
        emails: getNotifyEmails(),
        enabled: isEmailNotifyEnabled(),
        smtpHost: smtp.host,
        smtpPort: smtp.port,
        smtpMode: smtp.mode,
        smtpUser: smtp.user,
        smtpFrom: smtp.from,
        smtpPassSet: !!(smtp.pass && smtp.pass.length),
        mailTransport: smtp.transport,
        smtpTlsInsecure: smtp.tlsInsecure,
        smtpConfigured: isSmtpConfigured()
      });
      return true;
    }
    if (req.method === 'PUT') {
      if (!requireAdmin(req, res)) return true;
      const parsedBody = await readJsonFromRequest(req, res);
      if (!parsedBody) return true;
      const emails = Array.isArray(parsedBody.emails)
        ? parsedBody.emails.map(e => String(e).trim()).filter(Boolean)
        : [];
      const enabled = parsedBody.enabled === undefined ? isEmailNotifyEnabled() : !!parsedBody.enabled;
      kvSet('settings:notifyEmails', JSON.stringify(emails));
      kvSet('settings:emailNotifyEnabled', enabled ? '1' : '0');
      if (parsedBody.smtpHost !== undefined) kvSet('settings:smtpHost', String(parsedBody.smtpHost || '').trim());
      if (parsedBody.smtpPort !== undefined) kvSet('settings:smtpPort', String(parseInt(parsedBody.smtpPort, 10) || 587));
      if (parsedBody.smtpMode !== undefined) {
        const mode = String(parsedBody.smtpMode || 'starttls').toLowerCase();
        kvSet('settings:smtpMode', ['starttls', 'tls', 'none'].includes(mode) ? mode : 'starttls');
      }
      if (parsedBody.smtpUser !== undefined) kvSet('settings:smtpUser', String(parsedBody.smtpUser || '').trim());
      if (parsedBody.smtpFrom !== undefined) kvSet('settings:smtpFrom', String(parsedBody.smtpFrom || '').trim());
      if (parsedBody.smtpPass !== undefined && String(parsedBody.smtpPass) !== '') {
        kvSet('settings:smtpPass', String(parsedBody.smtpPass));
      }
      if (parsedBody.mailTransport !== undefined) {
        const transport = String(parsedBody.mailTransport || 'auto').toLowerCase();
        kvSet('settings:mailTransport', ['auto', 'smtp', 'outlook'].includes(transport) ? transport : 'auto');
      }
      if (parsedBody.smtpTlsInsecure !== undefined) {
        kvSet('settings:smtpTlsInsecure', (parsedBody.smtpTlsInsecure === true || parsedBody.smtpTlsInsecure === '1') ? '1' : '0');
      }
      const smtp = getSmtpSettings();
      writeSystemLog('info', 'email', 'Настройки за имейл известия обновени (включени: ' + (enabled ? 'да' : 'не') + ', ' + emails.length + ' адреса, transport=' + smtp.transport + ')');
      sendJSON(res, 200, {
        emails,
        enabled,
        smtpHost: smtp.host,
        smtpPort: smtp.port,
        smtpMode: smtp.mode,
        smtpUser: smtp.user,
        smtpFrom: smtp.from,
        smtpPassSet: !!(smtp.pass && smtp.pass.length),
        mailTransport: smtp.transport,
        smtpTlsInsecure: smtp.tlsInsecure,
        smtpConfigured: isSmtpConfigured()
      });
      return true;
    }
    return false;
  }

  async function handleNotifyTestRoute(req, res, pathname) {
    if (pathname !== '/api/notify-test' || req.method !== 'POST') return false;
    if (!requireAdmin(req, res)) return true;
    if (!isEmailNotifyEnabled()) {
      writeSystemLog('warn', 'email', 'Тестов имейл — отказан: известията са изключени.');
      sendJSON(res, 400, { ok: false, error: 'Имейл известията са изключени. Включете ги и запазете.' });
      return true;
    }
    const emails = getNotifyEmails();
    writeSystemLog('info', 'email', 'Тестов имейл — старт. Получатели: ' + (emails.length ? emails.join(', ') : '(няма)'));
    if (!emails.length) {
      writeSystemLog('warn', 'email', 'Тестов имейл — отказан: няма зададени адреси.');
      sendJSON(res, 400, { ok: false, error: 'Няма зададени имейли за известяване. Въведете адреси и натиснете „Запази“.' });
      return true;
    }
    const result = await sendMail(
      emails,
      'Тестов имейл — DiSt v1.5',
      'Това е тестово съобщение от системата за заявки за ремонт.\n\nАко сте получили това съобщение, автоматичното изпращане (SMTP или Outlook) работи коректно.'
    );
    if (result && result.ok) writeSystemLog('info', 'email', 'Тестов имейл — успешно до ' + emails.join(', '));
    else writeSystemLog('error', 'email', 'Тестов имейл — неуспех: ' + ((result && result.error) || 'неизвестна грешка'));
    sendJSON(res, result && result.ok ? 200 : 500, result);
    return true;
  }

  async function handleSettingsRoute(req, res, pathname) {
    if (await handleLoginInfoPanelRoute(req, res, pathname)) return true;
    if (await handleDropdownSettingsRoute(req, res, pathname)) return true;
    if (await handleNotifySettingsRoute(req, res, pathname)) return true;
    return handleNotifyTestRoute(req, res, pathname);
  }

  return { handleServerInfoRoute, handleVerificationGate, handleSettingsRoute };
}

module.exports = { createSettingsRoutes };

