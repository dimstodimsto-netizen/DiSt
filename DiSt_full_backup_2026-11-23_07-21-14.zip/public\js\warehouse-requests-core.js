/**
 * warehouse-requests.js — фаза 2а модулност
 * Складови списъци, филтри, модал преглед/изпълнение.
 * Зарежда се СЛЕД app.js.
 */

// ---- РЕНДИРАНЕ НА ТАБЛИЦА ЗА ЗАЯВКИ ЗА МАТЕРИАЛИ ----
async function renderWarehouseTable(opts) {
  const soft = (typeof isSoftRefreshOpts === 'function') ? isSoftRefreshOpts(opts) : !!(opts && opts.softRefresh);
  const tbody = document.getElementById('whTableBody');
  const info = document.getElementById('whTableInfo');
  if (typeof setContentLoading === 'function') {
    setContentLoading(tbody, '<tr><td colspan="8" class="hint">Зареждане...</td></tr>', soft);
  } else if (!soft) {
    const soft = (typeof isSoftRefreshOpts === 'function') ? isSoftRefreshOpts(opts) : !!(opts && opts.softRefresh);
    if (typeof setContentLoading === 'function') {
      setContentLoading(tbody, '<tr><td colspan="8" class="hint">Зареждане...</td></tr>', soft);
    } else if (!soft) {
      tbody.innerHTML = '<tr><td colspan="8" class="hint">Зареждане...</td></tr>';
    }
  }
  
  try {
    const recs = await getAllWhRecords();
    tbody.innerHTML = '';
    
    if (!recs.length) {
      tbody.innerHTML = '<tr><td colspan="8" class="hint">Няма подадени заявки за материали.</td></tr>';
      info.textContent = '0 заявки';
      return;
    }
    
    info.textContent = recs.length + ' заявки';
    
    recs.forEach((rec, idx) => {
      const statusClass = rec.status === 'izpalnena' ? 'wh-status-izpalnena' : 'wh-status-chakashta';
      const statusText = rec.status === 'izpalnena' ? 'Изпълнена' : 'Чакаща';
      
      // Определяне на типа материал за показване
      const materialTypeBadge = rec.materialType === 'office' ? '<span style="font-size:11px;color:var(--accent);">📝 Канцеларски</span>' : 
                               rec.materialType === 'sanitary' ? '<span style="font-size:11px;color:var(--ok);">🧻 Санитарни</span>' : 
                               '<span style="font-size:11px;color:var(--ink-soft);">Обща</span>';
      
      const canFulfill = (currentRole === 'admin' || currentRole === 'warehouse');
      const canReopenOrDelete = currentRole === 'admin';
      let actionButtons = '';
      // Преглед: клик върху реда (без отделен бутон)
      if (rec.status === 'izpalnena' || rec.status === 'Изпълнена') {
        if (canReopenOrDelete) {
          actionButtons += `<button class="wh-action-btn" onclick="event.stopPropagation(); markWhFulfilled('${rec.id}', true)">↺ Отвори отново</button>`;
        }
      } else if (canFulfill) {
        actionButtons += `<button class="wh-action-btn" onclick="event.stopPropagation(); markWhFulfilled('${rec.id}', false)">✅ Изпълни</button>`;
      }
      if (canReopenOrDelete) {
        actionButtons += `<button class="wh-action-btn" onclick="deleteWhRequest('${rec.id}')">✕</button>`;
      }

      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${escapeHtml(rec.id)}</td>
        <td>${escapeHtml(rec.datetime || '')}</td>
        <td>${WH_MONTH_NAMES[parseInt(rec.mesec)] || rec.mesec}</td>
        <td>${escapeHtml(rec.godina)}</td>
        <td>${escapeHtml(rec.struktura)}</td>
        <td>${escapeHtml(rec.zayavitel)}</td>
        <td>${materialTypeBadge}</td>
        <td><span class="wh-status-badge ${statusClass}">${statusText}</span></td>
        <td>${actionButtons || '—'}</td>
      `;
      // Клик събитие за отваряне на заявка в модален прозорец - НЕ и за
      // заявител: той вижда таблото, но не отваря/работи със заявките
      // тук (само в "Моите заявки за материали" може да ги разглежда).
      if (currentRole !== 'submitter') {
        tr.style.cursor = 'pointer';
        tr.onclick = (e) => {
          if (e.target.closest && e.target.closest('button')) return;
          if (e.target.tagName === 'BUTTON') return;
          openWhViewModal(rec.id, true);
        };
      }
      tbody.appendChild(tr);
    });
  } catch (e) {
    tbody.innerHTML = '<tr><td colspan="9" class="hint">Грешка при зареждане.</td></tr>';
  }
}

window.markWhFulfilled = async function(id, isFulfilled) {
  if (isFulfilled && currentRole !== 'admin') { toast('Само администратор може да отваря заявка отново.'); return; }
  if (!isFulfilled && currentRole !== 'admin' && currentRole !== 'warehouse') { toast('Нямате права.'); return; }
  try {
    const rec = await getWhById(id);
    if (!rec) { toast('❌ Заявката не е намерена.'); return; }
    if (!isFulfilled) {
      if (!Array.isArray(rec.materials)) rec.materials = [];
      rec.materials.forEach(function (m) {
        if (!m) return;
        if (m.otpusnatoKolichestvo == null) m.otpusnatoKolichestvo = '';
        if (m.zabelezka == null) m.zabelezka = '';
      });
      fillEmptyReleasedFromRequested(rec.materials);
      rec.status = 'izpalnena';
      rec.fulfilledAt = (typeof formatLocalDateTimeSeconds === 'function')
        ? formatLocalDateTimeSeconds(new Date())
        : new Date().toLocaleString('bg-BG');
      if (currentRole === 'warehouse') rec.warehouseLocked = true;
      toast('✅ Заявката е маркирана като изпълнена.');
    } else {
      rec.status = 'chakashta';
      rec.warehouseLocked = false;
      rec.fulfilledAt = null;
      toast('↺ Заявката е отворена отново.');
    }
    await saveWhRecord(rec);
    await Promise.all([
      typeof renderWarehouseTable === 'function' ? renderWarehouseTable() : Promise.resolve(),
      typeof renderWarehouseSanitaryTable === 'function' ? renderWarehouseSanitaryTable() : Promise.resolve(),
      typeof renderWarehouseOfficeTable === 'function' ? renderWarehouseOfficeTable() : Promise.resolve(),
      typeof renderMyMaterials === 'function' ? renderMyMaterials() : Promise.resolve()
    ]);
  } catch (e) {
    console.error('markWhFulfilled:', e);
    toast('❌ Грешка при обновяване.');
  }
};

window.deleteWhRequest = async function(id) {
  if (currentRole !== 'admin') { toast('Само администратор може да изтрива заявки.'); return; }
  if (!(await confirmDialog('Сигурни ли сте, че искате да изтриете тази заявка?'))) return;
  try {
    await deleteWhRecord(id);
    toast('✅ Заявката е изтрита.');
    renderWarehouseTable();
  } catch (e) {
    toast('❌ Грешка при изтриване.');
  }
};



// ---- Запис на попълнените от Склад "Забележка" (отпуснато количество)
// стойности - редактируеми само за роля Склад/администратор (виж
// openWhViewModal по-горе). Записва всички редове наведнъж.


/** Формат на дата на изпълнение за WH модала */
function formatWhFulfilledAt(v) {
  if (v == null || v === '') return '';
  try {
    if (typeof formatDisplayDateTime === 'function') {
      const s = formatDisplayDateTime(v);
      if (s) return s;
    }
  } catch (_) {}
  try {
    const d = (v instanceof Date) ? v : new Date(v);
    if (Number.isNaN(d.getTime())) return String(v);
    const pad = function (n) { return String(n).padStart(2, '0'); };
    return pad(d.getDate()) + '.' + pad(d.getMonth() + 1) + '.' + d.getFullYear() +
      ' ' + pad(d.getHours()) + '.' + pad(d.getMinutes());
  } catch (_) {
    return String(v);
  }
}
function isWhRequestFulfilled(rec) {
  const st = String((rec && rec.status) || '').trim().toLowerCase();
  return st === 'izpalnena' || st === 'изпълнена' || st === 'fulfilled' || st === 'done';
}

window.openWhViewModal = async function(id, showPrintButtons) {
  try {
    if (!document.getElementById('whViewModal') || !document.getElementById('whViewMaterialsBody')) {
      toast('❌ Модалът за материали липсва. Презаредете страницата (Ctrl+F5).');
      return;
    }
    const rec = await getWhById(id);
    if (!rec) { toast('❌ Заявката не е намерена.'); return; }

    // Заглавие според тип материали + номер
    const typeTitle =
      rec.materialType === 'office' ? 'Заявка за канцеларски материали' :
      rec.materialType === 'sanitary' ? 'Заявка за санитарни материали' :
      'Заявка за материали';
    const titleEl = document.getElementById('whViewTitle');
    if (titleEl) {
      titleEl.innerHTML = typeTitle + ' - № <span id="whViewId"></span>';
    }
    document.getElementById('whViewId').textContent = rec.id || '—';
    document.getElementById('whViewDate').textContent = rec.datetime || '—';
    document.getElementById('whViewMonthYear').textContent = (WH_MONTH_NAMES[parseInt(rec.mesec)] || rec.mesec) + ' ' + (rec.godina || '');
    document.getElementById('whViewStruktura').textContent = rec.struktura || '—';
    document.getElementById('whViewZayavitel').textContent = rec.zayavitel || '—';

    // Статус в цветна клетка: червена = Чакаща, зелена = Изпълнена
    const statusEl = document.getElementById('whViewStatus');
    const isDone = isWhRequestFulfilled(rec);
    if (statusEl) {
      statusEl.textContent = isDone ? 'Изпълнена' : 'Чакаща';
      statusEl.style.cssText = isDone
        ? 'display:inline-block;padding:4px 12px;border-radius:6px;font-weight:700;background:#d4edda;color:#155724;border:1px solid #c3e6cb;'
        : 'display:inline-block;padding:4px 12px;border-radius:6px;font-weight:700;background:#f8d7da;color:#721c24;border:1px solid #f5c6cb;';
    }
    // Дата на изпълнение — само при статус Изпълнена
    const fulWrap = document.getElementById('whViewFulfilledWrap');
    const fulEl = document.getElementById('whViewFulfilledAt');
    let fulText = '';
    try { fulText = isDone ? (formatWhFulfilledAt(rec.fulfilledAt) || '—') : ''; } catch (_) { fulText = isDone ? '—' : ''; }
    if (fulWrap) fulWrap.style.display = isDone ? '' : 'none';
    if (fulEl) fulEl.textContent = fulText || '—';

    // Заключване за Склад само когато заявката е „Изпълнена“.
    // (Старо поведение заключваше и при „Запази“ — премахнато.)
    const lockedForWarehouse = isWhRequestFulfilled(rec);
    const canEditZabelezka = (currentRole === 'admin' || (currentRole === 'warehouse' && !lockedForWarehouse)) && currentRole !== 'observer';

    const tbody = document.getElementById('whViewMaterialsBody');
    tbody.innerHTML = '';
    const materials = Array.isArray(rec.materials) ? rec.materials.map(normalizeWarehouseMaterial) : [];
    if (!materials.length) {
      tbody.innerHTML = '<tr><td colspan="7" style="padding:8px;text-align:center;">Няма въведени материали</td></tr>';
    } else {
      materials.forEach((m, i) => {
        const tr = document.createElement('tr');
        const zDisabled = canEditZabelezka ? '' : 'disabled';
        const zBg = canEditZabelezka ? '' : 'background:var(--locked-bg);';
        tr.innerHTML = `
          <td style="border:1px solid #ddd;padding:6px;text-align:center;">${i+1}</td>
          <td style="border:1px solid #ddd;padding:6px;text-align:center;white-space:nowrap;font-size:12px;">${escapeHtml(m.code || '—')}</td>
          <td style="border:1px solid #ddd;padding:6px;">${escapeHtml(m.name || '')}</td>
          <td style="border:1px solid #ddd;padding:6px;text-align:center;">${escapeHtml(m.merka || '')}</td>
          <td style="border:1px solid #ddd;padding:6px;text-align:center;"><input class="whview-kol" style="width:100%;max-width:64px;box-sizing:border-box;padding:4px;border:1px solid var(--line);border-radius:4px;text-align:center;" value="${escapeHtml(m.kolichestvo || '')}" ${currentRole !== 'admin' ? 'disabled' : ''}></td>
          <td style="border:1px solid #ddd;padding:6px;"><input class="whview-released" data-idx="${i}" style="width:100%;max-width:64px;box-sizing:border-box;padding:4px;border:1px solid var(--line);border-radius:4px;text-align:center;${zBg}" value="${escapeHtml(getReleasedQuantity(m))}" ${zDisabled} title="${canEditZabelezka ? '' : 'Записът е заключен. Само администратор може да редактира.'}"></td>
          <td style="border:1px solid #ddd;padding:6px;"><input class="whview-zabelezka" style="width:100%;box-sizing:border-box;padding:4px;border:1px solid var(--line);border-radius:4px;${zBg}" value="${escapeHtml(m.zabelezka || '')}" ${zDisabled} title="${canEditZabelezka ? '' : 'Записът е заключен. Само администратор може да редактира.'}"></td>
        `;
        tbody.appendChild(tr);
      });
      try { attachReleasedQuantityInputGuards(tbody); } catch (_) {}
    }

    // „Запази“: Склад (ако не е заключено) или Админ
    const saveBtn = document.getElementById('btnWhViewSave');
    if (saveBtn) {
      if (currentRole === 'admin') {
        saveBtn.style.display = '';
      } else if (currentRole === 'warehouse' && !lockedForWarehouse) {
        saveBtn.style.display = '';
      } else {
        saveBtn.style.display = 'none';
      }
    }

    const fulfillBtn = document.getElementById('btnWhViewFulfill');
    if (fulfillBtn) {
      if ((currentRole === 'admin' || currentRole === 'warehouse') && !isDone) {
        fulfillBtn.style.display = '';
        fulfillBtn.onclick = function (ev) {
          if (ev) { ev.preventDefault(); ev.stopPropagation(); }
          const rid = (document.getElementById('whViewId') && document.getElementById('whViewId').textContent) || '';
          if (!rid || rid === '—') { toast('❌ Няма номер на заявка.'); return; }
          if (typeof saveWhViewZabelezkaAndFulfill === 'function') {
            saveWhViewZabelezkaAndFulfill(rid);
          } else if (typeof markWhFulfilled === 'function') {
            markWhFulfilled(rid, false).then(function () { closeWhViewModal(); });
          }
        };
      } else {
        fulfillBtn.style.display = 'none';
        fulfillBtn.onclick = null;
      }
    }

    const printBtn = document.getElementById('btnWhViewPrint');
    if (printBtn) printBtn.style.display = showPrintButtons ? '' : 'none';

    // Ако модалът е статичният (първият в HTML), display flex
    const modal = document.getElementById('whViewModal');
    if (modal) modal.style.display = 'flex';
  } catch (e) {
    console.error(e);
    toast('❌ Грешка при отваряне на заявка.');
  }
};

async function saveWhViewModalChanges() {
  const idEl = document.getElementById('whViewId');
  const id = idEl ? idEl.textContent.trim() : '';
  if (!id || id === '—') return;
  if (currentRole !== 'warehouse' && currentRole !== 'admin') { toast('Нямате права за запис.'); return; }
  try {
    const rec = await getWhById(id);
    if (!rec) { toast('❌ Заявката не е намерена.'); return; }
    if (currentRole === 'warehouse' && (rec.status === 'izpalnena' || (typeof isWhRequestFulfilled === 'function' && isWhRequestFulfilled(rec)))) {
      toast('❌ Заявката е изпълнена и е заключена.');
      return;
    }
    if (typeof validateWhReleasedInputsOrToast === 'function' && !validateWhReleasedInputsOrToast()) return;

    applyWhModalInputsToMaterials(rec);
    // Debug: гарантираме, че няма размяна
    (rec.materials || []).forEach(function (m) {
      if (!m) return;
      m.otpusnatoKolichestvo = String(m.otpusnatoKolichestvo == null ? '' : m.otpusnatoKolichestvo);
      m.zabelezka = String(m.zabelezka == null ? '' : m.zabelezka);
    });

    try { addHistoryEntry(rec, currentRole === 'admin' ? 'Корекция (Админ)' : 'Запис (Склад)'); } catch (_) {}
    await saveWhRecord(rec);
    toast('✅ Промените са записани.');
    closeWhViewModal();
    await Promise.all([
      typeof renderWarehouseTable === 'function' ? renderWarehouseTable() : Promise.resolve(),
      typeof renderWarehouseSanitaryTable === 'function' ? renderWarehouseSanitaryTable() : Promise.resolve(),
      typeof renderWarehouseOfficeTable === 'function' ? renderWarehouseOfficeTable() : Promise.resolve(),
      typeof renderMyMaterials === 'function' ? renderMyMaterials() : Promise.resolve()
    ]);
  } catch (e) {
    console.error(e);
    toast('❌ Грешка при запис.');
  }
}



window.saveWhViewZabelezka = async function(id) {
  return saveWhViewModalChanges();
};

window.saveWhViewZabelezkaAndFulfill = async function(id) {
  try {
    const idEl = document.getElementById('whViewId');
    const rid = (id || (idEl && idEl.textContent) || '').toString().trim();
    if (!rid || rid === '—') { toast('❌ Няма номер на заявка.'); return; }
    const rec = await getWhById(rid);
    if (!rec) { toast('❌ Заявката не е намерена.'); return; }
    if (typeof validateWhReleasedInputsOrToast === 'function' && !validateWhReleasedInputsOrToast()) return;

    // 1) От модала: колона 5 = Отпуснато, колона 6 = Забележка
    applyWhModalInputsToMaterials(rec);
    // 2) Само празни Отпуснато ← Заявено
    fillEmptyReleasedFromRequested(rec.materials);

    rec.status = 'izpalnena';
    rec.fulfilledAt = (typeof formatLocalDateTimeSeconds === 'function')
        ? formatLocalDateTimeSeconds(new Date())
        : new Date().toLocaleString('bg-BG');
    if (currentRole === 'warehouse') rec.warehouseLocked = true;
    try { addHistoryEntry(rec, 'Изпълнена'); } catch (_) {}

    await saveWhRecord(rec);
    toast('✅ Заявката е изпълнена.');
    closeWhViewModal();
    await Promise.all([
      typeof renderWarehouseTable === 'function' ? renderWarehouseTable() : Promise.resolve(),
      typeof renderWarehouseSanitaryTable === 'function' ? renderWarehouseSanitaryTable() : Promise.resolve(),
      typeof renderWarehouseOfficeTable === 'function' ? renderWarehouseOfficeTable() : Promise.resolve()
    ]);
  } catch (e) {
    console.error('saveWhViewZabelezkaAndFulfill:', e);
    toast('❌ Грешка при изпълнение.');
  }
};

// ============================================================
//  ПЕЧАТ И PDF ЗА ЗАЯВКИ ЗА МАТЕРИАЛИ
// ============================================================
window.printWhRequest = async function(id) {
  const rec = await getWhById(id);
  if (!rec) {
    toast('❌ Заявката не е намерена.');
    return;
  }
  
  // Създаване на печатна версия
  const printWindow = window.open('', '_blank');
  const statusText = rec.status === 'izpalnena' ? 'Изпълнена' : 'Чакаща';
  
  let materialsRows = '';
  if (rec.materials && rec.materials.length) {
    materialsRows = rec.materials.map(m => `
      <tr>
        <td style="border:1px solid #000;padding:8px;">${escapeHtml(m.name)}</td>
        <td style="border:1px solid #000;padding:8px;">${escapeHtml(m.merka || '—')}</td>
        <td style="border:1px solid #000;padding:8px;">${escapeHtml(m.kolichestvo || '—')}</td>
        <td style="border:1px solid #000;padding:8px;">${escapeHtml(getReleasedQuantity(m) || '—')}</td>
        <td style="border:1px solid #000;padding:8px;">${escapeHtml(m.zabelezka || '—')}</td>
      </tr>
    `).join('');
  } else {
    materialsRows = '<tr><td colspan="4" style="border:1px solid #000;padding:8px;">Няма добавени материали</td></tr>';
  }
  
  printWindow.document.write(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>Заявка за материали №${rec.id}</title>
      
    </head>
    <body>
      <h1>Заявка за материали №${rec.id}</h1>
      
      <div class="info-grid">
        <div class="info-item">
          <span class="label">Дата на подаване:</span> ${escapeHtml(rec.datetime || '—')}
        </div>
        <div class="info-item">
          <span class="label">Месец:</span> ${WH_MONTH_NAMES[parseInt(rec.mesec)] || rec.mesec}
        </div>
        <div class="info-item">
          <span class="label">Година:</span> ${escapeHtml(rec.godina)}
        </div>
        <div class="info-item">
          <span class="label">Структура:</span> ${escapeHtml(rec.struktura)}
        </div>
        <div class="info-item">
          <span class="label">Заявител:</span> ${escapeHtml(rec.zayavitel)}
        </div>
        <div class="info-item">
          <span class="label">Статус:</span> ${statusText}
        </div>
      </div>
      
      <h2>Материали</h2>
      <table>
        <thead>
          <tr>
            <th>Материал</th>
            <th>Мярка</th>
            <th>Количество</th>
            <th>Забележка</th>
          </tr>
        </thead>
        <tbody>
          ${materialsRows}
        </tbody>
      </table>
      
      <div style="margin-top: 30px; text-align: center;">
        <button onclick="window.print()" style="padding: 10px 20px; font-size: 16px;">🖨 Печат</button>
        <button onclick="window.close()" style="padding: 10px 20px; font-size: 16px; margin-left: 10px;">Затвори</button>
      </div>
      
      <script>
        window.onload = function() {
          window.print();
        }
      <\/script>
    </body>
    </html>
  `);
  printWindow.document.close();
};

window.downloadWhRequestPDF = async function(id) {
  const rec = await getWhById(id);
  if (!rec) {
    toast('❌ Заявката не е намерена.');
    return;
  }
  
  // Използваме printWhRequest за да отворим прозореца, където потребителят може да избере "Save as PDF"
  await printWhRequest(id);
  toast('📄 Изберете "Save as PDF" от диалоговия прозорец за печат');
};

// ============================================================
//  РЕНДИРАНЕ НА МЕСЕЧНИ ЗАЯВКИ
// ============================================================
