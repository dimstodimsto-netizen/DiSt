@echo off
setlocal
cd /d "%~dp0"
if not exist "server.js" (
  if exist "%~dp0..\server.js" (
    cd /d "%~dp0.."
  ) else (
    echo ERROR: server.js not found.
    pause
    exit /b 1
  )
)
where node >nul 2>&1
if errorlevel 1 (
  echo ERROR: Node.js is not installed or not in PATH.
  pause
  exit /b 2
)

REM ============================================================
REM  Мрежа / HTTPS (по подразбиране: HTTP за цялата LAN)
REM  Не махайте REM редовете по-долу, освен ако имате обратен
REM  прокси (Caddy / nginx / IIS) пред Node с HTTPS.
REM
REM  set LISTEN_HOST=127.0.0.1
REM  set TRUST_PROXY=1
REM  set PORT=3000
REM ============================================================

echo Starting DiSt...
node server.js
