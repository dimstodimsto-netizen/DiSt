@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0.."
set "CFG=%~dp0BACKUP_TARGET.txt"
if not exist "%CFG%" (
  echo ERROR: Missing scripts\BACKUP_TARGET.txt
  echo Copy BACKUP_TARGET.txt.example to BACKUP_TARGET.txt and set the destination.
  exit /b 2
)
set "TARGET="
for /f "usebackq tokens=* delims=" %%A in ("%CFG%") do if not defined TARGET if not "%%A"=="" if not "%%A:~0,1%%"=="#" set "TARGET=%%A"
if not defined TARGET (
  echo ERROR: BACKUP_TARGET.txt has no destination path.
  exit /b 2
)
if not exist "%TARGET%" mkdir "%TARGET%" 2>nul
if not exist "%TARGET%" (
  echo ERROR: Destination is unavailable: %TARGET%
  exit /b 3
)
set "SRC=%~dp0..\data\backups"
for /f "delims=" %%F in ('dir /b /a-d /o-d "%SRC%\DiSt_full_backup_*.zip" 2^>nul') do if not defined LATEST set "LATEST=%%F"
if not defined LATEST (
  echo ERROR: No full Recovery backup found.
  exit /b 4
)
echo Copying %LATEST% to %TARGET% ...
robocopy "%SRC%" "%TARGET%" "%LATEST%" "%LATEST%.sha256" /Z /R:3 /W:5 /NFL /NDL /NP
set "RC=%ERRORLEVEL%"
if %RC% GEQ 8 (
  echo ERROR: robocopy failed, code %RC%
  exit /b %RC%
)
powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -Command "$s=(Get-FileHash -Algorithm SHA256 -LiteralPath '%SRC%\%LATEST%').Hash.ToLower(); $t=(Get-Content -LiteralPath '%TARGET%\%LATEST%.sha256' -Raw).Trim().Split()[0].ToLower(); if($s -ne $t){exit 9}" 
if errorlevel 1 (
  echo ERROR: SHA-256 verification failed after copy.
  exit /b 9
)
echo OK: external backup verified: %TARGET%\%LATEST%
exit /b 0
