'use strict';

/**
 * HTTP маршрути за ремонтни заявки (/api/records*).
 * createRecordsRoutes(deps) → async handle(req, res, parsed, pathname)
 * Връща true ако е обработил заявката.
 */
function createRecordsRoutes(deps) {
  const {
    requireAuth,
    readJsonFromRequest,
    sendJSON,
    listRecordsServer,
    createRecordServer,
    markRecordsSeenServer,
    updateRecordServer,
    deleteRecordServer,
    notifyNewRepairRequest,
    withTransaction,
    getNextRecordIdTx
  } = deps;

  return async function handleRecordsRoute(req, res, parsed, pathname) {
    if (pathname === '/api/records' && req.method === 'GET') {
      const sess = requireAuth(req, res);
      if (!sess) return true;
      try {
        const result = listRecordsServer(sess, {
          status: parsed.searchParams.get('status') || '',
          struktura: parsed.searchParams.get('struktura') || '',
          year: parsed.searchParams.get('year') || '',
          month: parsed.searchParams.get('month') || '',
          q: parsed.searchParams.get('q') || '',
          unresolved: parsed.searchParams.get('unresolved') || '',
          page: parsed.searchParams.get('page') || '1',
          pageSize: parsed.searchParams.get('pageSize') || '200'
        });
        sendJSON(res, 200, result);
      } catch (e) {
        sendJSON(res, 500, { error: e.message || 'Грешка при зареждане на заявките.' });
      }
      return true;
    }

    if (pathname === '/api/records' && req.method === 'POST') {
      const sess = requireAuth(req, res);
      if (!sess) return true;
      const input = await readJsonFromRequest(req, res, { maxBytes: 512 * 1024 });
      if (!input) return true;
      try {
        const rec = createRecordServer(sess, input);
        sendJSON(res, 201, rec);
        notifyNewRepairRequest(rec);
      } catch (e) {
        sendJSON(res, e.status || 500, { error: e.message || 'Грешка при създаване на заявка.' });
      }
      return true;
    }

    if (pathname === '/api/records/mark-seen' && req.method === 'POST') {
      const sess = requireAuth(req, res);
      if (!sess) return true;
      const input = await readJsonFromRequest(req, res, { maxBytes: 64 * 1024 });
      if (!input) return true;
      try {
        const result = markRecordsSeenServer(sess, input.ids || input);
        sendJSON(res, 200, result);
      } catch (e) {
        sendJSON(res, e.status || 500, { error: e.message || 'Грешка при маркиране.' });
      }
      return true;
    }

    if (pathname === '/api/records/next-id' && req.method === 'GET') {
      const sess = requireAuth(req, res);
      if (!sess) return true;
      // Само информативен — реалното ID се генерира атомично в POST /api/records
      const nextId = withTransaction(() => getNextRecordIdTx());
      sendJSON(res, 200, { nextId });
      return true;
    }

    if (pathname.startsWith('/api/records/') && req.method === 'PUT') {
      const id = decodeURIComponent(pathname.slice('/api/records/'.length));
      if (id === 'mark-seen' || id === 'next-id') return false;
      const sess = requireAuth(req, res);
      if (!sess) return true;
      const input = await readJsonFromRequest(req, res, { maxBytes: 512 * 1024 });
      if (!input) return true;
      try {
        const rec = updateRecordServer(sess, id, input);
        sendJSON(res, 200, rec);
      } catch (e) {
        sendJSON(res, e.status || 500, { error: e.message || 'Грешка при обновяване.' });
      }
      return true;
    }

    if (pathname.startsWith('/api/records/') && req.method === 'DELETE') {
      const id = decodeURIComponent(pathname.slice('/api/records/'.length));
      if (id === 'mark-seen' || id === 'next-id') return false;
      const sess = requireAuth(req, res);
      if (!sess) return true;
      try {
        deleteRecordServer(sess, id);
        sendJSON(res, 200, { ok: true, id });
      } catch (e) {
        sendJSON(res, e.status || 500, { error: e.message || 'Грешка при изтриване.' });
      }
      return true;
    }

    return false;
  };
}

module.exports = { createRecordsRoutes };
