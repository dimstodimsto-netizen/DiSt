@echo off
REM DiSt watchdog: if port 3000 is not LISTENING, start the server (hidden).
setlocal
cd /d "%~dp0.."

netstat -ano 2>nul | findstr ":3000" | findstr "LISTENING" >nul
if %errorlevel%==0 (
  echo [%date% %time%] OK - port 3000 is listening.
  exit /b 0
)

echo [%date% %time%] Port 3000 not listening - starting server...
if exist "START_HIDDEN.vbs" (
  cscript //nologo "START_HIDDEN.vbs"
  exit /b 0
)
if exist "START_SERVER.bat" (
  start "" /min "START_SERVER.bat"
  exit /b 0
)
if exist "server.js" (
  start "" /min cmd /c "node server.js"
  exit /b 0
)
echo ERROR: No START_HIDDEN.vbs / START_SERVER.bat / server.js found.
exit /b 1
