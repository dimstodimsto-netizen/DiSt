'use strict';

function createHttpHelpers({ addCORS }) {
function applySecurityHeaders(res) {
  // БЕЗ X-Frame-Options и БЕЗ Content-Security-Policy — iframe клиентът иначе чупи.
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=(), payment=(), usb=()');
  res.setHeader('X-DNS-Prefetch-Control', 'off');
  res.setHeader('Server', 'DiSt');
}

function cacheControlForExt(ext) {
  if (ext === '.html' || ext === '') return 'no-store';
  if (ext === '.js' || ext === '.css' || ext === '.map') return 'public, max-age=31536000, immutable';
  if (ext === '.png' || ext === '.ico' || ext === '.svg' || ext === '.jpg' || ext === '.jpeg' || ext === '.gif' || ext === '.webp') {
    return 'public, max-age=86400';
  }
  return 'no-store';
}

function sendJSON(res, status, obj) {
  const body = JSON.stringify(obj);
  addCORS(res);
  applySecurityHeaders(res);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store'
  });
  res.end(body);
}

function readBody(req, maxBytes = 5 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let chunks = [];
    let size = 0;
    req.on('data', c => {
      size += c.length;
      if (size > maxBytes) { reject(new Error('Body too large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (chunks.length === 0) {
        resolve('');
        return;
      }
      resolve(Buffer.concat(chunks).toString('utf8'));
    });
    req.on('error', reject);
  });
}

function parseJsonOrError(body, res, opts) {
  opts = opts || {};
  const raw = body == null ? '' : String(body);
  if (!raw.trim()) {
    if (opts.emptyOk) return {};
    sendJSON(res, 400, { error: opts.emptyError || 'empty body' });
    return null;
  }
  try {
    return JSON.parse(raw);
  } catch (e) {
    sendJSON(res, 400, { error: opts.badError || 'bad json' });
    return null;
  }
}

async function readJsonFromRequest(req, res, opts) {
  opts = opts || {};
  let body;
  try {
    body = await readBody(req, opts.maxBytes);
  } catch (e) {
    sendJSON(res, 400, { error: (e && e.message) || 'Body too large' });
    return null;
  }
  const raw = body == null ? '' : String(body);
  if (!raw.trim()) {
    if (opts.emptyOk) return {};
    sendJSON(res, 400, { error: opts.emptyError || 'empty body' });
    return null;
  }
  try {
    return JSON.parse(raw);
  } catch (e) {
    sendJSON(res, 400, { error: opts.badError || 'bad json' });
    return null;
  }
}
  return { applySecurityHeaders, cacheControlForExt, sendJSON, readBody, parseJsonOrError, readJsonFromRequest };
}
module.exports = { createHttpHelpers };
