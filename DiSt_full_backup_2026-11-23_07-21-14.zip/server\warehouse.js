'use strict';

/** Warehouse ownership, visibility and material-type migration. */
function createWarehouseModule({ kvGet, kvSet, getUserByIdServer, getUserByUsernameServer }) {
function ownStrukturaOf(sess) {
  const u = getUserByIdServer(sess.userId) || getUserByUsernameServer(sess.username);
  return String((u && u.struktura) || '').trim();
}

function normalizeStrukturaName(s) {
  return String(s || '').trim().replace(/\s+/g, ' ').toLowerCase();
}

function whRecordVisibleToUser(rec, ownStruktura) {
  // Празен ownStruktura или празна struktura в записа → видим (не крием стари данни)
  if (!ownStruktura || !rec || typeof rec !== 'object') return true;
  const rs = normalizeStrukturaName(rec.struktura);
  if (!rs) return true;
  return rs === normalizeStrukturaName(ownStruktura);
}

function materialNameSetFromKv(key) {
  const set = new Set();
  try {
    const raw = kvGet(key);
    if (!raw) return set;
    const arr = JSON.parse(raw);
    if (!Array.isArray(arr)) return set;
    for (const item of arr) {
      if (typeof item === 'string') set.add(item.trim().toLowerCase());
      else if (item && item.name) set.add(String(item.name).trim().toLowerCase());
    }
  } catch (_) {}
  return set;
}

function migrateWhMaterialTypes() {
  const officeNames = materialNameSetFromKv('available_office_materials');
  const sanitaryNames = materialNameSetFromKv('available_sanitary_materials');
  let idx = [];
  try {
    const raw = kvGet('wh-index');
    idx = raw ? JSON.parse(raw) : [];
    if (!Array.isArray(idx)) idx = [];
  } catch (_) { idx = []; }

  const updated = [];
  const skipped = [];
  const ambiguous = [];

  for (const id of idx) {
    const key = 'wh:' + String(id);
    let rec;
    try {
      const raw = kvGet(key);
      if (!raw) { skipped.push({ id, reason: 'missing' }); continue; }
      rec = JSON.parse(raw);
    } catch (_) {
      skipped.push({ id, reason: 'parse' });
      continue;
    }
    const existing = String(rec.materialType || '').trim();
    if (existing === 'office' || existing === 'sanitary') {
      skipped.push({ id, reason: 'already:' + existing });
      continue;
    }

    let officeHits = 0, sanitaryHits = 0;
    const mats = Array.isArray(rec.materials) ? rec.materials : [];
    for (const m of mats) {
      const n = String((m && m.name) || '').trim().toLowerCase();
      if (!n) continue;
      if (officeNames.has(n)) officeHits++;
      if (sanitaryNames.has(n)) sanitaryHits++;
    }

    let type = null;
    if (officeHits > 0 && sanitaryHits === 0) type = 'office';
    else if (sanitaryHits > 0 && officeHits === 0) type = 'sanitary';
    else if (officeHits > sanitaryHits) type = 'office';
    else if (sanitaryHits > officeHits) type = 'sanitary';
    else if (officeHits === 0 && sanitaryHits === 0) {
      // няма съвпадения — оставяме general, но маркираме
      type = 'general';
      ambiguous.push({ id, officeHits, sanitaryHits });
    } else {
      type = officeHits >= sanitaryHits ? 'office' : 'sanitary';
      ambiguous.push({ id, officeHits, sanitaryHits, chosen: type });
    }

    rec.materialType = type;
    try {
      kvSet(key, JSON.stringify(rec));
      updated.push({ id, materialType: type });
    } catch (e) {
      skipped.push({ id, reason: String(e.message || e) });
    }
  }
  return { updated, skipped, ambiguous, updatedCount: updated.length };
}
  return { ownStrukturaOf, normalizeStrukturaName, whRecordVisibleToUser, materialNameSetFromKv, migrateWhMaterialTypes };
}
module.exports = { createWarehouseModule };
