async function renderWarehouseSanitaryTable(opts) {
  const tbody = document.getElementById('whSanitaryTableBody');
  const info = document.getElementById('whSanitaryTableInfo');
  const fromFilter = !!(opts && opts.fromFilter);

  // При промяна на филтър НЕ се прави заявка към сървъра.
  if (!fromFilter && !Array.isArray(warehouseRequestsCache)) {
    const soft = (typeof isSoftRefreshOpts === 'function') ? isSoftRefreshOpts(opts) : !!(opts && opts.softRefresh);
    if (typeof setContentLoading === 'function') {
      setContentLoading(tbody, '<tr><td colspan="8" class="hint">Зареждане...</td></tr>', soft);
    } else if (!soft) {
      tbody.innerHTML = '<tr><td colspan="8" class="hint">Зареждане...</td></tr>';
    }
  }

  try {
    const recs = await loadWarehouseRequestsCache();

    const sanitaryRecs = recs.filter(r => {
      const t = String(r.materialType || '').trim();
      return t === 'sanitary' || t === '';
    });

    bindWarehouseRequestFilters('sanitary');
    populateWarehouseRequestFilters('sanitary', sanitaryRecs);
    const filteredRecs = filterWarehouseRequestRecords(sanitaryRecs, 'sanitary');

    tbody.innerHTML = '';

    if (!filteredRecs.length) {
      tbody.innerHTML = '<tr><td colspan="8" class="hint">' +
        (sanitaryRecs.length ? 'Няма заявки, отговарящи на избраните филтри.' : 'Няма подадени заявки за санитарни материали.') +
        '</td></tr>';
      info.textContent = sanitaryRecs.length ? '0 заявки от ' + sanitaryRecs.length : '0 заявки';
      return;
    }

    info.textContent = filteredRecs.length + ' заявки' +
      (filteredRecs.length !== sanitaryRecs.length ? ' от ' + sanitaryRecs.length : '');

    filteredRecs.forEach((rec) => {
      const statusClass = rec.status === 'izpalnena' ? 'wh-status-izpalnena' : 'wh-status-chakashta';
      const statusText = rec.status === 'izpalnena' ? 'Изпълнена' : 'Чакаща';
      const canFulfill = (currentRole === 'admin' || currentRole === 'warehouse');
      const canReopenOrDelete = currentRole === 'admin';
      let actionButtons = '';

      // Преглед: клик върху реда (без отделен бутон)
      if (rec.status === 'izpalnena' || rec.status === 'Изпълнена') {
        if (canReopenOrDelete) {
          actionButtons += `<button class="wh-action-btn" onclick="event.stopPropagation(); markWhFulfilled('${rec.id}', true)">↺ Отвори отново</button>`;
        }
      } else if (canFulfill) {
        actionButtons += `<button class="wh-action-btn" onclick="event.stopPropagation(); markWhFulfilled('${rec.id}', false)">✅ Изпълни</button>`;
      }
      if (canReopenOrDelete) {
        actionButtons += `<button class="wh-action-btn" onclick="deleteWhRequest('${rec.id}')">✕</button>`;
      }

      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${escapeHtml(rec.id)}</td>
        <td>${escapeHtml(rec.datetime || '')}</td>
        <td>${WH_MONTH_NAMES[parseInt(rec.mesec)] || rec.mesec}</td>
        <td>${escapeHtml(rec.godina)}</td>
        <td>${escapeHtml(rec.struktura)}</td>
        <td>${escapeHtml(rec.zayavitel)}</td>
        <td><span class="wh-status-badge ${statusClass}">${statusText}</span></td>
        <td>${actionButtons || '—'}</td>
      `;
      tr.style.cursor = 'pointer';
      tr.onclick = (e) => {
        if (e.target.tagName === 'BUTTON') return;
        openWhViewModal(rec.id, true);
      };
      tbody.appendChild(tr);
    });
  } catch (e) {
    console.error(e);
    tbody.innerHTML = '<tr><td colspan="8" class="hint">Грешка при зареждане.</td></tr>';
  }
}

// ============================================================
//  РЕНДИРАНЕ НА ЗАЯВКИ ЗА КАНЦЕЛСКИ МАТЕРИАЛИ (СКЛАД)
// ============================================================
// ============================================================
//  РЕНДИРАНЕ НА ЗАЯВКИ ЗА КАНЦЕЛАРСКИ МАТЕРИАЛИ (СКЛАД)
// ============================================================
async function renderWarehouseOfficeTable(opts) {
  const tbody = document.getElementById('whOfficeTableBody');
  const info = document.getElementById('whOfficeTableInfo');
  const fromFilter = !!(opts && opts.fromFilter);

  // При промяна на филтър НЕ се прави заявка към сървъра.
  if (!fromFilter && !Array.isArray(warehouseRequestsCache)) {
    const soft = (typeof isSoftRefreshOpts === 'function') ? isSoftRefreshOpts(opts) : !!(opts && opts.softRefresh);
    if (typeof setContentLoading === 'function') {
      setContentLoading(tbody, '<tr><td colspan="8" class="hint">Зареждане...</td></tr>', soft);
    } else if (!soft) {
      tbody.innerHTML = '<tr><td colspan="8" class="hint">Зареждане...</td></tr>';
    }
  }

  try {
    const recs = await loadWarehouseRequestsCache();

    const officeRecs = recs.filter(r => {
      const t = String(r.materialType || '').trim();
      return t === 'office' || t === '';
    });

    bindWarehouseRequestFilters('office');
    populateWarehouseRequestFilters('office', officeRecs);
    const filteredRecs = filterWarehouseRequestRecords(officeRecs, 'office');

    tbody.innerHTML = '';

    if (!filteredRecs.length) {
      tbody.innerHTML = '<tr><td colspan="8" class="hint">' +
        (officeRecs.length ? 'Няма заявки, отговарящи на избраните филтри.' : 'Няма подадени заявки за канцеларски материали.') +
        '</td></tr>';
      info.textContent = officeRecs.length ? '0 заявки от ' + officeRecs.length : '0 заявки';
      return;
    }

    info.textContent = filteredRecs.length + ' заявки' +
      (filteredRecs.length !== officeRecs.length ? ' от ' + officeRecs.length : '');

    filteredRecs.forEach((rec) => {
      const statusClass = rec.status === 'izpalnena' ? 'wh-status-izpalnena' : 'wh-status-chakashta';
      const statusText = rec.status === 'izpalnena' ? 'Изпълнена' : 'Чакаща';
      const canFulfill = (currentRole === 'admin' || currentRole === 'warehouse');
      const canReopenOrDelete = currentRole === 'admin';
      let actionButtons = '';

      // Преглед: клик върху реда (без отделен бутон)
      if (rec.status === 'izpalnena' || rec.status === 'Изпълнена') {
        if (canReopenOrDelete) {
          actionButtons += `<button class="wh-action-btn" onclick="event.stopPropagation(); markWhFulfilled('${rec.id}', true)">↺ Отвори отново</button>`;
        }
      } else if (canFulfill) {
        actionButtons += `<button class="wh-action-btn" onclick="event.stopPropagation(); markWhFulfilled('${rec.id}', false)">✅ Изпълни</button>`;
      }
      if (canReopenOrDelete) {
        actionButtons += `<button class="wh-action-btn" onclick="deleteWhRequest('${rec.id}')">✕</button>`;
      }

      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${escapeHtml(rec.id)}</td>
        <td>${escapeHtml(rec.datetime || '')}</td>
        <td>${WH_MONTH_NAMES[parseInt(rec.mesec)] || rec.mesec}</td>
        <td>${escapeHtml(rec.godina)}</td>
        <td>${escapeHtml(rec.struktura)}</td>
        <td>${escapeHtml(rec.zayavitel)}</td>
        <td><span class="wh-status-badge ${statusClass}">${statusText}</span></td>
        <td>${actionButtons || '—'}</td>
      `;
      tr.style.cursor = 'pointer';
      tr.onclick = (e) => {
        if (e.target.tagName === 'BUTTON') return;
        openWhViewModal(rec.id, true);
      };
      tbody.appendChild(tr);
    });
  } catch (e) {
    console.error(e);
    tbody.innerHTML = '<tr><td colspan="8" class="hint">Грешка при зареждане.</td></tr>';
  }
}

// ============================================================
//  РЕНДИРАНЕ НА МОИТЕ ЗАЯВКИ ЗА МАТЕРИАЛИ
// ============================================================
async function renderMyMaterials(opts) {
  const soft = (typeof isSoftRefreshOpts === 'function') ? isSoftRefreshOpts(opts) : !!(opts && opts.softRefresh);
  const tbody = document.getElementById('myMaterialsBody');
  const info = document.getElementById('myMaterialsInfo');
  if (typeof setContentLoading === 'function') {
    setContentLoading(tbody, '<tr><td colspan="6" class="hint">Зареждане...</td></tr>', soft);
  } else if (!soft) {
    tbody.innerHTML = '<tr><td colspan="6" class="hint">Зареждане...</td></tr>';
  }
  
  try {
    const recs = await getAllWhRecords();
    const myRecs = recs.filter(r => r.zayavitel === currentUserFullName);
    
    // Сортиране по дата (най-новите първи)
    myRecs.sort((a, b) => {
      const dateA = new Date(a.createdAt || 0);
      const dateB = new Date(b.createdAt || 0);
      return dateB - dateA;
    });
    
    tbody.innerHTML = '';
    info.textContent = myRecs.length + ' заявки';
    
    if (!myRecs.length) {
      tbody.innerHTML = '<tr><td colspan="5" class="hint">Няма подадени заявки за материали.</td></tr>';
      return;
    }
    
    myRecs.forEach((rec, idx) => {
      const statusClass = rec.status === 'izpalnena' ? 'wh-status-izpalnena' : 'wh-status-chakashta';
      const statusText = rec.status === 'izpalnena' ? 'Изпълнена' : 'Чакаща';
      
      // Определяне на типа материал за показване
      const materialTypeBadge = rec.materialType === 'office' ? '<span style="font-size:11px;color:var(--accent);">📝 Канцеларски</span>' : 
                               rec.materialType === 'sanitary' ? '<span style="font-size:11px;color:var(--ok);">🧻 Санитарни</span>' : 
                               '<span style="font-size:11px;color:var(--ink-soft);">Обща</span>';
      
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${escapeHtml(rec.id)}</td>
        <td>${escapeHtml(rec.datetime || '')}</td>
        <td>${WH_MONTH_NAMES[parseInt(rec.mesec)] || rec.mesec}</td>
        <td>${escapeHtml(rec.godina)}</td>
        <td>${materialTypeBadge}</td>
        <td><span class="wh-status-badge ${statusClass}">${statusText}</span></td>
      `;
      tr.style.cursor = 'pointer';
      tr.onclick = () => openWhViewModal(rec.id, true); // true = с бутони за печат/PDF
      tbody.appendChild(tr);
    });
    
  } catch (e) {
    console.error(e);
    tbody.innerHTML = '<tr><td colspan="6" class="hint">Грешка при зареждане.</td></tr>';
  }
}

// Нови функции: преглед на заявка за материали (модал)
// ============================================================

// Печат на заявката (опростен изглед)
function whViewPrint() {
  const id = document.getElementById('whViewId').textContent;
  const title = document.getElementById('whViewTitle').textContent;
  const date = document.getElementById('whViewDate').textContent;
  const struktura = document.getElementById('whViewStruktura').textContent;
  const zayavitel = document.getElementById('whViewZayavitel').textContent;
  const tbody = document.getElementById('whViewMaterialsBody');
  const rowsHtml = Array.from(tbody.querySelectorAll('tr')).map((tr, i) => {
    const cols = Array.from(tr.children).map(td => td.innerHTML);
    return '<tr>' + cols.map(c => '<td style="border:1px solid #000;padding:6px;">' + c + '</td>').join('') + '</tr>';
  }).join('');
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>${escapeHtml(title)}</title></head><body>` +
    `<h3>${escapeHtml(title)}</h3><div><b>Дата:</b> ${escapeHtml(date)}</div><div><b>Структура:</b> ${escapeHtml(struktura)}</div><div><b>Заявител:</b> ${escapeHtml(zayavitel)}</div>` +
    `<table style="width:100%;border-collapse:collapse;margin-top:12px;"><thead><tr><th style="border:1px solid #000;padding:6px;">№</th><th style="border:1px solid #000;padding:6px;width:72px;">Код</th><th style="border:1px solid #000;padding:6px;">Материал</th><th style="border:1px solid #000;padding:6px;width:64px;">Мярка</th><th style="border:1px solid #000;padding:6px;width:120px;">Заявено количество</th><th style="border:1px solid #000;padding:6px;width:128px;">Отпуснато количество</th><th style="border:1px solid #000;padding:6px;">Забележка</th></tr></thead><tbody>` + rowsHtml + `</tbody></table></body></html>`;
  const win = window.open('', '_blank');
  if (!win) { toast('Браузърът блокира отварянето на прозорец за печат.'); return; }
  win.document.write(html);
  win.document.close();
  win.focus();
  setTimeout(() => win.print(), 300);
}

// Свързваме бутоните на модала (веднъж)
(function bindWhViewModalButtons() {
  function wire() {
    const closeBtn = document.getElementById('btnWhViewClose');
    if (closeBtn && !closeBtn.__whBound) {
      closeBtn.__whBound = true;
      closeBtn.addEventListener('click', function (e) {
        e.preventDefault();
        closeWhViewModal();
      });
    }
    const saveBtn = document.getElementById('btnWhViewSave');
    if (saveBtn && !saveBtn.__whBound) {
      saveBtn.__whBound = true;
      saveBtn.addEventListener('click', function (e) {
        e.preventDefault();
        if (typeof saveWhViewModalChanges === 'function') saveWhViewModalChanges();
      });
    }
    const printBtn = document.getElementById('btnWhViewPrint');
    if (printBtn && !printBtn.__whBound) {
      printBtn.__whBound = true;
      printBtn.addEventListener('click', function (e) {
        e.preventDefault();
        if (typeof whViewPrint === 'function') whViewPrint();
      });
    }
    const fulfillBtn = document.getElementById('btnWhViewFulfill');
    if (fulfillBtn && !fulfillBtn.__whBound) {
      fulfillBtn.__whBound = true;
      fulfillBtn.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        const rid = (document.getElementById('whViewId') && document.getElementById('whViewId').textContent) || '';
        if (!rid || rid === '—') { toast('❌ Няма номер на заявка.'); return; }
        if (typeof saveWhViewZabelezkaAndFulfill === 'function') saveWhViewZabelezkaAndFulfill(rid);
        else if (typeof markWhFulfilled === 'function') markWhFulfilled(rid, false).then(function () { closeWhViewModal(); });
      });
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wire);
  else wire();
  setTimeout(wire, 300);
})();



  // Експорт (ако са function declarations в IIFE scope)
