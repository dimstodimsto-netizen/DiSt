/**
 * materials-catalog-ui.js — app.js modularization
 * Налични санитарни и канцеларски материали (списъци).
 * Load AFTER app.js.
 */

// ---- ФУНКЦИИ ЗА САНитарНИ МАТЕРИАЛИ ----
async function renderSanitaryMaterialsList(opts) {
  const soft = (typeof isSoftRefreshOpts === 'function') ? isSoftRefreshOpts(opts) : !!(opts && opts.softRefresh);
  const container = document.getElementById('sanitaryMaterialsListItems');
  const loading = document.getElementById('sanitaryMaterialsListLoading');
  if (!container) return;
  if (!soft) {
    if (loading) loading.style.display = 'block';
    container.innerHTML = '';
  } else {
    ensureDimLoadingStyle();
    container.classList.add('dim-loading');
  }

  try {
    const materials = await getAvailableSanitaryMaterials();
    if (loading) loading.style.display = 'none';
    container.classList.remove('dim-loading');
    container.innerHTML = '';

    if (!materials.length) {
      container.innerHTML = '<div class="hint">Все още няма добавени санитарни материали.</div>';
      return;
    }

    const frag = document.createDocumentFragment();
    materials.forEach((mat, index) => {
      const item = document.createElement('div');
      item.className = 'materials-list-item';
      const canEdit = (currentRole !== 'observer');
      const editBtn = canEdit
        ? `<button class="ghost" style="padding:4px 8px;font-size:12px;color:var(--accent);" title="Редактирай" onclick="editSanitaryMaterial(${index})">✎</button>`
        : '';
      const delBtn = canEdit
        ? `<button class="ghost" style="padding:4px 8px;font-size:12px;color:#c0392b;" title="Изтрий" onclick="deleteSanitaryMaterial(${index})">✕</button>`
        : '';
      item.innerHTML = `
        <div class="mat-code">${escapeHtml(mat.code || '—')}</div>
        <div class="mat-name">${escapeHtml(mat.name)}</div>
        <div class="mat-merka">${escapeHtml(mat.merka || '—')}</div>
        <div class="mat-actions">${editBtn}${delBtn}</div>
      `;
      frag.appendChild(item);
    });
    container.appendChild(frag);
  } catch (e) {
    console.error('renderSanitaryMaterialsList:', e);
    if (loading) loading.style.display = 'none';
    container.classList.remove('dim-loading');
    container.innerHTML = '<div class="hint">Грешка при зареждане на санитарните материали.</div>';
  }
}


window.__editingSanitaryIndex = null;
window.__editingOfficeIndex = null;

function setCatalogAddButtonLabel(btnId, editing) {
  var btn = document.getElementById(btnId);
  if (!btn) return;
  btn.textContent = editing ? '💾 Запази' : '+ Добави';
}

window.editSanitaryMaterial = async function(index) {
  if (currentRole === 'observer') { toast('Само преглед — нямате право за корекция.'); return; }
  try {
    const materials = await getAvailableSanitaryMaterials();
    const mat = materials[index];
    if (!mat) { toast('❌ Материалът не е намерен.'); return; }
    window.__editingSanitaryIndex = index;
    var codeInput = document.getElementById('newSanitaryMaterialCode');
    var nameInput = document.getElementById('newSanitaryMaterialName');
    var merkaInput = document.getElementById('newSanitaryMaterialMerka');
    if (codeInput) codeInput.value = mat.code || '';
    if (nameInput) nameInput.value = mat.name || '';
    if (merkaInput) merkaInput.value = mat.merka || '';
    setCatalogAddButtonLabel('btnAddSanitaryMaterial', true);
    if (nameInput) nameInput.focus();
    toast('Редакция: променете полетата и натиснете „Запази“.');
  } catch (e) {
    toast('❌ Грешка при зареждане за редакция.');
  }
};

window.editOfficeMaterial = async function(index) {
  if (currentRole === 'observer') { toast('Само преглед — нямате право за корекция.'); return; }
  try {
    const materials = await getAvailableOfficeMaterials();
    const mat = materials[index];
    if (!mat) { toast('❌ Материалът не е намерен.'); return; }
    window.__editingOfficeIndex = index;
    var codeInput = document.getElementById('newOfficeMaterialCode');
    var nameInput = document.getElementById('newOfficeMaterialName');
    var merkaInput = document.getElementById('newOfficeMaterialMerka');
    if (codeInput) codeInput.value = mat.code || '';
    if (nameInput) nameInput.value = mat.name || '';
    if (merkaInput) merkaInput.value = mat.merka || '';
    setCatalogAddButtonLabel('btnAddOfficeMaterial', true);
    if (nameInput) nameInput.focus();
    toast('Редакция: променете полетата и натиснете „Запази“.');
  } catch (e) {
    toast('❌ Грешка при зареждане за редакция.');
  }
};

window.deleteSanitaryMaterial = async function(index) {
  if (currentRole === 'observer') { toast('Само преглед — нямате право за корекция.'); return; }
  if (!(await confirmDialog('Сигурни ли сте, че искате да изтриете този санитарен материал?'))) return;
  
  try {
    const materials = await getAvailableSanitaryMaterials();
    materials.splice(index, 1);
    await saveAvailableSanitaryMaterials(materials);
    toast('✅ Санитарният материал е изтрит.');
    await renderSanitaryMaterialsList();
  } catch (e) {
    toast('❌ Грешка при изтриване.');
  }
};

document.getElementById('btnAddSanitaryMaterial').addEventListener('click', async function() {
  if (currentRole === 'observer') { toast('Само преглед — нямате право за корекция.'); return; }
  const codeInput = document.getElementById('newSanitaryMaterialCode');
  const nameInput = document.getElementById('newSanitaryMaterialName');
  const merkaInput = document.getElementById('newSanitaryMaterialMerka');
  const code = codeInput ? codeInput.value.trim() : '';
  const name = nameInput.value.trim();
  const merka = merkaInput.value.trim();
  
  if (!name) {
    toast('❌ Въведете име на санитарния материал.');
    return;
  }
  
  try {
    const materials = await getAvailableSanitaryMaterials();
    const idx = window.__editingSanitaryIndex;
    if (idx != null && idx >= 0 && idx < materials.length) {
      materials[idx] = { code, name, merka };
      window.__editingSanitaryIndex = null;
      setCatalogAddButtonLabel('btnAddSanitaryMaterial', false);
      toast('✅ Санитарният материал е обновен.');
    } else {
      materials.push({ code, name, merka });
      toast('✅ Санитарният материал е добавен.');
    }
    await saveAvailableSanitaryMaterials(materials);

    if (codeInput) codeInput.value = '';
    nameInput.value = '';
    merkaInput.value = '';
    (codeInput || nameInput).focus();

    await renderSanitaryMaterialsList();
  } catch (e) {
    toast('❌ Грешка при запис.');
  }
});

// ---- ФУНКЦИИ ЗА КАНЦЕЛСКИ МАТЕРИАЛИ ----
async function renderOfficeMaterialsList(opts) {
  const soft = (typeof isSoftRefreshOpts === 'function') ? isSoftRefreshOpts(opts) : !!(opts && opts.softRefresh);
  const container = document.getElementById('officeMaterialsListItems');
  const loading = document.getElementById('officeMaterialsListLoading');
  if (!container) return;
  if (!soft) {
    if (loading) loading.style.display = 'block';
    container.innerHTML = '';
  } else {
    ensureDimLoadingStyle();
    container.classList.add('dim-loading');
  }

  try {
    const materials = await getAvailableOfficeMaterials();
    if (loading) loading.style.display = 'none';
    container.classList.remove('dim-loading');
    container.innerHTML = '';

    if (!materials.length) {
      container.innerHTML = '<div class="hint">Все още няма добавени канцеларски материали.</div>';
      return;
    }

    const frag = document.createDocumentFragment();
    materials.forEach((mat, index) => {
      const item = document.createElement('div');
      item.className = 'materials-list-item';
      const canEdit = (currentRole !== 'observer');
      const editBtn = canEdit
        ? `<button class="ghost" style="padding:4px 8px;font-size:12px;color:var(--accent);" title="Редактирай" onclick="editOfficeMaterial(${index})">✎</button>`
        : '';
      const delBtn = canEdit
        ? `<button class="ghost" style="padding:4px 8px;font-size:12px;color:#c0392b;" title="Изтрий" onclick="deleteOfficeMaterial(${index})">✕</button>`
        : '';
      item.innerHTML = `
        <div class="mat-code">${escapeHtml(mat.code || '—')}</div>
        <div class="mat-name">${escapeHtml(mat.name)}</div>
        <div class="mat-merka">${escapeHtml(mat.merka || '—')}</div>
        <div class="mat-actions">${editBtn}${delBtn}</div>
      `;
      frag.appendChild(item);
    });
    container.appendChild(frag);
  } catch (e) {
    console.error('renderOfficeMaterialsList:', e);
    if (loading) loading.style.display = 'none';
    container.classList.remove('dim-loading');
    container.innerHTML = '<div class="hint">Грешка при зареждане на канцеларските материали.</div>';
  }
}

window.deleteOfficeMaterial = async function(index) {
  if (currentRole === 'observer') { toast('Само преглед — нямате право за корекция.'); return; }
  if (!(await confirmDialog('Сигурни ли сте, че искате да изтриете този канцеларски материал?'))) return;
  
  try {
    const materials = await getAvailableOfficeMaterials();
    materials.splice(index, 1);
    await saveAvailableOfficeMaterials(materials);
    toast('✅ Канцеларският материал е изтрит.');
    await renderOfficeMaterialsList();
  } catch (e) {
    toast('❌ Грешка при изтриване.');
  }
};

document.getElementById('btnAddOfficeMaterial').addEventListener('click', async function() {
  if (currentRole === 'observer') { toast('Само преглед — нямате право за корекция.'); return; }
  const codeInput = document.getElementById('newOfficeMaterialCode');
  const nameInput = document.getElementById('newOfficeMaterialName');
  const merkaInput = document.getElementById('newOfficeMaterialMerka');
  const code = codeInput ? codeInput.value.trim() : '';
  const name = nameInput.value.trim();
  const merka = merkaInput.value.trim();
  
  if (!name) {
    toast('❌ Въведете име на канцеларския материал.');
    return;
  }
  
  try {
    const materials = await getAvailableOfficeMaterials();
    const idx = window.__editingOfficeIndex;
    if (idx != null && idx >= 0 && idx < materials.length) {
      materials[idx] = { code, name, merka };
      window.__editingOfficeIndex = null;
      setCatalogAddButtonLabel('btnAddOfficeMaterial', false);
      toast('✅ Канцеларският материал е обновен.');
    } else {
      materials.push({ code, name, merka });
      toast('✅ Канцеларският материал е добавен.');
    }
    await saveAvailableOfficeMaterials(materials);

    if (codeInput) codeInput.value = '';
    nameInput.value = '';
    merkaInput.value = '';
    (codeInput || nameInput).focus();

    await renderOfficeMaterialsList();
  } catch (e) {
    toast('❌ Грешка при запис.');
  }
});

/* window exports */
try {
  if (typeof deleteOfficeMaterial==='function') window.deleteOfficeMaterial=deleteOfficeMaterial;
  if (typeof deleteSanitaryMaterial==='function') window.deleteSanitaryMaterial=deleteSanitaryMaterial;
  if (typeof editOfficeMaterial==='function') window.editOfficeMaterial=editOfficeMaterial;
  if (typeof editSanitaryMaterial==='function') window.editSanitaryMaterial=editSanitaryMaterial;
  if (typeof renderOfficeMaterialsList==='function') window.renderOfficeMaterialsList=renderOfficeMaterialsList;
  if (typeof renderSanitaryMaterialsList==='function') window.renderSanitaryMaterialsList=renderSanitaryMaterialsList;
} catch(_){}
