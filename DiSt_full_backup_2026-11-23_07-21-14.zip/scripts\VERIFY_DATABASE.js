#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const path = require('node:path');
let DatabaseSync;
try { ({ DatabaseSync } = require('node:sqlite')); } catch (e) {
  console.error('ERROR: Node.js 22+ with node:sqlite is required.'); process.exit(2);
}
const target = process.argv[2] ? path.resolve(process.argv[2]) : path.resolve(__dirname, '..', 'data', 'zayavki.db');
if (!fs.existsSync(target)) { console.error('ERROR: Database not found: ' + target); process.exit(1); }
let db;
try {
  db = new DatabaseSync(target, { readOnly: true });
  const integrity = db.prepare('PRAGMA integrity_check').get();
  const value = integrity && (integrity.integrity_check || integrity['integrity_check']);
  const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").all().map(r => r.name);
  const required = ['kv', 'system_log'];
  const missing = required.filter(x => !tables.includes(x));
  console.log('DiSt SQLite verification');
  console.log('------------------------');
  console.log('File:      ' + target);
  console.log('Size:      ' + fs.statSync(target).size + ' bytes');
  console.log('Integrity: ' + value);
  console.log('Tables:    ' + tables.join(', '));
  if (String(value).toLowerCase() !== 'ok' || missing.length) {
    if (missing.length) console.error('Missing required tables: ' + missing.join(', '));
    process.exitCode = 1;
  } else {
    console.log('RESULT:    OK');
  }
} catch (e) {
  console.error('ERROR: ' + (e.message || e)); process.exitCode = 1;
} finally { try { db && db.close(); } catch (_) {} }
