#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');
let DatabaseSync;
try { ({ DatabaseSync } = require('node:sqlite')); } catch (e) { console.error('ERROR: Node.js 22+ required.'); process.exit(2); }
const zipPath = process.argv[2] ? path.resolve(process.argv[2]) : null;
if (!zipPath || !fs.existsSync(zipPath)) { console.error('ERROR: ZIP not found.'); process.exit(1); }
const root = path.dirname(zipPath);
const tmp = path.join(root, '_verify_manual_' + Date.now());
function sha256(p) { const h=crypto.createHash('sha256'); h.update(fs.readFileSync(p)); return h.digest('hex'); }
function fail(msg) { console.error('FAILED: ' + msg); try { fs.rmSync(tmp,{recursive:true,force:true}); } catch(_){} process.exit(1); }
try {
  fs.mkdirSync(tmp,{recursive:true});
  let extract;
  if (process.platform === 'win32') {
    extract = spawnSync('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-Command',
      "Expand-Archive -LiteralPath '"+zipPath.replace(/'/g,"''")+"' -DestinationPath '"+tmp.replace(/'/g,"''")+"' -Force"],{windowsHide:true,encoding:'utf8',timeout:180000});
  } else {
    extract = spawnSync('unzip',['-o','-q',zipPath,'-d',tmp],{encoding:'utf8',timeout:180000});
  }
  if (extract.status !== 0) fail(String(extract.stderr||extract.stdout||extract.status));
  const mp=path.join(tmp,'backup-manifest.json'); if(!fs.existsSync(mp)) fail('backup-manifest.json missing');
  const m=JSON.parse(fs.readFileSync(mp,'utf8')); if(m.format!=='DiSt-Recovery-1') fail('unsupported manifest format');
  const expected = new Set();
  for(const item of m.files||[]){
    if(!item || typeof item.path!=='string' || item.path.includes('\\') || item.path.startsWith('/') || item.path.split('/').some(x=>!x || x==='.' || x==='..')) fail('unsafe manifest path');
    const key=item.path.toLowerCase(); if(expected.has(key)) fail('duplicate manifest path '+item.path); expected.add(key);
    const fp=path.join(tmp,...item.path.split('/')); if(!fs.existsSync(fp) || !fs.statSync(fp).isFile()) fail('missing '+item.path);
    if(fs.statSync(fp).size!==Number(item.size)) fail('size mismatch '+item.path); if(sha256(fp)!==item.sha256) fail('SHA-256 mismatch '+item.path);
  }
  const actual=[];
  function walk(dir,rel){ for(const name of fs.readdirSync(dir)){ const full=path.join(dir,name), r=rel?rel+'/'+name:name, st=fs.lstatSync(full); if(st.isSymbolicLink()) fail('symlink '+r); if(st.isDirectory()) walk(full,r); else if(st.isFile() && r!=='backup-manifest.json') actual.push(r); else if(!st.isFile()) fail('special file '+r); } }
  walk(tmp,'');
  if(actual.length!==expected.size) fail('manifest does not describe every archive file');
  for(const rel of actual) if(!expected.has(rel.toLowerCase())) fail('unlisted archive file '+rel);
  if(m.dependencyCheck) {
    const dep=spawnSync(process.execPath,[path.join(tmp,'scripts','depcheck.js'),'--json'],{cwd:tmp,encoding:'utf8',timeout:30000});
    if(dep.status!==0) fail('dependency check failed: '+String(dep.stderr||dep.stdout||dep.status));
    let depResult; try { depResult=JSON.parse(dep.stdout||'{}'); } catch(_) { fail('dependency check returned invalid JSON'); }
    if(!depResult || depResult.ok!==true) fail('archive contains unresolved dependencies');
    console.log('Depcheck:  OK ('+depResult.scannedFiles+' JS files, '+depResult.references+' references)');
  }
  const sidecarPath=zipPath+'.sha256';
  if(fs.existsSync(sidecarPath)) { const m2=fs.readFileSync(sidecarPath,'utf8').trim().match(/^([a-f0-9]{64})\s+(.+)$/i); if(!m2 || m2[1].toLowerCase()!==sha256(zipPath) || m2[2].trim()!==path.basename(zipPath)) fail('SHA-256 sidecar mismatch'); console.log('Sidecar:   OK'); }
  else console.log('Sidecar:   NOT FOUND (external SHA-256 file is optional for this manual check)');
  const dbp=path.join(tmp,'zayavki.db'); const db=new DatabaseSync(dbp,{readOnly:true}); const ir=db.prepare('PRAGMA integrity_check').get(); const val=ir && (ir.integrity_check||ir['integrity_check']); db.close();
  if(String(val).toLowerCase()!=='ok') fail('SQLite integrity_check = '+val);
  console.log('DiSt backup verification'); console.log('------------------------'); console.log('ZIP:       '+zipPath); console.log('SHA-256:   '+sha256(zipPath)); console.log('Backup ID: '+m.backupId); console.log('Records:   '+m.records); console.log('Users:     '+m.users); console.log('Files:     '+(m.files||[]).length); console.log('SQLite:    OK'); console.log('RESULT:    OK');
} catch(e){ fail(e.message||String(e)); } finally { try{fs.rmSync(tmp,{recursive:true,force:true});}catch(_){} }
