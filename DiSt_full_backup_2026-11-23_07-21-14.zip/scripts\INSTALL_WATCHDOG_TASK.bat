@echo off
setlocal
cd /d "%~dp0"

echo.
echo === DiSt Watchdog - Scheduled Task install ===
echo.

set "WD=%~dp0WATCHDOG.bat"
if not exist "%WD%" (
  echo ERROR: WATCHDOG.bat not found:
  echo   %WD%
  pause
  exit /b 1
)

REM Run every 5 minutes (more reliable than a forever-loop bat).
schtasks /Create /F /TN "DiSt_Watchdog" /SC MINUTE /MO 5 /RL LIMITED /TR "\"%WD%\""
if errorlevel 1 (
  echo.
  echo FAILED. Right-click this file - Run as administrator.
  pause
  exit /b 1
)

echo.
echo OK. Task name: DiSt_Watchdog
echo Runs every 5 minutes: %WD%
echo.
echo Test now:
schtasks /Run /TN "DiSt_Watchdog"
echo.
echo To remove later:
echo   schtasks /Delete /TN "DiSt_Watchdog" /F
echo.
pause
