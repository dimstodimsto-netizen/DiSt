#!/usr/bin/env node
'use strict';
/**
 * Кратки проверки след ъпдейт / рестарт.
 *   node scripts/smoke-tests.js
 *   set SMOKE_BASE=http://127.0.0.1:3000
 *   set SMOKE_USER=admin
 *   set SMOKE_PASS=...
 */
const BASE = (process.env.SMOKE_BASE || 'http://127.0.0.1:3000').replace(/\/$/, '');
const USER = process.env.SMOKE_USER || '';
const PASS = process.env.SMOKE_PASS || '';
let passed = 0, failed = 0;
function ok(name) { passed++; console.log('  OK  ' + name); }
function fail(name, err) { failed++; console.log('  FAIL ' + name + ' — ' + err); }
async function req(path, opts) {
  opts = opts || {};
  const headers = Object.assign({ Accept: 'application/json' }, opts.headers || {});
  if (opts.body && !headers['Content-Type']) headers['Content-Type'] = 'application/json';
  const res = await fetch(BASE + path, {
    method: opts.method || 'GET',
    headers,
    body: opts.body,
    redirect: 'manual'
  });
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch (_) {}
  return { res, text, json };
}
async function main() {
  console.log('DiSt smoke → ' + BASE);
  try {
    const r = await req('/api/server-info');
    if (r.res.status === 200 && r.json) ok('server-info');
    else fail('server-info', 'status ' + r.res.status);
  } catch (e) { fail('server-info', e.message); }
  try {
    const r = await req('/api/system/verification-status');
    if (r.res.status === 200 && r.json) ok('verification-status');
    else fail('verification-status', 'status ' + r.res.status);
  } catch (e) { fail('verification-status', e.message); }
  try {
    const r = await req('/');
    if (/<script[^>]+src=["'][^"']*xlsx\.full\.min\.js/.test(r.text || '')) {
      fail('lazy-xlsx', 'xlsx still eagerly loaded in index');
    } else ok('lazy-xlsx');
  } catch (e) { fail('index', e.message); }
  if (!USER || !PASS) {
    console.log('\n(Auth пропуснати — задайте SMOKE_USER / SMOKE_PASS)');
    console.log('Резултат: ' + passed + ' OK, ' + failed + ' FAIL');
    process.exit(failed ? 1 : 0);
  }
  let token = null;
  try {
    const r = await req('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username: USER, password: PASS })
    });
    if (r.res.status === 200 && r.json && (r.json.token || r.json.ok)) {
      token = r.json.token;
      ok('login');
    } else if (r.res.status === 500) {
      fail('login', 'HTTP 500 — ' + ((r.json && r.json.error) || r.text.slice(0, 80)));
    } else {
      fail('login', (r.json && r.json.error) || ('status ' + r.res.status));
    }
  } catch (e) { fail('login', e.message); }
  const auth = token ? { Authorization: 'Bearer ' + token } : {};
  if (token) {
    try {
      const r = await req('/api/auth/me', { headers: auth });
      if (r.res.status === 200) ok('auth/me');
      else fail('auth/me', 'status ' + r.res.status);
    } catch (e) { fail('auth/me', e.message); }
    try {
      const r = await req('/api/maintenance-materials', { headers: auth });
      if (r.res.status === 200 || r.res.status === 403) ok('maintenance-materials (' + r.res.status + ')');
      else fail('maintenance-materials', 'status ' + r.res.status);
    } catch (e) { fail('maintenance-materials', e.message); }
    try {
      const r = await req('/api/auth/logout', { method: 'POST', headers: auth, body: '{}' });
      if (r.res.status === 200) ok('logout');
      else fail('logout', 'status ' + r.res.status);
    } catch (e) { fail('logout', e.message); }
  }
  console.log('\nРезултат: ' + passed + ' OK, ' + failed + ' FAIL');
  process.exit(failed ? 1 : 0);
}
main().catch(function (e) { console.error(e); process.exit(2); });
