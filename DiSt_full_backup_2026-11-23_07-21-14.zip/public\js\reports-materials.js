/**
 * reports-materials.js — PDF бланки и настройки за отчети (материали)
 * Ориентация (portrait/landscape), данни за организация, подписи.
 */

var REPORT_FORM_STORAGE_KEY = 'dist_report_form_v1';

  function defaultReportForm() {
    return {
      orientation: 'landscape',
      orgName: '',
      orgUnit: '',
      orgAddress: '',
      orgExtra: '',
      docNumber: '',
      placeDate: '',
      preparedBy: '',
      preparedTitle: 'Изготвил',
      approvedBy: '',
      approvedTitle: 'Ръководител / утвърдил',
      thirdBy: '',
      thirdTitle: '',
      notes: '',
      showRowNumbers: true
    };
  }

  function loadReportForm() {
    var base = defaultReportForm();
    try {
      var raw = localStorage.getItem(REPORT_FORM_STORAGE_KEY);
      if (raw) {
        var parsed = JSON.parse(raw);
        if (parsed && typeof parsed === 'object') {
          Object.keys(base).forEach(function (k) {
            if (parsed[k] != null) base[k] = parsed[k];
          });
        }
      }
    } catch (_) {}
    return base;
  }

  function saveReportForm(form) {
    try {
      localStorage.setItem(REPORT_FORM_STORAGE_KEY, JSON.stringify(form || collectReportFormFromDom()));
    } catch (_) {}
  }

  function collectReportFormFromDom(prefix) {
    prefix = prefix || 'reportForm';
    function val(id) {
      var el = document.getElementById(prefix + '_' + id);
      if (!el) return '';
      if (el.type === 'checkbox') return !!el.checked;
      return String(el.value || '').trim();
    }
    function radio(name, fallback) {
      var el = document.querySelector('input[name="' + prefix + '_' + name + '"]:checked');
      return el ? String(el.value) : fallback;
    }
    var form = defaultReportForm();
    form.orientation = radio('orientation', form.orientation);
    form.orgName = val('orgName');
    form.orgUnit = val('orgUnit');
    form.orgAddress = val('orgAddress');
    form.orgExtra = val('orgExtra');
    form.docNumber = val('docNumber');
    form.placeDate = val('placeDate');
    form.preparedBy = val('preparedBy');
    form.preparedTitle = val('preparedTitle') || form.preparedTitle;
    form.approvedBy = val('approvedBy');
    form.approvedTitle = val('approvedTitle') || form.approvedTitle;
    form.thirdBy = val('thirdBy');
    form.thirdTitle = val('thirdTitle');
    form.notes = val('notes');
    var sn = document.getElementById(prefix + '_showRowNumbers');
    form.showRowNumbers = sn ? !!sn.checked : true;
    return form;
  }

  function fillReportFormDom(form, prefix) {
    prefix = prefix || 'reportForm';
    form = form || loadReportForm();
    function setVal(id, v) {
      var el = document.getElementById(prefix + '_' + id);
      if (!el) return;
      if (el.type === 'checkbox') el.checked = !!v;
      else el.value = v == null ? '' : String(v);
    }
    var ori = form.orientation === 'portrait' ? 'portrait' : 'landscape';
    var r1 = document.getElementById(prefix + '_ori_landscape');
    var r2 = document.getElementById(prefix + '_ori_portrait');
    if (r1) r1.checked = ori === 'landscape';
    if (r2) r2.checked = ori === 'portrait';
    setVal('orgName', form.orgName);
    setVal('orgUnit', form.orgUnit);
    setVal('orgAddress', form.orgAddress);
    setVal('orgExtra', form.orgExtra);
    setVal('docNumber', form.docNumber);
    setVal('placeDate', form.placeDate);
    setVal('preparedBy', form.preparedBy);
    setVal('preparedTitle', form.preparedTitle || 'Изготвил');
    setVal('approvedBy', form.approvedBy);
    setVal('approvedTitle', form.approvedTitle || 'Ръководител / утвърдил');
    setVal('thirdBy', form.thirdBy);
    setVal('thirdTitle', form.thirdTitle);
    setVal('notes', form.notes);
    setVal('showRowNumbers', form.showRowNumbers !== false);
  }

  /** HTML блок за панел „Настройки на бланката“ — prefix = matReportForm | whMatReportForm */
  function reportFormPanelHtml(prefix, title) {
    title = title || 'Настройки на бланката (PDF)';
    return (
      '<div class="report-form-panel" id="' + prefix + '_panel" style="border:1px solid var(--line);border-radius:10px;padding:12px 14px;margin-bottom:14px;background:var(--surface-soft,#f7f9fc);">' +
      '<div style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:8px;margin-bottom:10px;">' +
      '<div style="font-weight:700;">' + title + '</div>' +
      '<button type="button" class="ghost" id="' + prefix + '_toggle" style="margin:0;padding:4px 10px;font-size:12px;">▼ Покажи / скрий</button>' +
      '</div>' +
      '<div id="' + prefix + '_body">' +
      '<div class="hint" style="margin:0 0 10px;">Тези данни се ползват при PDF/печат. Запазват се в браузъра.</div>' +
      '<div style="display:flex;flex-wrap:wrap;gap:16px 24px;margin-bottom:12px;align-items:center;">' +
      '<span style="font-weight:600;">Ориентация на листа:</span>' +
      '<label style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;">' +
      '<input type="radio" name="' + prefix + '_orientation" id="' + prefix + '_ori_landscape" value="landscape" checked> Хоризонтална (пейзаж)</label>' +
      '<label style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;">' +
      '<input type="radio" name="' + prefix + '_orientation" id="' + prefix + '_ori_portrait" value="portrait"> Вертикална (портрет)</label>' +
      '<label style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;margin-left:8px;">' +
      '<input type="checkbox" id="' + prefix + '_showRowNumbers" checked> Номерация на редовете</label>' +
      '</div>' +
      '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px 14px;">' +
      '<div class="field" style="margin:0;"><label>Организация / учреждение</label>' +
      '<input type="text" id="' + prefix + '_orgName" placeholder="напр. МБАЛ …" style="width:100%;"></div>' +
      '<div class="field" style="margin:0;"><label>Структура / отдел</label>' +
      '<input type="text" id="' + prefix + '_orgUnit" placeholder="напр. Отдел техническо обслужване" style="width:100%;"></div>' +
      '<div class="field" style="margin:0;"><label>Адрес</label>' +
      '<input type="text" id="' + prefix + '_orgAddress" placeholder="по желание" style="width:100%;"></div>' +
      '<div class="field" style="margin:0;"><label>Допълнителен ред (ЕИК, телефон…)</label>' +
      '<input type="text" id="' + prefix + '_orgExtra" placeholder="по желание" style="width:100%;"></div>' +
      '<div class="field" style="margin:0;"><label>№ на документа</label>' +
      '<input type="text" id="' + prefix + '_docNumber" placeholder="по желание" style="width:100%;"></div>' +
      '<div class="field" style="margin:0;"><label>Място / дата (за бланката)</label>' +
      '<input type="text" id="' + prefix + '_placeDate" placeholder="напр. гр. …, ……….2026 г." style="width:100%;"></div>' +
      '</div>' +
      '<div style="font-weight:600;margin:14px 0 8px;">Подписи</div>' +
      '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px 14px;">' +
      '<div class="field" style="margin:0;"><label>Длъжност — изготвил</label>' +
      '<input type="text" id="' + prefix + '_preparedTitle" value="Изготвил" style="width:100%;"></div>' +
      '<div class="field" style="margin:0;"><label>Име — изготвил</label>' +
      '<input type="text" id="' + prefix + '_preparedBy" placeholder="име и фамилия" style="width:100%;"></div>' +
      '<div class="field" style="margin:0;"><label>Длъжност — утвърдил</label>' +
      '<input type="text" id="' + prefix + '_approvedTitle" value="Ръководител / утвърдил" style="width:100%;"></div>' +
      '<div class="field" style="margin:0;"><label>Име — утвърдил</label>' +
      '<input type="text" id="' + prefix + '_approvedBy" placeholder="име и фамилия" style="width:100%;"></div>' +
      '<div class="field" style="margin:0;"><label>Длъжност — трети подпис (по желание)</label>' +
      '<input type="text" id="' + prefix + '_thirdTitle" placeholder="напр. Главен счетоводител" style="width:100%;"></div>' +
      '<div class="field" style="margin:0;"><label>Име — трети подпис</label>' +
      '<input type="text" id="' + prefix + '_thirdBy" placeholder="по желание" style="width:100%;"></div>' +
      '</div>' +
      '<div class="field" style="margin:12px 0 0;">' +
      '<label>Забележка под таблицата</label>' +
      '<textarea id="' + prefix + '_notes" rows="2" placeholder="по желание" style="width:100%;resize:vertical;"></textarea>' +
      '</div>' +
      '<div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:12px;">' +
      '<button type="button" class="primary" id="' + prefix + '_save" style="margin:0;">💾 Запази настройките</button>' +
      '<button type="button" class="ghost" id="' + prefix + '_reset" style="margin:0;">Изчисти полетата</button>' +
      '</div>' +
      '</div></div>'
    );
  }

  function wireReportFormPanel(prefix) {
    var body = document.getElementById(prefix + '_body');
    var btnToggle = document.getElementById(prefix + '_toggle');
    var btnSave = document.getElementById(prefix + '_save');
    var btnReset = document.getElementById(prefix + '_reset');
    fillReportFormDom(loadReportForm(), prefix);
    if (btnToggle && body) {
      btnToggle.addEventListener('click', function () {
        var hidden = body.style.display === 'none';
        body.style.display = hidden ? '' : 'none';
      });
    }
    if (btnSave) {
      btnSave.addEventListener('click', function () {
        var form = collectReportFormFromDom(prefix);
        saveReportForm(form);
        // синхронизирай другия панел, ако съществува
        ['matReportForm', 'whMatReportForm'].forEach(function (p) {
          if (p !== prefix && document.getElementById(p + '_orgName')) {
            fillReportFormDom(form, p);
          }
        });
        if (typeof toast === 'function') toast('✅ Настройките на бланката са запазени.');
      });
    }
    if (btnReset) {
      btnReset.addEventListener('click', function () {
        if (!confirm('Изчистване на полетата на бланката?')) return;
        var empty = defaultReportForm();
        empty.orientation = 'landscape';
        fillReportFormDom(empty, prefix);
        saveReportForm(empty);
        if (typeof toast === 'function') toast('Полетата са изчистени.');
      });
    }
  }

  function openOfficialReportPdfBlank(opts) {
    opts = opts || {};
    var title = opts.title || 'Отчет';
    var subtitle = opts.subtitle || '';
    var filterLines = Array.isArray(opts.filters) ? opts.filters : [];
    var cols = opts.cols || [];
    var rows = opts.rows || [];
    var cellFn = typeof opts.cellFn === 'function' ? opts.cellFn : function (r, k) { return r[k] == null ? '' : r[k]; };
    var formPrefix = opts.formPrefix || null;
    var form = formPrefix ? collectReportFormFromDom(formPrefix) : loadReportForm();
    if (opts.form && typeof opts.form === 'object') {
      Object.keys(form).forEach(function (k) {
        if (opts.form[k] != null) form[k] = opts.form[k];
      });
    }
    saveReportForm(form);

    var nowStr = (typeof formatDisplayDateTime === 'function')
      ? formatDisplayDateTime(new Date())
      : new Date().toLocaleString('bg-BG');

    if (!cols.length) {
      if (typeof toast === 'function') toast('❌ Изберете поне една колона за отчета.');
      return;
    }
    if (!rows.length) {
      if (typeof toast === 'function') toast('❌ Няма данни за експорт при избраните филтри.');
      return;
    }

    var orientation = form.orientation === 'portrait' ? 'portrait' : 'landscape';
    var pageSize = orientation === 'portrait' ? 'A4 portrait' : 'A4 landscape';
    var showNum = form.showRowNumbers !== false;

    var filterHtml = filterLines.length
      ? ('<div class="filters"><b>Филтри / период:</b><ul>' +
          filterLines.map(function (l) { return '<li>' + escapeHtml(String(l)) + '</li>'; }).join('') +
          '</ul></div>')
      : '';

    var thead = cols.map(function (c) {
      return '<th>' + escapeHtml(c.label) + '</th>';
    }).join('');

    var tbody = rows.map(function (r, idx) {
      var numCell = showNum ? ('<td class="num">' + (idx + 1) + '</td>') : '';
      return '<tr>' + numCell + cols.map(function (c) {
        return '<td>' + escapeHtml(String(cellFn(r, c.key) == null ? '' : cellFn(r, c.key))) + '</td>';
      }).join('') + '</tr>';
    }).join('');

    var orgLines = [];
    if (form.orgName) orgLines.push(form.orgName);
    if (form.orgUnit) orgLines.push(form.orgUnit);
    if (form.orgAddress) orgLines.push(form.orgAddress);
    if (form.orgExtra) orgLines.push(form.orgExtra);
    var orgHtml = orgLines.length
      ? orgLines.map(function (l, i) {
          return i === 0
            ? ('<div class="org">' + escapeHtml(l) + '</div>')
            : ('<div class="org-sub">' + escapeHtml(l) + '</div>');
        }).join('')
      : '<div class="org">Официален отчет</div>';

    var metaBits = [];
    metaBits.push('Дата на изготвяне: <b>' + escapeHtml(nowStr) + '</b>');
    if (form.docNumber) metaBits.push('№: <b>' + escapeHtml(form.docNumber) + '</b>');
    if (form.placeDate) metaBits.push(escapeHtml(form.placeDate));
    metaBits.push('Позиции: <b>' + rows.length + '</b>');
    var metaHtml = '<div class="meta">' + metaBits.map(function (b) {
      return '<span>' + b + '</span>';
    }).join('') + '</div>';

    var signBoxes = [];
    function pushSign(title, name) {
      var t = String(title || '').trim();
      var n = String(name || '').trim();
      if (!t && !n) return;
      signBoxes.push(
        '<div class="box">' +
        (n ? ('<div class="name">' + escapeHtml(n) + '</div>') : '') +
        '<div class="line">' + escapeHtml(t || 'Подпис') + (n ? '' : ' (име, подпис)') + '</div>' +
        '</div>'
      );
    }
    pushSign(form.preparedTitle || 'Изготвил', form.preparedBy);
    pushSign(form.approvedTitle || 'Ръководител / утвърдил', form.approvedBy);
    if (form.thirdTitle || form.thirdBy) {
      pushSign(form.thirdTitle || 'Подпис', form.thirdBy);
    }
    if (!signBoxes.length) {
      pushSign('Изготвил (име, подпис)', '');
      pushSign('Ръководител / утвърдил (име, подпис)', '');
    }
    var signClass = signBoxes.length >= 3 ? 'sign sign-3' : 'sign';
    var signHtml = '<div class="' + signClass + '">' + signBoxes.join('') + '</div>';

    var notesHtml = form.notes
      ? ('<div class="notes"><b>Забележка:</b> ' + escapeHtml(form.notes) + '</div>')
      : '';

    var fontSize = orientation === 'portrait' ? '10pt' : '9.5pt';
    var html = '<!DOCTYPE html><html lang="bg"><head><meta charset="utf-8">' +
      '<title>' + escapeHtml(title) + '</title>' +
      '<style>' +
      '@page { size: ' + pageSize + '; margin: 12mm; }' +
      'body { font-family: "Times New Roman", Times, serif; font-size: 11pt; color: #000; margin: 0; padding: 8px 12px; }' +
      '.doc-header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 14px; }' +
      '.doc-header .org { font-size: 12pt; font-weight: bold; text-transform: uppercase; letter-spacing: 0.03em; }' +
      '.doc-header .org-sub { font-size: 10pt; margin-top: 2px; }' +
      '.doc-header h1 { font-size: 14pt; margin: 8px 0 4px; text-transform: uppercase; }' +
      '.doc-header .sub { font-size: 10pt; margin: 0; }' +
      '.meta { display: flex; flex-wrap: wrap; gap: 8px 18px; justify-content: space-between; font-size: 9.5pt; margin-bottom: 10px; }' +
      '.filters { font-size: 9.5pt; margin-bottom: 12px; }' +
      '.filters ul { margin: 4px 0 0 18px; padding: 0; }' +
      'table { width: 100%; border-collapse: collapse; font-size: ' + fontSize + '; }' +
      'th, td { border: 1px solid #000; padding: 4px 6px; vertical-align: top; }' +
      'th { background: #f0f0f0; font-weight: bold; text-align: center; }' +
      'td.num { width: 28px; text-align: center; }' +
      '.notes { margin-top: 12px; font-size: 9.5pt; }' +
      '.sign { margin-top: 28px; display: flex; justify-content: space-between; gap: 12px; font-size: 10pt; }' +
      '.sign-3 { flex-wrap: wrap; }' +
      '.sign .box { width: 42%; min-width: 140px; flex: 1; }' +
      '.sign-3 .box { width: 30%; }' +
      '.sign .name { text-align: center; font-size: 10pt; min-height: 1.2em; }' +
      '.sign .line { margin-top: 28px; border-top: 1px solid #000; padding-top: 4px; text-align: center; font-size: 9pt; }' +
      '.footer-note { margin-top: 16px; font-size: 8.5pt; color: #333; }' +
      '@media print { .no-print { display: none !important; } body { padding: 0; } }' +
      '</style></head><body>' +
      '<div class="no-print" style="margin-bottom:12px;text-align:center;">' +
      '<button onclick="window.print()" style="padding:8px 18px;font-size:14px;cursor:pointer;">🖨 Печат / Запази като PDF</button> ' +
      '<span style="font-size:12px;color:#555;">Ориентация: <b>' +
      (orientation === 'portrait' ? 'вертикална' : 'хоризонтална') +
      '</b> · Изберете „Принтер → Запазване като PDF“</span></div>' +
      '<div class="doc-header">' +
      orgHtml +
      '<h1>' + escapeHtml(title) + '</h1>' +
      (subtitle ? ('<p class="sub">' + escapeHtml(subtitle) + '</p>') : '') +
      '</div>' +
      metaHtml +
      filterHtml +
      '<table><thead><tr>' +
      (showNum ? '<th>№</th>' : '') + thead +
      '</tr></thead><tbody>' + tbody + '</tbody></table>' +
      notesHtml +
      signHtml +
      '<p class="footer-note">Документът е генериран от системата DiSt. При печат използвайте „Запазване като PDF“ за електронен архив.</p>' +
      '<script>setTimeout(function(){ try { window.print(); } catch(e){} }, 350);<\/script>' +
      '</body></html>';

    var w = window.open('', '_blank');
    if (!w) {
      if (typeof toast === 'function') toast('❌ Разрешете изскачащи прозорци за PDF/печат.');
      return;
    }
    w.document.open();
    w.document.write(html);
    w.document.close();
  }

  function getMatReportFilterLabels() {
    var lines = [];
    var y = ($('matReportYear') || {}).value || '';
    var m = ($('matReportMonth') || {}).value || '';
    var st = ($('matReportStruktura') || {}).value || '';
    var v = ($('matReportVid') || {}).value || '';
    if (y) lines.push('Година: ' + y);
    if (m) lines.push('Месец: ' + ((typeof WH_MONTH_NAMES !== 'undefined' && WH_MONTH_NAMES[Number(m)]) || m));
    if (st) lines.push('Структура: ' + st);
    if (v) lines.push('Вид материал: ' + v);
    if (!lines.length) lines.push('Всички периоди и структури (без допълнителен филтър)');
    return lines;
  }

  function exportMaterialsReportPdf() {
    openOfficialReportPdfBlank({
      title: 'Отчет за вложени материали',
      subtitle: 'Обобщена справка по заявки за ремонт',
      filters: getMatReportFilterLabels(),
      cols: typeof getSelectedMaterialReportColumns === 'function' ? getSelectedMaterialReportColumns() : [],
      rows: typeof materialsReportRows !== 'undefined' ? materialsReportRows : [],
      cellFn: typeof materialReportCell === 'function' ? materialReportCell : undefined,
      formPrefix: 'matReportForm'
    });
  }

  function getWhMatReportFilterLabels() {
    var lines = [];
    var y = ($('whMatReportYear') || {}).value || '';
    var m = ($('whMatReportMonth') || {}).value || '';
    var st = ($('whMatReportStruktura') || {}).value || '';
    var v = ($('whMatReportVid') || {}).value || '';
    var t = ($('whMatReportType') || {}).value || '';
    if (y) lines.push('Година: ' + y);
    if (m) lines.push('Месец: ' + ((typeof WH_MONTH_NAMES !== 'undefined' && WH_MONTH_NAMES[Number(m)]) || m));
    if (st) lines.push('Структура: ' + st);
    if (v) lines.push('Вид материал: ' + v);
    if (t === 'sanitary') lines.push('Тип: Санитарни');
    else if (t === 'office') lines.push('Тип: Канцеларски');
    if (!lines.length) lines.push('Всички периоди, структури и типове (без допълнителен филтър)');
    return lines;
  }

  function exportWhMaterialsReportPdf() {
    openOfficialReportPdfBlank({
      title: 'Отчет за вложени санитарни и канцеларски материали',
      subtitle: 'Обобщена справка по заявки за материали',
      filters: getWhMatReportFilterLabels(),
      cols: typeof getSelectedWhMaterialReportColumns === 'function' ? getSelectedWhMaterialReportColumns() : [],
      rows: typeof whMaterialsReportRows !== 'undefined' ? whMaterialsReportRows : [],
      cellFn: function (r, key) {
        if (key === 'month') return (typeof WH_MONTH_NAMES !== 'undefined' && WH_MONTH_NAMES[Number(r.month)]) || (r.month || '');
        if (key === 'type') {
          var t = String(r.type || r.materialType || '');
          if (t === 'sanitary') return 'Санитарни';
          if (t === 'office') return 'Канцеларски';
          return t || '';
        }
        return r[key] == null ? '' : r[key];
      },
      formPrefix: 'whMatReportForm'
    });
  }

  function initReportFormPanels() {
    var hosts = [
      { hostId: 'matReportFormHost', prefix: 'matReportForm', title: 'Настройки на бланката (PDF) — вложени материали' },
      { hostId: 'whMatReportFormHost', prefix: 'whMatReportForm', title: 'Настройки на бланката (PDF) — санитарни/канцеларски' }
    ];
    hosts.forEach(function (h) {
      var host = document.getElementById(h.hostId);
      if (!host) return;
      host.innerHTML = reportFormPanelHtml(h.prefix, h.title);
      wireReportFormPanel(h.prefix);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initReportFormPanels);
  } else {
    setTimeout(initReportFormPanels, 0);
  }

  openOfficialReportPdfBlank = openOfficialReportPdfBlank;
  getMatReportFilterLabels = getMatReportFilterLabels;
  exportMaterialsReportPdf = exportMaterialsReportPdf;
  getWhMatReportFilterLabels = getWhMatReportFilterLabels;
  exportWhMaterialsReportPdf = exportWhMaterialsReportPdf;
  loadReportForm = loadReportForm;
  saveReportForm = saveReportForm;
  initReportFormPanels = initReportFormPanels;

/* window exports */
try {
} catch(_){}
