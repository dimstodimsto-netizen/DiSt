/**
 * records-store.js — record cache + CRUD helpers (modularity stage 3)
 * Load AFTER session-auth.js, BEFORE app.js.
 */
if (typeof window !== 'undefined') {
  if (!window.__kvCache) window.__kvCache = new Map();
  if (typeof window.__kvCacheLoaded !== 'boolean') window.__kvCacheLoaded = false;
}
var __kvCache = (typeof window !== 'undefined' && window.__kvCache) ? window.__kvCache : new Map();
var __kvCacheLoaded = (typeof window !== 'undefined' && typeof window.__kvCacheLoaded === 'boolean')
  ? window.__kvCacheLoaded : false;

function __syncKvCacheGlobals() {
  if (typeof window === 'undefined') return;
  window.__kvCache = __kvCache;
  window.__kvCacheLoaded = __kvCacheLoaded;
}

function __recordsAuthFetch(url, options) {
  if (typeof authFetch === 'function') return authFetch(url, options);
  if (typeof window !== 'undefined' && typeof window.authFetch === 'function') return window.authFetch(url, options);
  return fetch(url, Object.assign({ credentials: 'same-origin', cache: 'no-store' }, options || {}));
}

// ---- Storage ----
async function __prefetchRecords() {
  // Предпочитаме агрегирания /api/records (по-малко заявки, ролеви филтър на сървъра).
  try {
    const res = await __recordsAuthFetch('/api/records?page=1&pageSize=500');
    if (res.ok) {
      const data = await res.json();
      const records = Array.isArray(data.records) ? data.records : [];
      __kvCache.clear();
      records.forEach(rec => {
        if (rec && rec.id != null) __kvCache.set('record:' + rec.id, JSON.stringify(rec));
      });
      // Ако има повече от 500 — дозареждане на останалите страници.
      const pages = Math.max(1, Number(data.pages) || 1);
      for (let p = 2; p <= pages && p <= 20; p++) {
        const r2 = await __recordsAuthFetch('/api/records?page=' + p + '&pageSize=500');
        if (!r2.ok) break;
        const d2 = await r2.json();
        (d2.records || []).forEach(rec => {
          if (rec && rec.id != null) __kvCache.set('record:' + rec.id, JSON.stringify(rec));
        });
      }
      __kvCacheLoaded = true; __syncKvCacheGlobals();
      return;
    }
  } catch (e) {
    console.warn('prefetch via /api/records failed, fallback to kv-list', e);
  }
  const res = await __recordsAuthFetch('/api/kv-list?prefix=' + encodeURIComponent('record:'));
  if (!res.ok) throw new Error('Неуспешно зареждане от сървъра (HTTP ' + res.status + ')');
  const items = await res.json();
  __kvCache.clear();
  items.forEach(it => __kvCache.set(it.key, it.value));
  __kvCacheLoaded = true; __syncKvCacheGlobals();
}

function invalidateRecordsCache() {
  __kvCacheLoaded = false;
  __syncKvCacheGlobals();
}

var S = window.S = {
  async get(key) {
    if (key.startsWith('record:')) {
      if (!__kvCacheLoaded) await __prefetchRecords();
      return __kvCache.has(key) ? { value: __kvCache.get(key) } : null;
    }
    const res = await __recordsAuthFetch('/api/kv/' + encodeURIComponent(key));
    if (res.status === 404) return null;
    if (res.status === 401 || res.status === 403) return null;
    if (!res.ok) throw new Error('Грешка при четене от сървъра (HTTP ' + res.status + ')');
    const data = await res.json();
    return { value: data.value };
  },
  async set(key, value) {
    const res = await __recordsAuthFetch('/api/kv/' + encodeURIComponent(key), {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ value })
    });
    if (!res.ok) throw new Error('Грешка при запис на сървъра (HTTP ' + res.status + ')');
    if (key.startsWith('record:')) __kvCache.set(key, value);
    return { key, value };
  },
  async delete(key) {
    const res = await __recordsAuthFetch('/api/kv/' + encodeURIComponent(key), { method: 'DELETE' });
    if (!res.ok) throw new Error('Грешка при изтриване на сървъра (HTTP ' + res.status + ')');
    if (key.startsWith('record:')) __kvCache.delete(key);
    return { key, deleted: true };
  }
};

// ---- Основни функции за данни ----

/** Зарежда заявки през /api/records (ролеви филтър на сървъра) и обновява кеша. */
async function loadRecordsForUi(opts) {
  opts = opts || {};
  const params = new URLSearchParams();
  params.set('page', '1');
  params.set('pageSize', String(opts.pageSize || 500));
  if (opts.struktura) params.set('struktura', opts.struktura);
  if (opts.year) params.set('year', opts.year);
  if (opts.month) params.set('month', opts.month);
  const res = await __recordsAuthFetch('/api/records?' + params.toString());
  if (!res.ok) throw new Error('HTTP ' + res.status);
  const data = await res.json();
  const records = Array.isArray(data.records) ? data.records : [];
  // Обновяваме кеша с получените записи (не чистим целия кеш — запазваме други ключове)
  records.forEach(function (rec) {
    if (rec && rec.id != null) __kvCache.set('record:' + rec.id, JSON.stringify(rec));
  });
  __kvCacheLoaded = true; __syncKvCacheGlobals();
  const pages = Math.max(1, Number(data.pages) || 1);
  for (let p = 2; p <= pages && p <= 10; p++) {
    params.set('page', String(p));
    const r2 = await __recordsAuthFetch('/api/records?' + params.toString());
    if (!r2.ok) break;
    const d2 = await r2.json();
    (d2.records || []).forEach(function (rec) {
      if (rec && rec.id != null) __kvCache.set('record:' + rec.id, JSON.stringify(rec));
    });
  }
  return records;
}

function sameStruktura(a, b) {
  return String(a || '').trim().toLowerCase() === String(b || '').trim().toLowerCase();
}

async function getIndex() {
  try {
    // Предпочитаме кеша от /api/records (работи и за заявител без директен достъп до records-index)
    if (!__kvCacheLoaded) {
      try { await __prefetchRecords(); } catch (_) {}
    }
    if (__kvCacheLoaded && __kvCache && __kvCache.size) {
      const ids = [];
      __kvCache.forEach(function (_val, key) {
        if (String(key).indexOf('record:') === 0) ids.push(String(key).slice(7));
      });
      if (ids.length) {
        ids.sort(function (a, b) {
          const na = Number(a), nb = Number(b);
          if (isFinite(na) && isFinite(nb) && na !== nb) return nb - na;
          return String(b).localeCompare(String(a), 'bg');
        });
        return ids;
      }
    }
    const r = await S.get('records-index');
    return r ? JSON.parse(r.value) : [];
  } catch (e) {
    return [];
  }
}

async function saveIndex(ids) {
  await S.set('records-index', JSON.stringify(ids));
}

async function getRecord(id) {
  try {
    const r = await S.get('record:' + id);
    return r ? JSON.parse(r.value) : null;
  } catch(e){ return null; }
}

async function markRecordsSeenBatch(ids) {
  const list = (ids || []).map(String).filter(Boolean);
  if (!list.length) return;
  try {
    const res = await __recordsAuthFetch('/api/records/mark-seen', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids: list })
    });
    if (!res.ok) return;
    list.forEach(id => {
      try {
        const key = 'record:' + id;
        if (typeof __kvCache !== 'undefined' && __kvCache.has(key)) {
          const rec = JSON.parse(__kvCache.get(key));
          rec.seen = true;
          __kvCache.set(key, JSON.stringify(rec));
        }
      } catch (_) {}
    });
  } catch (e) {
    console.warn('markRecordsSeenBatch:', e);
  }
}

async function saveRecord(rec) {
  // Новите заявки се създават от сървъра и получават атомично ID.
  if (!rec.id) {
    const res = await __recordsAuthFetch('/api/records', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(rec)
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Грешка при създаване на заявката.');
    rec.id = data.id != null ? data.id : data;
    const full = (data && typeof data === 'object' && data.id != null) ? data : Object.assign({}, rec, { id: rec.id });
    __kvCache.set('record:' + full.id, JSON.stringify(full));
    __kvCacheLoaded = true; __syncKvCacheGlobals();
    return full;
  }

  const res = await __recordsAuthFetch('/api/records/' + encodeURIComponent(rec.id), {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(rec)
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Грешка при обновяване на заявката.');
  __kvCache.set('record:' + rec.id, JSON.stringify(data));
  return data;
}

async function deleteRecord(id) {
  const res = await __recordsAuthFetch('/api/records/' + encodeURIComponent(id), { method: 'DELETE' });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Грешка при изтриване на заявката.');
  __kvCache.delete('record:' + id);
  return data;
}

async function nextId() {
  const res = await __recordsAuthFetch('/api/records/next-id');
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Грешка при получаване на следващ номер.');
  return String(data.nextId);
}

// Explicit public API used by the existing UI modules.
window.invalidateRecordsCache = invalidateRecordsCache;
window.loadRecordsForUi = loadRecordsForUi;
window.sameStruktura = sameStruktura;
window.getIndex = getIndex;
window.saveIndex = saveIndex;
window.getRecord = getRecord;
window.markRecordsSeenBatch = markRecordsSeenBatch;
window.saveRecord = saveRecord;
window.deleteRecord = deleteRecord;
window.nextId = nextId;

