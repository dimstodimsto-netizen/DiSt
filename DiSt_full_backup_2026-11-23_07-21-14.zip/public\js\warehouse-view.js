/**
 * warehouse-view.js — помощни функции за заявки за материали (преглед/печат/дати)
 * Зарежда се след app.js. Допълва/не дублира основната логика в app.js.
 * Цел: постепенно изнасяне на складовия UI извън монолитния app.js.
 */
(function () {
  'use strict';

  if (typeof window.formatWhDateTimeNow !== 'function') {
    window.formatWhDateTimeNow = function () {
      const now = new Date();
      return String(now.getDate()).padStart(2, '0') + '.' +
        String(now.getMonth() + 1).padStart(2, '0') + '.' +
        now.getFullYear() + ' ' +
        String(now.getHours()).padStart(2, '0') + ':' +
        String(now.getMinutes()).padStart(2, '0');
    };
  }

  if (typeof window.formatWhFulfilledAt !== 'function') {
    window.formatWhFulfilledAt = function (raw) {
      if (raw == null || raw === '') return '';
      const s = String(raw).trim();
      if (!s) return '';
      if (/^\d{1,2}\.\d{1,2}\.\d{4}/.test(s)) return s;
      const t = Date.parse(s);
      if (!Number.isNaN(t)) {
        const d = new Date(t);
        return String(d.getDate()).padStart(2, '0') + '.' +
          String(d.getMonth() + 1).padStart(2, '0') + '.' +
          d.getFullYear() + ' ' +
          String(d.getHours()).padStart(2, '0') + ':' +
          String(d.getMinutes()).padStart(2, '0');
      }
      return s;
    };
  }

  // Ако app.js е дефинирал локални function formatWh* — ползваме ги чрез window alias
  try {
    if (typeof formatWhDateTimeNow === 'function') window.formatWhDateTimeNow = formatWhDateTimeNow;
    if (typeof formatWhFulfilledAt === 'function') window.formatWhFulfilledAt = formatWhFulfilledAt;
  } catch (_) {}
})();
