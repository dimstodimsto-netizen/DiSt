/**
 * admin-sessions.js — активни сесии (админ)
 * „Остава“ = реално време до expiresAt на ВСЯКА сесия (синхрон със serverNow).
 */
(function () {
  'use strict';

  const ROLE_LABELS = {
    submitter: 'Заявител',
    technician: 'Техник',
    admin: 'Администратор',
    warehouse: 'Склад',
    observer: 'Наблюдател'
  };

  var remainTimer = null;
  /** Разлика clientNow - serverNow при последно зареждане (ms) */
  var clockSkewMs = 0;

  function roleLabel(role) {
    if (typeof ROLE_NAMES !== 'undefined' && ROLE_NAMES[role]) return ROLE_NAMES[role];
    return ROLE_LABELS[role] || role || '—';
  }

  function formatRemaining(ms) {
    if (ms == null || !isFinite(ms)) return '—';
    if (ms <= 0) return 'изтекла';
    var s = Math.floor(ms / 1000);
    var h = Math.floor(s / 3600);
    var m = Math.floor((s % 3600) / 60);
    var sec = s % 60;
    if (h > 0) return h + 'ч ' + m + 'м ' + sec + 'с';
    if (m > 0) return m + 'м ' + sec + 'с';
    return sec + 'с';
  }

  function formatTs(ms) {
    if (!ms) return '—';
    try {
      return new Date(ms).toLocaleString('bg-BG');
    } catch (_) {
      return '—';
    }
  }

  /** Оставащо според абсолютен expiresAt и отместване към сървърния часовник */
  function remainingFromExpires(expiresAt) {
    var exp = Number(expiresAt);
    if (!isFinite(exp)) return NaN;
    // serverNow ≈ Date.now() - clockSkewMs
    return exp - (Date.now() - clockSkewMs);
  }

  function stopRemainTicker() {
    if (remainTimer) {
      clearInterval(remainTimer);
      remainTimer = null;
    }
  }

  function tickRemainCells() {
    var cells = document.querySelectorAll('#adminSessionsPanel .admin-session-remain');
    if (!cells.length) {
      stopRemainTicker();
      return;
    }
    cells.forEach(function (el) {
      var exp = el.getAttribute('data-expires-at');
      if (!exp) {
        el.textContent = '—';
        return;
      }
      var left = remainingFromExpires(exp);
      el.textContent = formatRemaining(left);
      if (!isFinite(left) || left <= 0) {
        el.style.color = 'var(--danger, #c0392b)';
        el.style.fontWeight = '700';
      } else if (left < 5 * 60 * 1000) {
        el.style.color = 'var(--danger, #c0392b)';
        el.style.fontWeight = '600';
      } else {
        el.style.color = '';
        el.style.fontWeight = '';
      }
    });
  }

  function startRemainTicker() {
    stopRemainTicker();
    tickRemainCells();
    remainTimer = setInterval(tickRemainCells, 1000);
  }

  async function refreshAdminSessionsPanel(opts) {
    const soft = !!(opts && (opts.softRefresh || opts.silent || opts.background));
    const panel = document.getElementById('adminSessionsPanel');
    const status = document.getElementById('adminSessionsStatus');
    if (!panel) return;
    stopRemainTicker();
    if (!soft || !panel.children.length) {
      panel.innerHTML = '<div class="hint">Зареждане на сесии...</div>';
    } else {
      panel.style.opacity = '0.75';
    }
    if (status && !soft) status.textContent = '';
    try {
      const r = await authFetch('/api/admin/sessions');
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const data = await r.json();
      const list = data.sessions || [];
      var serverNow = data.serverNow != null ? Number(data.serverNow) : Date.now();
      clockSkewMs = Date.now() - serverNow;

      if (status) status.textContent = 'Активни: ' + (data.count != null ? data.count : list.length);
      if (!list.length) {
        panel.innerHTML = '<div class="hint">Няма активни сесии.</div>';
        return;
      }

      var onlineCount = 0;
      const rows = list.map(function (s) {
        const cur = s.isCurrent ? ' <span style="color:var(--accent,#2f6fed);font-weight:700;">(вие)</span>' : '';
        const kickBtn = s.isCurrent
          ? '<span class="hint">—</span>'
          : '<button type="button" class="ghost admin-kick-btn" data-token="' + String(s.token || '').replace(/"/g, '') +
            '" data-user="' + String(s.username || '').replace(/"/g, '&quot;') +
            '" style="padding:4px 8px;font-size:12px;border-color:#c0392b;color:#c0392b;">Изгони</button>';
        var exp = s.expiresAt != null ? Number(s.expiresAt) : NaN;
        var remainMs = isFinite(exp) ? remainingFromExpires(exp) : (s.remainingMs != null ? Number(s.remainingMs) : NaN);
        var remainAttr = isFinite(exp) ? String(exp) : '';
        var isOnline = !!s.online || !!s.isCurrent;
        if (isOnline) onlineCount++;
        var statusHtml = isOnline
          ? '<span style="color:#1e7e34;font-weight:700;">● Онлайн</span>'
          : '<span style="color:#888;">○ Офлайн</span>';
        return '<tr style="' + (isOnline ? '' : 'opacity:0.72;') + '">' +
          '<td style="padding:6px 8px;border-bottom:1px solid var(--line);">' + escapeHtml(s.username || '') + cur + '</td>' +
          '<td style="padding:6px 8px;border-bottom:1px solid var(--line);">' + escapeHtml(s.name || '—') + '</td>' +
          '<td style="padding:6px 8px;border-bottom:1px solid var(--line);">' + escapeHtml(roleLabel(s.role)) + '</td>' +
          '<td style="padding:6px 8px;border-bottom:1px solid var(--line);white-space:nowrap;">' + statusHtml + '</td>' +
          '<td class="admin-session-remain" data-expires-at="' + remainAttr + '" style="padding:6px 8px;border-bottom:1px solid var(--line);white-space:nowrap;font-variant-numeric:tabular-nums;">' +
            formatRemaining(remainMs) + '</td>' +
          '<td style="padding:6px 8px;border-bottom:1px solid var(--line);white-space:nowrap;font-size:12px;">' + formatTs(exp) + '</td>' +
          '<td style="padding:6px 8px;border-bottom:1px solid var(--line);">' + kickBtn + '</td>' +
          '</tr>';
      }).join('');
      if (status) status.textContent = 'Активни сесии: ' + list.length + ' · Онлайн сега: ' + onlineCount;

      panel.innerHTML =
        '<div style="overflow:auto;"><table style="width:100%;border-collapse:collapse;font-size:13px;">' +
        '<thead><tr>' +
        '<th style="text-align:left;padding:6px 8px;">Потребител</th>' +
        '<th style="text-align:left;padding:6px 8px;">Име</th>' +
        '<th style="text-align:left;padding:6px 8px;">Роля</th>' +
        '<th style="text-align:left;padding:6px 8px;">Връзка</th>' +
        '<th style="text-align:left;padding:6px 8px;">Остава</th>' +
        '<th style="text-align:left;padding:6px 8px;">Изтича</th>' +
        '<th style="text-align:left;padding:6px 8px;"></th>' +
        '</tr></thead><tbody>' + rows + '</tbody></table></div>' +
        '<div class="hint" style="margin-top:8px;font-size:11px;">„Връзка“ = реално онлайн (heartbeat на ~1 мин; офлайн след ~3 мин без сигнал, напр. изключен PC). „Остава“ = до края на сесията. Персонал: 12 ч от входа. Заявител: 30 мин idle.</div>';

      panel.querySelectorAll('.admin-kick-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
          kickSession(btn.getAttribute('data-token'), btn.getAttribute('data-user'));
        });
      });

      startRemainTicker();
    } catch (e) {
      stopRemainTicker();
      panel.innerHTML = '<div class="hint" style="color:var(--danger,#c0392b);">Грешка: ' + escapeHtml(e.message || e) + '</div>';
      if (status) status.textContent = '';
    }
  }

  async function kickSession(token, username) {
    if (!token) return;
    if (!await confirmDialog('Изгонване на „' + (username || '') + '”?\nСесията ще бъде прекратена незабавно.')) return;
    try {
      const r = await authFetch('/api/admin/sessions/revoke', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: token })
      });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      var data = {};
      try { data = await r.json(); } catch (_) {}
      if (typeof toast === 'function') toast('✅ Сесията на „' + (data.targetUser || username || '') + '“ е прекратена.');
      refreshAdminSessionsPanel();
    } catch (e) {
      if (typeof toast === 'function') toast('Неуспешно изгонване: ' + (e.message || e));
    }
  }

  function escapeHtml(str) {
    return String(str == null ? '' : str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  var sessionsAutoRefresh = null;
  function startSessionsAutoRefresh() {
    if (sessionsAutoRefresh) return;
    sessionsAutoRefresh = setInterval(function () {
      var panel = document.getElementById('adminSessionsPanel');
      if (!panel || panel.offsetParent === null) return;
      if (document.hidden) return;
      refreshAdminSessionsPanel({ softRefresh: true });
    }, 30000);
  }
  window.refreshAdminSessionsPanel = refreshAdminSessionsPanel;
  window.kickAdminSession = kickSession;
  startSessionsAutoRefresh();


  function wireBtn() {
    const btn = document.getElementById('btnRefreshAdminSessions');
    if (btn && !btn._sessionsWired) {
      btn._sessionsWired = true;
      btn.addEventListener('click', function () { refreshAdminSessionsPanel(); });
    }
  }
  document.addEventListener('DOMContentLoaded', wireBtn);
  if (document.readyState !== 'loading') wireBtn();

  document.addEventListener('visibilitychange', function () {
    if (document.hidden) stopRemainTicker();
    else if (document.querySelector('#adminSessionsPanel .admin-session-remain')) startRemainTicker();
  });
})();
