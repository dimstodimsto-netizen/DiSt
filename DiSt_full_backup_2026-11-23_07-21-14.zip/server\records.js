'use strict';

/** Transaction-safe repair-record operations. */
function createRecordsModule({ db, kvGet, kvSet, kvDelete, formatLocalDateTimeSeconds, getUserByIdServer, getUserByUsernameServer, reportDatePartsServer, cleanupOldServerFiles }) {
const stmtRecordKeys = db.prepare("SELECT key FROM kv WHERE key GLOB 'record:[0-9]*'");

function withTransaction(fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (e) {
    try { db.exec('ROLLBACK'); } catch (_) {}
    throw e;
  }
}

function parseJsonOrNull(raw) {
  try { return raw == null ? null : JSON.parse(raw); } catch (_) { return null; }
}

function getRecordServer(id) {
  if (!/^\d+$/.test(String(id))) return null;
  return parseJsonOrNull(kvGet('record:' + id));
}

function normalizeRecordInput(input) {
  const allowed = ['datetime','korpus','etaz','struktura','lokacia','vid','zabelezka','zayavitel',
    'status','dataIzp','izpalnitel','materiali','komentar','urgent','seen','hiddenFromTech'];
  const out = {};
  for (const key of allowed) {
    if (Object.prototype.hasOwnProperty.call(input, key)) out[key] = input[key];
  }
  return out;
}

function getNextRecordIdTx() {
  const stored = Number(kvGet('system:nextRecordId'));
  if (Number.isSafeInteger(stored) && stored > 0) return String(stored);
  let max = 0;
  for (const row of stmtRecordKeys.all()) {
    const n = Number(String(row.key).slice('record:'.length));
    if (Number.isSafeInteger(n) && n > max) max = n;
  }
  const next = max + 1;
  kvSet('system:nextRecordId', String(next));
  return String(next);
}
function advanceNextRecordId(nextId) {
  kvSet('system:nextRecordId', String(Number(nextId) + 1));
}

function getRecordsIndexSafe() {
  const parsed = parseJsonOrNull(kvGet('records-index'));
  return Array.isArray(parsed) ? parsed.map(String) : [];
}

function createRecordServer(sess, input) {
  // Наблюдател МОЖЕ да подава заявки за ремонт (като заявител за своя структура).
  // Забраната за материали (wh:) е на ниво KV PUT, не тук.
  const incoming = normalizeRecordInput(input || {});
  const user = getUserByIdServer(sess.userId) || getUserByUsernameServer(sess.username);
  if (sess.role === 'submitter' || sess.role === 'observer') {
    // Профилът е източникът на структура и заявител за тези роли.
    incoming.struktura = String((user && user.struktura) || '').trim();
    if (user && user.name) incoming.zayavitel = user.name;
  }
  if (!incoming.datetime || !incoming.korpus || !incoming.etaz || !incoming.lokacia || !incoming.vid || ((sess.role === 'submitter' || sess.role === 'observer') && !incoming.struktura)) {
    const err = new Error('Липсват задължителни полета на заявката.');
    err.status = 400;
    throw err;
  }


  const id = withTransaction(() => {
    const newId = getNextRecordIdTx();
    const rec = Object.assign({
      id: newId,
      datetime: '', korpus: '', etaz: '', struktura: '', lokacia: '', vid: '',
      zabelezka: '', zayavitel: '', status: 'Не е изпълнена', dataIzp: '', izpalnitel: '',
      materiali: '', komentar: '', urgent: false, seen: false
    }, incoming, {
      id: newId,
      // Всяка НОВА заявка започва задължително като „Не е изпълнена“.
      // Не приемаме status от клиента при създаване, за да не може
      // заявител или директна API заявка да създаде заявка с друг статус.
      status: 'Не е изпълнена',
      createdAt: formatLocalDateTimeSeconds(new Date())
    });

    kvSet('record:' + newId, JSON.stringify(rec));
    const idx = getRecordsIndexSafe();
    if (!idx.includes(newId)) idx.push(newId);
    kvSet('records-index', JSON.stringify(idx));
    advanceNextRecordId(newId);
    return rec;
  });

  return id;
}

function updateRecordServer(sess, id, input) {
  const existing = getRecordServer(id);
  if (!existing) {
    const err = new Error('Заявката не е намерена.');
    err.status = 404;
    throw err;
  }

  const incoming = normalizeRecordInput(input || {});
  let merged;

  if (sess.role === 'admin') {
    merged = Object.assign({}, existing, incoming, { id: String(id) });
  } else if (sess.role === 'technician') {
    merged = Object.assign({}, existing);
    // `seen` — маркиране като видяна в таблото на техниците (без да пипа други полета).
    for (const key of ['status', 'dataIzp', 'izpalnitel', 'materiali', 'komentar', 'seen']) {
      if (Object.prototype.hasOwnProperty.call(incoming, key)) merged[key] = incoming[key];
    }
    // Полетата, които са собственост на заявителя, никога не идват от техник.
    for (const key of ['datetime','korpus','etaz','struktura','lokacia','vid','zabelezka','zayavitel','urgent']) {
      merged[key] = existing[key];
    }
  } else {
    const err = new Error('Нямате право да редактирате съществуваща заявка.');
    err.status = 403;
    throw err;
  }

  // Историята се създава от сървъра. Клиентът не може да подмени
  // кой, кога и какво е редактирал.
  // Само маркиране „видяна“ (seen) от техник не се логва — иначе таблото
  // би пълнило историята при всяко отваряне на списъка.
  const trackedForHistory = ['status', 'dataIzp', 'izpalnitel', 'materiali', 'komentar',
    'datetime', 'korpus', 'etaz', 'struktura', 'lokacia', 'vid', 'zabelezka', 'zayavitel', 'urgent'];
  const hasTrackedChange = trackedForHistory.some(
    k => JSON.stringify(merged[k] ?? null) !== JSON.stringify(existing[k] ?? null)
  );
  const history = Array.isArray(existing.history) ? existing.history.slice() : [];
  if (hasTrackedChange) {
    history.push({
      at: formatLocalDateTimeSeconds(new Date()),
      by: sess.username || '—',
      action: 'Редакция'
    });
  }
  merged.history = history;

  withTransaction(() => {
    kvSet('record:' + id, JSON.stringify(merged));
    const idx = getRecordsIndexSafe();
    if (!idx.includes(String(id))) {
      idx.push(String(id));
      kvSet('records-index', JSON.stringify(idx));
    }
  });

  return merged;
}


/** Маркира много заявки като видени с една транзакция (табло техници). */
function markRecordsSeenServer(sess, ids) {
  if (sess.role !== 'technician' && sess.role !== 'admin') {
    const err = new Error('Нямате право да маркирате заявки като видени.');
    err.status = 403;
    throw err;
  }
  const list = Array.isArray(ids) ? ids.map(String).filter(id => /^\d+$/.test(id)) : [];
  if (!list.length) return { updated: 0 };
  let updated = 0;
  withTransaction(() => {
    for (const id of list) {
      const existing = getRecordServer(id);
      if (!existing) continue;
      if (existing.seen === true) continue;
      existing.seen = true;
      kvSet('record:' + id, JSON.stringify(existing));
      updated++;
    }
  });
  return { updated };
}

function deleteRecordServer(sess, id) {
  if (sess.role !== 'admin') {
    const err = new Error('Само администратор може да изтрива заявки.');
    err.status = 403;
    throw err;
  }
  withTransaction(() => {
    kvDelete('record:' + id);
    const idx = getRecordsIndexSafe().filter(x => x !== String(id));
    kvSet('records-index', JSON.stringify(idx));
  });
}

/** Списък заявки с филтри и пагинация (за GET /api/records). */
function listRecordsServer(sess, query) {
  const q = query || {};
  const status = String(q.status || '').trim();
  const struktura = String(q.struktura || '').trim();
  const year = String(q.year || '').trim();
  const month = String(q.month || '').trim();
  const search = String(q.q || '').trim().toLowerCase();
  const unresolved = q.unresolved === '1' || q.unresolved === 'true';
  const page = Math.max(1, parseInt(q.page, 10) || 1);
  const pageSizeRaw = parseInt(q.pageSize, 10);
  const pageSize = Math.min(500, Math.max(1, Number.isFinite(pageSizeRaw) ? pageSizeRaw : 200));

  // Наблюдател: преглед на ВСИЧКИ ремонтни заявки (като техник/админ).
  // Заявител: само собствената структура.
  let ownStructure = '';
  if (sess.role === 'submitter') {
    const user = getUserByIdServer(sess.userId) || getUserByUsernameServer(sess.username);
    ownStructure = (user && user.struktura) || '';
  }

  const idx = getRecordsIndexSafe();
  const all = [];
  for (const id of idx) {
    const rec = getRecordServer(String(id));
    if (!rec) continue;
    if (sess.role === 'submitter') {
      const a = String(rec.struktura || '').trim().toLowerCase();
      const b = String(ownStructure || '').trim().toLowerCase();
      if (b && a !== b) continue;
    }
    if (status && String(rec.status || '') !== status) continue;
    if (struktura && String(rec.struktura || '') !== struktura) continue;
    if (unresolved) {
      const st = String(rec.status || '');
      if (st === 'Изпълнена') continue;
    }
    if (year || month) {
      const dp = reportDatePartsServer(rec.datetime);
      if (year && dp.year !== year) continue;
      if (month && dp.month !== month) continue;
    }
    if (search) {
      const hay = [
        rec.id, rec.datetime, rec.korpus, rec.etaz, rec.struktura, rec.lokacia,
        rec.vid, rec.zabelezka, rec.zayavitel, rec.status, rec.dataIzp,
        rec.izpalnitel, typeof rec.materiali === 'string' ? rec.materiali : JSON.stringify(rec.materiali || ''),
        rec.komentar
      ].map(v => String(v == null ? '' : v)).join(' ').toLowerCase();
      if (!hay.includes(search)) continue;
    }
    all.push(rec);
  }

  all.sort((a, b) => {
    const ta = String(a.datetime || '');
    const tb = String(b.datetime || '');
    // datetime е DD.MM.YYYY HH:mm — лексикографското не е идеално; опит с ISO-подобно сравнение чрез части
    const pa = reportDatePartsServer(a.datetime);
    const pb = reportDatePartsServer(b.datetime);
    const ka = (pa.year || '0000') + String(pa.month || '0').padStart(2, '0') + ta;
    const kb = (pb.year || '0000') + String(pb.month || '0').padStart(2, '0') + tb;
    return kb.localeCompare(ka);
  });

  const total = all.length;
  const start = (page - 1) * pageSize;
  const records = all.slice(start, start + pageSize);
  return { records, total, page, pageSize, pages: Math.max(1, Math.ceil(total / pageSize)) };
}

/**
 * Почиства records-index от ID без валиден record:* запис.
 * Опционално добавя в индекса record:* ключове, които липсват в индекса.
 */
function cleanupOrphanRecordsServer() {
  const idx = getRecordsIndexSafe();
  const kept = [];
  const removedFromIndex = [];
  for (const id of idx) {
    const sid = String(id);
    if (getRecordServer(sid)) kept.push(sid);
    else removedFromIndex.push(sid);
  }

  const addedToIndex = [];
  try {
    const rows = stmtRecordKeys.all();
    const keptSet = new Set(kept);
    for (const row of rows) {
      const id = String(row.key).slice('record:'.length);
      if (!id || keptSet.has(id)) continue;
      if (getRecordServer(id)) {
        kept.push(id);
        keptSet.add(id);
        addedToIndex.push(id);
      }
    }
  } catch (e) {
    console.error('cleanup orphan scan:', e.message);
  }

  withTransaction(() => {
    kvSet('records-index', JSON.stringify(kept));
  });

  // Допълнително: стари ъпдейт-бекъпи и излишни файлове
  let filesCleanup = { removed: [], removedCount: 0, errors: [] };
  try {
    filesCleanup = cleanupOldServerFiles({ keepUpdateDirs: 3, keepDbBackups: 15 });
  } catch (e) {
    filesCleanup.errors.push(String(e && e.message ? e.message : e));
  }

  return {
    indexSize: kept.length,
    removedFromIndex,
    removedCount: removedFromIndex.length,
    addedToIndex,
    addedCount: addedToIndex.length,
    filesRemoved: filesCleanup.removed,
    filesRemovedCount: filesCleanup.removedCount,
    filesErrors: filesCleanup.errors
  };
}


  return { withTransaction, parseJsonOrNull, getRecordServer, normalizeRecordInput, getNextRecordIdTx, advanceNextRecordId, getRecordsIndexSafe, createRecordServer, updateRecordServer, markRecordsSeenServer, deleteRecordServer, listRecordsServer, cleanupOrphanRecordsServer };
}
module.exports = { createRecordsModule };
