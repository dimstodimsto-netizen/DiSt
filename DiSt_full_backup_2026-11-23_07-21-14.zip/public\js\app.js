
// ============================================================
//  КОРИГИРАН JS КОД - ВСИЧКИ НОВИ ФУНКЦИОНАЛНОСТИ
// ============================================================

// ---- Общото състояние се предоставя от app-state.js ----
function setWhEditingId(id) {
  whEditingId = id ? String(id) : null;
  const el = document.getElementById('whEditingIdField');
  if (el) el.value = whEditingId || '';
}
function getWhEditingId() {
  if (whEditingId) return String(whEditingId);
  const el = document.getElementById('whEditingIdField');
  const v = el && el.value ? String(el.value).trim() : '';
  return v || null;
}


// ---- Константи ----
const ROLE_NAMES = { submitter: 'Подаване на заявки', technician: 'Техник', admin: 'Администратор', warehouse: 'Склад', observer: 'Наблюдател' };

/** Менюта за роля „Наблюдател“ — админът избира кои да вижда всеки потребител. */
const OBSERVER_MENU_OPTIONS = [
  { key: 'submit', label: 'Заявка за ремонт' },
  { key: 'myRequests', label: 'Моите заявки за ремонт' },
  { key: 'myMaterials', label: 'Моите заявки за материали' },
  { key: 'warehouse', label: 'Заявка за материали (подаване)' },
  { key: 'warehouseSanitaryRequests', label: 'Получени заявки — санитарни' },
  { key: 'warehouseOfficeRequests', label: 'Получени заявки — канцеларски' },
  { key: 'sanitaryMaterialsList', label: 'Налични санитарни материали' },
  { key: 'officeMaterialsList', label: 'Налични канцеларски материали' },
  { key: 'whMaterialsReport', label: 'Отчет санитарни и канцеларски' },
  { key: 'technicians', label: 'За техници' },
  { key: 'objects', label: 'Обекти' },
  { key: 'search', label: 'Търсене / Обновяване' },
  { key: 'all', label: 'Всички заявки' },
  { key: 'materialsReport', label: 'Отчет за вложени материали' }
];
const DEFAULT_OBSERVER_MENUS = [
  'submit', 'myRequests',
  'warehouseSanitaryRequests', 'warehouseOfficeRequests',
  'sanitaryMaterialsList', 'officeMaterialsList'
];

function normalizeObserverMenus(list) {
  if (!Array.isArray(list) || !list.length) return DEFAULT_OBSERVER_MENUS.slice();
  const allowed = new Set(OBSERVER_MENU_OPTIONS.map(o => o.key));
  const out = [];
  list.forEach(function (k) {
    const key = String(k || '').trim();
    if (allowed.has(key) && out.indexOf(key) < 0) out.push(key);
  });
  return out.length ? out : DEFAULT_OBSERVER_MENUS.slice();
}

function renderObserverMenusCheckboxes(container, selected) {
  if (!container) return;
  const sel = new Set(normalizeObserverMenus(selected));
  container.innerHTML =
    '<div style="font-size:12px;font-weight:600;margin:4px 0 6px;color:var(--ink-soft);">Менюта за наблюдател (вижми табове)</div>' +
    '<div style="display:flex;flex-wrap:wrap;gap:6px 14px;padding:8px 10px;background:var(--surface,#fff);border:1px solid var(--line);border-radius:6px;">' +
    OBSERVER_MENU_OPTIONS.map(function (o) {
      const checked = sel.has(o.key) ? ' checked' : '';
      return '<label style="font-size:12px;display:flex;align-items:center;gap:4px;cursor:pointer;white-space:nowrap;">' +
        '<input type="checkbox" class="obs-menu-cb" value="' + o.key + '"' + checked + '> ' + o.label +
        '</label>';
    }).join('') +
    '</div>';
}

function readObserverMenusFrom(container) {
  if (!container) return DEFAULT_OBSERVER_MENUS.slice();
  const boxes = container.querySelectorAll('.obs-menu-cb:checked');
  const keys = Array.from(boxes).map(function (b) { return b.value; });
  return normalizeObserverMenus(keys);
}



/** Спешна заявка мига само докато НЕ е изпълнена. */
function isUrgentActive(rec) {
  if (!rec || rec.urgent !== true) return false;
  return String(rec.status || '').trim() !== 'Изпълнена';
}

const DEFAULT_TABLE_COLUMNS = ['id','datetime','lokacia','vid','zayavitel','status','izpalnitel'];
const ALL_TABLE_COLUMNS = [
  { key: 'id',         label: 'ID' },
  { key: 'datetime',   label: 'Дата - Час' },
  { key: 'korpus',     label: 'Корпус' },
  { key: 'etaz',       label: 'Етаж' },
  { key: 'struktura',  label: 'Структура' },
  { key: 'lokacia',    label: 'Локация' },
  { key: 'vid',        label: 'Вид на заявка' },
  { key: 'zabelezka',  label: 'Забележка' },
  { key: 'zayavitel',  label: 'Заявител' },
  { key: 'status',     label: 'Статус' },
  { key: 'dataIzp',    label: 'Дата на приключване' },
  { key: 'izpalnitel', label: 'Изпълнител' },
  { key: 'materiali',  label: 'Вложени материали' },
  { key: 'komentar',   label: 'Коментар' }
];
const WH_MONTH_NAMES = ['', 'Януари','Февруари','Март','Април','Май','Юни','Юли','Август','Септември','Октомври','Ноември','Декември'];
const TABLE_COLUMNS_KEY = 'zayavki_allTableColumns';
const CURRENT_USER_KEY = 'zayavki_currentUsername';
window.MAINTENANCE_MATERIALS_API = '/api/maintenance-materials';
const LOGIN_BACKGROUND_KEY = 'login_background';


const ALL_TABLE_SORT_LS = 'dist_allTable_sort';
function loadAllTableSort() {
  try {
    const raw = localStorage.getItem(ALL_TABLE_SORT_LS);
    if (!raw) return;
    const o = JSON.parse(raw);
    if (o && typeof o.sortKey === 'string' && o.sortKey) allTableState.sortKey = o.sortKey;
    if (o && (o.sortDir === 'asc' || o.sortDir === 'desc')) allTableState.sortDir = o.sortDir;
  } catch (_) {}
}
function saveAllTableSort() {
  try {
    localStorage.setItem(ALL_TABLE_SORT_LS, JSON.stringify({
      sortKey: allTableState.sortKey || 'datetime',
      sortDir: allTableState.sortDir === 'asc' ? 'asc' : 'desc'
    }));
  } catch (_) {}
}
loadAllTableSort();

function $(id) { return document.getElementById(id); }

// ---- Anti-flicker helpers ----
function ensureDimLoadingStyle() {
  if (document.getElementById('__dim_loading_style')) return;
  const s = document.createElement('style');
  s.id = '__dim_loading_style';
  s.textContent = '.dim-loading{opacity:0.72;transition:opacity 120ms}';
  document.head.appendChild(s);
}
function isSoftRefreshOpts(opts) {
  return !!(opts && (opts.softRefresh || opts.silent || opts.background));
}
function setContentLoading(el, loadingHtml, soft) {
  if (!el) return;
  const hasContent = !!(el.children && el.children.length);
  if (soft && hasContent) {
    ensureDimLoadingStyle();
    el.classList.add('dim-loading');
    return;
  }
  el.classList.remove('dim-loading');
  el.innerHTML = loadingHtml;
}
function clearContentLoading(el) {
  if (el && el.classList) el.classList.remove('dim-loading');
}
function setTableLoading(tbody, isLoading, colspan) {
  if (!tbody) return;
  if (isLoading) {
    if (tbody.children.length > 0) {
      ensureDimLoadingStyle();
      tbody.classList.add('dim-loading');
    } else {
      tbody.innerHTML = '<tr class="loading-row"><td colspan="' + (colspan || 6) + '" class="hint">Зареждане...</td></tr>';
    }
  } else {
    tbody.classList.remove('dim-loading');
  }
}
try {
  const desc = Object.getOwnPropertyDescriptor(Element.prototype, 'innerHTML');
  if (desc && desc.set && !Element.prototype.__distInnerHtmlPatched) {
    const originalSetter = desc.set;
    Object.defineProperty(Element.prototype, 'innerHTML', {
      configurable: true,
      enumerable: desc.enumerable,
      get: desc.get,
      set: function (v) {
        try {
          if (typeof v === 'string' && v.indexOf('Зареждане') !== -1) {
            const tag = this.tagName;
            if ((tag === 'TBODY' || tag === 'DIV') && this.children && this.children.length > 0) {
              const isPureLoading = /^\s*<(tr|div)[^>]*>[\s\S]*Зареждане/i.test(v) && v.length < 220;
              if (isPureLoading) {
                ensureDimLoadingStyle();
                this.classList.add('dim-loading');
                return;
              }
            }
          }
          if (this.classList && this.classList.contains('dim-loading')) {
            this.classList.remove('dim-loading');
          }
        } catch (_) {}
        originalSetter.call(this, v);
      }
    });
    Element.prototype.__distInnerHtmlPatched = true;
  }
} catch (e) { console.warn('Failed to patch innerHTML:', e); }

// ---- Dropdown + materials helpers → public/js/materials-dropdown-ui.js ----
// ---- Warehouse materials picker → public/js/warehouse-materials-picker-ui.js ----

// ---- Objects UI → public/js/objects-ui.js ----
// ---- Role/login UI → public/js/role-auth-ui.js ----

async function checkUnseenRequests() {
  if (currentRole !== 'technician' && currentRole !== 'admin') { stopAlertSound(); return; }
  try {
    const idx = await getIndex();
    let hasUnseen = false;
    for (const id of idx) {
      const rec = await getRecord(id);
      if (!rec) continue;
      const unresolved = rec.status === 'Не е изпълнена' || rec.status === 'Изпълнява се' || !rec.status;
      if (unresolved && !rec.seen) { hasUnseen = true; break; }
    }
    if (hasUnseen) startAlertSound(); else stopAlertSound();
  } catch(e) { /* тихо */ }
}


// ---- Material locks UI → public/js/material-locks-ui.js ----

// ---- Menu navigation / switchTab → public/js/menu-nav-ui.js ----

// ============================================================
//  РЕНДИРАНЕ НА ПОТРЕБИТЕЛИ (С РЕДАКТИРАНЕ)
// ============================================================
// ---- Users admin UI → public/js/users-admin-ui.js ----
// ---- Materials available list → public/js/materials-available-ui.js ----

// ---- Materials catalog UI → public/js/materials-catalog-ui.js ----
// ---- Materials excel import → public/js/materials-excel-import-ui.js ----

// ============================================================
//  ФУНКЦИИ ЗА ЗАЯВКИ ЗА МАТЕРИАЛИ
// ============================================================

// ---- Warehouse submit UI → public/js/warehouse-submit-ui.js ----
// ---- Technicians UI → public/js/technicians-ui.js ----

// ---- Отваряне на конкретна заявка в нов прозорец ----
// Сесията се споделя чрез HttpOnly cookie, затова authentication token
// никога не се поставя в URL.
//
// В този режим НЕ се показва цялата програма (без табове, без хедър) -
// само самата заявка, самостоятелно, сякаш е отделен мини-екран.
function openPendingRecordFromUrl() {
  const params = new URLSearchParams(location.search);
  const id = params.get('openRecord');
  if (!id) return;
  standaloneRecordMode = true;
  try { document.documentElement.classList.remove('standalone-open'); } catch (_) {}
  const mainTabs = document.getElementById('mainTabs');
  if (mainTabs) mainTabs.style.display = 'none';
  const appHeader = document.getElementById('appHeader');
  if (appHeader) appHeader.style.display = 'none';
  // Скриваме всички карти освен заявката — UI вече е подготвен и в
  // applyRoleUI при pendingOpenId, тук е застраховка.
  document.querySelectorAll('#appWrap > .card').forEach(card => {
    if (card.id !== 'recordCard') card.style.display = 'none';
  });
  document.title = 'Заявка #' + id + ' — DiSt';
  openRecord(id);
}

// ============================================================
//  ОТВАРЯНЕ НА ЗАЯВКА ЗА РЕДАКТИРАНЕ
// ============================================================
// true = заявката е отворена в СЪЩИЯ прозорец (не в отделен popup).
// Използва се вместо window.open, защото в WebView2/desktop Client вторият
// прозорец споделя/убива сесията и изхвърля техника към екрана за вход.

window.openRecord = async function(id) {
  // ВИНАГИ отваряме в същия прозорец — без window.open.
  // Това е единственият надежден начин в desktop Client + споделени компютри.
  if (!standaloneRecordMode) {
    inPlaceRecordView = true;
    try {
      // Скриваме само табовете и другите карти. Хедърът (с „Изход“)
      // остава видим — иначе бутонът изчезва и не се връща коректно.
      // Keep main menu tabs visible so user can navigate away; only swap content cards
      const mainTabs = document.getElementById('mainTabs');
      if (mainTabs) mainTabs.style.display = '';
      const appHeader = document.getElementById('appHeader');
      if (appHeader) appHeader.style.display = '';
      document.querySelectorAll('#appWrap > .card').forEach(function (card) {
        if (card.id !== 'recordCard') card.style.display = 'none';
      });
      document.title = 'Заявка #' + id + ' — DiSt';
    } catch (_) {}
  }

  currentId = id;
  const rec = await getRecord(id);
  if (!rec) {
    toast('❌ Заявката не е намерена.');
    if (inPlaceRecordView) {
      restoreMainUiAfterRecordView();
    }
    return;
  }

  await fillForm(rec);
  document.getElementById('recordCard').style.display = 'block';
  editing = false;
  setLocked(true);
  // Скролираме до картата и слагаме фокус на бутона „Затвори" —
  // потребителите с клавиатура и скрийн ридъри влизат директно в картата.
  try {
    const card = document.getElementById('recordCard');
    if (card) card.scrollIntoView({ behavior: 'smooth', block: 'start' });
    const closeBtn = document.getElementById('btnCloseRecord');
    if (closeBtn) setTimeout(() => { try { closeBtn.focus(); } catch (_) {} }, 120);
  } catch (_) {}
  try {
    const canEdit = currentRole === 'admin' || currentRole === 'technician';
    const btnEdit = document.getElementById('btnEdit');
    const btnSave = document.getElementById('btnSave');
    const btnCloseBottom = document.getElementById('btnCloseRecordBottom');
    if (btnEdit) {
      btnEdit.style.display = canEdit ? '' : 'none';
      btnEdit.textContent = 'Редактирай';
      btnEdit.className = 'record-edit-btn';
      btnEdit.disabled = false;
    }
    if (btnSave) {
      btnSave.style.display = 'none';
      btnSave.textContent = 'Запиши';
      btnSave.className = 'primary';
      btnSave.disabled = false;
    }
    if (btnCloseBottom) {
      btnCloseBottom.style.display = '';
      btnCloseBottom.textContent = 'Затвори';
      btnCloseBottom.disabled = false;
      btnCloseBottom.className = 'ghost';
    }
  } catch (_) {}
};

/** Възстановява табове, хедър и списъка след in-place преглед на заявка. */
function restoreMainUiAfterRecordView() {
  inPlaceRecordView = false;
  currentId = null;
  editing = false;
  try { document.getElementById('recordCard').style.display = 'none'; } catch (_) {}
  try {
    const mainTabs = document.getElementById('mainTabs');
    if (mainTabs) mainTabs.style.display = '';
    const appHeader = document.getElementById('appHeader');
    if (appHeader) appHeader.style.display = '';
  } catch (_) {}
  if (currentRole) {
    try {
      applyRoleUI(currentRole, currentUsername, currentUserFullName, currentUserStruktura, currentUserAllowedMenus);
    } catch (e) { try { console.warn('restore applyRoleUI', e); } catch (_) {} }
  }
  // openRecord hides ALL cards — must re-show the active tab panel
  try {
    var tab = currentTab || 'submit';
    if (typeof switchTab === 'function') {
      switchTab(tab, { historyMode: 'none' });
    }
  } catch (e) { try { console.warn('restore switchTab', e); } catch (_) {} }
}

// ---- Maintenance materials UI → public/js/maintenance-materials-ui.js ----

// ---- Required materials UI → public/js/required-materials-ui.js ----

// ---- Repair request form → public/js/repair-request-form-ui.js ----
// ---- Objects list → public/js/objects-list-ui.js ----
// ---- Objects form UI → public/js/objects-ui.js ----
// ============================================================
//  МОДАЛЕН ПРОЗОРЕЦ ЗА ПРЕГЛЕД НА ЗАЯВКА ЗА МАТЕРИАЛИ
// ============================================================


window.closeWhViewModal = function() {
  document.getElementById('whViewModal').style.display = 'none';
};
// Клик върху тъмния фон (извън кутията на модала) също затваря прегледа.
(function wireWhViewModalBackdrop() {
  const modal = document.getElementById('whViewModal');
  if (modal && !modal.__backdropBound) {
    modal.__backdropBound = true;
    modal.addEventListener('click', function (e) {
      if (e.target === modal) window.closeWhViewModal();
    });
  }
})();


// WH modal/lists → public/js/warehouse-requests.js (фаза 2а)
// ============================================================
//  РЕНДИРАНЕ НА СЪРВЪР ТАБ
// ============================================================




// ---- formatBytes / formatUptime → public/js/ui-utils.js ----

// ---- Admin settings UI → public/js/admin-settings-ui.js ----
// ---- ФУНКЦИЯ ЗА КОПИРАНЕ В КЛИПБОРД ----
window.copyToClipboard = function(text) {
  navigator.clipboard.writeText(text).then(() => {
    toast('📋 Копирано: ' + text);
  }).catch(err => {
    // Fallback за по-стари браузъри
    const textarea = document.createElement('textarea');
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.select();
    try {
      document.execCommand('copy');
      toast('📋 Копирано: ' + text);
    } catch (err) {
      toast('❌ Неуспешно копиране');
    }
    document.body.removeChild(textarea);
  });
};

// ---- Login screen UI → public/js/login-screen-ui.js ----
// ============================================================

// ---- Materials reports → public/js/materials-report-ui.js ----// login listeners → role-auth-ui.js

// ---- EVENT LISTENERS ЗА ТАБ БУТОНИТЕ ----
// btnMenuBack/Forward → menu-nav-ui.js
document.getElementById('tabSubmit').addEventListener('click', () => switchTab('submit'));
document.getElementById('tabMyRequests').addEventListener('click', () => switchTab('myRequests'));
document.getElementById('tabMyMaterials').addEventListener('click', () => switchTab('myMaterials'));
document.getElementById('tabRequiredMaterials').addEventListener('click', () => switchTab('requiredMaterials'));
// required materials button listeners → required-materials-ui.js
document.getElementById('tabSearch').addEventListener('click', () => switchTab('search'));
document.getElementById('tabAll').addEventListener('click', () => switchTab('all'));
$('tabMaterialsReport').addEventListener('click', () => switchTab('materialsReport'));
const tabWhMatRep = $('tabWhMaterialsReport');
if (tabWhMatRep) tabWhMatRep.addEventListener('click', () => switchTab('whMaterialsReport'));
document.getElementById('tabTechnicians').addEventListener('click', () => switchTab('technicians'));
document.getElementById('tabObjects').addEventListener('click', (e) => {
  e.stopPropagation();
  switchTab('objects');
  const menu = document.getElementById('objectsDropdownContent');
  if (menu) menu.classList.toggle('show');
  document.getElementById('warehouseDropdownContent')?.classList.remove('show');
  document.getElementById('warehouseMgmtDropdownContent')?.classList.remove('show');
  document.getElementById('adminDropdownContent')?.classList.remove('show');
});
document.getElementById('tabObjectsActive')?.addEventListener('click', (e) => {
  e.stopPropagation(); __objectsStatusFilter = 'active'; switchTab('objects');
  document.getElementById('objectsDropdownContent')?.classList.remove('show');
});
document.getElementById('tabObjectsCompleted')?.addEventListener('click', (e) => {
  e.stopPropagation(); __objectsStatusFilter = 'completed'; switchTab('objects');
  document.getElementById('objectsDropdownContent')?.classList.remove('show');
});
document.getElementById('tabMaterialsList').addEventListener('click', () => switchTab('materialsList'));
function __closeWhMgmtDd() {
  const d = document.getElementById('warehouseMgmtDropdownContent');
  if (d) d.classList.remove('show');
}
document.getElementById('tabWarehouseSanitaryRequests')?.addEventListener('click', (e) => { e.stopPropagation(); switchTab('warehouseSanitaryRequests'); __closeWhMgmtDd(); });
document.getElementById('tabWarehouseOfficeRequests')?.addEventListener('click', (e) => { e.stopPropagation(); switchTab('warehouseOfficeRequests'); __closeWhMgmtDd(); });
document.getElementById('tabSanitaryMaterialsList')?.addEventListener('click', (e) => { e.stopPropagation(); switchTab('sanitaryMaterialsList'); __closeWhMgmtDd(); });
document.getElementById('tabOfficeMaterialsList')?.addEventListener('click', (e) => { e.stopPropagation(); switchTab('officeMaterialsList'); __closeWhMgmtDd(); });
document.getElementById('tabWhMaterialsReport')?.addEventListener('click', (e) => { e.stopPropagation(); switchTab('whMaterialsReport'); __closeWhMgmtDd(); });
document.getElementById('tabServer').addEventListener('click', (e) => { e.stopPropagation(); switchTab('server'); const d=document.getElementById('adminDropdownContent'); if(d) d.classList.remove('show'); });
document.getElementById('tabUsers').addEventListener('click', (e) => { e.stopPropagation(); switchTab('users'); const d=document.getElementById('adminDropdownContent'); if(d) d.classList.remove('show'); });
document.getElementById('tabLogs').addEventListener('click', (e) => { e.stopPropagation(); switchTab('logs'); const d=document.getElementById('adminDropdownContent'); if(d) d.classList.remove('show'); });
const tabMaterialLocks=document.getElementById('tabMaterialLocks');
if(tabMaterialLocks) tabMaterialLocks.addEventListener('click',(e)=>{
  e.stopPropagation(); switchTab('materialLocks');
  const d=document.getElementById('adminDropdownContent'); if(d)d.classList.remove('show');
});
  // material locks buttons → material-locks-ui.js
  // maintenance materials listeners → maintenance-materials-ui.js

document.getElementById('tabAdmin').addEventListener('click', function(e) {
  e.stopPropagation();
  const dropdown = document.getElementById('adminDropdownContent');
  if (dropdown) dropdown.classList.toggle('show');
});

// ---- EVENT LISTENERS ЗА DROPDOWN МЕНЮТО ЗА МАТЕРИАЛИ ----
// Основният бутон за отваряне на dropdown
document.getElementById('tabWarehouse').addEventListener('click', function(e) {
  e.stopPropagation();
  const dropdown = document.getElementById('warehouseDropdownContent');
  if (dropdown) {
    dropdown.classList.toggle('show');
  }
});

// Затваряне на dropdown при клик извън него
document.addEventListener('click', function() {
  const dropdown = document.getElementById('warehouseDropdownContent');
  if (dropdown && dropdown.classList.contains('show')) {
    dropdown.classList.remove('show');
  }
  const objectsDd = document.getElementById('objectsDropdownContent');
  if (objectsDd && objectsDd.classList.contains('show')) objectsDd.classList.remove('show');
  const adminDd = document.getElementById('adminDropdownContent');
  if (adminDd && adminDd.classList.contains('show')) {
    adminDd.classList.remove('show');
  }
  const whMgmtDd = document.getElementById('warehouseMgmtDropdownContent');
  if (whMgmtDd && whMgmtDd.classList.contains('show')) {
    whMgmtDd.classList.remove('show');
  }
});

document.getElementById('tabWarehouseMgmt')?.addEventListener('click', function(e) {
  e.stopPropagation();
  const dropdown = document.getElementById('warehouseMgmtDropdownContent');
  if (dropdown) dropdown.classList.toggle('show');
  const w = document.getElementById('warehouseDropdownContent');
  if (w) w.classList.remove('show');
  const a = document.getElementById('adminDropdownContent');
  if (a) a.classList.remove('show');
});


// Функция за проверка на връзка със сървъра и зареждане на фонова снимка
async function checkServerConnectionAndLoadBackground() {
  try {
    const response = await fetch('/api/server-info', { cache: 'no-store' });
    if (response.ok) {
      await loadLoginBackground();
    }
  } catch (e) {
  }
}

// ---- Инициализация ----
document.addEventListener('DOMContentLoaded', async () => {
  // Ако страницата е отворена от главния прозорец с изричен токен в адреса
  // (виж openRecord по-горе), използваме именно него — самоличността на
  // потребителя, който наистина е влязъл в приложението — вместо да
  // разчитаме на каквато и да е бисквитка, останала в този браузър/профил.
  try {
    const urlParams = new URLSearchParams(location.search);
    const carriedToken = urlParams.get('t');
    if (carriedToken) {
      saveSessionToken(carriedToken);
      urlParams.delete('t');
      const cleanQuery = urlParams.toString();
      const cleanUrl = location.pathname + (cleanQuery ? '?' + cleanQuery : '') + location.hash;
      window.history.replaceState(null, '', cleanUrl);
    }
  } catch (_) {}

  // Публичният текст на информационния панел се зарежда преди проверката за вход.
  await loadLoginInfoPanel();

  // Зареждане на фонова снимка веднага при зареждане на страницата
  await loadLoginBackground();
  
  await loadDropdownSettings();
  await autoLogin();
  
  // Wire other toggles
  wireOtherToggle('sKorpus', 'sKorpusOther');
  wireOtherToggle('sStruktura', 'sStrukturaOther');
  wireOtherToggle('fKorpus', 'fKorpusOther');
  wireOtherToggle('fStruktura', 'fStrukturaOther');
  wireOtherToggle('fIzpalnitel', 'fIzpalnitelOther');
  wireOtherToggle('whStruktura', 'whStrukturaOther');
  
  // Инициализиране на формата за материали — само при активна сесия (иначе KV → 401 в Network)
  if (hasClientSessionForKv() && $('whMaterialsTableBody') && !$('whMaterialsTableBody').children.length) {
    try {
      await resetWhForm();
    } catch (e) {
    }
  }

  // Event listener за бутона за верификация в Сървър таба (използва submitProgramVerification) 
  // Event listeners за подменютата за материали (добавени след зареждане на DOM)
  const tabOfficeMaterials = document.getElementById('tabOfficeMaterials');
  const tabSanitaryMaterials = document.getElementById('tabSanitaryMaterials');
  
  if (tabOfficeMaterials) {
    tabOfficeMaterials.addEventListener('click', async function(e) {
      e.stopPropagation();
      currentMaterialType = 'office';
      setWhEditingId(null);
      switchTab('warehouse');
      const dropdown = document.getElementById('warehouseDropdownContent');
      if (dropdown) dropdown.classList.remove('show');
      try { await resetWhForm(); } catch (_) {}
      try { await renderWhLastRequestPanel(); } catch (_) {}
    });
  }
  
  if (tabSanitaryMaterials) {
    tabSanitaryMaterials.addEventListener('click', async function(e) {
      e.stopPropagation();
      currentMaterialType = 'sanitary';
      setWhEditingId(null);
      switchTab('warehouse');
      const dropdown = document.getElementById('warehouseDropdownContent');
      if (dropdown) dropdown.classList.remove('show');
      try { await resetWhForm(); } catch (_) {}
      try { await renderWhLastRequestPanel(); } catch (_) {}
    });
  }
});



document.addEventListener('DOMContentLoaded', () => {
  const verifyBtn = $('btnVerifyProgram');
  if (verifyBtn) verifyBtn.addEventListener('click', submitProgramVerification);
  const codeInput = $('verificationCode');
  if (codeInput) codeInput.addEventListener('keydown', e => { if (e.key === 'Enter') submitProgramVerification(); });
  const unlockBtn = $('btnUnlockInstallation');
  if (unlockBtn) unlockBtn.addEventListener('click', submitUnlockInstallation);
  const unlockCode = $('unlockVerificationCode');
  if (unlockCode) unlockCode.addEventListener('keydown', e => { if (e.key === 'Enter') submitUnlockInstallation(); });
  const unlockPass = $('unlockAdminPass');
  if (unlockPass) unlockPass.addEventListener('keydown', e => { if (e.key === 'Enter') submitUnlockInstallation(); });
  const changeBtn = $('btnChangeVerifyCode');
  if (changeBtn) changeBtn.addEventListener('click', submitChangeVerificationCode);
  const licBtn = $('btnSaveLicenseContact');
  if (licBtn) licBtn.addEventListener('click', saveLicenseContact);
  refreshVerificationStatus();
  if (!verificationTimer) verificationTimer = setInterval(refreshVerificationStatus, 5 * 60 * 1000);

  // Проверка на сесията: локален таймер до точния момент на изтичане +
  // периодична проверка като резервен механизъм.
  if (!sessionCheckTimer) sessionCheckTimer = setInterval(checkSessionValidity, 30 * 1000);
});

let sessionCheckTimer = null;

// Parent (client.html) може да поиска logout при затваряне с X
window.addEventListener('message', function (ev) {
  if (!ev.data || ev.data.type !== 'zayavki-force-logout') return;
  try { logoutRole(); } catch (_) {}
});


// ---- Enter → следващо позволено поле ----
(function setupEnterMovesToNextField() {
  function isFocusableField(el) {
    if (!el || el.disabled || el.readOnly) return false;
    if (el.tabIndex < 0) return false;
    if (el.type === 'hidden' || el.type === 'file') return false;
    if (el.offsetParent === null && el.type !== 'checkbox' && el.type !== 'radio') return false;
    const tag = (el.tagName || '').toUpperCase();
    if (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA') return true;
    return false;
  }
  function collectFields(root) {
    const nodes = root.querySelectorAll('input, select, textarea');
    return Array.from(nodes).filter(isFocusableField);
  }
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Enter') return;
    if (e.ctrlKey || e.altKey || e.metaKey || e.shiftKey) return;
    const el = e.target;
    if (!el || !el.tagName) return;
    const tag = el.tagName.toUpperCase();
    // В textarea Enter е нов ред (освен с Ctrl — но тук не пипаме)
    if (tag === 'TEXTAREA') return;
    // Бутони / submit — не прехващаме
    if (tag === 'BUTTON') return;
    if (tag === 'INPUT' && (el.type === 'submit' || el.type === 'button' || el.type === 'checkbox' || el.type === 'radio')) return;
    if (tag !== 'INPUT' && tag !== 'SELECT') return;

    // Намери контейнера на формата (карта / модал / gate)
    const root = el.closest('.card, [id$="Modal"], #roleGate, #appWrap, form') || document;
    const fields = collectFields(root);
    const idx = fields.indexOf(el);
    if (idx < 0) return;
    e.preventDefault();
    // Следващо позволено поле
    for (let i = idx + 1; i < fields.length; i++) {
      const next = fields[i];
      if (isFocusableField(next)) {
        try { next.focus(); if (next.select && next.type !== 'checkbox' && next.type !== 'radio' && next.tagName !== 'SELECT') next.select(); } catch (_) {}
        return;
      }
    }
    // Няма следващо поле: на екрана за вход → Вход
    const onLogin = !!(el.closest('#roleGate') || el.id === 'loginUsername' || el.id === 'loginPassword');
    if (onLogin && typeof attemptLogin === 'function') {
      attemptLogin();
    }
  }, true);
})();



(function(){
  function applyDesktopDensity(){
    try {
      var w = window.innerWidth || 1200;
      document.documentElement.classList.remove('desk-sm','desk-md','desk-lg');
      if (w < 1366) document.documentElement.classList.add('desk-sm');
      else if (w < 1700) document.documentElement.classList.add('desk-md');
      else document.documentElement.classList.add('desk-lg');
    } catch(_){}
  }
  if (typeof window !== 'undefined') {
    window.addEventListener('resize', applyDesktopDensity);
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', applyDesktopDensity);
    else applyDesktopDensity();
  }
})();

