/**
 * maintenance-materials-ui.js — app.js modularization
 * Каталог материали за поддръжка.
 * Load AFTER app.js.
 */

var MAINTENANCE_MATERIALS_API = MAINTENANCE_MATERIALS_API || '/api/maintenance-materials';

// ---- Структурирани вложени материали по заявка ----
let fMaterialRowSeq = 0;
async function maintenanceMaterialsRequest(url, options) {
  const res = await authFetch(url, options);
  let data = {};
  try { data = await res.json(); } catch (_) {}
  if (!res.ok) throw new Error(data.error || 'Грешка при работа с каталога за материали.');
  return data;
}

async function getMaintenanceMaterials(force) {
  if (!force && Array.isArray(maintenanceMaterialsCache)) return maintenanceMaterialsCache;
  const data = await maintenanceMaterialsRequest(MAINTENANCE_MATERIALS_API);
  maintenanceMaterialsCache = Array.isArray(data.materials) ? data.materials.filter(m => m && m.active) : [];
  return maintenanceMaterialsCache;
}

async function renderMaintenanceMaterials() {
  const container = document.getElementById('maintenanceMaterialsList');
  const status = document.getElementById('maintenanceMaterialsStatus');
  if (!container) return;
  container.textContent = 'Зареждане...';
  if (status && !maintenanceMaterialEditingId) status.textContent = '';
  try {
    const data = await maintenanceMaterialsRequest(MAINTENANCE_MATERIALS_API);
    let items = Array.isArray(data.materials) ? data.materials.filter(m => m && m.active !== false) : [];
    items = items.slice().sort(function (a, b) {
      return String(a.name || '').localeCompare(String(b.name || ''), 'bg', { sensitivity: 'base' });
    });
    container.innerHTML = '';
    if (!items.length) {
      container.textContent = 'Каталогът е празен. Добавете първия материал от формата по-горе.';
      return;
    }
    const table = document.createElement('table');
    table.className = 'data-tbl mm-maint-tbl';
    table.style.cssText = 'width:auto;max-width:100%;border-collapse:collapse;font-size:13px;';
    table.innerHTML = '<thead><tr>' +
      '<th style="padding:4px 8px;text-align:left;">Материал</th>' +
      '<th style="padding:4px 8px;text-align:left;width:72px;">Мярка</th>' +
      '<th style="padding:4px 6px;text-align:center;width:1%;white-space:nowrap;">Действия</th>' +
      '</tr></thead>';
    const tbody = document.createElement('tbody');
    items.forEach(function (material) {
      const row = document.createElement('tr');
      const name = document.createElement('td');
      name.textContent = material.name;
      name.style.cssText = 'padding:3px 8px;vertical-align:middle;line-height:1.25;';
      const unit = document.createElement('td');
      unit.textContent = material.merka || '—';
      unit.style.cssText = 'padding:3px 8px;vertical-align:middle;white-space:nowrap;';
      const actions = document.createElement('td');
      actions.style.cssText = 'padding:2px 4px;vertical-align:middle;white-space:nowrap;width:1%;';
      const wrap = document.createElement('div');
      wrap.style.cssText = 'display:inline-flex;gap:4px;align-items:center;';
      const editButton = document.createElement('button');
      editButton.type = 'button';
      editButton.className = 'ghost';
      editButton.textContent = 'Редакт.';
      editButton.title = 'Редактирай';
      editButton.style.cssText = 'padding:2px 8px;font-size:12px;line-height:1.2;margin:0;';
      editButton.addEventListener('click', function () {
        maintenanceMaterialEditingId = material.id;
        const nameInput = document.getElementById('newMaintenanceMaterialName');
        const unitInput = document.getElementById('newMaintenanceMaterialUnit');
        const addBtn = document.getElementById('btnAddMaintenanceMaterial');
        if (nameInput) nameInput.value = material.name || '';
        if (unitInput) unitInput.value = material.merka || '';
        if (addBtn) addBtn.textContent = '💾 Запази промените';
        if (status) status.textContent = 'Редакция: „' + material.name + '“. Променете полетата и натиснете „Запази промените“.';
        if (nameInput) nameInput.focus();
      });
      const deleteButton = document.createElement('button');
      deleteButton.type = 'button';
      deleteButton.className = 'ghost';
      deleteButton.textContent = 'Изтрий';
      deleteButton.title = 'Изтрий';
      deleteButton.style.cssText = 'padding:2px 8px;font-size:12px;line-height:1.2;margin:0;color:#c0392b;';
      deleteButton.addEventListener('click', async function () {
        if (!(await confirmDialog('Материалът „' + material.name + '“ ще бъде изтрит от каталога. Старите заявки, в които е използван, няма да се променят. Продължаваме ли?'))) return;
        try {
          await maintenanceMaterialsRequest(MAINTENANCE_MATERIALS_API + '/' + encodeURIComponent(material.id) + '?permanent=1', { method: 'DELETE' });
          if (maintenanceMaterialEditingId === material.id) {
            maintenanceMaterialEditingId = null;
            const nameInput = document.getElementById('newMaintenanceMaterialName');
            const unitInput = document.getElementById('newMaintenanceMaterialUnit');
            const addBtn = document.getElementById('btnAddMaintenanceMaterial');
            if (nameInput) nameInput.value = '';
            if (unitInput) unitInput.value = '';
            if (addBtn) addBtn.textContent = '+ Добави материал';
          }
          maintenanceMaterialsCache = null;
          await renderMaintenanceMaterials();
          if (status) status.textContent = 'Материалът е изтрит.';
        } catch (e) { if (status) status.textContent = e.message || 'Грешка при изтриване на материала.'; }
      });
      wrap.appendChild(editButton);
      wrap.appendChild(deleteButton);
      actions.appendChild(wrap);
      row.append(name, unit, actions);
      tbody.appendChild(row);
    });
    table.appendChild(tbody);
    container.appendChild(table);
  } catch (e) {
    container.textContent = e.message || 'Грешка при зареждане на каталога.';
  }
}


async function addMaintenanceMaterialFromUI() {
  if (currentRole !== 'admin') return;
  const nameInput = document.getElementById('newMaintenanceMaterialName');
  const unitInput = document.getElementById('newMaintenanceMaterialUnit');
  const status = document.getElementById('maintenanceMaterialsStatus');
  const addBtn = document.getElementById('btnAddMaintenanceMaterial');
  const name = nameInput ? nameInput.value.trim() : '';
  const merka = unitInput ? unitInput.value.trim() : '';
  if (!name) { if (status) status.textContent = 'Въведете име на материала.'; return; }
  try {
    if (maintenanceMaterialEditingId) {
      await maintenanceMaterialsRequest(MAINTENANCE_MATERIALS_API + '/' + encodeURIComponent(maintenanceMaterialEditingId), {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, merka, active: true })
      });
      maintenanceMaterialEditingId = null;
      if (status) status.textContent = 'Материалът е обновен.';
    } else {
      await maintenanceMaterialsRequest(MAINTENANCE_MATERIALS_API, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, merka })
      });
      if (status) status.textContent = 'Материалът е добавен.';
    }
    maintenanceMaterialsCache = null;
    if (nameInput) nameInput.value = '';
    if (unitInput) unitInput.value = '';
    if (addBtn) addBtn.textContent = '+ Добави материал';
    await renderMaintenanceMaterials();
  } catch (e) { if (status) status.textContent = e.message || 'Грешка при запис на материала.'; }
}

function exportMaintenanceMaterialsXlsx() {
  return exportWithXlsx(async function () {
  const status = document.getElementById('maintenanceMaterialsStatus');
  if (typeof XLSX === 'undefined') { if (status) status.textContent = 'Библиотеката за Excel не е заредена.'; return; }
  maintenanceMaterialsRequest(MAINTENANCE_MATERIALS_API + '?includeArchived=1').then(data => {
    const items = Array.isArray(data.materials) ? data.materials : [];
    const rows = [['Материал', 'Мярка', 'Статус'], ...items.map(m => [m.name, m.merka || '', m.active ? 'Активен' : 'Архивиран'])];
    const ws = XLSX.utils.aoa_to_sheet(rows);
    ws['!cols'] = [{ wch: 48 }, { wch: 16 }, { wch: 16 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Материали');
    XLSX.writeFile(wb, 'Materiali_za_poddrazhka_' + new Date().toISOString().slice(0, 10) + '.xlsx');
    if (status) status.textContent = 'Експортирани са ' + items.length + ' материала (включително архивираните).';
  }).catch(e => { if (status) status.textContent = e.message || 'Грешка при експортиране.'; });

  });
}
async function importMaintenanceMaterialsFile(file) {
  await ensureXlsxLoaded();

  const status = document.getElementById('maintenanceMaterialsStatus');
  if (!file) return;
  if (typeof XLSX === 'undefined') { if (status) status.textContent = 'Библиотеката за Excel не е заредена.'; return; }
  try {
    const wb = XLSX.read(await file.arrayBuffer(), { type: 'array' });
    const sheet = wb.Sheets[wb.SheetNames[0]];
    if (!sheet) throw new Error('Excel файлът няма лист с данни.');
    const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '', raw: false });
    if (!rows.length) throw new Error('Excel файлът е празен.');
    const norm = v => String(v || '').trim().toLocaleLowerCase('bg').replace(/[\s_]+/g, ' ');
    const header = rows[0].map(norm);
    const nameIndex = header.findIndex(x => ['материал', 'наименование', 'име', 'name', 'material'].includes(x));
    const unitIndex = header.findIndex(x => ['мярка', 'мерна единица', 'единица', 'unit', 'measure'].includes(x));
    const statusIndex = header.findIndex(x => ['статус', 'status'].includes(x));
    if (nameIndex < 0) throw new Error('Не е намерена колона „Материал“. Използвайте шаблона от експортирания Excel.');
    const materials = rows.slice(1).map(row => {
      const statusText = statusIndex >= 0 ? norm(row[statusIndex]) : '';
      return {
        name: String(row[nameIndex] || '').trim(),
        merka: unitIndex >= 0 ? String(row[unitIndex] || '').trim() : '',
        active: !['архивиран', 'архивирана', 'archived', 'inactive'].includes(statusText)
      };
    }).filter(m => m.name);
    if (!materials.length) throw new Error('Не са намерени материали за импорт.');
    const result = await maintenanceMaterialsRequest(MAINTENANCE_MATERIALS_API + '/import', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ materials })
    });
    maintenanceMaterialsCache = null;
    await renderMaintenanceMaterials();
    if (status) status.textContent = 'Импортът приключи: добавени ' + result.added + ', пропуснати ' + result.skipped + ' (празни или вече съществуващи имена).';
  } catch (e) { if (status) status.textContent = e.message || 'Грешка при импорт на Excel.'; }
}



  try {
    var tabMaintenanceMaterials = document.getElementById('tabMaintenanceMaterials');
    if (tabMaintenanceMaterials) tabMaintenanceMaterials.addEventListener('click', function(e) {
      e.stopPropagation();
      if (typeof switchTab === 'function') switchTab('maintenanceMaterials');
      var d = document.getElementById('adminDropdownContent'); if (d) d.classList.remove('show');
    });
    document.getElementById('btnAddMaintenanceMaterial')?.addEventListener('click', function() {
      if (typeof addMaintenanceMaterialFromUI === 'function') addMaintenanceMaterialFromUI();
    });
    document.getElementById('btnExportMaintenanceMaterials')?.addEventListener('click', function() {
      if (typeof exportMaintenanceMaterialsXlsx === 'function') exportMaintenanceMaterialsXlsx();
    });
    document.getElementById('btnChooseMaintenanceMaterialsImport')?.addEventListener('click', function() {
      document.getElementById('fileImportMaintenanceMaterials')?.click();
    });
    document.getElementById('fileImportMaintenanceMaterials')?.addEventListener('change', async function() {
      var file = this.files && this.files[0];
      this.value = '';
      if (file && typeof importMaintenanceMaterialsFile === 'function') await importMaintenanceMaterialsFile(file);
    });
  } catch (e) { try { console.warn('maintenance-materials-ui bind:', e); } catch (_) {} }

/* window exports */
try {
  if (typeof addMaintenanceMaterialFromUI==='function') window.addMaintenanceMaterialFromUI=addMaintenanceMaterialFromUI;
  if (typeof exportMaintenanceMaterialsXlsx==='function') window.exportMaintenanceMaterialsXlsx=exportMaintenanceMaterialsXlsx;
  if (typeof getMaintenanceMaterials==='function') window.getMaintenanceMaterials=getMaintenanceMaterials;
  if (typeof importMaintenanceMaterialsFile==='function') window.importMaintenanceMaterialsFile=importMaintenanceMaterialsFile;
  if (typeof maintenanceMaterialsRequest==='function') window.maintenanceMaterialsRequest=maintenanceMaterialsRequest;
  if (typeof renderMaintenanceMaterials==='function') window.renderMaintenanceMaterials=renderMaintenanceMaterials;
} catch(_){}
