// ---- Отчет за санитарни и канцеларски материали (Администратор) ----
let whMaterialsReportRows = [];
const WH_MATERIAL_REPORT_COLUMNS = [
  {key:'year', label:'Година'},
  {key:'month', label:'Месец'},
  {key:'struktura', label:'Структура'},
  {key:'type', label:'Тип'},
  {key:'code', label:'Код'},
  {key:'vid', label:'Вид материал'},
  {key:'merka', label:'Мярка'},
  {key:'kolichestvo', label:'Количество'}
];
const WH_MAT_REPORT_COL_ORDER_KEY = 'dist_wh_mat_report_col_order_v1';
const WH_MAT_REPORT_COL_CHECKED_KEY = 'dist_wh_mat_report_col_checked_v1';

function getWhMatReportColumnOrder() {
  const def = WH_MATERIAL_REPORT_COLUMNS.map(c => c.key);
  try {
    const raw = localStorage.getItem(WH_MAT_REPORT_COL_ORDER_KEY);
    if (!raw) return def.slice();
    const arr = JSON.parse(raw);
    if (!Array.isArray(arr) || !arr.length) return def.slice();
    const known = new Set(def);
    const ordered = arr.filter(k => known.has(k));
    def.forEach(k => { if (!ordered.includes(k)) ordered.push(k); });
    return ordered;
  } catch (_) { return def.slice(); }
}
function saveWhMatReportColumnOrder(order) {
  try { localStorage.setItem(WH_MAT_REPORT_COL_ORDER_KEY, JSON.stringify(order)); } catch (_) {}
}
function getWhMatReportCheckedMap() {
  const map = {};
  WH_MATERIAL_REPORT_COLUMNS.forEach(c => { map[c.key] = true; });
  try {
    const raw = localStorage.getItem(WH_MAT_REPORT_COL_CHECKED_KEY);
    if (raw) {
      const o = JSON.parse(raw);
      if (o && typeof o === 'object') Object.assign(map, o);
    }
  } catch (_) {}
  return map;
}
function saveWhMatReportCheckedMap(map) {
  try { localStorage.setItem(WH_MAT_REPORT_COL_CHECKED_KEY, JSON.stringify(map)); } catch (_) {}
}
function getSelectedWhMaterialReportColumns() {
  const byKey = {};
  WH_MATERIAL_REPORT_COLUMNS.forEach(c => { byKey[c.key] = c; });
  const order = getWhMatReportColumnOrder();
  const checked = getWhMatReportCheckedMap();
  return order.map(k => byKey[k]).filter(c => {
    if (!c) return false;
    const el = document.getElementById('whMatCol_' + c.key);
    if (el) return !!el.checked;
    return checked[c.key] !== false;
  });
}
function moveWhMatReportColumn(key, dir) {
  const order = getWhMatReportColumnOrder();
  const i = order.indexOf(key);
  if (i < 0) return;
  const j = i + dir;
  if (j < 0 || j >= order.length) return;
  const tmp = order[i]; order[i] = order[j]; order[j] = tmp;
  saveWhMatReportColumnOrder(order);
  renderWhMatReportColumnsPanel();
  if (typeof renderWhMaterialsReport === 'function') renderWhMaterialsReport();
}
function renderWhMatReportColumnsPanel() {
  const box = document.getElementById('whMatReportColumnsList');
  if (!box) return;
  const order = getWhMatReportColumnOrder();
  const checked = getWhMatReportCheckedMap();
  const byKey = {};
  WH_MATERIAL_REPORT_COLUMNS.forEach(c => { byKey[c.key] = c; });
  box.innerHTML = order.map(function (k, idx) {
    const c = byKey[k];
    if (!c) return '';
    const isOn = checked[k] !== false;
    return '<div class="report-col-row" data-key="' + c.key + '" style="display:flex;align-items:center;gap:6px;padding:4px 0;border-bottom:1px solid var(--line,#e8ecf0);">' +
      '<span style="color:var(--ink-soft);font-size:12px;width:18px;text-align:right;">' + (idx + 1) + '.</span>' +
      '<label style="flex:1;margin:0;cursor:pointer;display:flex;align-items:center;gap:6px;">' +
      '<input type="checkbox" id="whMatCol_' + c.key + '"' + (isOn ? ' checked' : '') + '> ' + escapeHtml(c.label) + '</label>' +
      '<button type="button" class="ghost wh-mat-col-up" data-key="' + c.key + '" title="Нагоре" style="margin:0;padding:2px 8px;font-size:12px;"' + (idx === 0 ? ' disabled' : '') + '>↑</button>' +
      '<button type="button" class="ghost wh-mat-col-down" data-key="' + c.key + '" title="Надолу" style="margin:0;padding:2px 8px;font-size:12px;"' + (idx === order.length - 1 ? ' disabled' : '') + '>↓</button>' +
      '</div>';
  }).join('');
  box.querySelectorAll('input[type="checkbox"]').forEach(function (cb) {
    cb.addEventListener('change', function () {
      const map = getWhMatReportCheckedMap();
      const key = this.id.replace(/^whMatCol_/, '');
      map[key] = this.checked;
      saveWhMatReportCheckedMap(map);
      if (typeof renderWhMaterialsReport === 'function') renderWhMaterialsReport();
    });
  });
  box.querySelectorAll('.wh-mat-col-up').forEach(function (btn) {
    btn.addEventListener('click', function () { moveWhMatReportColumn(this.getAttribute('data-key'), -1); });
  });
  box.querySelectorAll('.wh-mat-col-down').forEach(function (btn) {
    btn.addEventListener('click', function () { moveWhMatReportColumn(this.getAttribute('data-key'), 1); });
  });
}

function whReportTypeLabel(t) {
  if (t === 'sanitary') return 'Санитарни';
  if (t === 'office') return 'Канцеларски';
  return t || '';
}
function whReportDateParts(rec) {
  const y = String(rec.godina || '').trim();
  const m = String(rec.mesec || '').trim();
  if (y || m) return { year: y, month: m ? String(Number(m)) : '' };
  // fallback: datetime
  const raw = String(rec.datetime || '').trim();
  const dmY = raw.match(/^(\d{1,2})\.(\d{1,2})\.(\d{4})/);
  if (dmY) return { year: dmY[3], month: String(Number(dmY[2])) };
  return { year: '', month: '' };
}
function whMaterialQty(m) {
  // Отчетите използват само реално отпуснатото количество.
  return getReleasedQuantity(m);
}
function buildWhMaterialsReportData(records) {
  // Филтър „Вид“ — на ниво ред материал.
  const filterVid = String(($('whMatReportVid') || {}).value || '').trim();
  // Отметнатите колони определят измеренията за групиране/сумиране.
  // Пример: махната „Структура“ → сумиране през всички структури за същия вид.
  const includeStruktura = document.getElementById('whMatCol_struktura')?.checked === true;
  const includeType = document.getElementById('whMatCol_type')?.checked === true;
  const includeCode = document.getElementById('whMatCol_code')?.checked === true;
  const includeYear = document.getElementById('whMatCol_year')?.checked === true;
  const includeMonth = document.getElementById('whMatCol_month')?.checked === true;

  const groups = new Map();
  records.forEach(rec => {
    const dp = whReportDateParts(rec);
    const strukturaFull = String(rec.struktura || '').trim();
    const typeFull = String(rec.materialType || '').trim();
    const mats = Array.isArray(rec.materials) ? rec.materials : [];
    mats.forEach(m => {
      const vid = String(m.name || '').trim();
      const merka = String(m.merka || '').trim();
      const codeFull = String(m.code || '').trim();
      if (!vid && !merka && !codeFull) return;
      if (filterVid && vid !== filterVid) return;

      const struktura = includeStruktura ? strukturaFull : '';
      const type = includeType ? typeFull : '';
      const code = includeCode ? codeFull : '';
      const yearKey = includeYear ? (dp.year || '') : '';
      const monthKey = includeMonth ? (dp.month || '') : '';

      const key = [type, struktura, code, vid, merka, yearKey, monthKey].join('\u001f');
      const q = parseMaterialQuantity(whMaterialQty(m));
      const g = groups.get(key) || {
        type, struktura, code, vid, merka,
        kolichestvo: 0, _hasNumericQty: false, _nonNumericQty: [],
        month: monthKey, year: yearKey,
        _years: new Set(), _months: new Set()
      };
      if (dp.year) g._years.add(String(dp.year));
      if (dp.month) g._months.add(String(dp.month));
      if (q !== null) { g.kolichestvo += q; g._hasNumericQty = true; }
      else {
        const rawQ = whMaterialQty(m);
        if (rawQ && !g._nonNumericQty.includes(rawQ)) g._nonNumericQty.push(rawQ);
      }
      groups.set(key, g);
    });
  });
  return Array.from(groups.values()).map(g => {
    g.kolichestvo = g._hasNumericQty ? formatMaterialQuantity(g.kolichestvo) : g._nonNumericQty.join(', ');
    if (includeYear) {
      g.year = g.year || (g._years.size === 1 ? [...g._years][0] : '');
    } else {
      g.year = '';
    }
    if (includeMonth) {
      g.month = g.month || (g._months.size === 1 ? [...g._months][0] : '');
    } else {
      g.month = '';
    }
    if (!includeStruktura) g.struktura = '';
    if (!includeType) g.type = '';
    if (!includeCode) g.code = '';
    delete g._hasNumericQty; delete g._nonNumericQty; delete g._years; delete g._months;
    return g;
  }).sort((a, b) =>
    String(a.type).localeCompare(String(b.type), 'bg') ||
    String(a.struktura).localeCompare(String(b.struktura), 'bg') ||
    String(a.code).localeCompare(String(b.code), 'bg') ||
    String(a.vid).localeCompare(String(b.vid), 'bg') ||
    String(a.merka).localeCompare(String(b.merka), 'bg')
  );
}

function populateWhMaterialsReportFilters(records) {
  const years = [...new Set(records.map(r => whReportDateParts(r).year).filter(Boolean))].sort((a,b)=>b.localeCompare(a));
  const structures = [...new Set(records.map(r => String(r.struktura||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'bg'));
  const vids = [...new Set(records.flatMap(r => (Array.isArray(r.materials)?r.materials:[]).map(m => String(m.name||'').trim()).filter(Boolean)))].sort((a,b)=>a.localeCompare(b,'bg'));
  function fill(id, values) {
    const el = $(id); if (!el) return;
    const cur = el.value;
    el.innerHTML = '<option value="">Всички</option>' + values.map(v => '<option value="'+escapeHtml(v)+'">'+escapeHtml(v)+'</option>').join('');
    if (values.includes(cur)) el.value = cur;
  }
  fill('whMatReportYear', years);
  fill('whMatReportStruktura', structures);
  fill('whMatReportVid', vids);
}
function filterWhMaterialsReportRecords(records) {
  const y = ($('whMatReportYear')||{}).value || '';
  const m = ($('whMatReportMonth')||{}).value || '';
  const st = ($('whMatReportStruktura')||{}).value || '';
  const v = ($('whMatReportVid')||{}).value || '';
  const t = ($('whMatReportType')||{}).value || '';
  return records.filter(r => {
    if (r.materialType !== 'sanitary' && r.materialType !== 'office') return false;
    const dp = whReportDateParts(r);
    if (y && dp.year !== y) return false;
    if (m && String(dp.month) !== String(Number(m))) return false;
    if (st && String(r.struktura||'') !== st) return false;
    if (t && String(r.materialType||'') !== t) return false;
    if (v) {
      const mats = Array.isArray(r.materials) ? r.materials : [];
      if (!mats.some(x => String(x.name||'') === v)) return false;
    }
    return true;
  });
}
function whMaterialReportCell(r, key) {
  if (key === 'type') return whReportTypeLabel(r.type);
  if (key === 'month') {
    const n = Number(r.month);
    return (n >= 1 && n <= 12) ? (WH_MONTH_NAMES[n] || r.month) : (r.month || '');
  }
  return r[key] == null ? '' : r[key];
}
function renderWhMaterialsReportTable() {
  const body = $('whMatReportTableBody');
  const head = $('whMatReportTableHead');
  if (!body || !head) return;
  const cols = getSelectedWhMaterialReportColumns();
  head.innerHTML = cols.map(c => '<th>'+escapeHtml(c.label)+'</th>').join('');
  body.innerHTML = whMaterialsReportRows.length
    ? whMaterialsReportRows.map(r => '<tr>'+cols.map(c => '<td>'+escapeHtml(String(whMaterialReportCell(r,c.key)))+'</td>').join('')+'</tr>').join('')
    : '<tr><td colspan="'+Math.max(cols.length,1)+'" class="hint">Няма данни за избраните филтри.</td></tr>';
  const info = $('whMatReportInfo');
  if (info) info.textContent = 'Общо позиции в отчета: ' + whMaterialsReportRows.length;
}
async function renderWhMaterialsReport() {
  try {
    const all = await getAllWhRecords();
    const base = (all || []).filter(r => r && (r.materialType === 'sanitary' || r.materialType === 'office'));
    populateWhMaterialsReportFilters(base);
    const filtered = filterWhMaterialsReportRecords(base);
    whMaterialsReportRows = buildWhMaterialsReportData(filtered);
    // Допълнителна защита: махаме редове, които не съвпадат с филтъра „Вид“
    const fv = String(($('whMatReportVid') || {}).value || '').trim();
    if (fv) whMaterialsReportRows = whMaterialsReportRows.filter(r => String(r.vid || '').trim() === fv);
    renderWhMaterialsReportTable();
  } catch (e) {
    console.error(e);
    const body = $('whMatReportTableBody');
    if (body) body.innerHTML = '<tr><td class="hint">Грешка при зареждане на отчета.</td></tr>';
  }
}
function exportWhMaterialsReportXlsx() {
  return exportWithXlsx(async function () {
  if (typeof XLSX === 'undefined') { toast('❌ Библиотеката за Excel не е заредена.'); return; }
  const cols = getSelectedWhMaterialReportColumns();
  if (!cols.length) { toast('Изберете поне една колона.'); return; }
  if (!whMaterialsReportRows.length) { toast('Няма данни за експорт.'); return; }
  const summary = [cols.map(c => c.label), ...whMaterialsReportRows.map(r => cols.map(c => whMaterialReportCell(r, c.key)))];
  const ws = XLSX.utils.aoa_to_sheet(summary);
  ws['!cols'] = cols.map(c => ({ wch: Math.min(40, Math.max(10, String(c.label).length + 4)) }));
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Санит_Канц');
  const stamp = new Date().toISOString().slice(0,10);
  XLSX.writeFile(wb, 'Otchet_sanitarni_kancelarski_' + stamp + '.xlsx');
  toast('Експортирани ' + whMaterialsReportRows.length + ' позиции.');

  });
}

['whMatReportYear','whMatReportMonth','whMatReportStruktura','whMatReportVid','whMatReportType'].forEach(id => {
  const el = $(id);
  if (el) el.addEventListener('change', () => renderWhMaterialsReport());
});
const whMatCols = document.getElementById('whMatReportColumns');
if (whMatCols) {
  whMatCols.addEventListener('change', (e) => {
    if (e.target && e.target.matches('input[type="checkbox"]')) {
      renderWhMaterialsReport();
    }
  });
}
const btnWhMatClear = $('btnWhMatReportClear');
if (btnWhMatClear) btnWhMatClear.addEventListener('click', () => {
  ['whMatReportYear','whMatReportMonth','whMatReportStruktura','whMatReportVid','whMatReportType'].forEach(id => { const el=$(id); if (el) el.value=''; });
  renderWhMaterialsReport();
});
const btnWhMatSelAll = $('btnWhMatReportSelectAll');
if (btnWhMatSelAll) btnWhMatSelAll.addEventListener('click', () => {
  document.querySelectorAll('#whMatReportColumnsList input[type="checkbox"]').forEach(x => { x.checked = true; });
  const _wOn = {}; WH_MATERIAL_REPORT_COLUMNS.forEach(c => { _wOn[c.key] = true; }); saveWhMatReportCheckedMap(_wOn);
  renderWhMaterialsReport();
});
const btnWhMatDeselAll = $('btnWhMatReportDeselectAll');
if (btnWhMatDeselAll) btnWhMatDeselAll.addEventListener('click', () => {
  document.querySelectorAll('#whMatReportColumnsList input[type="checkbox"]').forEach(x => { x.checked = false; });
  const _wOff = {}; WH_MATERIAL_REPORT_COLUMNS.forEach(c => { _wOff[c.key] = false; }); saveWhMatReportCheckedMap(_wOff);
  renderWhMaterialsReport();
});
const btnWhMatExport = $('btnWhMatReportExport');
if (btnWhMatExport) btnWhMatExport.addEventListener('click', exportWhMaterialsReportXlsx);
const btnWhMatExportPdf = $('btnWhMatReportExportPdf');
document.getElementById('btnWhMatReportResetOrder')?.addEventListener('click', () => {
  try { localStorage.removeItem(WH_MAT_REPORT_COL_ORDER_KEY); } catch (_) {}
  renderWhMatReportColumnsPanel();
  if (typeof renderWhMaterialsReport === 'function') renderWhMaterialsReport();
  toast('Редът на колоните е нулиран.');
});
try { renderWhMatReportColumnsPanel(); } catch (e) { console.warn(e); }
if (btnWhMatExportPdf) btnWhMatExportPdf.addEventListener('click', function () { if (typeof exportWhMaterialsReportPdf === 'function') exportWhMaterialsReportPdf(); });
