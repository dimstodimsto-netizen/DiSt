/**
 * materials-report-ui.js — app.js modularization
 * Отчети за вложени материали и санитарни/канцеларски.
 * Load AFTER app.js.
 */

// ---- Отчет за вложени материали (само Администратор) ----
let materialsReportRows = [];
const MATERIAL_REPORT_COLUMNS = [
  {key:'year', label:'Година'},
  {key:'month', label:'Месец'},
  {key:'struktura', label:'Структура'},
  {key:'korpus', label:'Корпус'},
  {key:'vid', label:'Вид материал'},
  {key:'merka', label:'Мярка'},
  {key:'kolichestvo', label:'Количество'},
  {key:'lokacia', label:'Локация'}
];
const MAT_REPORT_COL_ORDER_KEY = 'dist_mat_report_col_order_v1';
const MAT_REPORT_COL_CHECKED_KEY = 'dist_mat_report_col_checked_v1';

function getMatReportColumnOrder() {
  const def = MATERIAL_REPORT_COLUMNS.map(c => c.key);
  try {
    const raw = localStorage.getItem(MAT_REPORT_COL_ORDER_KEY);
    if (!raw) return def.slice();
    const arr = JSON.parse(raw);
    if (!Array.isArray(arr) || !arr.length) return def.slice();
    const known = new Set(def);
    const ordered = arr.filter(k => known.has(k));
    def.forEach(k => { if (!ordered.includes(k)) ordered.push(k); });
    return ordered;
  } catch (_) { return def.slice(); }
}
function saveMatReportColumnOrder(order) {
  try { localStorage.setItem(MAT_REPORT_COL_ORDER_KEY, JSON.stringify(order)); } catch (_) {}
}
function getMatReportCheckedMap() {
  const map = {};
  MATERIAL_REPORT_COLUMNS.forEach(c => { map[c.key] = true; });
  try {
    const raw = localStorage.getItem(MAT_REPORT_COL_CHECKED_KEY);
    if (raw) {
      const o = JSON.parse(raw);
      if (o && typeof o === 'object') Object.assign(map, o);
    }
  } catch (_) {}
  return map;
}
function saveMatReportCheckedMap(map) {
  try { localStorage.setItem(MAT_REPORT_COL_CHECKED_KEY, JSON.stringify(map)); } catch (_) {}
}
function getSelectedMaterialReportColumns() {
  const byKey = {};
  MATERIAL_REPORT_COLUMNS.forEach(c => { byKey[c.key] = c; });
  const order = getMatReportColumnOrder();
  const checked = getMatReportCheckedMap();
  // DOM override if rendered
  return order.map(k => byKey[k]).filter(c => {
    if (!c) return false;
    const el = document.getElementById('matCol_' + c.key);
    if (el) return !!el.checked;
    return checked[c.key] !== false;
  });
}
function moveMatReportColumn(key, dir) {
  const order = getMatReportColumnOrder();
  const i = order.indexOf(key);
  if (i < 0) return;
  const j = i + dir;
  if (j < 0 || j >= order.length) return;
  const tmp = order[i]; order[i] = order[j]; order[j] = tmp;
  saveMatReportColumnOrder(order);
  renderMatReportColumnsPanel();
  if (typeof renderMaterialsReport === 'function') renderMaterialsReport();
}
function renderMatReportColumnsPanel() {
  const box = document.getElementById('matReportColumnsList');
  if (!box) return;
  const order = getMatReportColumnOrder();
  const checked = getMatReportCheckedMap();
  const byKey = {};
  MATERIAL_REPORT_COLUMNS.forEach(c => { byKey[c.key] = c; });
  box.innerHTML = order.map(function (k, idx) {
    const c = byKey[k];
    if (!c) return '';
    const isOn = checked[k] !== false;
    return '<div class="report-col-row" data-key="' + c.key + '" style="display:flex;align-items:center;gap:6px;padding:4px 0;border-bottom:1px solid var(--line,#e8ecf0);">' +
      '<span style="color:var(--ink-soft);font-size:12px;width:18px;text-align:right;">' + (idx + 1) + '.</span>' +
      '<label style="flex:1;margin:0;cursor:pointer;display:flex;align-items:center;gap:6px;">' +
      '<input type="checkbox" id="matCol_' + c.key + '"' + (isOn ? ' checked' : '') + '> ' + escapeHtml(c.label) + '</label>' +
      '<button type="button" class="ghost mat-col-up" data-key="' + c.key + '" title="Нагоре" style="margin:0;padding:2px 8px;font-size:12px;"' + (idx === 0 ? ' disabled' : '') + '>↑</button>' +
      '<button type="button" class="ghost mat-col-down" data-key="' + c.key + '" title="Надолу" style="margin:0;padding:2px 8px;font-size:12px;"' + (idx === order.length - 1 ? ' disabled' : '') + '>↓</button>' +
      '</div>';
  }).join('');
  box.querySelectorAll('input[type="checkbox"]').forEach(function (cb) {
    cb.addEventListener('change', function () {
      const map = getMatReportCheckedMap();
      const key = this.id.replace(/^matCol_/, '');
      map[key] = this.checked;
      saveMatReportCheckedMap(map);
      if (typeof renderMaterialsReport === 'function') renderMaterialsReport();
    });
  });
  box.querySelectorAll('.mat-col-up').forEach(function (btn) {
    btn.addEventListener('click', function () { moveMatReportColumn(this.getAttribute('data-key'), -1); });
  });
  box.querySelectorAll('.mat-col-down').forEach(function (btn) {
    btn.addEventListener('click', function () { moveMatReportColumn(this.getAttribute('data-key'), 1); });
  });
}
function reportDateParts(rec) {
  // Репер: дата на изпълнение (dataIzp), не дата на подаване.
  const raw = String((rec && (rec.dataIzp || rec.data_izp)) || '').trim();
  if (!raw) return { year: '', month: '' };
  const dmY = raw.match(/^(\d{1,2})\.(\d{1,2})\.(\d{4})/);
  if (dmY) return { year: dmY[3], month: String(Number(dmY[2])) };
  const iso = raw.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (iso) return { year: iso[1], month: String(Number(iso[2])) };
  const d = parseStamp(raw) || new Date(raw);
  if (!d || isNaN(d.getTime())) return { year: '', month: '' };
  return { year: String(d.getFullYear()), month: String(d.getMonth() + 1) };
}
function parseMaterialQuantity(value) {
  const raw = String(value == null ? '' : value).trim().replace(/\s/g, '').replace(',', '.');
  if (!raw) return null;
  const n = Number(raw);
  return Number.isFinite(n) ? n : null;
}
function formatMaterialQuantity(n) {
  if (typeof n !== 'number' || !Number.isFinite(n)) return '';
  return Number.isInteger(n) ? String(n) : String(Number(n.toFixed(3)));
}
function buildMaterialsReportData(records) {
  // Групиране само по отметнатите колони; без „Структура“ — сумиране по вид+мярка.
  const includeLocation = document.getElementById('matCol_lokacia')?.checked === true;
  const includeKorpus = document.getElementById('matCol_korpus')?.checked === true;
  const includeStruktura = document.getElementById('matCol_struktura')?.checked === true;
  const includeYear = document.getElementById('matCol_year')?.checked === true;
  const includeMonth = document.getElementById('matCol_month')?.checked === true;
  const groups = new Map();
  records.forEach(rec => {
    const dp = reportDateParts(rec);
    parseRepairMaterials(rec.materiali ?? rec.materials).forEach(m => {
      const strukturaFull = String(rec.struktura || '').trim();
      const korpusFull = String(rec.korpus || '').trim();
      const lokaciaFull = String(rec.lokacia || '').trim();
      const vid = String(m.name || '').trim();
      const merkaRaw = String(m.merka || '').trim();
      const merkaKey = merkaRaw.replace(/\s+/g, ' ').replace(/\.$/, '').toLowerCase();
      if (!vid && !merkaRaw) return;
      const struktura = includeStruktura ? strukturaFull : '';
      const korpus = includeKorpus ? korpusFull : '';
      const lokacia = includeLocation ? lokaciaFull : '';
      const yearKey = includeYear ? (dp.year || '') : '';
      const monthKey = includeMonth ? (dp.month || '') : '';
      const key = [struktura, korpus, vid.toLowerCase(), merkaKey, lokacia, yearKey, monthKey].join('\u001f');
      const q = parseMaterialQuantity(m.kolichestvo);
      const g = groups.get(key) || {
        vid, merka: merkaRaw, kolichestvo: 0, _hasNumericQty: false, _nonNumericQty: [],
        struktura, korpus, lokacia,
        month: monthKey, year: yearKey,
        _years: new Set(), _months: new Set()
      };
      if (dp.year) g._years.add(String(dp.year));
      if (dp.month) g._months.add(String(dp.month));
      if (!g.merka && merkaRaw) g.merka = merkaRaw;
      if (q !== null) { g.kolichestvo += q; g._hasNumericQty = true; }
      else if (String(m.kolichestvo || '').trim() && !g._nonNumericQty.includes(String(m.kolichestvo).trim())) {
        g._nonNumericQty.push(String(m.kolichestvo).trim());
      }
      groups.set(key, g);
    });
  });
  return Array.from(groups.values()).map(g => {
    g.kolichestvo = g._hasNumericQty ? formatMaterialQuantity(g.kolichestvo) : g._nonNumericQty.join(', ');
    if (includeYear) {
      g.year = g.year || (g._years.size === 1 ? [...g._years][0] : '');
    } else {
      g.year = '';
    }
    if (includeMonth) {
      g.month = g.month || (g._months.size === 1 ? [...g._months][0] : '');
    } else {
      g.month = '';
    }
    if (!includeStruktura) g.struktura = '';
    if (!includeLocation) g.lokacia = '';
    if (!includeKorpus) g.korpus = '';
    delete g._hasNumericQty; delete g._nonNumericQty; delete g._years; delete g._months;
    return g;
  }).sort((a, b) =>
    String(a.struktura || '').localeCompare(String(b.struktura || ''), 'bg') ||
    String(a.korpus || '').localeCompare(String(b.korpus || ''), 'bg') ||
    String(a.lokacia || '').localeCompare(String(b.lokacia || ''), 'bg') ||
    String(a.vid || '').localeCompare(String(b.vid || ''), 'bg') ||
    String(a.merka || '').localeCompare(String(b.merka || ''), 'bg')
  );
}

function populateMaterialsReportFilters(records) {
  const years = [...new Set(records.map(r => reportDateParts(r).year).filter(Boolean))].sort((a,b)=>b.localeCompare(a));
  const structures = [...new Set(records.map(r=>String(r.struktura||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'bg'));
  const vids = [...new Set(records.flatMap(r=>parseRepairMaterials(r.materiali ?? r.materials).map(m=>m.name).filter(Boolean)))].sort((a,b)=>a.localeCompare(b,'bg'));
  const fill=(id,vals)=>{ const el=$(id), old=el.value; el.innerHTML='<option value="">Всички</option>'+vals.map(v=>'<option value="'+escapeHtml(v)+'">'+escapeHtml(v)+'</option>').join(''); if(vals.includes(old)) el.value=old; };
  fill('matReportYear',years); fill('matReportStruktura',structures); fill('matReportVid',vids);
}
function filteredMaterialsReport(records) {
  const y=$('matReportYear').value, m=$('matReportMonth').value, st=$('matReportStruktura').value, v=$('matReportVid').value;
  return records.filter(r=>{ const dp=reportDateParts(r); return (!y||dp.year===y)&&(!m||dp.month===m)&&(!st||String(r.struktura||'')===st)&&(!v||parseRepairMaterials(r.materiali ?? r.materials).some(x=>x.name===v)); });
}
function materialReportCell(r,key){
  if(key==='month') return WH_MONTH_NAMES[Number(r.month)]||'';
  return r[key] == null ? '' : r[key];
}
function renderMaterialsReportTable() {
  const body=$('matReportTableBody'), cols=getSelectedMaterialReportColumns();
  $('matReportTableHead').innerHTML=cols.map(c=>'<th>'+escapeHtml(c.label)+'</th>').join('');
  body.innerHTML=materialsReportRows.length
    ? materialsReportRows.map(r=>'<tr>'+cols.map(c=>'<td>'+escapeHtml(String(materialReportCell(r,c.key)))+'</td>').join('')+'</tr>').join('')
    : '<tr><td colspan="'+Math.max(cols.length,1)+'" class="hint">Няма данни за избраните филтри.</td></tr>';
  $('matReportInfo').textContent='Общо позиции в отчета: '+materialsReportRows.length;
}
async function renderMaterialsReport() {
  if (currentRole !== 'admin') return;
  try {
    // Сумиране на клиента според отметките:
    // - без „Локация“/„Корпус“ → по-грубо групиране
    // - с „Корпус“ / „Локация“ → разделяне по съответното поле
    const all = await getAllRecords();
    populateMaterialsReportFilters(all);
    const filtered = filteredMaterialsReport(all);
    materialsReportRows = buildMaterialsReportData(filtered);
    renderMaterialsReportTable();
  } catch(e) {
    console.error(e);
    const body = $('matReportTableBody');
    if (body) body.innerHTML = '<tr><td colspan="7" class="hint">Грешка при зареждане на отчета.</td></tr>';
  }
}

/** Официална бланка за PDF/печат на отчети за материали */

// PDF отчети — изнесени в public/js/reports-materials.js (фаза 1 модулност)
function exportMaterialsReportXlsx() {
  return exportWithXlsx(async function () {
  const cols=getSelectedMaterialReportColumns();
  const summary=[cols.map(c=>c.label), ...materialsReportRows.map(r=>cols.map(c=>materialReportCell(r,c.key)))];
  const wb=XLSX.utils.book_new(), ws=XLSX.utils.aoa_to_sheet(summary);
  ws['!cols']=cols.map(c=>({wch: c.key==='kolichestvo'?14:(c.key==='merka'?12: c.key==='year'?10: c.key==='month'?14:25)}));
  XLSX.utils.book_append_sheet(wb,ws,'Отчет');
  XLSX.writeFile(wb,'Otchet_vlozheni_materiali_'+new Date().toISOString().slice(0,10)+'.xlsx');

  });
}
['matReportYear','matReportMonth','matReportStruktura','matReportVid'].forEach(id => {
  const el = $(id);
  if (el) el.addEventListener('change', renderMaterialsReport);
});
try { renderMatReportColumnsPanel(); } catch (e) { console.warn(e); }
const btnMatClear = $('btnMatReportClear');
if (btnMatClear) btnMatClear.addEventListener('click', () => {
  $('matReportYear').value = '';
  $('matReportMonth').value = '';
  $('matReportStruktura').value = '';
  $('matReportVid').value = '';
  renderMaterialsReport();
});
document.getElementById('btnMatReportResetOrder')?.addEventListener('click', () => {
  try { localStorage.removeItem(MAT_REPORT_COL_ORDER_KEY); } catch (_) {}
  renderMatReportColumnsPanel();
  if (typeof renderMaterialsReport === 'function') renderMaterialsReport();
  toast('Редът на колоните е нулиран.');
});
const btnMatSelAll = $('btnMatReportSelectAll');
if (btnMatSelAll) btnMatSelAll.addEventListener('click', () => {
  document.querySelectorAll('#matReportColumnsList input[type="checkbox"]').forEach(x => { x.checked = true; });
  const _mOn = {}; MATERIAL_REPORT_COLUMNS.forEach(c => { _mOn[c.key] = true; }); saveMatReportCheckedMap(_mOn);
  renderMaterialsReport();
});
const btnMatDeselAll = $('btnMatReportDeselectAll');
if (btnMatDeselAll) btnMatDeselAll.addEventListener('click', () => {
  document.querySelectorAll('#matReportColumnsList input[type="checkbox"]').forEach(x => { x.checked = false; });
  const _mOff = {}; MATERIAL_REPORT_COLUMNS.forEach(c => { _mOff[c.key] = false; }); saveMatReportCheckedMap(_mOff);
  renderMaterialsReport();
});
const btnMatExport = $('btnMatReportExport');
if (btnMatExport) btnMatExport.addEventListener('click', exportMaterialsReportXlsx);
const btnMatExportPdf = $('btnMatReportExportPdf');
if (btnMatExportPdf) btnMatExportPdf.addEventListener('click', function () { if (typeof exportMaterialsReportPdf === 'function') exportMaterialsReportPdf(); });
