/**
 * agent-ui.js — автоматични проверки (agent-suite).
 * Load after app.js / session-auth / menu-nav.
 */
(function () {
  'use strict';

  var DIGEST_SESSION_KEY = 'dist_agent_digest_day';

  function escapeSafe(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function fmtTs(ts) {
    if (!ts) return '—';
    try {
      return new Date(ts).toLocaleString('bg-BG');
    } catch (_) {
      return '—';
    }
  }

  function statusIcon(st) {
    if (st === 'ok') return '✅';
    if (st === 'fail') return '❌';
    return '⚠️';
  }

  function ensureBannerEl() {
    var el = document.getElementById('agentDigestBanner');
    if (el) return el;
    el = document.createElement('div');
    el.id = 'agentDigestBanner';
    el.style.cssText = 'display:none;position:fixed;left:50%;transform:translateX(-50%);top:12px;z-index:4500;' +
      'max-width:min(560px,92vw);padding:12px 16px;border-radius:10px;box-shadow:0 6px 24px rgba(0,0,0,.18);' +
      'font-size:14px;line-height:1.35;';
    document.body.appendChild(el);
    return el;
  }

  function hideDigestBanner() {
    var el = document.getElementById('agentDigestBanner');
    if (el) el.style.display = 'none';
  }

  function showDigestBanner(digest) {
    if (!digest || !digest.overall) return;
    var el = ensureBannerEl();
    var overall = digest.overall;
    var bg = overall === 'ok' ? '#eafaf1' : (overall === 'fail' ? '#fdecea' : '#fff8e6');
    var border = overall === 'ok' ? '#27ae60' : (overall === 'fail' ? '#c0392b' : '#e67e22');
    var title = overall === 'ok'
      ? '✅ Всичко е наред'
      : (overall === 'fail' ? '❌ Има проблем' : '⚠️ Предупреждение');
    var lines = '';
    var issues = digest.issues || [];
    if (overall === 'ok') {
      lines = '<div style="margin-top:4px;opacity:.9;">' + escapeSafe(digest.headline || 'Автоматичните проверки са успешни.') + '</div>';
    } else {
      issues.slice(0, 2).forEach(function (iss) {
        lines += '<div style="margin-top:6px;"><b>' + escapeSafe(iss.title) + '</b>' +
          (iss.detail ? ' — ' + escapeSafe(iss.detail) : '') +
          (iss.advice ? '<div class="hint" style="margin:2px 0 0;color:inherit;opacity:.9;">→ ' + escapeSafe(iss.advice) + '</div>' : '') +
          '</div>';
      });
      if ((digest.issueCount || 0) > 2) {
        lines += '<div class="hint" style="margin-top:6px;">… и още ' + (digest.issueCount - 2) + ' (вижте Проверки)</div>';
      }
    }
    el.style.background = bg;
    el.style.border = '1px solid ' + border;
    el.innerHTML =
      '<div style="display:flex;gap:10px;align-items:flex-start;justify-content:space-between;">' +
        '<div style="flex:1;min-width:0;">' +
          '<div style="font-weight:700;">' + title + '</div>' + lines +
        '</div>' +
        '<div style="display:flex;flex-direction:column;gap:4px;flex-shrink:0;">' +
          '<button type="button" class="ghost" id="btnAgentDigestOpen" style="padding:4px 8px;font-size:12px;margin:0;">Проверки</button>' +
          '<button type="button" class="ghost" id="btnAgentDigestClose" style="padding:4px 8px;font-size:12px;margin:0;">Затвори</button>' +
        '</div>' +
      '</div>';
    el.style.display = 'block';
    var btnClose = document.getElementById('btnAgentDigestClose');
    if (btnClose) btnClose.onclick = function () { hideDigestBanner(); };
    var btnOpen = document.getElementById('btnAgentDigestOpen');
    if (btnOpen) {
      btnOpen.onclick = function () {
        hideDigestBanner();
        if (typeof switchTab === 'function') switchTab('agent');
      };
    }
  }

  /** Once per calendar day per browser, after admin login. */
  window.maybeShowAgentMorningDigest = async function maybeShowAgentMorningDigest() {
    try {
      if (typeof currentRole === 'string' ? currentRole !== 'admin' : (window.currentRole !== 'admin' && !(window.AppState && AppState.currentRole === 'admin'))) {
        // roleAuthState path
        var role = null;
        try {
          if (typeof roleAuthState !== 'undefined' && roleAuthState.currentRole) role = roleAuthState.currentRole;
        } catch (_) {}
        try {
          if (!role && typeof currentRole !== 'undefined') role = currentRole;
        } catch (_) {}
        try {
          if (!role && window.AppState && AppState.get) role = AppState.get('currentRole');
        } catch (_) {}
        if (role !== 'admin') return;
      }
      var dayKey = new Date().toISOString().slice(0, 10);
      try {
        if (sessionStorage.getItem(DIGEST_SESSION_KEY) === dayKey) return;
      } catch (_) {}

      if (typeof authFetch !== 'function') return;
      var r = await authFetch('/api/admin/agent/digest');
      if (!r.ok) return;
      var digest = await r.json();
      if (!digest || !digest.overall) return;
      try { sessionStorage.setItem(DIGEST_SESSION_KEY, dayKey); } catch (_) {}
      showDigestBanner(digest);
    } catch (e) {
      try { console.warn('agent digest', e); } catch (_) {}
    }
  };

  function renderChecksList(checks, onlyProblems) {
    var list = Array.isArray(checks) ? checks : [];
    if (onlyProblems) list = list.filter(function (c) { return c.status !== 'ok'; });
    if (!list.length) {
      return '<div style="color:#27ae60;padding:8px 0;">✅ Няма проблеми в този отчет.</div>';
    }
    return list.map(function (c) {
      return '<div style="padding:8px 0;border-bottom:1px solid var(--line);">' +
        '<div><span style="margin-right:6px;">' + statusIcon(c.status) + '</span><b>' + escapeSafe(c.title) + '</b></div>' +
        (c.detail ? '<div class="hint" style="margin:2px 0 0 22px;">' + escapeSafe(c.detail) + '</div>' : '') +
        (c.advice ? '<div style="margin:4px 0 0 22px;font-size:13px;">→ ' + escapeSafe(c.advice) + '</div>' : '') +
        '</div>';
    }).join('');
  }

  function renderAgentTab(data) {
    var el = document.getElementById('agentTabContent');
    if (!el) return;
    var report = data && data.report;
    var cfg = (data && data.config) || {};
    var summary = (report && report.summary) || { overall: '—', ok: 0, warn: 0, fail: 0 };
    var overall = summary.overall || '—';
    var headColor = overall === 'ok' ? '#27ae60' : (overall === 'fail' ? '#c0392b' : (overall === 'warn' ? '#e67e22' : 'inherit'));

    el.innerHTML =
      '<div style="margin-bottom:12px;">' +
        '<div style="font-size:16px;font-weight:700;color:' + headColor + ';">' +
          escapeSafe(report && report.headline ? report.headline : 'Няма наличен отчет') +
        '</div>' +
        '<div class="hint" style="margin-top:4px;">' +
          (report ? ('Генериран: ' + fmtTs(report.generatedAt) +
            (report.meta && report.meta.trigger ? ' · ' + escapeSafe(report.meta.trigger) : '')) : '') +
          (cfg.runAfterUpdate !== false ? ' · след ъпдейт: вкл.' : ' · след ъпдейт: изкл.') +
        '</div>' +
      '</div>' +
      '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px;">' +
        '<button type="button" class="primary" id="btnAgentRun" style="margin:0;">▶ Стартирай проверки</button>' +
        '<button type="button" class="ghost" id="btnAgentShowAll" style="margin:0;">Всички</button>' +
        '<button type="button" class="ghost" id="btnAgentShowProblems" style="margin:0;">Само проблеми</button>' +
      '</div>' +
      '<div id="agentRunStatus" class="hint" style="margin-bottom:10px;"></div>' +
      '<div id="agentChecksWrap">' + renderChecksList(report && report.checks, false) + '</div>' +
      '<div style="margin-top:18px;"><b>Асистирани действия</b></div>' +
      '<div class="hint" style="margin:4px 0 8px;">Само по бутон и потвърждение — не се изпълняват автоматично.</div>' +
      '<div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:14px;">' +
        '<button type="button" class="ghost" id="btnAgentActBackup" style="margin:0;">📦 Бекъп сега</button>' +
        '<button type="button" class="ghost" id="btnAgentActCrash" style="margin:0;">🧾 Последен crash log</button>' +
        '<button type="button" class="ghost" id="btnAgentActCleanup" style="margin:0;">🧹 Временни файлове</button>' +
        '<button type="button" class="ghost" id="btnAgentActClearHist" style="margin:0;color:#c0392b;">🗑 Изчисти история</button>' +
      '</div>' +
      '<pre id="agentActionOut" style="display:none;max-height:220px;overflow:auto;background:#f7f7f7;padding:10px;border-radius:8px;font-size:12px;white-space:pre-wrap;"></pre>' +
      '<div style="margin-top:18px;"><b>История</b></div>' +
      '<div id="agentHistoryWrap" class="hint">Зареждане…</div>';

    wireButtons(report);
    wireActions();
    loadHistory();
  }

  function wireButtons(report) {
    var btn = document.getElementById('btnAgentRun');
    if (btn) {
      btn.onclick = async function () {
        var st = document.getElementById('agentRunStatus');
        btn.disabled = true;
        if (st) st.textContent = 'Изпълняват се проверки…';
        try {
          var r = await authFetch('/api/admin/agent/run', { method: 'POST' });
          var data = await r.json().catch(function () { return {}; });
          if (!r.ok) throw new Error(data.error || ('HTTP ' + r.status));
          renderAgentTab({ report: data.report, config: data.config });
          if (st) st.textContent = 'Готово.';
        } catch (e) {
          if (st) st.textContent = e.message || 'Грешка';
        } finally {
          btn.disabled = false;
        }
      };
    }
    var all = document.getElementById('btnAgentShowAll');
    var prob = document.getElementById('btnAgentShowProblems');
    var wrap = document.getElementById('agentChecksWrap');
    if (all && wrap) {
      all.onclick = function () {
        wrap.innerHTML = renderChecksList(report && report.checks, false);
      };
    }
    if (prob && wrap) {
      prob.onclick = function () {
        wrap.innerHTML = renderChecksList(report && report.checks, true);
      };
    }
  }


  async function agentAction(actionName, confirmMsg) {
    if (confirmMsg) {
      if (typeof confirmDialog === 'function') {
        if (!(await confirmDialog(confirmMsg))) return;
      } else if (!window.confirm(confirmMsg)) return;
    }
    var out = document.getElementById('agentActionOut');
    if (out) { out.style.display = 'block'; out.textContent = 'Изпълнява се…'; }
    try {
      var r = await authFetch('/api/admin/agent/action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: actionName })
      });
      var data = await r.json().catch(function () { return {}; });
      if (!r.ok) throw new Error(data.error || ('HTTP ' + r.status));
      if (out) {
        if (actionName === 'crash-log') {
          var lines = data.lines || [];
          out.textContent = lines.length ? lines.map(function (x) {
            return typeof x === 'string' ? x : JSON.stringify(x);
          }).join('\n') : 'Няма записи в crash log.';
        } else if (actionName === 'run-backup') {
          var b = data.backup || {};
          out.textContent = 'Бекъп: ' + (b.fileName || b.name || 'OK') +
            (b.size != null ? (' (' + b.size + ' bytes)') : '');
          if (typeof toast === 'function') toast('✅ Бекъпът е създаден');
        } else if (actionName === 'clear-history') {
          out.textContent = 'Историята е изчистена.';
          loadHistory();
        } else if (actionName === 'cleanup-temp') {
          var res = (data && data.result) ? data.result : data;
          var removed = (res && res.removed) ? res.removed : [];
          var n = (res && res.removedCount != null) ? res.removedCount : removed.length;
          var errs = (res && res.errors) ? res.errors : [];
          var msg = (n > 0)
            ? ('Изтрити файлове/папки: ' + n + (removed.length ? '\n• ' + removed.slice(0, 20).join('\n• ') : ''))
            : 'Няма стари временни файлове за изтриване (вече са в лимита).';
          if (errs && errs.length) {
            msg += '\nПредупреждения: ' + errs.slice(0, 5).join('; ');
          }
          out.textContent = msg;
          if (typeof toast === 'function') {
            toast(n > 0 ? ('✅ Изтрити: ' + n) : '✅ Няма нищо за изтриване');
          }
        } else {
          out.textContent = (data && data.message) ? String(data.message) : 'Готово.';
        }
      }
    } catch (e) {
      if (out) out.textContent = e.message || 'Грешка';
      if (typeof toast === 'function') toast('❌ ' + (e.message || 'Грешка'));
    }
  }

  function wireActions() {
    var b1 = document.getElementById('btnAgentActBackup');
    if (b1) b1.onclick = function () {
      agentAction('run-backup', 'Да се създаде ли пълен бекъп на сървъра сега?');
    };
    var b2 = document.getElementById('btnAgentActCrash');
    if (b2) b2.onclick = function () { agentAction('crash-log'); };
    var b3 = document.getElementById('btnAgentActCleanup');
    if (b3) b3.onclick = function () {
      agentAction('cleanup-temp', 'Да се изчистят ли стари временни/ъпдейт файлове на сървъра?');
    };
    var b4 = document.getElementById('btnAgentActClearHist');
    if (b4) b4.onclick = function () {
      agentAction('clear-history', 'Да се изчисти ли историята на автоматичните проверки?');
    };
  }

  async function loadHistory() {
    var el = document.getElementById('agentHistoryWrap');
    if (!el) return;
    try {
      var r = await authFetch('/api/admin/agent/history?limit=12');
      var data = await r.json();
      var hist = (data && data.history) || [];
      if (!hist.length) {
        el.textContent = 'Все още няма история.';
        return;
      }
      el.innerHTML = hist.map(function (h) {
        return '<div style="padding:4px 0;border-bottom:1px solid var(--line);">' +
          statusIcon(h.overall) + ' ' + fmtTs(h.generatedAt) +
          ' · ok=' + (h.ok || 0) + ' warn=' + (h.warn || 0) + ' fail=' + (h.fail || 0) +
          (h.trigger ? ' · ' + escapeSafe(h.trigger) : '') +
          (h.headline ? '<div class="hint">' + escapeSafe(h.headline) + '</div>' : '') +
          '</div>';
      }).join('');
    } catch (e) {
      el.textContent = e.message || 'Грешка при история.';
    }
  }

  async function loadAgentTab() {
    var el = document.getElementById('agentTabContent');
    if (!el) return;
    el.innerHTML = '<div class="hint">Зареждане…</div>';
    try {
      var r = await authFetch('/api/admin/agent/report');
      var data = await r.json();
      if (!r.ok) throw new Error(data.error || ('HTTP ' + r.status));
      renderAgentTab(data);
    } catch (e) {
      el.innerHTML = '<div class="hint" style="color:var(--danger);">❌ ' + escapeSafe(e.message || 'Грешка') + '</div>' +
        '<button type="button" class="primary" id="btnAgentRun" style="margin-top:10px;">▶ Стартирай проверки</button>' +
        '<div id="agentRunStatus" class="hint" style="margin-top:8px;"></div>';
      wireButtons(null);
    }
  }

  window.renderAgentTab = loadAgentTab;
  window.showAgentDigestBanner = showDigestBanner;
  window.hideAgentDigestBanner = hideDigestBanner;

  document.addEventListener('DOMContentLoaded', function () {
    var btn = document.getElementById('tabAgent');
    if (btn && !btn.__agentBound) {
      btn.__agentBound = true;
      btn.addEventListener('click', function (e) {
        e.stopPropagation();
        if (typeof switchTab === 'function') switchTab('agent');
        var d = document.getElementById('adminDropdownContent');
        if (d) d.classList.remove('show');
      });
    }
  });
})();
