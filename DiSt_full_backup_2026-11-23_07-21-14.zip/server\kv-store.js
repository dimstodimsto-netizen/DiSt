'use strict';

/** SQLite key/value access and the role-based read policy. */
function createKvStore({ stmtGet, stmtUpsert, stmtDelete, stmtListPrefix }) {
function escapeLike(s) {
  return s.replace(/[\\%_]/g, ch => '\\' + ch);
}

function kvGet(key) {
  const row = stmtGet.get(key);
  return row ? row.value : null;
}

function kvSet(key, value) {
  stmtUpsert.run(key, value);
}

function kvDelete(key) {
  stmtDelete.run(key);
}

function kvListByPrefix(prefix) {
  if (!prefix) return [];
  return stmtListPrefix.all(escapeLike(prefix) + '%');
}

function isSecretKvKey(key) {
  const k = String(key || '');
  return k === 'users-index' || k.startsWith('user:') ||
    k.startsWith('system:verification:code');
}

function kvReadAllowedForRole(key, role) {
  if (isSecretKvKey(key)) return false;
  const k = String(key || '');
  if (k === 'maintenance_materials' && role !== 'admin' && role !== 'technician') return false;
  if (k.startsWith('required-materials:') && role !== 'admin' && role !== 'technician') return false;
  if (k.startsWith('system:') && role !== 'admin') return false;
  // settings:* съдържа и SMTP данни (включително smtpPass в чист текст) —
  // никой клиентски екран не чете settings:* през общия KV API (списъците
  // corpusList/strukturaList/technicianList/statusList се подават през
  // отделен, вече филтриран ендпойнт), затова е безопасно да се затвори
  // изцяло за не-администратори тук.
  if (k.startsWith('settings:') && role !== 'admin') return false;
  return true;
}
  return { kvGet, kvSet, kvDelete, kvListByPrefix, isSecretKvKey, kvReadAllowedForRole };
}
module.exports = { createKvStore };
