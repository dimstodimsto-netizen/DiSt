/* DiSt app-state.js — Stage 1: centralized mutable client state.
 * Loaded before every legacy classic script. Global accessors preserve compatibility
 * while storing values in a private object. New code should use AppState.get/set.
 */
(function (global) {
  'use strict';
  const values = {
    currentRole: null,
    currentUsername: null,
    currentUserFullName: null,
    currentUserStruktura: null,
    pendingRoleType: null,
    authToken: null,
    sessionExpiresAt: null,
    sessionExpiryTimer: null,
    currentId: null,
    techAutoRefresh: null,
    suppressSessionTouch: false,
    pendingUserActivity: false,
    editing: false,
    audioCtx: null,
    alertSoundInterval: null,
    unseenCheckInterval: null,
    materialRowSeq: 0,
    __kvCache: new Map(),
    __kvCacheLoaded: false,
    __objectsRenderSeq: 0,
    __whRenderSeq: 0,
    __techRenderSeq: 0,
    __objectsSearchDebounce: null,
    __objectsStatusFilter: 'active',
    currentTab: 'submit',
    dropdownCorpusList: [],
    dropdownStrukturaList: [],
    dropdownTechnicianList: [],
    dropdownStatusList: [],
    currentMaterialType: null,
    currentUserStrukturaLocked: true,
    currentUserKorpus: '',
    currentUserEtazhi: [],
    whEditingId: null,
    currentUserAllowedMenus: null,
    allTableState: {
      records: [], filtered: [], page: 1, pageSize: 50,
      columns: ['id','datetime','lokacia','vid','zayavitel','status','izpalnitel'],
      sortKey: 'datetime', sortDir: 'desc'
    },
    standaloneRecordMode: false,
    inPlaceRecordView: false,
    maintenanceMaterialsCache: null,
    maintenanceMaterialEditingId: null,
    menuNavigationHistory: [],
    menuNavigationHistoryIndex: -1
  };
  const keys = Object.keys(values);
  const api = Object.freeze({
    get: function (key) {
      if (!Object.prototype.hasOwnProperty.call(values, key)) throw new TypeError('Unknown DiSt state key: ' + key);
      return values[key];
    },
    set: function (key, value) {
      if (!Object.prototype.hasOwnProperty.call(values, key)) throw new TypeError('Unknown DiSt state key: ' + key);
      values[key] = value;
      return value;
    },
    bind: function (names) {
      if (!Array.isArray(names)) throw new TypeError('AppState.bind expects an array of keys');
      const view = {};
      names.forEach(function (key) {
        if (!Object.prototype.hasOwnProperty.call(values, key)) throw new TypeError('Unknown DiSt state key: ' + key);
        if (Object.prototype.hasOwnProperty.call(view, key)) return;
        Object.defineProperty(view, key, {
          configurable: false, enumerable: true,
          get: function () { return values[key]; },
          set: function (value) { values[key] = value; }
        });
      });
      return Object.freeze(view);
    },
    keys: function () { return keys.slice(); }
  });
  Object.defineProperty(global, 'AppState', {
    configurable: false, enumerable: false, writable: false, value: api
  });
  keys.forEach(function (key) {
    const existing = Object.getOwnPropertyDescriptor(global, key);
    if (existing && !existing.configurable && !(existing.get && existing.set)) {
      throw new Error('Cannot install DiSt state compatibility accessor: ' + key);
    }
    Object.defineProperty(global, key, {
      configurable: true, enumerable: true,
      get: function () { return values[key]; },
      set: function (value) { values[key] = value; }
    });
  });
})(window);
