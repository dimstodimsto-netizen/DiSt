/* window exports */
try {
  if (typeof bindWarehouseRequestFilters==='function') window.bindWarehouseRequestFilters=bindWarehouseRequestFilters;
  if (typeof closeMyReqFilterCal==='function') window.closeMyReqFilterCal=closeMyReqFilterCal;
  if (typeof deleteWhRequest==='function') window.deleteWhRequest=deleteWhRequest;
  if (typeof downloadWhRequestPDF==='function') window.downloadWhRequestPDF=downloadWhRequestPDF;
  if (typeof filterWarehouseRequestRecords==='function') window.filterWarehouseRequestRecords=filterWarehouseRequestRecords;
  if (typeof formatWhFulfilledAt==='function') window.formatWhFulfilledAt=formatWhFulfilledAt;
  if (typeof isWhRequestFulfilled==='function') window.isWhRequestFulfilled=isWhRequestFulfilled;
  if (typeof markWhFulfilled==='function') window.markWhFulfilled=markWhFulfilled;
  if (typeof openMyReqFilterCal==='function') window.openMyReqFilterCal=openMyReqFilterCal;
  if (typeof openWhViewModal==='function') window.openWhViewModal=openWhViewModal;
  if (typeof populateWarehouseRequestFilters==='function') window.populateWarehouseRequestFilters=populateWarehouseRequestFilters;
  if (typeof printWhRequest==='function') window.printWhRequest=printWhRequest;
  if (typeof renderMonthlyPanel==='function') window.renderMonthlyPanel=renderMonthlyPanel;
  if (typeof renderMyMaterials==='function') window.renderMyMaterials=renderMyMaterials;
  if (typeof renderMyReqFilterCal==='function') window.renderMyReqFilterCal=renderMyReqFilterCal;
  if (typeof renderMyRequests==='function') window.renderMyRequests=renderMyRequests;
  if (typeof renderWarehouseOfficeTable==='function') window.renderWarehouseOfficeTable=renderWarehouseOfficeTable;
  if (typeof renderWarehouseSanitaryTable==='function') window.renderWarehouseSanitaryTable=renderWarehouseSanitaryTable;
  if (typeof renderWarehouseTable==='function') window.renderWarehouseTable=renderWarehouseTable;
  if (typeof saveWhViewModalChanges==='function') window.saveWhViewModalChanges=saveWhViewModalChanges;
  if (typeof saveWhViewZabelezka==='function') window.saveWhViewZabelezka=saveWhViewZabelezka;
  if (typeof saveWhViewZabelezkaAndFulfill==='function') window.saveWhViewZabelezkaAndFulfill=saveWhViewZabelezkaAndFulfill;
  if (typeof setMyReqFilterDate==='function') window.setMyReqFilterDate=setMyReqFilterDate;
  if (typeof whViewPrint==='function') window.whViewPrint=whViewPrint;
} catch(_){}
