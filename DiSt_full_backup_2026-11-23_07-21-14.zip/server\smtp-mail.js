'use strict';

/**
 * Минимален SMTP клиент (без npm зависимости).
 * Поддържа: plain, STARTTLS (587), implicit TLS (465).
 * AUTH LOGIN (Base64).
 */

const net = require('node:net');
const tls = require('node:tls');

function b64(s) {
  return Buffer.from(String(s), 'utf8').toString('base64');
}

// Премахва CR/LF от стойности, които влизат директно в SMTP команди или в
// хедъри на писмото (MAIL FROM, RCPT TO, From:, To:) — иначе стойност,
// съдържаща \r\n, може да прекрати текущия ред и да добави произволна
// SMTP команда или пощенски хедър (напр. скрит Bcc:).
function stripCrlf(s) {
  return String(s == null ? '' : s).replace(/[\r\n]+/g, ' ').trim();
}

function normalizeRecipients(to) {
  const list = Array.isArray(to)
    ? to.map(x => String(x))
    : String(to || '').split(/[;,]+/);
  return list.map(s => stripCrlf(s)).filter(Boolean);
}

/**
 * @param {object} cfg
 * @param {string} cfg.host
 * @param {number} [cfg.port]
 * @param {'starttls'|'tls'|'none'} [cfg.mode]
 * @param {string} [cfg.user]
 * @param {string} [cfg.pass]
 * @param {string} cfg.from
 * @param {string|string[]} cfg.to
 * @param {string} cfg.subject
 * @param {string} cfg.body
 * @param {number} [cfg.timeoutMs]
 * @returns {Promise<{ok:boolean, error?:string, transport?:string}>}
 */
function sendSmtpMail(cfg) {
  return new Promise((resolve) => {
    const host = String(cfg.host || '').trim();
    if (!host) {
      resolve({ ok: false, error: 'Липсва SMTP хост.' });
      return;
    }
    const mode = String(cfg.mode || 'starttls').toLowerCase();
    const port = Number(cfg.port) || (mode === 'tls' ? 465 : mode === 'none' ? 25 : 587);
    const user = stripCrlf(cfg.user != null ? cfg.user : '');
    const pass = cfg.pass != null ? String(cfg.pass) : ''; // само по AUTH LOGIN (base64 ред), не влиза в хедъри
    const from = stripCrlf(cfg.from || user || 'noreply@localhost');
    const recipients = normalizeRecipients(cfg.to);
    if (!recipients.length) {
      resolve({ ok: false, error: 'Няма получатели.' });
      return;
    }
    // По подразбиране сертификатът на SMTP хоста СЕ проверява. Изключва се
    // само изрично (cfg.tlsInsecure === true) — за вътрешен сървър със
    // самоподписан сертификат — никога по подразбиране, защото иначе паролата
    // на пощенския акаунт (AUTH LOGIN) минава по TLS канал без гаранция с кого.
    const rejectUnauthorized = cfg.tlsInsecure === true ? false : true;
    const subject = String(cfg.subject || '');
    const body = String(cfg.body || '');
    const timeoutMs = Number(cfg.timeoutMs) || 30000;

    let socket = null;
    let buffer = '';
    let settled = false;
    let step = 0;
    let rcptIndex = 0;
    const queue = [];

    const finish = (result) => {
      if (settled) return;
      settled = true;
      try { if (socket) socket.destroy(); } catch (_) {}
      resolve(Object.assign({ transport: 'smtp' }, result));
    };

    const timer = setTimeout(() => finish({ ok: false, error: 'SMTP timeout (' + timeoutMs + ' ms).' }), timeoutMs);

    const sendLine = (line) => {
      if (!socket || socket.destroyed) return;
      socket.write(line + '\r\n', 'utf8');
    };

    const processBuffer = () => {
      while (true) {
        const idx = buffer.indexOf('\n');
        if (idx < 0) break;
        let line = buffer.slice(0, idx);
        buffer = buffer.slice(idx + 1);
        if (line.endsWith('\r')) line = line.slice(0, -1);
        // multi-line replies: "250-..." continue; "250 " final
        if (line.length >= 4 && line[3] === '-') continue;
        handleReply(line);
        if (settled) return;
      }
    };

    const expect = (codes, onOk) => {
      queue.push({ codes: codes.map(Number), onOk });
    };

    const handleReply = (line) => {
      const code = parseInt(line.slice(0, 3), 10);
      if (!queue.length) {
        // unexpected
        return;
      }
      const cur = queue[0];
      if (!cur.codes.includes(code)) {
        queue.shift();
        clearTimeout(timer);
        finish({ ok: false, error: 'SMTP ' + code + ': ' + line.slice(4) });
        return;
      }
      queue.shift();
      try { cur.onOk(line); } catch (e) {
        clearTimeout(timer);
        finish({ ok: false, error: e.message || String(e) });
      }
    };

    const startHandshake = () => {
      expect([220], () => {
        sendLine('EHLO dist-local');
        expect([250], () => afterEhlo());
      });
    };

    const afterEhlo = () => {
      if (mode === 'starttls' && step === 0) {
        step = 1;
        sendLine('STARTTLS');
        expect([220], () => {
          const secure = tls.connect({
            socket,
            host,
            servername: host,
            rejectUnauthorized
          });
          socket = secure;
          buffer = '';
          socket.setEncoding('utf8');
          socket.on('data', (chunk) => { buffer += chunk; processBuffer(); });
          socket.on('error', (e) => { clearTimeout(timer); finish({ ok: false, error: 'TLS: ' + (e.message || e) }); });
          socket.on('close', () => { if (!settled) { clearTimeout(timer); finish({ ok: false, error: 'Връзката беше затворена.' }); } });
          sendLine('EHLO dist-local');
          expect([250], () => doAuthOrMail());
        });
        return;
      }
      doAuthOrMail();
    };

    const doAuthOrMail = () => {
      if (user) {
        sendLine('AUTH LOGIN');
        expect([334], () => {
          sendLine(b64(user));
          expect([334], () => {
            sendLine(b64(pass));
            expect([235], () => sendMailFrom());
          });
        });
      } else {
        sendMailFrom();
      }
    };

    const sendMailFrom = () => {
      sendLine('MAIL FROM:<' + from.replace(/[<>]/g, '') + '>');
      expect([250], () => sendRcpt());
    };

    const sendRcpt = () => {
      if (rcptIndex >= recipients.length) {
        sendData();
        return;
      }
      const r = recipients[rcptIndex++];
      sendLine('RCPT TO:<' + r.replace(/[<>]/g, '') + '>');
      expect([250, 251], () => sendRcpt());
    };

    const sendData = () => {
      sendLine('DATA');
      expect([354], () => {
        const headers =
          'From: ' + from + '\r\n' +
          'To: ' + recipients.join(', ') + '\r\n' +
          'Subject: =?UTF-8?B?' + b64(subject) + '?=\r\n' +
          'MIME-Version: 1.0\r\n' +
          'Content-Type: text/plain; charset=UTF-8\r\n' +
          'Content-Transfer-Encoding: base64\r\n' +
          '\r\n' +
          b64(body).replace(/(.{1,76})/g, '$1\r\n') +
          '\r\n.';
        // DATA body ends with \r\n.\r\n
        if (!socket || socket.destroyed) return;
        socket.write(headers + '\r\n', 'utf8');
        expect([250], () => {
          sendLine('QUIT');
          expect([221], () => {
            clearTimeout(timer);
            finish({ ok: true });
          });
          // some servers close without 221
          setTimeout(() => {
            if (!settled) {
              clearTimeout(timer);
              finish({ ok: true });
            }
          }, 1500);
        });
      });
    };

    const onConnect = () => {
      socket.setEncoding('utf8');
      socket.on('data', (chunk) => { buffer += chunk; processBuffer(); });
      socket.on('error', (e) => { clearTimeout(timer); finish({ ok: false, error: e.message || String(e) }); });
      socket.on('close', () => {
        if (!settled) {
          clearTimeout(timer);
          finish({ ok: false, error: 'Връзката беше затворена.' });
        }
      });
      startHandshake();
    };

    try {
      if (mode === 'tls') {
        socket = tls.connect({ host, port, servername: host, rejectUnauthorized }, onConnect);
      } else {
        socket = net.connect({ host, port }, onConnect);
      }
    } catch (e) {
      clearTimeout(timer);
      finish({ ok: false, error: e.message || String(e) });
    }
  });
}

module.exports = { sendSmtpMail, normalizeRecipients };
