'use strict';

/** Validates and applies DiSt update archives. */
function createUpdateModule({ fs, path, os, spawnSync, crypto, ROOT_DIR, DATA_DIR, computeUiVersion, getUiVersion }) {
  const UPDATE_MAX_BYTES = 80 * 1024 * 1024;
  const UPDATE_MAX_FILES = 500;
  const UPDATE_ALLOWED_EXACT = new Set([
    'server.js', 'package.json', 'README.txt', 'Zayavki.exe',
    'START.bat', 'START_SERVER.bat', 'START_HIDDEN.vbs', 'STOP_SERVER.bat',
    'WATCHDOG.bat', 'INSTALL_WATCHDOG_TASK.bat', 'ico.ico'
  ]);
  const UPDATE_ALLOWED_PREFIXES = ['public/', 'server/', 'scripts/'];
  const UPDATE_FORBIDDEN_PREFIXES = ['data/', 'node/', 'logs/'];

  function normalizeUpdateRelPath(value) {
    if (typeof value !== 'string' || !value || value.includes('\0') || value.includes('\\')) return null;
    if (value.startsWith('/') || /^[a-zA-Z]:/.test(value)) return null;
    const segments = value.split('/');
    if (segments.some(part => !part || part === '.' || part === '..' || part.includes(':'))) return null;
    return segments.join('/');
  }

  function isUpdatePathAllowed(value) {
    const rel = normalizeUpdateRelPath(value);
    if (!rel) return false;
    const lower = rel.toLowerCase();
    if (UPDATE_FORBIDDEN_PREFIXES.some(prefix => lower === prefix.slice(0, -1) || lower.startsWith(prefix))) return false;
    if (Array.from(UPDATE_ALLOWED_EXACT).some(item => item.toLowerCase() === lower)) return true;
    return UPDATE_ALLOWED_PREFIXES.some(prefix => lower === prefix.slice(0, -1) || lower.startsWith(prefix));
  }

  // Inspect central-directory entries before calling the platform ZIP extractor.
  function inspectZipArchive(buffer) {
    if (!Buffer.isBuffer(buffer) || buffer.length < 22 || buffer.length > UPDATE_MAX_BYTES) {
      throw new Error('Размерът на ZIP архива е невалиден.');
    }
    const minEocd = Math.max(0, buffer.length - 65557);
    let eocd = -1;
    for (let i = buffer.length - 22; i >= minEocd; i--) {
      if (buffer.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw new Error('ZIP архивът няма валиден централен каталог.');
    const disk = buffer.readUInt16LE(eocd + 4);
    const centralDisk = buffer.readUInt16LE(eocd + 6);
    const diskEntries = buffer.readUInt16LE(eocd + 8);
    const entries = buffer.readUInt16LE(eocd + 10);
    const centralSize = buffer.readUInt32LE(eocd + 12);
    const centralOffset = buffer.readUInt32LE(eocd + 16);
    const commentLength = buffer.readUInt16LE(eocd + 20);
    if (disk !== 0 || centralDisk !== 0 || diskEntries !== entries || entries === 0 || entries > UPDATE_MAX_FILES ||
        entries === 0xffff || centralSize === 0xffffffff || centralOffset === 0xffffffff ||
        eocd + 22 + commentLength !== buffer.length || centralOffset + centralSize > eocd) {
      throw new Error('ZIP архивът е многотомов, прекалено сложен или с невалидна структура.');
    }

    const names = new Set();
    const localRanges = [];
    const items = [];
    let totalUncompressed = 0;
    let cursor = centralOffset;
    for (let i = 0; i < entries; i++) {
      if (cursor + 46 > centralOffset + centralSize || buffer.readUInt32LE(cursor) !== 0x02014b50) {
        throw new Error('Невалиден запис в централния каталог на ZIP архива.');
      }
      const madeBy = buffer.readUInt16LE(cursor + 4);
      const flags = buffer.readUInt16LE(cursor + 8);
      const method = buffer.readUInt16LE(cursor + 10);
      const compressedSize = buffer.readUInt32LE(cursor + 20);
      const uncompressedSize = buffer.readUInt32LE(cursor + 24);
      const nameLength = buffer.readUInt16LE(cursor + 28);
      const extraLength = buffer.readUInt16LE(cursor + 30);
      const entryCommentLength = buffer.readUInt16LE(cursor + 32);
      const startDisk = buffer.readUInt16LE(cursor + 34);
      const externalAttributes = buffer.readUInt32LE(cursor + 38);
      const localOffset = buffer.readUInt32LE(cursor + 42);
      const end = cursor + 46 + nameLength + extraLength + entryCommentLength;
      if (end > centralOffset + centralSize || startDisk !== 0 || compressedSize === 0xffffffff ||
          uncompressedSize === 0xffffffff || localOffset === 0xffffffff) {
        throw new Error('ZIP архивът използва неподдържани или невалидни разширения.');
      }
      if ((flags & 0x0001) || (flags & 0x0040) || (flags & 0x2000)) throw new Error('Криптирани ZIP записи не се приемат.');
      if (method !== 0 && method !== 8) throw new Error('ZIP архивът използва неподдържан метод за компресия.');

      const nameBytes = buffer.subarray(cursor + 46, cursor + 46 + nameLength);
      let rawName;
      try {
        if (flags & 0x0800) rawName = new TextDecoder('utf-8', { fatal: true }).decode(nameBytes);
        else {
          if (nameBytes.some(byte => byte > 0x7f)) throw new Error('non-ascii');
          rawName = nameBytes.toString('ascii');
        }
      } catch (_) { throw new Error('ZIP архивът съдържа невалидно кодирано име на файл.'); }
      const isDirectory = rawName.endsWith('/');
      const name = isDirectory ? rawName.slice(0, -1) : rawName;
      const rel = normalizeUpdateRelPath(name);
      if (!rel || (rel !== 'update-manifest.json' && !isUpdatePathAllowed(rel))) throw new Error('Забранен или небезопасен път в ZIP архива: ' + rawName);
      const key = rel.toLowerCase();
      if (names.has(key)) throw new Error('ZIP архивът съдържа дублиран път: ' + rel);
      names.add(key);

      const hostSystem = madeBy >>> 8;
      const unixMode = externalAttributes >>> 16;
      const fileType = unixMode & 0xf000;
      if (hostSystem === 3 && fileType && fileType !== 0x8000 && fileType !== 0x4000) {
        throw new Error('Символни връзки и специални файлове не се приемат: ' + rel);
      }
      if (isDirectory && uncompressedSize !== 0) throw new Error('Невалиден ZIP запис за папка: ' + rel);
      if (!isDirectory) {
        totalUncompressed += uncompressedSize;
        if (uncompressedSize > UPDATE_MAX_BYTES || totalUncompressed > UPDATE_MAX_BYTES) {
          throw new Error('Разархивираният пакет надхвърля разрешения лимит.');
        }
        items.push({ rel, isDirectory: false, size: uncompressedSize });
      }

      if (localOffset + 30 > centralOffset || buffer.readUInt32LE(localOffset) !== 0x04034b50) {
        throw new Error('Невалиден локален запис в ZIP архива.');
      }
      const localNameLength = buffer.readUInt16LE(localOffset + 26);
      const localExtraLength = buffer.readUInt16LE(localOffset + 28);
      const localNameStart = localOffset + 30;
      const dataStart = localNameStart + localNameLength + localExtraLength;
      const dataEnd = dataStart + compressedSize;
      if (dataStart > centralOffset || dataEnd > centralOffset || localNameLength !== nameLength ||
          !buffer.subarray(localNameStart, localNameStart + localNameLength).equals(nameBytes)) {
        throw new Error('Несъответствие между локалния запис и ZIP каталога.');
      }
      localRanges.push([localOffset, dataEnd]);
      cursor = end;
    }
    if (cursor !== centralOffset + centralSize) throw new Error('ZIP каталогът съдържа непознати данни.');
    if (!names.has('update-manifest.json')) throw new Error('ZIP архивът трябва да съдържа update-manifest.json в основната папка.');
    localRanges.sort((a, b) => a[0] - b[0]);
    for (let i = 1; i < localRanges.length; i++) {
      if (localRanges[i][0] < localRanges[i - 1][1]) throw new Error('ZIP записите се припокриват.');
    }
    return items;
  }

  function extractZipToDir(zipPath, destDir) {
    fs.mkdirSync(destDir, { recursive: true });
    if (process.platform === 'win32') {
      const ps = ['-NoProfile', '-Command',
        "Expand-Archive -LiteralPath '" + zipPath.replace(/'/g, "''") + "' -DestinationPath '" + destDir.replace(/'/g, "''") + "' -Force"];
      const result = spawnSync('powershell', ps, { encoding: 'utf8', windowsHide: true, timeout: 120000 });
      if (result.error || result.status !== 0) {
        const detail = (result.stderr || result.stdout || (result.error && result.error.message) || 'Expand-Archive failed').toString();
        throw new Error('Неуспешно разархивиране: ' + detail.slice(0, 400));
      }
      return;
    }
    const result = spawnSync('unzip', ['-o', '-q', zipPath, '-d', destDir], { encoding: 'utf8', timeout: 120000 });
    if (result.error || result.status !== 0) {
      throw new Error('Неуспешно разархивиране: ' + String(result.stderr || result.stdout || (result.error && result.error.message) || result.status).slice(0, 400));
    }
  }

  function walkFiles(dir, base) {
    const out = [];
    for (const name of fs.readdirSync(dir)) {
      const full = path.join(dir, name);
      const st = fs.lstatSync(full);
      if (st.isSymbolicLink()) throw new Error('ZIP архивът е извлякъл символна връзка.');
      const rel = path.relative(base, full).replace(/\\/g, '/');
      if (st.isDirectory()) out.push(...walkFiles(full, base));
      else if (st.isFile()) out.push({ full, rel });
      else throw new Error('ZIP архивът съдържа специален файл: ' + rel);
    }
    return out;
  }

  function findExtractRoot(extractDir) {
    const entries = fs.readdirSync(extractDir);
    if (entries.length === 1) {
      const only = path.join(extractDir, entries[0]);
      if (fs.lstatSync(only).isDirectory()) return only;
    }
    return extractDir;
  }

  function parseAndVerifyManifest(root, extracted, zipEntries) {
    const manifestPath = path.join(root, 'update-manifest.json');
    if (!fs.existsSync(manifestPath) || !fs.lstatSync(manifestPath).isFile()) {
      throw new Error('Пакетът няма задължителен update-manifest.json.');
    }
    let manifest;
    try { manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8').replace(/^\uFEFF/, '')); }
    catch (_) { throw new Error('Невалиден update-manifest.json.'); }
    if (!manifest || manifest.format !== 'DiSt-Update-1' || !Array.isArray(manifest.files) ||
        !manifest.files.length || manifest.files.length > UPDATE_MAX_FILES || typeof manifest.version !== 'string') {
      throw new Error('Manifest-ът не отговаря на изисквания формат DiSt-Update-1.');
    }
    const expected = new Map();
    for (const item of manifest.files) {
      const rel = normalizeUpdateRelPath(item && item.path);
      const size = item && item.size;
      const hash = item && item.sha256;
      if (!rel || rel === 'update-manifest.json' || !isUpdatePathAllowed(rel) ||
          !Number.isSafeInteger(size) || size < 0 || size > UPDATE_MAX_BYTES ||
          typeof hash !== 'string' || !/^[a-f0-9]{64}$/i.test(hash)) {
        throw new Error('Manifest-ът съдържа невалиден файл или хеш.');
      }
      const key = rel.toLowerCase();
      if (expected.has(key)) throw new Error('Manifest-ът съдържа дублиран път: ' + rel);
      expected.set(key, { rel, size, sha256: hash.toLowerCase() });
    }
    const actual = extracted.filter(file => file.rel.toLowerCase() !== 'update-manifest.json');
    if (actual.length !== expected.size || actual.length !== zipEntries.filter(entry => !entry.isDirectory && entry.rel.toLowerCase() !== 'update-manifest.json').length) {
      throw new Error('Файловете в ZIP архива не съвпадат с manifest-а.');
    }
    for (const file of actual) {
      const descriptor = expected.get(file.rel.toLowerCase());
      if (!descriptor || descriptor.rel !== file.rel) throw new Error('Непосочен или различно изписан файл в ZIP архива: ' + file.rel);
      const stat = fs.statSync(file.full);
      if (stat.size !== descriptor.size) throw new Error('Размерът не съвпада с manifest-а: ' + file.rel);
      const hash = crypto.createHash('sha256').update(fs.readFileSync(file.full)).digest('hex');
      if (hash !== descriptor.sha256) throw new Error('SHA-256 проверката не премина: ' + file.rel);
    }
    const deleteList = Array.isArray(manifest.delete) ? manifest.delete : [];
    if (deleteList.length > 100) throw new Error('Manifest-ът съдържа прекалено много изтривания.');
    const deletes = new Set();
    for (const value of deleteList) {
      const rel = normalizeUpdateRelPath(value);
      if (!rel || !isUpdatePathAllowed(rel) || rel === 'server.js' || rel === 'server/update.js' || rel.startsWith('server/')) {
        throw new Error('Изтриването на този път е забранено: ' + value);
      }
      const key = rel.toLowerCase();
      if (deletes.has(key) || expected.has(key)) throw new Error('Конфликт или дублиране при изтриване: ' + rel);
      deletes.add(key);
    }
    return { manifest, files: actual, deleteList: Array.from(deletes, key => deleteList.find(value => String(value).toLowerCase() === key)) };
  }

  function safeDestination(rel) {
    const destination = path.resolve(ROOT_DIR, ...rel.split('/'));
    const relative = path.relative(path.resolve(ROOT_DIR), destination);
    if (!relative || relative === '..' || relative.startsWith('..' + path.sep) || path.isAbsolute(relative)) {
      throw new Error('Небезопасен път за запис: ' + rel);
    }
    let cursor = path.resolve(ROOT_DIR);
    const parts = relative.split(path.sep);
    for (const part of parts.slice(0, -1)) {
      cursor = path.join(cursor, part);
      if (!fs.existsSync(cursor)) continue;
      const st = fs.lstatSync(cursor);
      if (st.isSymbolicLink() || !st.isDirectory()) throw new Error('Небезопасна папка за запис: ' + rel);
    }
    if (fs.existsSync(destination) && fs.lstatSync(destination).isSymbolicLink()) {
      throw new Error('Замяна на символна връзка е забранена: ' + rel);
    }
    return destination;
  }

  function applyProgramUpdate(zipBuffer) {
    const tmpRoot = path.join(os.tmpdir(), 'dist-update-' + Date.now() + '-' + crypto.randomBytes(6).toString('hex'));
    const zipPath = path.join(tmpRoot, 'update.zip');
    const extractDir = path.join(tmpRoot, 'extracted');
    const backupDir = path.join(DATA_DIR, 'update-backups', new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19));
    const applied = [];
    const deleted = [];
    const touched = new Map();
    let restartRequired = false;
    try {
      const zipEntries = inspectZipArchive(zipBuffer);
      fs.mkdirSync(extractDir, { recursive: true });
      fs.writeFileSync(zipPath, zipBuffer, { flag: 'wx' });
      extractZipToDir(zipPath, extractDir);
      const root = findExtractRoot(extractDir);
      const extracted = walkFiles(root, root);
      const verified = parseAndVerifyManifest(root, extracted, zipEntries);
      const manifest = verified.manifest;
      const files = verified.files;
      const toDelete = verified.deleteList;
      fs.mkdirSync(backupDir, { recursive: true });

      function preserveOriginal(rel, destination) {
        if (touched.has(rel)) return;
        if (fs.existsSync(destination)) {
          const st = fs.lstatSync(destination);
          if (!st.isFile() || st.isSymbolicLink()) throw new Error('Целта не е обикновен файл: ' + rel);
          const backup = path.join(backupDir, ...rel.split('/'));
          fs.mkdirSync(path.dirname(backup), { recursive: true });
          fs.copyFileSync(destination, backup);
          touched.set(rel, { existed: true, backup });
        } else touched.set(rel, { existed: false });
      }

      try {
        for (const file of files) {
          const destination = safeDestination(file.rel);
          preserveOriginal(file.rel, destination);
          fs.mkdirSync(path.dirname(destination), { recursive: true });
          fs.copyFileSync(file.full, destination);
          applied.push(file.rel);
          if (file.rel === 'server.js' || file.rel.startsWith('server/')) restartRequired = true;
        }
        for (const rel of toDelete) {
          const destination = safeDestination(rel);
          if (!fs.existsSync(destination)) continue;
          preserveOriginal(rel, destination);
          fs.unlinkSync(destination);
          deleted.push(rel);
        }
      } catch (applyError) {
        const rollbackErrors = [];
        for (const [rel, original] of Array.from(touched.entries()).reverse()) {
          try {
            const destination = safeDestination(rel);
            if (original.existed) {
              fs.mkdirSync(path.dirname(destination), { recursive: true });
              fs.copyFileSync(original.backup, destination);
            } else if (fs.existsSync(destination)) fs.unlinkSync(destination);
          } catch (rollbackError) { rollbackErrors.push(rel + ': ' + (rollbackError.message || rollbackError)); }
        }
        if (rollbackErrors.length) throw new Error('Неуспешно обновление: ' + applyError.message + '. И rollback има грешки: ' + rollbackErrors.join('; '));
        throw new Error('Обновлението е отменено и старите файлове са възстановени: ' + (applyError.message || applyError));
      }

      try { computeUiVersion(); } catch (_) {}
      return {
        ok: true,
        version: manifest.version,
        applied,
        deleted,
        skipped: [],
        backupDir: path.relative(ROOT_DIR, backupDir).replace(/\\/g, '/'),
        restartRequired,
        uiVersion: getUiVersion()
      };
    } finally {
      try { fs.rmSync(tmpRoot, { recursive: true, force: true }); } catch (_) {}
    }
  }

  return {
    UPDATE_MAX_BYTES, UPDATE_ALLOWED_EXACT, UPDATE_ALLOWED_PREFIXES, UPDATE_FORBIDDEN_PREFIXES,
    normalizeUpdateRelPath, isUpdatePathAllowed, inspectZipArchive, extractZipToDir,
    walkFiles, findExtractRoot, applyProgramUpdate
  };
}

module.exports = { createUpdateModule };
