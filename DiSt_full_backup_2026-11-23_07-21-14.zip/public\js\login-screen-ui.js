/**
 * login-screen-ui.js — app.js modularization
 * Инфо панел и фон преди вход.
 * Load AFTER app.js.
 */

// ---- Информационен панел преди вход ----
if (typeof loginInfoPanelConfig !== 'object' || !loginInfoPanelConfig) {
  loginInfoPanelConfig = { enabled: false, content: '' };
}
if (typeof loginStateResolved !== 'boolean') {
  loginStateResolved = false;
}

function renderLoginInfoPanel() {
  const panel = document.getElementById('loginInfoPanel');
  const contentEl = document.getElementById('loginInfoPanelContent');
  const roleGate = document.getElementById('roleGate');
  const cfg = loginInfoPanelConfig || { enabled: false, content: '' };
  const shouldShow = !!(loginStateResolved && panel && roleGate && roleGate.style.display !== 'none' && !currentRole && cfg.enabled && String(cfg.content || '').trim());
  if (contentEl) contentEl.textContent = cfg.content || '';
  if (panel) panel.style.display = shouldShow ? 'block' : 'none';
}

async function loadLoginInfoPanel() {
  try {
    const response = await fetch('/api/login-info-panel', { cache: 'no-store', credentials: 'same-origin' });
    if (!response.ok) throw new Error('HTTP ' + response.status);
    const data = await response.json();
    loginInfoPanelConfig = { enabled: data.enabled === true, content: String(data.content || '').slice(0, 5000) };
  } catch (e) {
    console.warn('Информационният панел не може да бъде зареден:', e);
    loginInfoPanelConfig = { enabled: false, content: '' };
  }
  renderLoginInfoPanel();
}

async function loadLoginInfoPanelSettings() {
  const status = document.getElementById('loginInfoPanelStatus');
  try {
    const response = await authFetch('/api/login-info-panel', { cache: 'no-store' });
    if (!response.ok) throw new Error('HTTP ' + response.status);
    const data = await response.json();
    const enabled = document.getElementById('loginInfoPanelEnabled');
    const input = document.getElementById('loginInfoPanelInput');
    if (enabled) enabled.checked = data.enabled === true;
    if (input) input.value = String(data.content || '').slice(0, 5000);
    if (status) status.textContent = '';
  } catch (e) {
    if (status) status.textContent = '❌ Неуспешно зареждане на настройките.';
    console.warn('Настройки на информационния панел:', e);
  }
}

async function saveLoginInfoPanelSettings() {
  const button = document.getElementById('btnSaveLoginInfoPanel');
  const status = document.getElementById('loginInfoPanelStatus');
  const enabled = !!(document.getElementById('loginInfoPanelEnabled') || {}).checked;
  const content = String((document.getElementById('loginInfoPanelInput') || {}).value || '');
  if (content.length > 5000) { if (status) status.textContent = '❌ Максимум 5000 символа.'; return; }
  if (button) button.disabled = true;
  if (status) status.textContent = 'Записване...';
  try {
    const response = await authFetch('/api/login-info-panel', {
      method: 'PUT', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ enabled, content })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok || !data.ok) throw new Error(data.error || ('HTTP ' + response.status));
    loginInfoPanelConfig = { enabled: data.enabled === true, content: String(data.content || '') };
    renderLoginInfoPanel();
    if (status) status.textContent = '✅ Настройките са запазени.';
  } catch (e) {
    if (status) status.textContent = '❌ ' + (e.message || 'Грешка при запис.');
  } finally {
    if (button) button.disabled = false;
  }
}

const btnSaveLoginInfoPanel = document.getElementById('btnSaveLoginInfoPanel');
if (btnSaveLoginInfoPanel) btnSaveLoginInfoPanel.addEventListener('click', saveLoginInfoPanelSettings);

// ---- ФУНКЦИИ ЗА ФОН НА ВХОДЯЩ ЕКРАН ----
async function saveLoginBackground(file) {
  if (!file) {
    throw new Error('Моля, изберете файл.');
  }

  if (file.size > 500 * 1024) throw new Error('Файлът е твърде голям. Максимален размер: 500 KB.');
  const allowedTypes = ['image/png','image/jpeg','image/gif','image/webp','image/avif','image/bmp'];
  if (file.type && !allowedTypes.includes(file.type.toLowerCase())) throw new Error('Форматът не се поддържа. Използвайте PNG, JPEG, GIF, WebP, AVIF или BMP.');

  try {
    const base64Data = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(new Error('Файлът не може да бъде прочетен.'));
      reader.onload = () => resolve(reader.result);
      reader.readAsDataURL(file);
    });
    await S.set(LOGIN_BACKGROUND_KEY, base64Data);
    await loadLoginBackground();
    toast('✅ Фоновата снимка е качена на сървъра и приложена.');
  } catch (e) {
    console.error('Грешка при запазване на фонова снимка:', e);
    throw e;
  }
}

async function loadLoginBackground() {
  try {
    // Лек /meta + binary image URL (браузърът кешира по ETag)
    const res = await fetch('/api/login-background/meta', { cache: 'no-store' });
    if (res.status === 404) {
      removeLoginBackground();
      hideCurrentBackgroundPreview();
      return;
    }
    if (!res.ok) {
      // Fallback към legacy JSON endpoint
      const leg = await fetch('/api/login-background', { cache: 'no-store' });
      if (leg.status === 404) { removeLoginBackground(); hideCurrentBackgroundPreview(); return; }
      if (!leg.ok) return;
      const data = await leg.json();
      if (data && data.value) {
        applyLoginBackground(data.value);
        showCurrentBackgroundPreview(data.value);
      } else {
        removeLoginBackground();
        hideCurrentBackgroundPreview();
      }
      return;
    }
    const data = await res.json();
    if (data && data.enabled && data.url) {
      const imageUrl = new URL(data.url, location.href).href;
      applyLoginBackground(imageUrl);
      showCurrentBackgroundPreview(imageUrl);
    } else {
      removeLoginBackground();
      hideCurrentBackgroundPreview();
    }
  } catch (e) {
    console.error('Грешка при зареждане на фонова снимка:', e);
  }
}

function applyLoginBackground(base64Data) {
  const roleGate = document.getElementById('roleGate');
  if (roleGate) {
    roleGate.style.backgroundImage = `url(${base64Data})`;
    roleGate.style.backgroundSize = 'cover';
    roleGate.style.backgroundPosition = 'center';
    roleGate.style.backgroundRepeat = 'no-repeat';
  } else {
    console.error('roleGate елементът не е намерен');
  }
}

function removeLoginBackground() {
  const roleGate = document.getElementById('roleGate');
  if (roleGate) {
    roleGate.style.backgroundImage = '';
  }
}

function showCurrentBackgroundPreview(base64Data) {
  const preview = document.getElementById('currentBackgroundPreview');
  const image = document.getElementById('currentBackgroundImage');
  if (preview && image) {
    preview.style.display = 'block';
    image.src = base64Data;
  }
}

function hideCurrentBackgroundPreview() {
  const preview = document.getElementById('currentBackgroundPreview');
  if (preview) {
    preview.style.display = 'none';
  }
}

async function deleteLoginBackground() {
  try {
    await S.delete(LOGIN_BACKGROUND_KEY);
    toast('✅ Фоновата снимка е изтрита от сървъра.');
    removeLoginBackground();
    hideCurrentBackgroundPreview();
  } catch (e) {
    console.error('Грешка при премахване на фонова снимка:', e);
    toast('❌ Грешка при премахване на фонова снимка.');
  }
}

// Event listeners за управление на фонова снимка
document.getElementById('btnSaveLoginBackground').addEventListener('click', function() {
  const fileInput = document.getElementById('loginBackgroundInput');
  const file = fileInput.files[0];
  const statusEl = document.getElementById('loginBackgroundStatus');
  
  if (!file) {
    toast('❌ Моля, изберете файл.');
    return;
  }
  
  statusEl.textContent = 'Качване на сървъра...';
  saveLoginBackground(file).then(() => {
    statusEl.textContent = '';
    fileInput.value = ''; // Изчистване на input след успешен запис
  }).catch((e) => {
    statusEl.textContent = e.message || 'Грешка при качване на фоновата снимка.';
  });
});

document.getElementById('btnRemoveLoginBackground').addEventListener('click', async function() {
  if (!(await confirmDialog('Сигурни ли сте, че искате да премахнете фонова снимка?'))) return;
  await deleteLoginBackground();
});


// ============================================================
//  ТЪРСЕНЕ, ВСИЧКИ ЗАЯВКИ, КОЛОНИ, ПАГИНАЦИЯ И XLSX

/* window exports */
try {
  if (typeof applyLoginBackground==='function') window.applyLoginBackground=applyLoginBackground;
  if (typeof deleteLoginBackground==='function') window.deleteLoginBackground=deleteLoginBackground;
  if (typeof hideCurrentBackgroundPreview==='function') window.hideCurrentBackgroundPreview=hideCurrentBackgroundPreview;
  if (typeof loadLoginBackground==='function') window.loadLoginBackground=loadLoginBackground;
  if (typeof loadLoginInfoPanel==='function') window.loadLoginInfoPanel=loadLoginInfoPanel;
  if (typeof loadLoginInfoPanelSettings==='function') window.loadLoginInfoPanelSettings=loadLoginInfoPanelSettings;
  if (typeof removeLoginBackground==='function') window.removeLoginBackground=removeLoginBackground;
  if (typeof renderLoginInfoPanel==='function') window.renderLoginInfoPanel=renderLoginInfoPanel;
  if (typeof saveLoginBackground==='function') window.saveLoginBackground=saveLoginBackground;
  if (typeof saveLoginInfoPanelSettings==='function') window.saveLoginInfoPanelSettings=saveLoginInfoPanelSettings;
  if (typeof showCurrentBackgroundPreview==='function') window.showCurrentBackgroundPreview=showCurrentBackgroundPreview;
} catch(_){}
