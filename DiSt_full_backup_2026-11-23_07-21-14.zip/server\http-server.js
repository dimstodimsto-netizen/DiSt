'use strict';

/** Builds the HTTP server and dispatches each request to its route module. */
function createHttpServer(deps) {
  const {
    http, URL, addCORS, applySecurityHeaders, serveStatic,
    handleRecordsRoute, handleLoginBackgroundRoute,
    handleMaintenanceMaterialsRoute, handleRequiredMaterialsRoute,
    handleMaterialsReportRoute, handleAuthRoute, handleSystemRoute,
    handleAdminRoute, handleKvRoute,
    handleServerInfoRoute, handleVerificationGate, handleSettingsRoute
  } = deps;

  return http.createServer(async (req, res) => {
    res._origin = req.headers['origin'] || '';
    try {
      if (req.method === 'OPTIONS') {
        addCORS(res);
        applySecurityHeaders(res);
        res.writeHead(204);
        res.end();
        return;
      }

      const parsed = new URL(req.url, 'http://localhost');
      const pathname = decodeURIComponent(parsed.pathname);

      if (await handleRecordsRoute(req, res, parsed, pathname)) return;
      if (handleLoginBackgroundRoute(req, res, pathname)) return;
      if (await handleMaintenanceMaterialsRoute(req, res, parsed, pathname)) return;
      if (await handleRequiredMaterialsRoute(req, res, parsed, pathname)) return;
      if (handleMaterialsReportRoute(req, res, parsed, pathname)) return;
      if (await handleAuthRoute(req, res, parsed, pathname)) return;
      if (await handleSystemRoute(req, res, parsed, pathname)) return;
      if (await handleAdminRoute(req, res, parsed, pathname)) return;

      if (handleServerInfoRoute(req, res, pathname)) return;
      if (handleVerificationGate(res, pathname)) return;
      if (await handleKvRoute(req, res, parsed, pathname)) return;
      if (await handleSettingsRoute(req, res, pathname)) return;

      if (req.method === 'GET' || req.method === 'HEAD') {
        serveStatic(req, res, pathname);
        return;
      }

      applySecurityHeaders(res);
      res.writeHead(405);
      res.end('Method not allowed');
    } catch (err) {
      console.error('Грешка при обработка на заявка:', err);
      if (!res.headersSent) {
        res.writeHead(500);
        res.end('Server error');
      }
    }
  });
}

module.exports = { createHttpServer };
