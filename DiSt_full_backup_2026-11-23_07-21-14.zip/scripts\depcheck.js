#!/usr/bin/env node
'use strict';

/**
 * DiSt dependency audit (no npm packages required).
 * Checks literal CommonJS/ESM references in the application source tree.
 * Usage: node scripts/depcheck.js [--json]
 */
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');

const ROOT = path.resolve(__dirname, '..');
const SOURCE_DIRS = ['server', 'scripts', 'public/js'];
const ROOT_FILES = ['server.js'];
const BUILTINS = new Set(Module.builtinModules.flatMap(name => [name, name.replace(/^node:/, ''), 'node:' + name.replace(/^node:/, '')]));
const references = [];
const errors = [];
const warnings = [];
const sourceFiles = [];

function walk(dir) {
  if (!fs.existsSync(dir)) return;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isSymbolicLink()) { warnings.push('Пропусната символна връзка: ' + path.relative(ROOT, full)); continue; }
    if (entry.isDirectory()) {
      if (!['node_modules', '.git', 'logs'].includes(entry.name.toLowerCase())) walk(full);
    } else if (entry.isFile() && entry.name.toLowerCase().endsWith('.js')) sourceFiles.push(full);
  }
}
for (const rel of SOURCE_DIRS) walk(path.join(ROOT, rel));
for (const rel of ROOT_FILES) if (fs.existsSync(path.join(ROOT, rel))) sourceFiles.push(path.join(ROOT, rel));

function maskComments(source) {
  // Keep string/template contents intact while blanking JS comments.
  let out = '', i = 0, state = 'code';
  while (i < source.length) {
    const c = source[i], n = source[i + 1];
    if (state === 'code') {
      if (c === '/' && n === '/') { out += '  '; i += 2; state = 'line'; continue; }
      if (c === '/' && n === '*') { out += '  '; i += 2; state = 'block'; continue; }
      if (c === "'") state = 'single'; else if (c === '"') state = 'double'; else if (c === '`') state = 'template';
      out += c; i++; continue;
    }
    if (state === 'line') { if (c === '\n') { out += '\n'; state = 'code'; } else out += ' '; i++; continue; }
    if (state === 'block') { if (c === '*' && n === '/') { out += '  '; i += 2; state = 'code'; } else { out += c === '\n' ? '\n' : ' '; i++; } continue; }
    const end = state === 'single' ? "'" : state === 'double' ? '"' : '`';
    out += c; i++;
    if (c === '\\' && i < source.length) { out += source[i++]; continue; }
    if (c === end) state = 'code';
  }
  return out;
}
function resolveLocal(fromFile, request) {
  const base = path.resolve(path.dirname(fromFile), request);
  const candidates = [base, base + '.js', base + '.cjs', base + '.mjs', base + '.json', path.join(base, 'index.js')];
  return candidates.find(candidate => {
    try { return fs.statSync(candidate).isFile(); } catch (_) { return false; }
  }) || null;
}
for (const file of sourceFiles) {
  let source;
  try { source = maskComments(fs.readFileSync(file, 'utf8')); }
  catch (e) { errors.push('Не може да се прочете ' + path.relative(ROOT, file) + ': ' + e.message); continue; }
  const patterns = [
    /\brequire\s*\(\s*(['"])([^'"]+)\1\s*\)/g,
    /\bimport\s*\(\s*(['"])([^'"]+)\1\s*\)/g,
    /\bfrom\s*(['"])([^'"]+)\1/g
  ];
  for (const re of patterns) {
    let match;
    while ((match = re.exec(source))) references.push({ file, request: match[2] });
  }
}

const external = new Set();
for (const ref of references) {
  const request = ref.request;
  if (request.startsWith('.') || request.startsWith('/')) {
    if (!resolveLocal(ref.file, request)) errors.push('Липсва локален модул: ' + path.relative(ROOT, ref.file) + ' -> ' + request);
    continue;
  }
  if (BUILTINS.has(request) || request.startsWith('node:')) continue;
  external.add(request.split('/')[0].startsWith('@') ? request.split('/').slice(0, 2).join('/') : request.split('/')[0]);
}

const packagePath = path.join(ROOT, 'package.json');
if (fs.existsSync(packagePath)) {
  try {
    const pkg = JSON.parse(fs.readFileSync(packagePath, 'utf8'));
    const declared = Object.assign({}, pkg.dependencies, pkg.optionalDependencies, pkg.peerDependencies);
    for (const name of external) if (!declared[name]) errors.push('Външен модул без декларация в package.json: ' + name);
    for (const name of Object.keys(declared)) if (!external.has(name)) warnings.push('Декларирана, но неизползвана зависимост: ' + name);
  } catch (e) { errors.push('Невалиден package.json: ' + e.message); }
} else if (external.size) {
  errors.push('Открити са външни npm модули, но липсва package.json: ' + Array.from(external).join(', '));
}

const result = {
  ok: errors.length === 0,
  scannedFiles: sourceFiles.length,
  references: references.length,
  externalPackages: Array.from(external).sort(),
  errors,
  warnings,
  note: 'Проверяват се статични, буквени require/import препратки. Динамично конструирани имена не могат да бъдат доказани статично.'
};
if (process.argv.includes('--json')) console.log(JSON.stringify(result, null, 2));
else {
  console.log('DiSt dependency check');
  console.log('---------------------');
  console.log('Сканирани JS файлове: ' + result.scannedFiles);
  console.log('Открити препратки:    ' + result.references);
  console.log('Външни npm пакети:    ' + (result.externalPackages.join(', ') || 'няма'));
  for (const item of warnings) console.log('WARN: ' + item);
  for (const item of errors) console.error('ERROR: ' + item);
  console.log('RESULT: ' + (result.ok ? 'OK' : 'FAILED'));
}
process.exitCode = result.ok ? 0 : 1;
