/**
 * Мързеливо зареждане на SheetJS (xlsx) — само при Excel импорт/експорт.
 * Не се тегли с началната страница (~952 KB).
 */
(function (global) {
  'use strict';
  var loading = null;

  function ensureXlsxLoaded() {
    if (typeof global.XLSX !== 'undefined') return Promise.resolve(global.XLSX);
    if (loading) return loading;
    loading = new Promise(function (resolve, reject) {
      var s = document.createElement('script');
      var v = encodeURIComponent(global.__UI_VERSION__ || '');
      s.src = '/lib/xlsx.full.min.js' + (v ? ('?v=' + v) : '');
      s.async = true;
      s.onload = function () {
        if (typeof global.XLSX === 'undefined') {
          loading = null;
          reject(new Error('XLSX не се зареди'));
        } else resolve(global.XLSX);
      };
      s.onerror = function () {
        loading = null;
        reject(new Error('Неуспешно зареждане на Excel библиотеката'));
      };
      document.head.appendChild(s);
    });
    return loading;
  }

  function exportWithXlsx(fn) {
    return ensureXlsxLoaded().then(function () {
      return fn();
    }).catch(function (e) {
      if (typeof global.toast === 'function') {
        global.toast('❌ ' + (e && e.message ? e.message : e), 'error');
      } else {
        console.error(e);
      }
      return null;
    });
  }

  global.ensureXlsxLoaded = ensureXlsxLoaded;
  global.exportWithXlsx = exportWithXlsx;
})(typeof window !== 'undefined' ? window : this);
