/**
 * materials-excel-import-ui.js — app.js modularization phase 3
 * Импорт/шаблон Excel за санитарни и канцеларски материали.
 * Load AFTER app.js.
 */

// ============================================================
//  ИМПОРТ НА НАЛИЧНИ МАТЕРИАЛИ ОТ EXCEL
// ============================================================
function normalizeMaterialHeader(h) {
  return String(h == null ? '' : h).trim().toLowerCase()
    .replace(/\s+/g, ' ')
    .replace(/[.:]/g, '');
}

function detectMaterialColumns(headerRow) {
  let nameIdx = -1;
  let merkaIdx = -1;
  let codeIdx = -1;
  (headerRow || []).forEach((cell, i) => {
    const h = normalizeMaterialHeader(cell);
    if (!h) return;
    if (codeIdx < 0 && (
      h === 'код' || h === 'code' || h === 'ref' || h === 'реф' || h === 'референция' ||
      h === 'реф. код' || h === 'реф код' || h === 'sku' || h === 'артикул' ||
      h.includes('код') || h.includes('code') || h.includes('артикул')
    )) codeIdx = i;
    if (nameIdx < 0 && (
      h === 'материал' || h === 'material' || h === 'name' || h === 'име' ||
      h === 'наименование' || h === 'вид' || h === 'вид материал' ||
      h.includes('материал') || h.includes('наимен')
    )) nameIdx = i;
    if (merkaIdx < 0 && (
      h === 'мярка' || h === 'мерка' || h === 'merka' || h === 'unit' ||
      h === 'единица' || h === 'единица мярка' || h === 'м-ка' ||
      h.includes('мярк') || h.includes('мерк') || h.includes('unit')
    )) merkaIdx = i;
  });
  return { nameIdx, merkaIdx, codeIdx };
}

function parseMaterialsFromSheetRows(rows) {
  if (!rows || !rows.length) return [];
  const first = rows[0] || [];
  const { nameIdx: detName, merkaIdx: detMerka, codeIdx: detCode } = detectMaterialColumns(first);
  const hasHeader = detName >= 0 || detCode >= 0;
  let nameIdx, merkaIdx, codeIdx;
  if (hasHeader) {
    nameIdx = detName >= 0 ? detName : (detCode === 0 ? 1 : 0);
    merkaIdx = detMerka >= 0 ? detMerka : -1;
    codeIdx = detCode >= 0 ? detCode : -1;
  } else {
    if (first.length >= 3) { codeIdx = 0; nameIdx = 1; merkaIdx = 2; }
    else { codeIdx = -1; nameIdx = 0; merkaIdx = 1; }
  }
  const startRow = hasHeader ? 1 : 0;
  const out = [];
  const seen = new Set();
  for (let i = startRow; i < rows.length; i++) {
    const row = rows[i] || [];
    const name = String(row[nameIdx] == null ? '' : row[nameIdx]).trim();
    if (!name) continue;
    const nLow = name.toLowerCase();
    if (nLow === 'материал' || nLow === 'material' || nLow === 'наименование' || nLow === 'код' || nLow === 'code') continue;
    const merka = merkaIdx >= 0 ? String(row[merkaIdx] == null ? '' : row[merkaIdx]).trim() : '';
    const code = codeIdx >= 0 ? String(row[codeIdx] == null ? '' : row[codeIdx]).trim() : '';
    const key = (code ? ('c:' + code.toLowerCase()) : '') + '\u001f' + name.toLowerCase() + '\u001f' + merka.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({ code, name, merka });
  }
  return out;
}

function readMaterialsFromExcelFile(file) {
  return ensureXlsxLoaded().then(function () {
    return new Promise(function (resolve, reject) {
      if (!file) { reject(new Error('Няма избран файл.')); return; }
      const reader = new FileReader();
      reader.onload = function (e) {
        try {
          const data = new Uint8Array(e.target.result);
          const wb = XLSX.read(data, { type: 'array' });
          const sheetName = wb.SheetNames[0];
          if (!sheetName) { reject(new Error('Файлът няма листове.')); return; }
          const sheet = wb.Sheets[sheetName];
          const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '', raw: false });
          resolve(parseMaterialsFromSheetRows(rows));
        } catch (err) { reject(err); }
      };
      reader.onerror = function () { reject(new Error('Грешка при четене на файла.')); };
      reader.readAsArrayBuffer(file);
    });
  });
}

function materialKey(m) {
  const code = String(m.code || '').trim().toLowerCase();
  const name = String(m.name || '').trim().toLowerCase();
  const merka = String(m.merka || '').trim().toLowerCase();
  if (code) return 'c:' + code;
  return name + '\u001f' + merka;
}

function mergeMaterialsLists(existing, incoming) {
  const list = Array.isArray(existing) ? existing.slice() : [];
  const keys = new Set(list.map(materialKey));
  let added = 0;
  let skipped = 0;
  for (const m of incoming) {
    if (!m || !String(m.name || '').trim()) continue;
    const k = materialKey(m);
    if (keys.has(k)) {
      skipped++;
      continue;
    }
    keys.add(k);
    list.push({
      code: String(m.code || '').trim(),
      name: String(m.name).trim(),
      merka: String(m.merka || '').trim()
    });
    added++;
  }
  return { list, added, skipped };
}

function downloadMaterialsTemplate(fileName) {
  return exportWithXlsx(async function () {
  if (typeof XLSX === 'undefined') {
    toast('❌ Библиотеката за Excel не е заредена.');
    return;
  }
  const ws = XLSX.utils.aoa_to_sheet([
    ['Код', 'Материал', 'Мярка'],
    ['S001', 'Тоалетна хартия', 'бр.'],
    ['S002', 'Сапун течен', 'л']
  ]);
  ws['!cols'] = [{ wch: 12 }, { wch: 28 }, { wch: 10 }];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Материали');
  XLSX.writeFile(wb, fileName || 'shablon_materiali.xlsx');

  });
}

async function importMaterialsFromExcel(kind, file) {
  // kind: 'sanitary' | 'office'
  try {
    const imported = await readMaterialsFromExcelFile(file);
    if (!imported.length) {
      toast('❌ Във файла не са намерени материали. Очакват се колони „Код“, „Материал“ и „Мярка“.');
      return;
    }
    const existing = kind === 'sanitary'
      ? await getAvailableSanitaryMaterials()
      : await getAvailableOfficeMaterials();
    const { list, added, skipped } = mergeMaterialsLists(existing, imported);
    if (added === 0) {
      toast('ℹ️ Няма нови материали за добавяне (' + skipped + ' дубликата).');
      return;
    }
    if (kind === 'sanitary') {
      await saveAvailableSanitaryMaterials(list);
      await renderSanitaryMaterialsList();
    } else {
      await saveAvailableOfficeMaterials(list);
      await renderOfficeMaterialsList();
    }
    try { await populateMaterialSelects(); } catch (_) {}
    toast('✅ Импортирани: ' + added + (skipped ? ', пропуснати дубликати: ' + skipped : '') + '.');
  } catch (e) {
    console.error(e);
    toast('❌ Грешка при импорт: ' + (e.message || e));
  }
}

(function wireMaterialsExcelImport() {
  const map = [
    {
      kind: 'sanitary',
      btnImport: 'btnImportSanitaryMaterials',
      fileInput: 'fileImportSanitaryMaterials',
      btnTemplate: 'btnTemplateSanitaryMaterials',
      templateName: 'shablon_sanitarni_materiali.xlsx'
    },
    {
      kind: 'office',
      btnImport: 'btnImportOfficeMaterials',
      fileInput: 'fileImportOfficeMaterials',
      btnTemplate: 'btnTemplateOfficeMaterials',
      templateName: 'shablon_kancelarski_materiali.xlsx'
    }
  ];
  map.forEach(cfg => {
    const btn = document.getElementById(cfg.btnImport);
    const input = document.getElementById(cfg.fileInput);
    const tpl = document.getElementById(cfg.btnTemplate);
    if (btn && input) {
      btn.addEventListener('click', () => {
        input.value = '';
        input.click();
      });
      input.addEventListener('change', async () => {
        const file = input.files && input.files[0];
        if (!file) return;
        btn.disabled = true;
        const prev = btn.textContent;
        btn.textContent = 'Импорт...';
        try {
          await importMaterialsFromExcel(cfg.kind, file);
        } finally {
          btn.disabled = false;
          btn.textContent = prev;
          input.value = '';
        }
      });
    }
    if (tpl) {
      tpl.addEventListener('click', () => downloadMaterialsTemplate(cfg.templateName));
    }
  });
})();

/* window exports */
try {
  if (typeof detectMaterialColumns==='function') window.detectMaterialColumns=detectMaterialColumns;
  if (typeof downloadMaterialsTemplate==='function') window.downloadMaterialsTemplate=downloadMaterialsTemplate;
  if (typeof importMaterialsFromExcel==='function') window.importMaterialsFromExcel=importMaterialsFromExcel;
  if (typeof materialKey==='function') window.materialKey=materialKey;
  if (typeof mergeMaterialsLists==='function') window.mergeMaterialsLists=mergeMaterialsLists;
  if (typeof normalizeMaterialHeader==='function') window.normalizeMaterialHeader=normalizeMaterialHeader;
  if (typeof parseMaterialsFromSheetRows==='function') window.parseMaterialsFromSheetRows=parseMaterialsFromSheetRows;
  if (typeof readMaterialsFromExcelFile==='function') window.readMaterialsFromExcelFile=readMaterialsFromExcelFile;
} catch(_){}
