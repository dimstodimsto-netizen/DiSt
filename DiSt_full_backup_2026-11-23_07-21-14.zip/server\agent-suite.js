'use strict';

/**
 * agent-suite.js — read-only health checks for DiSt.
 * Triggers: manual, post-update, morning-login (stale report).
 * Does not modify business records (only stores report/history/config in KV).
 */
function createAgentSuite(deps) {
  const {
    db, kvGet, kvSet, writeSystemLog,
    getAllUsersServer, listActiveSessions, getRecordsIndexSafe, getLoginLockSnapshot,
    fs, path, ROOT_DIR, PUBLIC_DIR, DATA_DIR, DB_PATH,
    APP_VERSION, UI_VERSION, SERVER_STARTED_AT, PORT
  } = deps;

  const REPORT_KEY = 'system:agent:last-report';
  const HISTORY_KEY = 'system:agent:history';
  const CFG_KEY = 'system:agent:config';

  function getConfig() {
    const def = {
      runAfterUpdate: true,
      morningMaxAgeHours: 14,
      backupWarnHours: 26,
      backupFailHours: 48,
      diskWarnMb: 1024
    };
    try {
      const raw = kvGet(CFG_KEY);
      if (!raw) return Object.assign({}, def);
      const p = typeof raw === 'string' ? JSON.parse(raw) : raw;
      return Object.assign({}, def, p && typeof p === 'object' ? p : {});
    } catch (_) {
      return Object.assign({}, def);
    }
  }

  function ok(id, title, detail, advice) {
    return { id: id, title: title, status: 'ok', detail: detail || '', advice: advice || '' };
  }
  function warn(id, title, detail, advice) {
    return { id: id, title: title, status: 'warn', detail: detail || '', advice: advice || '' };
  }
  function fail(id, title, detail, advice) {
    return { id: id, title: title, status: 'fail', detail: detail || '', advice: advice || '' };
  }

  function checkUptime() {
    try {
      const started = Number(SERVER_STARTED_AT) || null;
      const upMin = started ? Math.floor((Date.now() - started) / 60000) : null;
      const detail = 'app=' + (APP_VERSION || '?') + ', ui=' + (UI_VERSION || '?') +
        ', port=' + (PORT || '?') + (upMin != null ? ', uptime=' + upMin + ' мин' : '');
      return ok('runtime', 'Сървър / версия', detail);
    } catch (e) {
      return warn('runtime', 'Сървър / версия', e.message || String(e));
    }
  }

  function checkPaths() {
    try {
      const need = [
        { name: 'ROOT', p: ROOT_DIR },
        { name: 'PUBLIC', p: PUBLIC_DIR },
        { name: 'DATA', p: DATA_DIR },
        { name: 'DB', p: DB_PATH }
      ];
      const missing = [];
      need.forEach(function (x) {
        if (!x.p || !fs.existsSync(x.p)) missing.push(x.name);
      });
      if (missing.length) {
        return fail('paths', 'Пътища на инсталацията', 'липсват: ' + missing.join(', '),
          'Проверете инсталацията / възстановете от бекъп.');
      }
      return ok('paths', 'Пътища на инсталацията', 'ROOT/PUBLIC/DATA/DB налични');
    } catch (e) {
      return fail('paths', 'Пътища на инсталацията', e.message || String(e));
    }
  }

  function checkDbIntegrity() {
    try {
      const row = db.prepare('PRAGMA integrity_check').get();
      const val = row && (row.integrity_check || row['integrity_check'] || Object.values(row)[0]);
      if (String(val).toLowerCase() === 'ok') return ok('db_integrity', 'База данни (integrity)', 'ok');
      return fail('db_integrity', 'База данни (integrity)', String(val),
        'Спрете сървъра и възстановете zayavki.db от проверен бекъп.');
    } catch (e) {
      return fail('db_integrity', 'База данни (integrity)', e.message || String(e));
    }
  }

  function checkWal() {
    try {
      const row = db.prepare('PRAGMA journal_mode').get();
      const mode = String((row && (row.journal_mode || Object.values(row)[0])) || '').toLowerCase();
      const walPath = String(DB_PATH || '') + '-wal';
      const shmPath = String(DB_PATH || '') + '-shm';
      const hasWal = fs.existsSync(walPath);
      const hasShm = fs.existsSync(shmPath);
      const detail = 'journal_mode=' + mode +
        (hasWal ? ', -wal наличен' : '') +
        (hasShm ? ', -shm наличен' : '');
      if (mode === 'wal') return ok('db_wal', 'SQLite WAL', detail);
      return warn('db_wal', 'SQLite WAL', detail,
        'Препоръка: PRAGMA journal_mode=WAL за по-добра паралелност.');
    } catch (e) {
      return warn('db_wal', 'SQLite WAL', e.message || String(e));
    }
  }

  function checkDbSize() {
    try {
      if (!DB_PATH || !fs.existsSync(DB_PATH)) {
        return fail('db_size', 'Размер на базата', 'файлът липсва');
      }
      const st = fs.statSync(DB_PATH);
      const mb = (st.size / (1024 * 1024)).toFixed(2);
      return ok('db_size', 'Размер на базата', mb + ' MB');
    } catch (e) {
      return warn('db_size', 'Размер на базата', e.message || String(e));
    }
  }

  function checkDisk() {
    try {
      const cfg = getConfig();
      const warnMb = Number(cfg.diskWarnMb) || 1024;
      const target = DATA_DIR || ROOT_DIR;
      if (!target || !fs.existsSync(target)) {
        return warn('disk', 'Свободно място', 'DATA_DIR недостъпен');
      }
      if (typeof fs.statfsSync === 'function') {
        const s = fs.statfsSync(target);
        const free = Number(s.bavail != null ? s.bavail : s.bfree) * Number(s.bsize || 0);
        const freeMb = Math.floor(free / (1024 * 1024));
        const detail = 'свободно ~' + freeMb + ' MB (' + target + ')';
        if (freeMb < Math.max(200, Math.floor(warnMb / 4))) {
          return fail('disk', 'Свободно място', detail, 'Освободете диск или преместете стари бекъпи.');
        }
        if (freeMb < warnMb) {
          return warn('disk', 'Свободно място', detail, 'Следете мястото за бекъпи и логове.');
        }
        return ok('disk', 'Свободно място', detail);
      }
      return ok('disk', 'Свободно място', 'statfs недостъпен на тази платформа — пропусната количествена проверка');
    } catch (e) {
      return warn('disk', 'Свободно място', e.message || String(e));
    }
  }

  function checkKv() {
    try {
      const row = db.prepare('SELECT COUNT(*) AS c FROM kv').get();
      const c = row && row.c != null ? row.c : 0;
      return ok('kv_read', 'KV хранилище', 'записи: ' + c);
    } catch (e) {
      return fail('kv_read', 'KV хранилище', e.message || String(e));
    }
  }

  function checkSystemLog() {
    try {
      const since = Date.now() - 24 * 3600 * 1000;
      let c = 0;
      let ec = 0;
      try {
        const rows = db.prepare(
          "SELECT level FROM kv WHERE key LIKE 'system:log:%' LIMIT 5000"
        ).all();
        // fallback if structure differs — count keys only
        c = rows ? rows.length : 0;
      } catch (_) {
        try {
          const row = db.prepare(
            "SELECT COUNT(*) AS c FROM kv WHERE key LIKE 'system:log:%'"
          ).get();
          c = row && row.c != null ? row.c : 0;
        } catch (__) {}
      }
      try {
        const raw = kvGet('system:log:recent') || kvGet('system:last-errors');
        if (raw && /error|crash/i.test(String(raw))) ec = 1;
      } catch (_) {}
      // Parse system log index if present
      try {
        const idx = kvGet('system:logs-index');
        if (idx) {
          const arr = typeof idx === 'string' ? JSON.parse(idx) : idx;
          if (Array.isArray(arr)) {
            c = arr.length;
            ec = arr.filter(function (x) {
              return x && (x.level === 'error' || x.level === 'crash');
            }).length;
          }
        }
      } catch (_) {}
      if (ec > 0) {
        return warn('system_log', 'Системен лог', 'индикации за грешки (прегледайте Лог)',
          'Отворете Администратор → Лог за детайли.');
      }
      return ok('system_log', 'Системен лог', 'записи (прибл.): ' + c);
    } catch (e) {
      return warn('system_log', 'Системен лог', e.message || String(e));
    }
  }

  function checkUsers() {
    try {
      const list = typeof getAllUsersServer === 'function' ? (getAllUsersServer() || []) : [];
      if (!list.length) {
        return warn('users', 'Потребители', 'няма записани потребители');
      }
      const byRole = {};
      list.forEach(function (u) {
        const r = (u && u.role) || '?';
        byRole[r] = (byRole[r] || 0) + 1;
      });
      const parts = Object.keys(byRole).map(function (k) { return k + '=' + byRole[k]; });
      const admins = byRole.admin || 0;
      if (admins < 1) {
        return fail('users', 'Потребители', 'общо ' + list.length + ' · няма admin',
          'Създайте поне един администратор.');
      }
      return ok('users', 'Потребители', 'общо ' + list.length + ' (' + parts.join(', ') + ')');
    } catch (e) {
      return fail('users', 'Потребители', e.message || String(e));
    }
  }

  function checkSessions() {
    try {
      const now = Date.now();
      const list = typeof listActiveSessions === 'function' ? (listActiveSessions(now) || []) : [];
      const online = list.filter(function (s) { return s && s.online; }).length;
      const admins = list.filter(function (s) { return s && s.role === 'admin'; }).length;
      const offline = list.length - online;
      const detail = 'общо ' + list.length + ', онлайн ' + online + ', офлайн ' + offline + ', admin сесии ' + admins;
      if (list.length > 50) {
        return warn('sessions', 'Активни сесии', detail, 'Много сесии — прегледайте „Активни сесии“ и изгонете стари.');
      }
      if (admins > 5) {
        return warn('sessions', 'Активни сесии', detail, 'Необичайно много admin сесии.');
      }
      return ok('sessions', 'Активни сесии', detail);
    } catch (e) {
      return fail('sessions', 'Активни сесии', e.message || String(e));
    }
  }

  function checkLoginLocks() {
    try {
      if (typeof getLoginLockSnapshot !== 'function') {
        return ok('login_locks', 'Заключени входове', 'снимката не е налична в тази версия');
      }
      const snap = getLoginLockSnapshot() || { locked: [], tracked: 0 };
      const locked = Array.isArray(snap.locked) ? snap.locked : [];
      if (!locked.length) {
        return ok('login_locks', 'Заключени входове', 'няма активни заключвания (следени опити: ' + (snap.tracked || 0) + ')');
      }
      const sample = locked.slice(0, 3).map(function (x) {
        return (x.key || '?') + ' (~' + (x.secondsLeft || 0) + 'с)';
      }).join('; ');
      return warn('login_locks', 'Заключени входове', locked.length + ' активни: ' + sample,
        'Възможни грешни пароли или опити за достъп — прегледайте логовете.');
    } catch (e) {
      return warn('login_locks', 'Заключени входове', e.message || String(e));
    }
  }

  function checkRecordsIndex() {
    try {
      const list = typeof getRecordsIndexSafe === 'function' ? (getRecordsIndexSafe() || []) : [];
      return ok('records_index', 'Индекс заявки (ремонт)', 'записи: ' + list.length);
    } catch (e) {
      return fail('records_index', 'Индекс заявки (ремонт)', e.message || String(e));
    }
  }

  function checkWhIndex() {
    try {
      let n = 0;
      try {
        const raw = kvGet('wh-index') || kvGet('warehouse-index') || kvGet('wh:index');
        if (raw) {
          const p = typeof raw === 'string' ? JSON.parse(raw) : raw;
          n = Array.isArray(p) ? p.length : (p && typeof p === 'object' ? Object.keys(p).length : 0);
        }
      } catch (_) {}
      return ok('wh_index', 'Индекс заявки (материали)', 'id-та: ' + n);
    } catch (e) {
      return warn('wh_index', 'Индекс заявки (материали)', e.message || String(e));
    }
  }

  function checkBackupFreshness() {
    try {
      const cfg = getConfig();
      const warnH = Number(cfg.backupWarnHours) || 26;
      const failH = Number(cfg.backupFailHours) || 48;
      let ts = null;
      let source = null;
      let zipName = null;
      const kvKeys = ['system:last-backup-at', 'settings:lastBackupAt', 'settings:lastSuccessfulBackup'];
      for (let i = 0; i < kvKeys.length; i++) {
        try {
          const val = kvGet(kvKeys[i]);
          const n = val != null && val !== '' ? Number(val) : NaN;
          if (isFinite(n) && n > 100000) { ts = n; source = 'kv:' + kvKeys[i]; break; }
        } catch (_) {}
      }
      try {
        const bdir = path.join(DATA_DIR, 'backups');
        if (fs.existsSync(bdir)) {
          let bestM = 0;
          let bestName = '';
          const names = fs.readdirSync(bdir);
          for (let i = 0; i < names.length; i++) {
            const name = names[i];
            if (!/^DiSt_full_backup_.*\.zip$/i.test(name)) continue;
            const st = fs.statSync(path.join(bdir, name));
            const m = st && st.mtimeMs ? st.mtimeMs : 0;
            if (m > bestM) { bestM = m; bestName = name; }
          }
          if (bestM > 0 && (ts == null || bestM > ts)) {
            ts = bestM;
            source = bestName;
            zipName = bestName;
          } else if (bestName) {
            zipName = bestName;
          }
        }
      } catch (_) {}

      if (!ts || !isFinite(ts)) {
        return warn('backup', 'Последен бекъп', 'няма backup файлове / timestamp',
          'Направете пълен бекъп от Отдалечено администриране.');
      }
      const ageH = Math.floor((Date.now() - ts) / 3600000);
      const when = new Date(ts).toLocaleString('bg-BG');
      const extra = source ? (' · ' + source) : '';
      if (ageH > failH) {
        return fail('backup', 'Последен бекъп', when + ' · преди ' + ageH + ' ч' + extra,
          'Направете нов бекъп възможно най-скоро.');
      }
      if (ageH > warnH) {
        return warn('backup', 'Последен бекъп', when + ' · преди ' + ageH + ' ч' + extra,
          'Препоръчително е дневен бекъп.');
      }
      return ok('backup', 'Последен бекъп', when + ' · преди ' + ageH + ' ч' + extra);
    } catch (e) {
      return warn('backup', 'Последен бекъп', e.message || String(e));
    }
  }

  function checkBackupSha() {
    try {
      const bdir = path.join(DATA_DIR, 'backups');
      if (!fs.existsSync(bdir)) {
        return warn('backup_sha', 'SHA-256 на бекъп', 'няма папка data/backups');
      }
      const names = fs.readdirSync(bdir).filter(function (n) {
        return /^DiSt_full_backup_.*\.zip$/i.test(n);
      });
      if (!names.length) {
        return warn('backup_sha', 'SHA-256 на бекъп', 'няма ZIP бекъпи',
          'Генерирайте пълен бекъп (създава и .sha256).');
      }
      names.sort();
      const latest = names[names.length - 1];
      const side = latest + '.sha256';
      if (fs.existsSync(path.join(bdir, side))) {
        return ok('backup_sha', 'SHA-256 на бекъп', 'sidecar за ' + latest);
      }
      return warn('backup_sha', 'SHA-256 на бекъп', 'липсва ' + side + ' за последния ZIP',
        'Нов бекъп ще създаде .sha256 файл.');
    } catch (e) {
      return warn('backup_sha', 'SHA-256 на бекъп', e.message || String(e));
    }
  }

  function checkCriticalStatic() {
    try {
      const files = [
        'public/index.html',
        'public/js/app.js',
        'public/js/agent-ui.js'
      ];
      const missing = [];
      files.forEach(function (rel) {
        const full = path.join(ROOT_DIR, rel);
        if (!fs.existsSync(full)) missing.push(rel);
      });
      if (missing.length) {
        return fail('static', 'Ключови UI файлове', 'липсват: ' + missing.join(', '),
          'Приложете отново последния ъпдейт или възстановете от бекъп.');
      }
      return ok('static', 'Ключови UI файлове', 'index/app/agent налични');
    } catch (e) {
      return warn('static', 'Ключови UI файлове', e.message || String(e));
    }
  }

  function summarize(checks) {
    let okN = 0, warnN = 0, failN = 0;
    checks.forEach(function (c) {
      if (c.status === 'ok') okN++;
      else if (c.status === 'fail') failN++;
      else warnN++;
    });
    return {
      overall: failN ? 'fail' : (warnN ? 'warn' : 'ok'),
      ok: okN,
      warn: warnN,
      fail: failN
    };
  }

  function headlineFrom(summary, issues) {
    if (!summary || summary.overall === 'ok') {
      return 'Всичко е наред — автоматичните проверки са успешни.';
    }
    if (summary.fail > 0) {
      const first = issues && issues[0];
      return 'Има проблем' + (first ? ': ' + first.title : '') +
        (summary.fail > 1 ? ' (+' + (summary.fail - 1) + ' още)' : '') + '.';
    }
    const first = issues && issues[0];
    const second = issues && issues[1];
    let h = 'Предупреждение';
    if (first) h += ': ' + first.title;
    if (second) h += '; ' + second.title;
    return h + '.';
  }

  function buildReport(checks, meta) {
    const summary = summarize(checks);
    const issues = checks.filter(function (c) { return c.status !== 'ok'; });
    const report = {
      generatedAt: Date.now(),
      phase: 2,
      summary: summary,
      checks: checks,
      issues: issues,
      headline: headlineFrom(summary, issues),
      meta: meta || {}
    };
    try {
      kvSet(REPORT_KEY, JSON.stringify(report));
    } catch (_) {}
    try {
      let hist = [];
      try {
        const raw = kvGet(HISTORY_KEY);
        if (raw) hist = typeof raw === 'string' ? JSON.parse(raw) : raw;
        if (!Array.isArray(hist)) hist = [];
      } catch (_) { hist = []; }
      hist.unshift({
        generatedAt: report.generatedAt,
        overall: summary.overall,
        ok: summary.ok,
        warn: summary.warn,
        fail: summary.fail,
        headline: report.headline,
        trigger: (meta && meta.trigger) || 'manual'
      });
      if (hist.length > 30) hist = hist.slice(0, 30);
      kvSet(HISTORY_KEY, JSON.stringify(hist));
    } catch (_) {}
    try {
      if (typeof writeSystemLog === 'function') {
        writeSystemLog(
          summary.fail ? 'warn' : 'info',
          'agent',
          'Agent suite: ' + summary.overall +
            ' (ok=' + summary.ok + ', warn=' + summary.warn + ', fail=' + summary.fail + ')' +
            (meta && meta.trigger ? ' [' + meta.trigger + ']' : ''),
          meta || {}
        );
      }
    } catch (_) {}
    return report;
  }

  function runSuite(meta) {
    const checks = [
      checkUptime(),
      checkPaths(),
      checkDbIntegrity(),
      checkWal(),
      checkDbSize(),
      checkDisk(),
      checkKv(),
      checkSystemLog(),
      checkUsers(),
      checkSessions(),
      checkLoginLocks(),
      checkRecordsIndex(),
      checkWhIndex(),
      checkBackupFreshness(),
      checkBackupSha(),
      checkCriticalStatic()
    ];
    return buildReport(checks, meta);
  }

  function getLastReport() {
    try {
      const raw = kvGet(REPORT_KEY);
      if (!raw) return null;
      return typeof raw === 'string' ? JSON.parse(raw) : raw;
    } catch (_) {
      return null;
    }
  }

  function getHistory(limit) {
    try {
      const raw = kvGet(HISTORY_KEY);
      if (!raw) return [];
      const p = typeof raw === 'string' ? JSON.parse(raw) : raw;
      const arr = Array.isArray(p) ? p : [];
      return arr.slice(0, Math.min(30, Math.max(1, limit || 15)));
    } catch (_) {
      return [];
    }
  }

  function shouldRunAfterUpdate() {
    try {
      return !!getConfig().runAfterUpdate;
    } catch (_) {
      return true;
    }
  }

  /** Morning / post-login digest: reuse report if fresh, otherwise re-run. */
  function getDigest(meta) {
    meta = meta || {};
    const cfg = getConfig();
    const maxAgeH = Number(cfg.morningMaxAgeHours);
    const ageLimit = isFinite(maxAgeH) && maxAgeH > 0 ? maxAgeH : 14;
    let report = getLastReport();
    let ran = false;
    const ageH = report && report.generatedAt
      ? (Date.now() - Number(report.generatedAt)) / 3600000
      : 9999;
    if (!report || ageH > ageLimit || meta.force) {
      report = runSuite({
        trigger: meta.trigger || 'morning-login',
        username: meta.username || null
      });
      ran = true;
    }
    const issues = (report.issues && report.issues.length)
      ? report.issues
      : (report.checks || []).filter(function (c) { return c.status !== 'ok'; });
    const top = issues.slice(0, 2);
    return {
      ok: true,
      ran: ran,
      report: report,
      headline: report.headline || headlineFrom(report.summary, issues),
      overall: (report.summary && report.summary.overall) || 'ok',
      issues: top,
      issueCount: issues.length,
      ageHours: Math.round(ageH * 10) / 10
    };
  }

  function clearHistory() {
    try {
      kvSet(HISTORY_KEY, JSON.stringify([]));
      return { ok: true };
    } catch (e) {
      return { ok: false, error: e.message || String(e) };
    }
  }

  return {
    runSuite: runSuite,
    getLastReport: getLastReport,
    getHistory: getHistory,
    getConfig: getConfig,
    shouldRunAfterUpdate: shouldRunAfterUpdate,
    getDigest: getDigest,
    clearHistory: clearHistory
  };
}

module.exports = { createAgentSuite };
