@echo off
setlocal
cd /d "%~dp0.."
echo.
echo === DiSt - SQLite integrity check ===
echo.
node "%~dp0VERIFY_DATABASE.js" "%~dp0..\data\zayavki.db"
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (echo RESULT: OK) else (echo RESULT: FAILED)
pause
exit /b %RC%
