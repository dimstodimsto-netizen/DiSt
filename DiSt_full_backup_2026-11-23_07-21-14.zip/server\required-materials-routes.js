'use strict';

const PREFIX = 'required-materials:';
const MAX_ROWS_PER_MONTH = 2000;
// Node.js clamps a setTimeout delay above 2^31-1 ms to 1 ms. Check long
// calendar waits in bounded chunks so early-month scheduling cannot spin.
const MAX_TIMEOUT_DELAY_MS = 2147483647;

function createRequiredMaterialsRoutes(deps) {
  const { requireAuth, sendJSON, readJsonFromRequest, kvGet, kvSet, kvListByPrefix, crypto } = deps;

  function currentMonth() {
    const now = new Date();
    return now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0');
  }
  function nextCalendarMonth(month) {
    const year = Number(month.slice(0, 4));
    const monthNumber = Number(month.slice(5, 7));
    const date = new Date(year, monthNumber, 1);
    return date.getFullYear() + '-' + String(date.getMonth() + 1).padStart(2, '0');
  }
  function validMonth(value) {
    return /^\d{4}-(0[1-9]|1[0-2])$/.test(String(value || ''));
  }
  function monthKey(month) { return PREFIX + month; }
  function readMonth(month) {
    try {
      const raw = kvGet(monthKey(month));
      if (raw == null) return null;
      const parsed = JSON.parse(raw);
      if (!parsed || !Array.isArray(parsed.items)) return null;
      return { month, createdAt: parsed.createdAt || '', items: parsed.items.filter(x => x && typeof x === 'object') };
    } catch (_) { return null; }
  }
  function ensureMonth(month) {
    let table = readMonth(month);
    if (!table) {
      table = { month, createdAt: new Date().toISOString(), items: [] };
      kvSet(monthKey(month), JSON.stringify(table));
    }
    return table;
  }
  function saveMonth(table) { kvSet(monthKey(table.month), JSON.stringify(table)); }
  function cleanText(value, limit) { return String(value == null ? '' : value).trim().slice(0, limit); }
  function monthIsFuture(month) { return month > currentMonth(); }
  function monthCanBeOpened(month) {
    return !monthIsFuture(month) || (month === nextCalendarMonth(currentMonth()) && !!readMonth(month));
  }
  function scheduleMonthCreation() {
    const now = new Date();
    const scheduledMonth = currentMonth();
    const next = new Date(now.getFullYear(), now.getMonth() + 1, 1, 0, 0, 1, 0);
    const delay = Math.max(1000, next.getTime() - now.getTime());
    const timer = setTimeout(() => {
      const monthNow = currentMonth();
      if (monthNow !== scheduledMonth) ensureMonth(monthNow);
      scheduleMonthCreation();
    }, Math.min(delay, MAX_TIMEOUT_DELAY_MS));
    if (timer && typeof timer.unref === 'function') timer.unref();
  }

  // Create this month's table on server start and again automatically at each month boundary.
  ensureMonth(currentMonth());
  scheduleMonthCreation();

  return async function handleRequiredMaterialsRoute(req, res, parsed, pathname) {
    if (pathname !== '/api/required-materials' && !pathname.startsWith('/api/required-materials/')) return false;
    const sess = requireAuth(req, res);
    if (!sess) return true;
    if (sess.role !== 'admin' && sess.role !== 'technician') {
      sendJSON(res, 403, { error: 'Менюто „Необходими материали“ е достъпно само за администратор и техник.' });
      return true;
    }

    if (pathname === '/api/required-materials/months' && req.method === 'GET') {
      ensureMonth(currentMonth());
      const months = kvListByPrefix(PREFIX).map(row => row.key.slice(PREFIX.length)).filter(validMonth).sort((a, b) => b.localeCompare(a));
      sendJSON(res, 200, { currentMonth: currentMonth(), months });
      return true;
    }

    if (pathname === '/api/required-materials' && req.method === 'GET') {
      const month = parsed.searchParams.get('month') || currentMonth();
      if (!validMonth(month)) { sendJSON(res, 400, { error: 'Невалиден месец.' }); return true; }
      if (!monthCanBeOpened(month)) { sendJSON(res, 400, { error: 'Може да се отваря само текущ или вече създадената таблица за следващия месец.' }); return true; }
      const table = ensureMonth(month);
      sendJSON(res, 200, table);
      return true;
    }

    if (pathname === '/api/required-materials/import' && req.method === 'POST') {
      const month = parsed.searchParams.get('month') || currentMonth();
      if (!validMonth(month) || !monthCanBeOpened(month)) { sendJSON(res, 400, { error: 'Месецът е невалиден или таблицата още не е създадена.' }); return true; }
      const body = await readJsonFromRequest(req, res, { maxBytes: 512 * 1024 });
      if (!body) return true;
      if (!Array.isArray(body.items)) { sendJSON(res, 400, { error: 'Липсва списък с редове за импорт.' }); return true; }
      if (body.items.length > MAX_ROWS_PER_MONTH) { sendJSON(res, 413, { error: 'Импортът е ограничен до ' + MAX_ROWS_PER_MONTH + ' реда.' }); return true; }
      const table = ensureMonth(month);
      const fingerprint = item => [item.name, item.quantity, item.unit, item.note, item.requestedBy].map(value => String(value || '').trim().toLocaleLowerCase('bg')).join('\u001f');
      const known = new Set(table.items.map(fingerprint));
      const additions = [];
      let skipped = 0;
      for (const row of body.items) {
        const name = cleanText(row && row.name, 160);
        const candidate = {
          name,
          quantity: cleanText(row && row.quantity, 40),
          unit: cleanText(row && row.unit, 32),
          note: cleanText(row && row.note, 240),
          requestedBy: cleanText(row && row.requestedBy, 120)
        };
        if (!candidate.name || !candidate.unit || !candidate.quantity || !candidate.requestedBy) {
          sendJSON(res, 400, { error: 'За всеки материал попълнете Материал, Мярка, Количество и Заявил. Бележка е по желание.' });
          return true;
        }
        if (candidate.quantity && !/^\d+$/.test(candidate.quantity)) { sendJSON(res, 400, { error: 'Количеството може да съдържа само цифри.' }); return true; }
        if (/\p{N}/u.test(candidate.unit)) { sendJSON(res, 400, { error: 'Полето „Мярка“ не може да съдържа цифри.' }); return true; }
        if (!name || known.has(fingerprint(candidate))) { skipped++; continue; }
        known.add(fingerprint(candidate));
        additions.push(candidate);
      }
      if (table.items.length + additions.length > MAX_ROWS_PER_MONTH) {
        sendJSON(res, 413, { error: 'Импортът надвишава максималния брой редове за месеца.', added: 0, skipped });
        return true;
      }
      const now = new Date().toISOString();
      for (const candidate of additions) {
        table.items.push({
          id: 'rm_' + Date.now().toString(36) + '_' + crypto.randomBytes(5).toString('hex'),
          ...candidate,
          createdAt: now,
          updatedAt: now
        });
      }
      if (additions.length) saveMonth(table);
      sendJSON(res, 200, { added: additions.length, skipped, month });
      return true;
    }

    if (pathname === '/api/required-materials/items' && req.method === 'POST') {
      const month = parsed.searchParams.get('month') || currentMonth();
      if (!validMonth(month) || !monthCanBeOpened(month)) { sendJSON(res, 400, { error: 'Месецът е невалиден или таблицата още не е създадена.' }); return true; }
      const body = await readJsonFromRequest(req, res, { maxBytes: 32 * 1024 });
      if (!body) return true;
      const name = cleanText(body.name, 160);
      if (!name) { sendJSON(res, 400, { error: 'Въведете наименование на материала.' }); return true; }
      const quantity = cleanText(body.quantity, 40);
      const unit = cleanText(body.unit, 32);
      const requestedBy = cleanText(body.requestedBy, 120);
      if (!unit || !quantity || !requestedBy) { sendJSON(res, 400, { error: 'Попълнете Материал, Мярка, Количество и Заявил. Бележка е по желание.' }); return true; }
      if (quantity && !/^\d+$/.test(quantity)) { sendJSON(res, 400, { error: 'Количеството може да съдържа само цифри.' }); return true; }
      if (/\p{N}/u.test(unit)) { sendJSON(res, 400, { error: 'Полето „Мярка“ не може да съдържа цифри.' }); return true; }
      const table = ensureMonth(month);
      if (table.items.length >= MAX_ROWS_PER_MONTH) { sendJSON(res, 413, { error: 'Достигнат е максималният брой редове за месеца.' }); return true; }
      const item = {
        id: 'rm_' + Date.now().toString(36) + '_' + crypto.randomBytes(5).toString('hex'),
        name,
        quantity,
        unit,
        note: cleanText(body.note, 240),
        requestedBy,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      table.items.push(item);
      saveMonth(table);
      sendJSON(res, 201, { item, month });
      return true;
    }

    const itemMatch = pathname.match(/^\/api\/required-materials\/items\/([a-z0-9_-]+)(?:\/(request|transfer))?$/i);
    if (itemMatch && (req.method === 'PUT' || req.method === 'DELETE' || req.method === 'POST')) {
      if (req.method === 'POST' && (itemMatch[2] === 'request' || itemMatch[2] === 'transfer') && sess.role !== 'admin') {
        sendJSON(res, 403, { error: 'Действията „Заявено“ и „Прехвърли“ са достъпни само за администратор.' });
        return true;
      }
      const month = parsed.searchParams.get('month') || currentMonth();
      if (!validMonth(month) || !monthCanBeOpened(month)) { sendJSON(res, 400, { error: 'Месецът е невалиден или таблицата още не е създадена.' }); return true; }
      const table = readMonth(month);
      if (!table) { sendJSON(res, 404, { error: 'Месечната таблица не е намерена.' }); return true; }
      const index = table.items.findIndex(x => x.id === itemMatch[1]);
      if (index < 0) { sendJSON(res, 404, { error: 'Материалът не е намерен.' }); return true; }
      if (req.method === 'POST' && pathname.endsWith('/request')) {
        const item = table.items[index];
        if (item.status === 'transferred') { sendJSON(res, 409, { error: 'Вече прехвърлен материал не може да се маркира като заявен.' }); return true; }
        const body = await readJsonFromRequest(req, res, { maxBytes: 8 * 1024 });
        if (!body) return true;
        item.status = body.requested ? 'requested' : '';
        item.requestedAt = body.requested ? new Date().toISOString() : '';
        item.updatedAt = new Date().toISOString();
        saveMonth(table);
        sendJSON(res, 200, { item, month });
        return true;
      }
      if (req.method === 'POST' && pathname.endsWith('/transfer')) {
        if (monthIsFuture(month)) { sendJSON(res, 400, { error: 'Прехвърлянето се извършва от текущ или предходен месец.' }); return true; }
        const item = table.items[index];
        if (!item.name || !item.unit || !item.quantity || !item.requestedBy) {
          sendJSON(res, 400, { error: 'Преди прехвърляне попълнете Материал, Мярка, Количество и Заявил. Бележка е по желание.' });
          return true;
        }
        if (!/^\d+$/.test(item.quantity) || /\p{N}/u.test(item.unit)) {
          sendJSON(res, 400, { error: 'Преди прехвърляне въведете само цифри в Количество и премахнете цифрите от Мярка.' });
          return true;
        }
        if (item.status === 'transferred' && item.transferredTo) {
          sendJSON(res, 200, { transferred: true, alreadyTransferred: true, targetMonth: item.transferredTo });
          return true;
        }
        const targetMonth = nextCalendarMonth(month);
        const target = ensureMonth(targetMonth);
        const existing = target.items.find(x => x.sourceMonth === month && x.sourceItemId === item.id);
        if (!existing) {
          const now = new Date().toISOString();
          target.items.push({
            id: 'rm_' + Date.now().toString(36) + '_' + crypto.randomBytes(5).toString('hex'),
            name: item.name, quantity: item.quantity || '', unit: item.unit || '', note: item.note || '', requestedBy: item.requestedBy || '',
            status: '', sourceMonth: month, sourceItemId: item.id, createdAt: now, updatedAt: now
          });
          saveMonth(target);
        }
        item.status = 'transferred';
        item.transferredTo = targetMonth;
        item.transferredAt = new Date().toISOString();
        item.updatedAt = new Date().toISOString();
        saveMonth(table);
        sendJSON(res, 200, { transferred: true, targetMonth, item });
        return true;
      }
      if (req.method === 'DELETE') {
        const removed = table.items.splice(index, 1)[0];
        saveMonth(table);
        sendJSON(res, 200, { deleted: true, item: removed });
        return true;
      }
      const body = await readJsonFromRequest(req, res, { maxBytes: 32 * 1024 });
      if (!body) return true;
      const name = cleanText(body.name, 160);
      if (!name) { sendJSON(res, 400, { error: 'Въведете наименование на материала.' }); return true; }
      const quantity = cleanText(body.quantity, 40);
      const unit = cleanText(body.unit, 32);
      const requestedBy = cleanText(body.requestedBy, 120);
      if (!unit || !quantity || !requestedBy) { sendJSON(res, 400, { error: 'Попълнете Материал, Мярка, Количество и Заявил. Бележка е по желание.' }); return true; }
      if (quantity && !/^\d+$/.test(quantity)) { sendJSON(res, 400, { error: 'Количеството може да съдържа само цифри.' }); return true; }
      if (/\p{N}/u.test(unit)) { sendJSON(res, 400, { error: 'Полето „Мярка“ не може да съдържа цифри.' }); return true; }
      table.items[index] = {
        ...table.items[index], name,
        quantity,
        unit,
        note: cleanText(body.note, 240),
        requestedBy,
        updatedAt: new Date().toISOString()
      };
      saveMonth(table);
      sendJSON(res, 200, { item: table.items[index], month });
      return true;
    }

    sendJSON(res, 405, { error: 'Методът не е разрешен.' });
    return true;
  };
}

module.exports = { createRequiredMaterialsRoutes };
