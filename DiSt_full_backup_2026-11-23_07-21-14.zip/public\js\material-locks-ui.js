/**
 * material-locks-ui.js — app.js modularization step A
 * Периоди за заключване на заявки за канцеларски/санитарни материали.
 * Load AFTER app.js (uses S, currentRole, currentMaterialType, currentTab, toast, confirmDialog).
 */

// ============================================================
//  ПЕРИОДИ ЗА ЗАКЛЮЧВАНЕ НА ЗАЯВКИ ЗА МАТЕРИАЛИ
// ============================================================
const MATERIAL_LOCKS_KEY = 'material_submission_locks';
const DEFAULT_MATERIAL_LOCKS = { office:{start:0,end:0}, sanitary:{start:0,end:0} };
var materialLocks = JSON.parse(JSON.stringify(DEFAULT_MATERIAL_LOCKS));

function normalizeMaterialLocks(raw) {
  const out = JSON.parse(JSON.stringify(DEFAULT_MATERIAL_LOCKS));
  if (!raw || typeof raw !== 'object') return out;
  ['office','sanitary'].forEach(type => {
    const x=raw[type] || {};
    out[type]={
      start:Math.max(0,Math.min(31,Number.parseInt(x.start,10)||0)),
      end:Math.max(0,Math.min(31,Number.parseInt(x.end,10)||0))
    };
  });
  return out;
}
async function loadMaterialLocks() {
  try {
    const r=await S.get(MATERIAL_LOCKS_KEY);
    materialLocks=normalizeMaterialLocks(r ? JSON.parse(r.value||'{}') : null);
  } catch(e) {
    console.warn('Material lock settings:',e);
    materialLocks=JSON.parse(JSON.stringify(DEFAULT_MATERIAL_LOCKS));
  }
  return materialLocks;
}
function isMaterialTypeLocked(type,date=new Date()) {
  const p=materialLocks[type];
  if (!p || !p.start || !p.end) return false;
  const d=date.getDate();
  return p.start<=p.end ? (d>=p.start && d<=p.end) : (d>=p.start || d<=p.end);
}
function materialLockPeriodText(type) {
  const p=materialLocks[type];
  return p && p.start && p.end ? (p.start+'–'+p.end+' число') : '';
}
function setMaterialFormControlsDisabled(disabled) {
  const wrap=document.getElementById('whFormWrap');
  if (!wrap) return;
  wrap.querySelectorAll('input,select,textarea,button').forEach(el=>{
    if (el.id==='btnWhCancel' || el.id==='btnWhLastEdit') { el.disabled=false; return; }
    if (el.closest && el.closest('#whLastRequestPanel')) { el.disabled=false; return; }
    el.disabled=!!disabled;
  });
}
async function applyMaterialSubmissionLockUI() {
  await loadMaterialLocks();
  const type=currentMaterialType;
  const warning=document.getElementById('whLockWarning');
  if (!warning) return false;
  const locked=currentRole !== 'admin' && (type==='office'||type==='sanitary') && isMaterialTypeLocked(type);
  if (locked) {
    const label=type==='office'?'канцеларски материали':'санитарни материали';
    warning.textContent='🔒 Подаването на заявки за '+label+' е временно заключено за периода '+materialLockPeriodText(type)+'. В този период не могат да се въвеждат и изпращат нови заявки.';
    warning.style.display='block';
  } else {
    warning.textContent='';
    warning.style.display='none';
  }
  setMaterialFormControlsDisabled(locked);
  return locked;
}
async function renderMaterialLocksTab() {
  await loadMaterialLocks();
  [['officeLockStart',materialLocks.office.start],['officeLockEnd',materialLocks.office.end],
   ['sanitaryLockStart',materialLocks.sanitary.start],['sanitaryLockEnd',materialLocks.sanitary.end]]
   .forEach(([id,v])=>{const e=document.getElementById(id);if(e)e.value=String(v||0);});
  const s=document.getElementById('materialLocksStatus');
  if(s)s.textContent='Текущите настройки са заредени.';
}
async function saveMaterialLocksFromUI() {
  const day=id=>{
    const n=Number.parseInt(document.getElementById(id)?.value||'0',10);
    if(!Number.isInteger(n)||n<0||n>31) throw new Error('Дните трябва да са между 0 и 31.');
    return n;
  };
  try {
    const next={office:{start:day('officeLockStart'),end:day('officeLockEnd')},
                sanitary:{start:day('sanitaryLockStart'),end:day('sanitaryLockEnd')}};
    for(const type of ['office','sanitary']) {
      const p=next[type];
      if((p.start===0)!==(p.end===0)) throw new Error('За всеки вид материали задайте и двата дни или оставете и двата на 0.');
    }
    await S.set(MATERIAL_LOCKS_KEY,JSON.stringify(next));
    materialLocks=normalizeMaterialLocks(next);
    const s=document.getElementById('materialLocksStatus');
    if(s)s.textContent='✅ Настройките са запазени.';
    toast('✅ Периодите за заключване са запазени.');
    if(currentTab==='warehouse') await applyMaterialSubmissionLockUI();
      try { await renderWhLastRequestPanel(); } catch (_) {}
  } catch(e) { toast('❌ '+(e.message||'Грешка при записване.')); }
}
async function clearMaterialLocks() {
  const next=JSON.parse(JSON.stringify(DEFAULT_MATERIAL_LOCKS));
  await S.set(MATERIAL_LOCKS_KEY,JSON.stringify(next));
  materialLocks=next;
  ['officeLockStart','officeLockEnd','sanitaryLockStart','sanitaryLockEnd'].forEach(id=>{const e=document.getElementById(id);if(e)e.value='0';});
  const s=document.getElementById('materialLocksStatus'); if(s)s.textContent='Заключването е изключено.';
  toast('✅ Подаването на заявки за материали е отключено.');
  if(currentTab==='warehouse') await applyMaterialSubmissionLockUI();
      try { await renderWhLastRequestPanel(); } catch (_) {}
}

// ---- UI wiring ----
(function wireMaterialLocksUI() {
  const btnSave = document.getElementById('btnSaveMaterialLocks');
  if (btnSave) btnSave.addEventListener('click', function () { saveMaterialLocksFromUI(); });
  const btnClear = document.getElementById('btnClearMaterialLocks');
  if (btnClear) btnClear.addEventListener('click', async function () {
    if (await confirmDialog('Да се изключи ли заключването за двата вида материали?')) clearMaterialLocks();
  });
})();

/* window exports — switchTab() и warehouse UI разчитат на глобални имена */
try {
  window.MATERIAL_LOCKS_KEY = MATERIAL_LOCKS_KEY;
  window.DEFAULT_MATERIAL_LOCKS = DEFAULT_MATERIAL_LOCKS;
  window.materialLocks = materialLocks;
  window.normalizeMaterialLocks = normalizeMaterialLocks;
  window.loadMaterialLocks = loadMaterialLocks;
  window.isMaterialTypeLocked = isMaterialTypeLocked;
  window.materialLockPeriodText = materialLockPeriodText;
  window.setMaterialFormControlsDisabled = setMaterialFormControlsDisabled;
  window.applyMaterialSubmissionLockUI = applyMaterialSubmissionLockUI;
  window.renderMaterialLocksTab = renderMaterialLocksTab;
  window.saveMaterialLocksFromUI = saveMaterialLocksFromUI;
  window.clearMaterialLocks = clearMaterialLocks;
} catch (_) {}
