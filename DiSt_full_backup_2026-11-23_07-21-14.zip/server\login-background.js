'use strict';

/**
 * Фонова снимка на входния екран:
 * - GET /api/login-background/meta  → { enabled, url }
 * - GET /api/login-background/image/<sha256> → binary + ETag + дълъг кеш
 * - GET /api/login-background → legacy JSON (съвместимост)
 */
const MAX_UPLOAD_IMAGE_BYTES = 500 * 1024;
const MAX_STORED_IMAGE_BYTES = 20 * 1024 * 1024;
const IMAGE_DATA_URL = /^data:(image\/(?:png|jpeg|gif|webp|avif|bmp));base64,([A-Za-z0-9+/=\s]+)$/i;

function detectImageType(bytes) {
  if (bytes.length >= 8 && bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) return 'image/png';
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return 'image/jpeg';
  if (bytes.length >= 6 && ['GIF87a', 'GIF89a'].includes(bytes.subarray(0, 6).toString('ascii'))) return 'image/gif';
  if (bytes.length >= 12 && bytes.subarray(0, 4).toString('ascii') === 'RIFF' && bytes.subarray(8, 12).toString('ascii') === 'WEBP') return 'image/webp';
  if (bytes.length >= 2 && bytes.subarray(0, 2).toString('ascii') === 'BM') return 'image/bmp';
  if (bytes.length >= 16 && bytes.subarray(4, 8).toString('ascii') === 'ftyp') {
    const boxLength = Math.min(bytes.readUInt32BE(0), bytes.length);
    for (let offset = 8; offset + 4 <= boxLength; offset += (offset === 8 ? 8 : 4)) {
      const brand = bytes.subarray(offset, offset + 4).toString('ascii');
      if (brand === 'avif' || brand === 'avis') return 'image/avif';
    }
  }
  return '';
}

function inspectImageDataUrl(value, maxBytes) {
  maxBytes = maxBytes || MAX_UPLOAD_IMAGE_BYTES;
  const maxBase64Chars = Math.ceil(maxBytes / 3) * 4;
  const match = IMAGE_DATA_URL.exec(String(value || '').trim());
  if (!match) {
    const error = new Error('Изберете валиден файл с изображение (PNG, JPEG, GIF, WebP, AVIF или BMP).');
    error.status = 415;
    throw error;
  }
  const base64 = match[2].replace(/\s/g, '');
  if (base64.length > maxBase64Chars) {
    const error = new Error(maxBytes === MAX_UPLOAD_IMAGE_BYTES ? 'Фоновата снимка надвишава максималния размер от 500 KB.' : 'Фоновата снимка надвишава максималния поддържан размер.');
    error.status = 413;
    throw error;
  }
  const bytes = Buffer.from(base64, 'base64');
  if (!bytes.length) {
    const error = new Error('Файлът не съдържа валидно изображение.');
    error.status = 415;
    throw error;
  }
  if (bytes.length > maxBytes) {
    const error = new Error(maxBytes === MAX_UPLOAD_IMAGE_BYTES ? 'Фоновата снимка надвишава максималния размер от 500 KB.' : 'Фоновата снимка надвишава максималния поддържан размер.');
    error.status = 413;
    throw error;
  }
  const contentType = match[1].toLowerCase();
  if (detectImageType(bytes) !== contentType) {
    const error = new Error('Типът на файла не съвпада със съдържанието му или форматът не се поддържа.');
    error.status = 415;
    throw error;
  }
  return { bytes, contentType };
}

function validateLoginBackgroundValue(value) {
  try { inspectImageDataUrl(value, MAX_UPLOAD_IMAGE_BYTES); return null; }
  catch (e) { return { status: e.status || 415, error: e.message || 'Невалидна фонова снимка.' }; }
}

function createLoginBackgroundRoutes(deps) {
  const { kvGet, sendJSON, addCORS, applySecurityHeaders, crypto } = deps;
  let cachedSource = null;
  let cachedImage = null;

  function getImage() {
    const value = kvGet('login_background');
    if (value === null || value === '') {
      cachedSource = null;
      cachedImage = null;
      return null;
    }
    if (value === cachedSource && cachedImage) return cachedImage;

    const { bytes, contentType } = inspectImageDataUrl(value, MAX_STORED_IMAGE_BYTES);
    const hash = crypto.createHash('sha256').update(bytes).digest('hex');
    cachedSource = value;
    cachedImage = {
      bytes,
      contentType,
      hash,
      etag: '"' + hash + '"',
      url: '/api/login-background/image/' + hash
    };
    return cachedImage;
  }

  function handle(req, res, pathname) {
    if (pathname === '/api/login-background') {
      if (req.method !== 'GET') return false;
      const value = kvGet('login_background');
      if (value === null || value === '') {
        sendJSON(res, 404, { error: 'not found' });
      } else {
        sendJSON(res, 200, { key: 'login_background', value });
      }
      return true;
    }

    if (pathname === '/api/login-background/meta') {
      if (req.method !== 'GET') return false;
      try {
        const image = getImage();
        sendJSON(res, 200, { enabled: !!image, url: image ? image.url : null });
      } catch (e) {
        sendJSON(res, e.status || 500, { error: e.message || 'Грешка при зареждане на фоновата снимка.' });
      }
      return true;
    }

    const m = pathname.match(/^\/api\/login-background\/image\/([a-f0-9]{64})$/i);
    if (!m) return false;
    if (req.method !== 'GET' && req.method !== 'HEAD') return false;
    try {
      const image = getImage();
      if (!image || image.hash !== m[1].toLowerCase()) {
        sendJSON(res, 404, { error: 'not found' });
        return true;
      }
      addCORS(res);
      applySecurityHeaders(res);
      res.setHeader('Vary', 'Origin');
      res.setHeader('ETag', image.etag);
      res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
      res.setHeader('Content-Type', image.contentType);
      res.setHeader('Content-Length', String(image.bytes.length));
      const ifNoneMatch = String(req.headers['if-none-match'] || '');
      if (ifNoneMatch.split(',').some(tag => tag.trim() === image.etag || tag.trim() === 'W/' + image.etag || tag.trim() === '*')) {
        res.writeHead(304);
        res.end();
        return true;
      }
      res.writeHead(200);
      if (req.method === 'HEAD') res.end();
      else res.end(image.bytes);
    } catch (e) {
      sendJSON(res, e.status || 500, { error: e.message || 'Грешка при зареждане на фоновата снимка.' });
    }
    return true;
  }

  return handle;
}

module.exports = { createLoginBackgroundRoutes, validateLoginBackgroundValue, MAX_UPLOAD_IMAGE_BYTES };
