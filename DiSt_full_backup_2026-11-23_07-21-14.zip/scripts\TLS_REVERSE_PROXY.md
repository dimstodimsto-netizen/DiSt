# TLS пред DiSt (препоръка)

Node остава на HTTP. TLS е на обратния прокси.

## Вариант A — само LAN + VPN
- Не отваряйте порт 3000 към интернет.
- Отдалечен достъп през VPN до мрежата на организацията.
- Cookie без Secure е ОК при чист HTTP в LAN.

## Вариант B — Caddy (автоматичен HTTPS)

1. Node слуша само локално:
   ```
   set LISTEN_HOST=127.0.0.1
   set TRUST_PROXY=1
   ```
   (Windows: System env или преди START_SERVER.bat)

2. Caddyfile:
   ```
   dist.example.com {
     reverse_proxy 127.0.0.1:3000
   }
   ```

3. Клиентите отварят `https://dist.example.com`

## Вариант C — nginx

```
server {
  listen 443 ssl http2;
  server_name dist.example.com;
  ssl_certificate     /path/fullchain.pem;
  ssl_certificate_key /path/privkey.pem;

  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
  }
}
```

Env на Node:
```
LISTEN_HOST=127.0.0.1
TRUST_PROXY=1
```
(при TRUST_PROXY=1 cookie получава Secure, когато X-Forwarded-Proto=https)

Принудително Secure (само ако ВСИЧКИ клиенти са на HTTPS):
```
COOKIE_SECURE=1
```

## Вариант D — IIS ARR
- Site с HTTPS binding + URL Rewrite към `http://127.0.0.1:3000`
- Добавете server variable `HTTP_X_FORWARDED_PROTO` = https
- LISTEN_HOST=127.0.0.1, TRUST_PROXY=1

## Важно
- Не слагайте COOKIE_SECURE=1 при чист HTTP LAN — браузърът няма да запази cookie.
- След смяна на env → рестарт на Zayavki / Node.
