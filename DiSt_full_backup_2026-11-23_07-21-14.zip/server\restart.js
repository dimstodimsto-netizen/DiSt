'use strict';

/** Platform-specific graceful restart orchestration. */
function createRestartModule({ fs, path, os, spawn, ROOT_DIR, PID_PATH, PORT, db, writeSystemLog, markGracefulStop, getServer }) {
// ---- Дистанционен рестарт на сървъра (само админ) ----
// На Windows директният spawn + process.exit често убива и дъщерния процес.
// Затова пишем .bat с кратък timeout и го стартираме с "start", после излизаме.
let __restartScheduled = false;
function scheduleServerRestart(delayMs, reason, username) {
  if (__restartScheduled) return false;
  __restartScheduled = true;
  const ms = Math.max(800, Number(delayMs) || 1500);
  try {
    writeSystemLog('warn', 'system', 'Планиран рестарт на сървъра след ' + ms + ' ms' + (reason ? (': ' + reason) : ''), {
      username: username || ''
    });
  } catch (_) {}
  console.log('🔄 Рестарт на сървъра след ' + ms + ' ms' + (reason ? (' (' + reason + ')') : ''));
  setTimeout(() => {
    let started = false;
    try {
      const nodeExe = process.execPath;
      const serverJs = path.join(ROOT_DIR, 'server.js');
      const waitSec = 3;
      // Предпочитаме portable node от папка node/, ако съществува
      let nodeToRun = nodeExe;
      const portable = path.join(ROOT_DIR, 'node', 'node.exe');
      if (process.platform === 'win32' && fs.existsSync(portable)) {
        nodeToRun = portable;
      }

      if (process.platform === 'win32') {
        const batPath = path.join(os.tmpdir(), 'dist_restart_' + Date.now() + '.bat');
        const batBody = [
          '@echo off',
          'cd /d "' + ROOT_DIR.replace(/"/g, '') + '"',
          'timeout /t ' + waitSec + ' /nobreak >nul',
          'if exist server.pid (',
          '  for /f "usebackq delims=" %%p in ("server.pid") do taskkill /F /PID %%p >nul 2>&1',
          '  del /f /q server.pid >nul 2>&1',
          ')',
          "for /f \"tokens=5\" %%a in ('netstat -ano ^| findstr \":" + PORT + "\" ^| findstr \"LISTENING\"') do taskkill /F /PID %%a >nul 2>&1",
          'timeout /t 2 /nobreak >nul',
          'if exist START_HIDDEN.vbs (cscript //nologo START_HIDDEN.vbs) else ("' + nodeToRun.replace(/"/g, '') + '" "' + serverJs.replace(/"/g, '') + '")',
          ''
        ].join('\r\n');
        fs.writeFileSync(batPath, batBody, 'utf8');
        const child = spawn('cmd.exe', ['/c', 'start', '', '/min', batPath], {
          detached: true,
          stdio: 'ignore',
          cwd: ROOT_DIR,
          windowsHide: true
        });
        child.unref();
        started = true;
        console.log('🔄 Рестарт чрез bat:', batPath);
      } else {
        const child = spawn(nodeToRun, [serverJs], {
          detached: true,
          stdio: 'ignore',
          cwd: ROOT_DIR,
          env: process.env
        });
        child.unref();
        started = true;
      }
    } catch (e) {
      console.error('❌ Неуспешен spawn при рестарт:', e && e.message ? e.message : e);
      try {
        writeSystemLog('error', 'system', 'Неуспешен spawn при рестарт: ' + (e && e.message ? e.message : String(e)));
      } catch (_) {}
      __restartScheduled = false;
      return;
    }
    if (!started) {
      __restartScheduled = false;
      return;
    }
    try {
      const activeServer = getServer();
      if (activeServer && activeServer.listening) activeServer.close();
    } catch (_) {}
    try { markGracefulStop('дистанционен рестарт'); } catch (_) {}
    try { if (fs.existsSync(PID_PATH)) fs.unlinkSync(PID_PATH); } catch (_) {}
    try { db.close(); } catch (_) {}
    // Даваме време портът да се освободи; bat изчаква още
    setTimeout(() => process.exit(0), 400);
  }, ms);
  return true;
}



  return { scheduleServerRestart };
}
module.exports = { createRestartModule };
