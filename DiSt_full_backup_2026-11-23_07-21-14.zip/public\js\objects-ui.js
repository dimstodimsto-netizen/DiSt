/**
 * objects-ui.js — app.js modularization
 * Обекти: списък, форма, акт за вложени материали.
 * Load AFTER app.js.
 */
const objectsUiState = AppState.bind(['materialRowSeq']);


// ---- Обекти ----
async function getObjectIds() {
  const r = await S.get('objects-index');
  if (!r || !r.value) return [];
  try {
    const parsed = JSON.parse(r.value);
    return Array.isArray(parsed) ? parsed : [];
  } catch(e) { return []; }
}

async function saveObjectIds(ids) { await S.set('objects-index', JSON.stringify(ids)); }

async function getObjectById(id) {
  const r = await S.get('object:' + id);
  if (!r || !r.value) return null;
  try { return JSON.parse(r.value); }
  catch(e) { return null; }
}

async function saveObjectRecord(obj) {
  await S.set('object:' + obj.id, JSON.stringify(obj));
  const ids = await getObjectIds();
  if (!ids.includes(obj.id)) { ids.push(obj.id); await saveObjectIds(ids); }
}

async function deleteObjectRecord(id) {
  await S.delete('object:' + id);
  const ids = await getObjectIds();
  await saveObjectIds(ids.filter(x => x !== id));
}

async function getAllObjects() {
  const ids = await getObjectIds();
  const results = await Promise.all(ids.map(id => getObjectById(id)));
  const objs = results.filter(Boolean);
  objs.sort((a,b) => (b.createdAt||'').localeCompare(a.createdAt||''));
  return objs;
}

function addMaterialRow(data) {
  data = data || {};
  const rowId = 'mrow' + (objectsUiState.materialRowSeq++);
  const tr = document.createElement('tr');
  tr.id = rowId;
  tr.style.borderBottom = '1px solid var(--line)';
  tr.innerHTML =
    '<td style="padding:4px 6px;"><input type="text" class="mat-name" style="margin:0;" value="' + escapeHtml(data.name||'') + '"></td>' +
    '<td style="padding:4px 6px;"><input type="text" class="mat-merka" style="margin:0;" placeholder="бр./м/кг" value="' + escapeHtml(data.merka||'') + '"></td>' +
    '<td style="padding:4px 6px;"><input type="text" class="mat-kolichestvo" style="margin:0;" value="' + escapeHtml(data.kolichestvo||'') + '"></td>' +
    '<td style="padding:4px 6px;text-align:center;"><button type="button" class="ghost" style="padding:4px 8px;font-size:12px;color:#c0392b;" onclick="document.getElementById(\'' + rowId + '\').remove()">✕</button></td>';
  document.getElementById('materialsTableBody').appendChild(tr);
  // Ако основните полета са заключени (техник), материалите трябва да останат редактируеми
  // освен при завършен обект — синхронизираме според текущото състояние на „Възложител“.
  try {
    const mainLocked = !!(document.getElementById('oVazlozhitel') && document.getElementById('oVazlozhitel').disabled);
    const completed = !!(document.getElementById('oCompletedAt') && document.getElementById('oCompletedAt').value);
    if (currentRole === 'technician') {
      const editable = !completed;
      const inputs = tr.querySelectorAll('input');
      inputs.forEach(input => {
        input.disabled = !editable;
        input.style.background = editable ? '' : 'var(--locked-bg)';
      });
      const btn = tr.querySelector('button');
      if (btn) {
        btn.disabled = !editable;
        btn.style.opacity = editable ? '' : '0.45';
        btn.style.pointerEvents = editable ? '' : 'none';
      }
    } else if (mainLocked && completed) {
      const inputs = tr.querySelectorAll('input, button');
      inputs.forEach(el => {
        el.disabled = true;
        if (el.tagName === 'INPUT') el.style.background = 'var(--locked-bg)';
      });
    }
  } catch (_) {}
}

function readMaterialsFromTable() {
  const rows = Array.from(document.getElementById('materialsTableBody').querySelectorAll('tr'));
  return rows.map(tr => ({
    name: tr.querySelector('.mat-name') ? tr.querySelector('.mat-name').value.trim() : '',
    merka: tr.querySelector('.mat-merka') ? tr.querySelector('.mat-merka').value.trim() : '',
    kolichestvo: tr.querySelector('.mat-kolichestvo') ? tr.querySelector('.mat-kolichestvo').value.trim() : ''
  })).filter(m => m.name || m.merka || m.kolichestvo);
}

// ---- Износ на "Акт за вложени материали" (таб "Обекти") ----
function getCurrentObjectActData() {
  return {
    vazlozhitel: document.getElementById('oVazlozhitel').value.trim(),
    osnovanie: document.getElementById('oOsnovanie').value.trim(),
    lokacia: document.getElementById('oLokacia').value.trim(),
    vidDeinost: document.getElementById('oVidDeinost').value.trim(),
    materiali: readMaterialsFromTable()
  };
}
function actTodayStr() {
  const d = new Date();
  return String(d.getDate()).padStart(2, '0') + '.' + String(d.getMonth() + 1).padStart(2, '0') + '.' + d.getFullYear();
}
function buildActHtml(data) {
  const rows = data.materiali.map((m, i) =>
    '<tr>' +
      '<td style="border:1px solid #000;padding:5px;text-align:center;">' + (i + 1) + '</td>' +
      '<td style="border:1px solid #000;padding:5px;">' + escapeHtml(m.name) + '</td>' +
      '<td style="border:1px solid #000;padding:5px;text-align:center;">' + escapeHtml(m.merka) + '</td>' +
      '<td style="border:1px solid #000;padding:5px;text-align:center;">' + escapeHtml(m.kolichestvo) + '</td>' +
      '<td style="border:1px solid #000;padding:5px;">' + escapeHtml(m.zabelezka) + '</td>' +
    '</tr>'
  ).join('');
  return `
    <div style="font-family:Arial,sans-serif;font-size:13px;color:#000;">
      <h2 style="text-align:center;margin-bottom:4px;">АКТ ЗА ВЛОЖЕНИ МАТЕРИАЛИ</h2>
      <p style="text-align:center;margin-top:0;">от ${escapeHtml(actTodayStr())}</p>
      <p><b>Възложител:</b> ${escapeHtml(data.vazlozhitel)}</p>
      <p><b>Основание:</b> ${escapeHtml(data.osnovanie)}</p>
      <p><b>Локация:</b> ${escapeHtml(data.lokacia)}</p>
      ${data.vidDeinost ? '<p><b>Вид дейност:</b> ' + escapeHtml(data.vidDeinost) + '</p>' : ''}
      <table style="width:100%;border-collapse:collapse;margin-top:14px;">
        <thead>
          <tr style="background:#eee;">
            <th style="border:1px solid #000;padding:5px;width:36px;">№</th>
            <th style="border:1px solid #000;padding:5px;">Материал</th>
            <th style="border:1px solid #000;padding:5px;">Мярка</th>
            <th style="border:1px solid #000;padding:5px;">Заявено количество</th>
            <th style="border:1px solid #000;padding:5px;">Забележка</th>
          </tr>
        </thead>
        <tbody>${rows || '<tr><td colspan="5" style="border:1px solid #000;padding:8px;text-align:center;">Няма въведени материали</td></tr>'}</tbody>
      </table>
      <div style="display:flex;justify-content:space-between;margin-top:60px;">
        <div>Предал: ___________________</div>
        <div>Приел: ___________________</div>
      </div>
    </div>
  `;
}

document.getElementById('btnExportActXlsx').addEventListener('click', function() {
  return exportWithXlsx(async function () {
  const data = getCurrentObjectActData();
  if (!data.vazlozhitel || !data.osnovanie || !data.lokacia) {
    toast('Моля, попълнете задължителните полета преди износ.');
    return;
  }
  const header = ['№', 'Материал', 'Мярка', 'Заявено количество', 'Забележка / Отпуснато количество'];
  const rows = data.materiali.map((m, i) => [i + 1, m.name, m.merka, m.kolichestvo, m.zabelezka]);
  const ws = XLSX.utils.aoa_to_sheet([
    ['АКТ ЗА ВЛОЖЕНИ МАТЕРИАЛИ'],
    ['Възложител:', data.vazlozhitel],
    ['Основание:', data.osnovanie],
    ['Локация:', data.lokacia],
    [],
    header,
    ...rows
  ]);
  ws['!cols'] = [{ wch: 6 }, { wch: 30 }, { wch: 10 }, { wch: 12 }, { wch: 24 }];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Акт');
  XLSX.writeFile(wb, 'Akt_vlozheni_materiali_' + actTodayStr().replace(/\./g, '-') + '.xlsx');
  });
});

document.getElementById('btnExportActWord').addEventListener('click', function() {
  const data = getCurrentObjectActData();
  if (!data.vazlozhitel || !data.osnovanie || !data.lokacia) {
    toast('Моля, попълнете задължителните полета преди износ.');
    return;
  }
  const bodyHtml = buildActHtml(data);
  const docHtml =
    '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">' +
    '<head><meta charset="utf-8"><title>Акт за вложени материали</title></head>' +
    '<body>' + bodyHtml + '</body></html>';
  const blob = new Blob(['\ufeff', docHtml], { type: 'application/msword' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'Akt_vlozheni_materiali_' + actTodayStr().replace(/\./g, '-') + '.doc';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 2000);
});

document.getElementById('btnExportActPdf').addEventListener('click', function() {
  const data = getCurrentObjectActData();
  if (!data.vazlozhitel || !data.osnovanie || !data.lokacia) {
    toast('Моля, попълнете задължителните полета преди износ.');
    return;
  }
  const bodyHtml = buildActHtml(data);
  const win = window.open('', '_blank');
  if (!win) { toast('Браузърът блокира отварянето на нов прозорец за печат.'); return; }
  win.document.write(
    '<html><head><meta charset="utf-8"><title>Акт за вложени материали</title></head>' +
    '<body onload="window.print()">' + bodyHtml + '</body></html>'
  );
  win.document.close();
});


// ---- EVENT LISTENER ЗА ТЪРСЕНЕ НА ОБЕКТИ ----
document.getElementById('objectsSearchInput').addEventListener('input', function() {
  renderObjectsList();
});

// ---- EVENT LISTENER ЗА НОВ ОБЕКТ ----
document.getElementById('btnNewObject').addEventListener('click', () => openObjectForm(null));

// ============================================================
//  ОТВАРЯНЕ НА ФОРМА ЗА ОБЕКТ
// ============================================================
window.openObjectForm = async function(id) {
  const formWrap = document.getElementById('objectFormWrap');
  const listWrap = document.getElementById('objectsListWrap');
  const formTitle = document.getElementById('objectFormTitle');
  
  listWrap.style.display = 'none';
  formWrap.style.display = 'block';
  
  if (id) {
    // Редакция на съществуващ обект
    const obj = await getObjectById(id);
    if (!obj) {
      toast('❌ Обектът не е намерен.');
      listWrap.style.display = 'block';
      formWrap.style.display = 'none';
      return;
    }
    
    formTitle.textContent = 'Редакция на обект';
    document.getElementById('oId').value = obj.id;
    document.getElementById('oVazlozhitel').value = obj.vazlozhitel || '';
    document.getElementById('oOsnovanie').value = obj.osnovanie || '';
    document.getElementById('oKorpus').value = obj.korpus || '';
    document.getElementById('oEtaz').value = obj.etaz || '';
    document.getElementById('oStruktura').value = obj.struktura || '';
    document.getElementById('oLokacia').value = obj.lokacia || '';
    document.getElementById('oVidDeinost').value = obj.vidDeinost || '';
    
    // Показване на материалите
    const tbody = document.getElementById('materialsTableBody');
    tbody.innerHTML = '';
    if (obj.materials && obj.materials.length) {
      obj.materials.forEach(mat => addMaterialRow(mat));
    } else {
      addMaterialRow();
    }
    
    // Показване на статус за завършен обект
    const completedWrap = document.getElementById('oCompletedWrap');
    const completedBadge = document.getElementById('oCompletedBadge');
    const btnCompleted = document.getElementById('btnMarkObjectCompleted');
    const btnReopen = document.getElementById('btnReopenObject');
    const btnDelete = document.getElementById('btnDeleteObject');
    
    if (obj.completedAt) {
      completedWrap.style.display = 'block';
      document.getElementById('oCompletedAt').value = obj.completedAt;
      completedBadge.style.display = 'block';
      btnCompleted.style.display = 'none';
      btnReopen.style.display = currentRole === 'admin' ? 'inline-block' : 'none';
      btnDelete.style.display = currentRole === 'admin' ? 'inline-block' : 'none';
      setObjectFormLocked(true);
    } else {
      completedWrap.style.display = 'none';
      completedBadge.style.display = 'none';
      btnCompleted.style.display = currentRole === 'admin' ? 'inline-block' : 'none';
      btnReopen.style.display = 'none';
      btnDelete.style.display = currentRole === 'admin' ? 'inline-block' : 'none';
      // Заключване на основните полета за техници, независимо дали обектът е завършен
      setObjectFormLockedForRole();
    }
    
  } else {
    // Нов обект
    formTitle.textContent = 'Нов обект';
    document.getElementById('oId').value = '';
    document.getElementById('oVazlozhitel').value = '';
    document.getElementById('oOsnovanie').value = '';
    document.getElementById('oKorpus').value = '';
    document.getElementById('oEtaz').value = '';
    document.getElementById('oStruktura').value = '';
    document.getElementById('oLokacia').value = '';
    document.getElementById('oVidDeinost').value = '';
    
    const tbody = document.getElementById('materialsTableBody');
    tbody.innerHTML = '';
    addMaterialRow();
    
    document.getElementById('oCompletedWrap').style.display = 'none';
    document.getElementById('oCompletedBadge').style.display = 'none';
    document.getElementById('btnMarkObjectCompleted').style.display = currentRole === 'admin' ? 'inline-block' : 'none';
    document.getElementById('btnReopenObject').style.display = 'none';
    document.getElementById('btnDeleteObject').style.display = 'none';
    // Заключване на основните полета за техници при нов обект
    setObjectFormLockedForRole();
  }
};

// ---- ФУНКЦИИ ЗА ФОРМА ЗА ОБЕКТ ----
// Техник: само „Вложени материали“ са редактируеми (при незавършен обект).
// Админ: всичко. Завършен обект: само админ може да пипа каквото и да е.
function setObjectMaterialsEditable(editable) {
  const matInputs = document.querySelectorAll('#materialsTableBody input');
  matInputs.forEach(input => {
    input.disabled = !editable;
    input.style.background = editable ? '' : 'var(--locked-bg)';
  });
  const matButtons = document.querySelectorAll('#materialsTableBody button');
  matButtons.forEach(btn => {
    btn.disabled = !editable;
    btn.style.opacity = editable ? '' : '0.45';
    btn.style.pointerEvents = editable ? '' : 'none';
  });
  const addBtn = document.getElementById('btnAddMaterialRow');
  if (addBtn) {
    addBtn.disabled = !editable;
    addBtn.style.opacity = editable ? '' : '0.45';
    addBtn.style.pointerEvents = editable ? '' : 'none';
  }
}

function setObjectFormLocked(locked) {
  // locked = true → обектът е завършен (или принудително заключен)
  const mainFields = ['oVazlozhitel', 'oOsnovanie', 'oKorpus', 'oEtaz', 'oStruktura', 'oLokacia', 'oVidDeinost'];
  const isAdmin = currentRole === 'admin';
  mainFields.forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    // Основните полета: само админ и само когато обектът НЕ е заключен
    const fieldLocked = locked || !isAdmin;
    el.disabled = fieldLocked;
    el.style.background = fieldLocked ? 'var(--locked-bg)' : '';
    el.title = !isAdmin ? 'Само администратор може да променя това поле.' : '';
  });

  // Материали: техник и админ могат да ги пипат, ако обектът не е завършен
  const materialsEditable = !locked && (isAdmin || currentRole === 'technician');
  setObjectMaterialsEditable(materialsEditable);
}

function setObjectFormLockedForRole() {
  // Незавършен обект: админ — всичко; техник — само материали
  setObjectFormLocked(false);
}

window.resetObjectForm = function() {
  document.getElementById('objectFormWrap').style.display = 'none';
  document.getElementById('objectsListWrap').style.display = 'block';
  renderObjectsList();
};

// ---- EVENT LISTENERS ЗА БУТОНИТЕ В ФОРМАТА ЗА ОБЕКТ ----
document.getElementById('btnCancelObject').addEventListener('click', resetObjectForm);

document.getElementById('btnSaveObject').addEventListener('click', async function() {
  const id = document.getElementById('oId').value;
  const materials = readMaterialsFromTable();

  // Само администратор може да създава нови обекти
  if (!id && currentRole !== 'admin') {
    toast('❌ Само администратор може да създава нови обекти.');
    return;
  }

  try {
    if (id) {
      const obj = await getObjectById(id);
      if (!obj) {
        toast('❌ Обектът не е намерен.');
        return;
      }
      if (obj.completedAt && currentRole !== 'admin') {
        toast('❌ Завършен обект може да се редактира само от администратор.');
        return;
      }

      if (currentRole === 'technician') {
        // Техник: променя САМО вложените материали
        obj.materials = materials;
      } else {
        const vazlozhitel = document.getElementById('oVazlozhitel').value.trim();
        const osnovanie = document.getElementById('oOsnovanie').value.trim();
        const korpus = document.getElementById('oKorpus').value.trim();
        const etaz = document.getElementById('oEtaz').value.trim();
        const struktura = document.getElementById('oStruktura').value.trim();
        const lokacia = document.getElementById('oLokacia').value.trim();
        const vidDeinost = document.getElementById('oVidDeinost').value.trim();
        if (!vazlozhitel) { toast('❌ Въведете възложител.'); return; }
        if (!osnovanie) { toast('❌ Въведете основание.'); return; }
        if (!lokacia) { toast('❌ Въведете локация на обекта.'); return; }
        obj.vazlozhitel = vazlozhitel;
        obj.osnovanie = osnovanie;
        obj.korpus = korpus;
        obj.etaz = etaz;
        obj.struktura = struktura;
        obj.lokacia = lokacia;
        obj.vidDeinost = vidDeinost;
        obj.materials = materials;
      }
      await saveObjectRecord(obj);
      toast('✅ Обектът е обновен.');
    } else {
      const vazlozhitel = document.getElementById('oVazlozhitel').value.trim();
      const osnovanie = document.getElementById('oOsnovanie').value.trim();
      const korpus = document.getElementById('oKorpus').value.trim();
      const etaz = document.getElementById('oEtaz').value.trim();
      const struktura = document.getElementById('oStruktura').value.trim();
      const lokacia = document.getElementById('oLokacia').value.trim();
      const vidDeinost = document.getElementById('oVidDeinost').value.trim();
      if (!vazlozhitel) { toast('❌ Въведете възложител.'); return; }
      if (!osnovanie) { toast('❌ Въведете основание.'); return; }
      if (!lokacia) { toast('❌ Въведете локация на обекта.'); return; }
      const newId = 'obj_' + Date.now();
      const newObj = {
        id: newId,
        vazlozhitel,
        osnovanie,
        korpus,
        etaz,
        struktura,
        lokacia,
        vidDeinost,
        materials,
        createdAt: new Date().toISOString(),
        completedAt: null
      };
      await saveObjectRecord(newObj);
      toast('✅ Обектът е създаден.');
    }

    resetObjectForm();
  } catch (e) {
    console.error(e);
    toast('❌ Грешка при запис.');
  }
});

document.getElementById('btnAddMaterialRow').addEventListener('click', () => addMaterialRow());

document.getElementById('btnMarkObjectCompleted').addEventListener('click', async function() {
  if (currentRole !== 'admin') { toast('Нямате права за това действие.'); return; }
  const id = document.getElementById('oId').value;
  if (!id) return;
  
  if (!(await confirmDialog('Сигурни ли сте, че искате да маркирате този обект като завършен?'))) return;
  
  try {
    const obj = await getObjectById(id);
    if (obj) {
      obj.completedAt = new Date().toISOString();
      await saveObjectRecord(obj);
      toast('✅ Обектът е маркиран като завършен.');
      openObjectForm(id); // Рефреш на формата
    }
  } catch (e) {
    console.error(e);
    toast('❌ Грешка при обновяване.');
  }
});

document.getElementById('btnReopenObject').addEventListener('click', async function() {
  if (currentRole !== 'admin') { toast('Нямате права за това действие.'); return; }
  const id = document.getElementById('oId').value;
  if (!id) return;
  
  if (!(await confirmDialog('Сигурни ли сте, че искате да отворите отново този обект?'))) return;
  
  try {
    const obj = await getObjectById(id);
    if (obj) {
      obj.completedAt = null;
      await saveObjectRecord(obj);
      toast('✅ Обектът е отворен отново.');
      openObjectForm(id); // Рефреш на формата
    }
  } catch (e) {
    console.error(e);
    toast('❌ Грешка при обновяване.');
  }
});

document.getElementById('btnDeleteObject').addEventListener('click', async function() {
  if (currentRole !== 'admin') { toast('Нямате права за това действие.'); return; }
  const id = document.getElementById('oId').value;
  if (!id) return;
  
  if (!(await confirmDialog('Сигурни ли сте, че искате да изтриете този обект?'))) return;
  
  try {
    await deleteObjectRecord(id);
    toast('✅ Обектът е изтрит.');
    resetObjectForm();
  } catch (e) {
    console.error(e);
    toast('❌ Грешка при изтриване.');
  }
});

/* window exports */
try {
  if (typeof actTodayStr==='function') window.actTodayStr=actTodayStr;
  if (typeof addMaterialRow==='function') window.addMaterialRow=addMaterialRow;
  if (typeof buildActHtml==='function') window.buildActHtml=buildActHtml;
  if (typeof deleteObjectRecord==='function') window.deleteObjectRecord=deleteObjectRecord;
  if (typeof getAllObjects==='function') window.getAllObjects=getAllObjects;
  if (typeof getCurrentObjectActData==='function') window.getCurrentObjectActData=getCurrentObjectActData;
  if (typeof getObjectById==='function') window.getObjectById=getObjectById;
  if (typeof getObjectIds==='function') window.getObjectIds=getObjectIds;
  if (typeof openObjectForm==='function') window.openObjectForm=openObjectForm;
  if (typeof readMaterialsFromTable==='function') window.readMaterialsFromTable=readMaterialsFromTable;
  if (typeof saveObjectIds==='function') window.saveObjectIds=saveObjectIds;
  if (typeof saveObjectRecord==='function') window.saveObjectRecord=saveObjectRecord;
  if (typeof setObjectFormLocked==='function') window.setObjectFormLocked=setObjectFormLocked;
  if (typeof setObjectFormLockedForRole==='function') window.setObjectFormLockedForRole=setObjectFormLockedForRole;
  if (typeof setObjectMaterialsEditable==='function') window.setObjectMaterialsEditable=setObjectMaterialsEditable;
} catch(_){}
