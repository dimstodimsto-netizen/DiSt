﻿# DiSt-mail-script-v2
# Silent email via Microsoft Outlook COM. JSON: {to, subject, body}
param([Parameter(Mandatory=$true)][string]$JsonPath)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
try {
  if (-not (Test-Path -LiteralPath $JsonPath)) { throw "Data file not found: $JsonPath" }
  $raw = Get-Content -LiteralPath $JsonPath -Raw -Encoding UTF8
  $data = $raw | ConvertFrom-Json
  if (-not $data.to) { throw "No recipient (to) specified." }
  $outlook = $null
  try { $outlook = [Runtime.InteropServices.Marshal]::GetActiveObject('Outlook.Application') } catch {
    try { $outlook = New-Object -ComObject Outlook.Application } catch {
      throw "Cannot start Outlook COM. Install Outlook desktop and sign in. Detail: $($_.Exception.Message)"
    }
  }
  try { $ns = $outlook.GetNamespace('MAPI'); $ns.Logon($null, $null, $false, $false) | Out-Null } catch {}
  $mail = $outlook.CreateItem(0)
  $mail.To = [string]$data.to
  $mail.Subject = [string]$data.subject
  $mail.Body = [string]$data.body
  $mail.Send()
  Start-Sleep -Milliseconds 800
  Write-Output 'OK'
  exit 0
} catch {
  $msg = $_.Exception.Message
  if (-not $msg) { $msg = "$_" }
  [Console]::Error.WriteLine($msg)
  exit 1
}
