/**
 * menu-nav-ui.js — app.js modularization step E
 * switchTab + browser-like menu history (back/forward).
 * Load AFTER app.js and role-auth-ui.js (uses tabsForRole, navigationState.currentRole, render* tabs, …).
 */
const navigationState = AppState.bind(['currentRole','currentTab','currentMaterialType','__objectsStatusFilter','menuNavigationHistory','menuNavigationHistoryIndex','currentUserFullName','currentUserStruktura','techAutoRefresh','suppressSessionTouch']);



// ============================================================
//  СВИТЧВАНЕ НА ТАБОВЕ
// ============================================================
function menuHistoryLocation(tab) {
  return {
    tab,
    objectsStatus: tab === 'objects' ? navigationState.__objectsStatusFilter : '',
    materialType: tab === 'warehouse' ? (navigationState.currentMaterialType || '') : ''
  };
}

function sameMenuHistoryLocation(a, b) {
  return !!a && !!b && a.tab === b.tab &&
    (a.objectsStatus || '') === (b.objectsStatus || '') &&
    (a.materialType || '') === (b.materialType || '');
}

function updateMenuHistoryButtons() {
  const back = document.getElementById('btnMenuBack');
  const forward = document.getElementById('btnMenuForward');
  if (back) back.disabled = !navigationState.currentRole || navigationState.menuNavigationHistoryIndex <= 0;
  if (forward) forward.disabled = !navigationState.currentRole || navigationState.menuNavigationHistoryIndex < 0 || navigationState.menuNavigationHistoryIndex >= navigationState.menuNavigationHistory.length - 1;
}

function resetMenuNavigationHistory() {
  navigationState.menuNavigationHistory = [];
  navigationState.menuNavigationHistoryIndex = -1;
  updateMenuHistoryButtons();
}

function recordMenuHistory(location, mode) {
  if (mode === 'none') return;
  if (mode === 'replace' && navigationState.menuNavigationHistoryIndex >= 0) {
    navigationState.menuNavigationHistory[navigationState.menuNavigationHistoryIndex] = location;
    updateMenuHistoryButtons();
    return;
  }
  const current = navigationState.menuNavigationHistory[navigationState.menuNavigationHistoryIndex];
  if (sameMenuHistoryLocation(current, location)) {
    updateMenuHistoryButtons();
    return;
  }
  navigationState.menuNavigationHistory = navigationState.menuNavigationHistory.slice(0, navigationState.menuNavigationHistoryIndex + 1);
  navigationState.menuNavigationHistory.push(location);
  if (navigationState.menuNavigationHistory.length > 80) navigationState.menuNavigationHistory.shift();
  navigationState.menuNavigationHistoryIndex = navigationState.menuNavigationHistory.length - 1;
  updateMenuHistoryButtons();
}

function navigateMenuHistory(direction) {
  if (!navigationState.currentRole) return;
  const targetIndex = navigationState.menuNavigationHistoryIndex + direction;
  if (targetIndex < 0 || targetIndex >= navigationState.menuNavigationHistory.length) return;
  const target = navigationState.menuNavigationHistory[targetIndex];
  if (!target || !tabsForRole(navigationState.currentRole).includes(target.tab)) return;
  navigationState.menuNavigationHistoryIndex = targetIndex;
  if (target.tab === 'objects' && target.objectsStatus) navigationState.__objectsStatusFilter = target.objectsStatus;
  if (target.tab === 'warehouse') navigationState.currentMaterialType = target.materialType || null;
  ['warehouseDropdownContent', 'objectsDropdownContent', 'warehouseMgmtDropdownContent', 'adminDropdownContent'].forEach(id => {
    const dropdown = document.getElementById(id);
    if (dropdown) dropdown.classList.remove('show');
  });
  switchTab(target.tab, { historyMode: 'none' });
  updateMenuHistoryButtons();
}

function switchTab(tab, options) {
  if (navigationState.currentRole && !tabsForRole(navigationState.currentRole).includes(tab)) return;
  options = options || {};
  recordMenuHistory(menuHistoryLocation(tab), options.historyMode || 'push');
  navigationState.currentTab = tab;
  
  document.getElementById('tabSubmit').classList.toggle('active', tab === 'submit');
  document.getElementById('tabMyRequests').classList.toggle('active', tab === 'myRequests');
  document.getElementById('tabMyMaterials').classList.toggle('active', tab === 'myMaterials');
  document.getElementById('tabRequiredMaterials').classList.toggle('active', tab === 'requiredMaterials');
  document.getElementById('tabSearch').classList.toggle('active', tab === 'search');
  document.getElementById('tabAll').classList.toggle('active', tab === 'all');
  document.getElementById('tabMaterialsReport').classList.toggle('active', tab === 'materialsReport');
  const whMatTab = document.getElementById('tabWhMaterialsReport');
  if (whMatTab) whMatTab.classList.toggle('active', tab === 'whMaterialsReport');
  document.getElementById('tabTechnicians').classList.toggle('active', tab === 'technicians');
  document.getElementById('tabObjects').classList.toggle('active', tab === 'objects');
  document.getElementById('tabWarehouse').classList.toggle('active', tab === 'warehouse');
  document.getElementById('tabMaterialsList').classList.toggle('active', tab === 'materialsList');
  document.getElementById('tabWarehouseSanitaryRequests').classList.toggle('active', tab === 'warehouseSanitaryRequests');
  document.getElementById('tabWarehouseOfficeRequests').classList.toggle('active', tab === 'warehouseOfficeRequests');
  document.getElementById('tabSanitaryMaterialsList').classList.toggle('active', tab === 'sanitaryMaterialsList');
  document.getElementById('tabOfficeMaterialsList').classList.toggle('active', tab === 'officeMaterialsList');
  const whMgmtBtn = document.getElementById('tabWarehouseMgmt');
  if (whMgmtBtn) {
    const whMgmtActive = ['warehouseSanitaryRequests','warehouseOfficeRequests','sanitaryMaterialsList','officeMaterialsList','whMaterialsReport'].includes(tab);
    whMgmtBtn.classList.toggle('active', whMgmtActive);
  }
  document.getElementById('tabServer').classList.toggle('active', tab === 'server');
  document.getElementById('tabUsers').classList.toggle('active', tab === 'users');
  const tabLogsEl = document.getElementById('tabLogs');
  if (tabLogsEl) tabLogsEl.classList.toggle('active', tab === 'logs');
  const tabAgentEl = document.getElementById('tabAgent');
  if (tabAgentEl) tabAgentEl.classList.toggle('active', tab === 'agent');
  const tabMaterialLocksEl=document.getElementById('tabMaterialLocks');
  if(tabMaterialLocksEl) tabMaterialLocksEl.classList.toggle('active', tab === 'materialLocks');
  const tabMaintenanceMaterialsEl = document.getElementById('tabMaintenanceMaterials');
  if (tabMaintenanceMaterialsEl) tabMaintenanceMaterialsEl.classList.toggle('active', tab === 'maintenanceMaterials');
  const tabAdminEl = document.getElementById('tabAdmin');
  if (tabAdminEl) tabAdminEl.classList.toggle('active', tab === 'server' || tab === 'users' || tab === 'logs' || tab === 'materialLocks' || tab === 'maintenanceMaterials' || tab === 'agent');
  
  document.getElementById('submitCard').style.display = tab === 'submit' ? 'block' : 'none';
  document.getElementById('monthlyPanel').style.display = tab === 'submit' ? 'block' : 'none';
  if (tab === 'submit' && navigationState.currentUserFullName && !$('sZayavitel').value.trim()) {
    $('sZayavitel').value = navigationState.currentUserFullName;
  }
  // АВТОМАТИЧНО ПОПЪЛВАНЕ НА СТРУКТУРАТА ПРИ СМЯНА НА ТАБ
  if (tab === 'submit' && navigationState.currentUserStruktura && $('sStruktura').value === '' && $('sStrukturaOther').style.display === 'none') {
    setSelectValueWithFallback($('sStruktura'), $('sStrukturaOther'), navigationState.currentUserStruktura);
  }
  if (tab === 'submit') applyStrukturaLockUI();
  
  document.getElementById('myRequestsCard').style.display = tab === 'myRequests' ? 'block' : 'none';
  document.getElementById('myMaterialsCard').style.display = tab === 'myMaterials' ? 'block' : 'none';
  document.getElementById('requiredMaterialsCard').style.display = tab === 'requiredMaterials' ? 'block' : 'none';
  document.getElementById('searchCard').style.display = tab === 'search' ? 'block' : 'none';
  document.getElementById('allCard').style.display = tab === 'all' ? 'block' : 'none';
  document.getElementById('materialsReportCard').style.display = tab === 'materialsReport' ? 'block' : 'none';
  const whMatCard = document.getElementById('whMaterialsReportCard');
  if (whMatCard) whMatCard.style.display = tab === 'whMaterialsReport' ? 'block' : 'none';
  document.getElementById('techniciansCard').style.display = tab === 'technicians' ? 'block' : 'none';
  document.getElementById('objectsCard').style.display = tab === 'objects' ? 'block' : 'none';
  document.getElementById('warehouseCard').style.display = tab === 'warehouse' ? 'block' : 'none';
  document.getElementById('materialsListCard').style.display = tab === 'materialsList' ? 'block' : 'none';
  document.getElementById('warehouseSanitaryRequestsCard').style.display = tab === 'warehouseSanitaryRequests' ? 'block' : 'none';
  document.getElementById('warehouseOfficeRequestsCard').style.display = tab === 'warehouseOfficeRequests' ? 'block' : 'none';
  document.getElementById('sanitaryMaterialsListCard').style.display = tab === 'sanitaryMaterialsList' ? 'block' : 'none';
  document.getElementById('officeMaterialsListCard').style.display = tab === 'officeMaterialsList' ? 'block' : 'none';
  document.getElementById('serverCard').style.display = tab === 'server' ? 'block' : 'none';
  document.getElementById('usersCard').style.display = tab === 'users' ? 'block' : 'none';
  const logsCard = document.getElementById('logsCard');
  if (logsCard) logsCard.style.display = tab === 'logs' ? 'block' : 'none';
  const agentCard = document.getElementById('agentCard');
  if (agentCard) agentCard.style.display = tab === 'agent' ? 'block' : 'none';
  const materialLocksCard=document.getElementById('materialLocksCard');
  if(materialLocksCard) materialLocksCard.style.display=tab==='materialLocks'?'block':'none';
  const maintenanceMaterialsCard = document.getElementById('maintenanceMaterialsCard');
  if (maintenanceMaterialsCard) maintenanceMaterialsCard.style.display = tab === 'maintenanceMaterials' ? 'block' : 'none';
  document.getElementById('recordCard').style.display = 'none';

  invalidateRecordsCache();
  
  if (navigationState.techAutoRefresh) { clearInterval(navigationState.techAutoRefresh); navigationState.techAutoRefresh = null; }
  
  // Рендиране на съответния таб
  if (tab === 'submit') renderMonthlyPanel();
  else if (tab === 'myRequests') renderMyRequests();
  else if (tab === 'myMaterials') renderMyMaterials();
  else if (tab === 'requiredMaterials') renderRequiredMaterials();
  else if (tab === 'search') { /* празно */ }
  else if (tab === 'all') renderAllTable();
  else if (tab === 'materialsReport') renderMaterialsReport();
  else if (tab === 'whMaterialsReport') renderWhMaterialsReport();
  else if (tab === 'technicians') renderTechniciansTable();
  else if (tab === 'objects') renderObjectsList();
  else if (tab === 'materialLocks') renderMaterialLocksTab();
  else if (tab === 'maintenanceMaterials') renderMaintenanceMaterials();
  else if (tab === 'warehouse') {
    const canSubmitWh = navigationState.currentRole !== 'warehouse';
    $('whFormWrap').style.display = canSubmitWh ? '' : 'none';
    const _whZabH = document.getElementById('whZabelezkaHeader');
    if (_whZabH) _whZabH.style.display = 'none';
    // При потребителите, които подават заявки, не се показва архивът
    // с вече подадените заявки. Той остава достъпен за Склад/Администратор.
    const whListWrap = $('whListWrap');
    if (whListWrap) whListWrap.style.display = navigationState.currentRole === 'submitter' ? 'none' : '';
    if (canSubmitWh) {
      if (!$('whMaterialsTableBody').children.length) resetWhForm();
      if (navigationState.currentUserFullName && !$('whZayavitel').value.trim()) $('whZayavitel').value = navigationState.currentUserFullName;
      if (navigationState.currentUserStruktura && $('whStruktura').value === '' && $('whStrukturaOther').style.display === 'none') {
        setSelectValueWithFallback($('whStruktura'), $('whStrukturaOther'), navigationState.currentUserStruktura);
      }
      // Обновяване на селектите за материали при влизане в таба
      populateMaterialSelects();
      
      // Обновяване на заглавието според избрания тип материал
      const whFormTitle = $('whFormTitle');
      if (navigationState.currentMaterialType === 'office') {
        whFormTitle.textContent = 'Нова заявка за канцеларски материали';
      } else if (navigationState.currentMaterialType === 'sanitary') {
        whFormTitle.textContent = 'Нова заявка за санитарни материали';
      } else {
        whFormTitle.textContent = 'Нова заявка за материали';
      }
    }
    renderWarehouseTable();
    applyMaterialSubmissionLockUI().then(function() {
      return renderWhLastRequestPanel();
    }).catch(function() {
      try { renderWhLastRequestPanel(); } catch (_) {}
    });
  } else if (tab === 'materialsList') renderMaterialsList();
  else if (tab === 'warehouseSanitaryRequests') renderWarehouseSanitaryTable();
  else if (tab === 'warehouseOfficeRequests') renderWarehouseOfficeTable();
  else if (tab === 'sanitaryMaterialsList') renderSanitaryMaterialsList();
  else if (tab === 'officeMaterialsList') renderOfficeMaterialsList();
  else if (tab === 'server') window.renderServerTab();
  else if (tab === 'users') renderUsersTab();
  else if (tab === 'logs') window.renderLogsTab();
  else if (tab === 'agent' && typeof window.renderAgentTab === 'function') window.renderAgentTab();
  else if (tab === 'materialLocks') renderMaterialLocksTab();

  // Авто-обновяване на 45 сек (по-леко натоварване при много отворени клиенти)
  // Фоновите заявки НЕ удължават сесията на заявител (30 мин неактивност).
  if (['technicians', 'all', 'submit', 'warehouse', 'myRequests', 'myMaterials', 'materialsList', 'warehouseSanitaryRequests', 'warehouseOfficeRequests', 'sanitaryMaterialsList', 'officeMaterialsList'].includes(tab)) {
    navigationState.techAutoRefresh = setInterval(async () => {
      if (navigationState.currentTab !== tab) return;
      navigationState.suppressSessionTouch = true;

      // --- Запазваме позицията на скрола и фокусираното поле, защото
      // render-функциите по-долу временно събарят и пресъздават DOM
      // (tbody.innerHTML = ''), което кара браузъра да "клампне" scrollY
      // към 0 (прегъва липсваща височина) => видимо премигване и скок горе.
      const __scrollY = window.scrollY;
      const __active = document.activeElement;
      const __activeId = (__active && __active.id) ? __active.id : null;
      const __selStart = (__activeId && typeof __active.selectionStart === 'number') ? __active.selectionStart : null;
      const __selEnd = (__activeId && typeof __active.selectionEnd === 'number') ? __active.selectionEnd : null;

      // Ако потребителят точно в момента пише в поле (има избран текст/каре
      // във input или textarea), прескачаме този цикъл на обновяване изцяло —
      // по-добре пропуснат refresh, отколкото изтрит текст или скочен курсор.
      const __typing = __active && (__active.tagName === 'INPUT' || __active.tagName === 'TEXTAREA')
        && typeof __active.value === 'string' && __active.value.length > 0
        && document.activeElement === __active;
      if (__typing) { navigationState.suppressSessionTouch = false; return; }

      try {
        const __soft = { softRefresh: true, background: true };
        if (tab === 'submit') await renderMonthlyPanel(__soft);
        else if (tab === 'myRequests') await renderMyRequests(__soft);
        else if (tab === 'myMaterials') await renderMyMaterials(__soft);
        else if (tab === 'all') await renderAllTable(__soft);
        else if (tab === 'technicians') {
          try { await renderTechniciansTable(__soft); }
          catch (e) { console.warn('tech soft refresh:', e); }
        }
        else if (tab === 'warehouse') {
          await renderWarehouseTable(__soft);
          populateMaterialSelects();
          await applyMaterialSubmissionLockUI();
          try { await renderWhLastRequestPanel(__soft); } catch (_) {}
        }
        else if (tab === 'materialsList') await renderMaterialsList(__soft);
        else if (tab === 'warehouseSanitaryRequests') await renderWarehouseSanitaryTable(__soft);
        else if (tab === 'warehouseOfficeRequests') await renderWarehouseOfficeTable(__soft);
        else if (tab === 'sanitaryMaterialsList') await renderSanitaryMaterialsList(__soft);
        else if (tab === 'officeMaterialsList') await renderOfficeMaterialsList(__soft);
      } catch (e) {
        console.warn('Auto-refresh error:', e);
      } finally {
        navigationState.suppressSessionTouch = false;
        // Възстановяваме скрола след като браузърът е преизчислил оформлението
        // (два rAF-а — първият хваща следващия layout pass, вторият е буфер
        // при по-бавно рисуване на големи таблици).
        requestAnimationFrame(() => {
          requestAnimationFrame(() => {
            if (Math.abs(window.scrollY - __scrollY) > 1) {
              window.scrollTo({ top: __scrollY, left: 0, behavior: 'instant' in window ? 'instant' : 'auto' });
            }
            if (__activeId) {
              const el = document.getElementById(__activeId);
              if (el && document.activeElement !== el) {
                try {
                  el.focus({ preventScroll: true });
                  if (__selStart != null && typeof el.setSelectionRange === 'function') {
                    el.setSelectionRange(__selStart, __selEnd);
                  }
                } catch (_) {}
              }
            }
          });
        });
      }
    }, 60000);
  }
}

// ---- Menu history buttons ----
document.getElementById('btnMenuBack')?.addEventListener('click', () => navigateMenuHistory(-1));
document.getElementById('btnMenuForward')?.addEventListener('click', () => navigateMenuHistory(1));

/* window exports */
try {
  window.menuNavigationHistory = navigationState.menuNavigationHistory;
  window.menuNavigationHistoryIndex = navigationState.menuNavigationHistoryIndex;
  window.menuHistoryLocation = menuHistoryLocation;
  window.sameMenuHistoryLocation = sameMenuHistoryLocation;
  window.updateMenuHistoryButtons = updateMenuHistoryButtons;
  window.resetMenuNavigationHistory = resetMenuNavigationHistory;
  window.recordMenuHistory = recordMenuHistory;
  window.navigateMenuHistory = navigateMenuHistory;
  window.switchTab = switchTab;
} catch (_) {}
