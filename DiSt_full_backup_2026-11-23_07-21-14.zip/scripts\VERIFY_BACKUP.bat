@echo off
setlocal
cd /d "%~dp0.."
if "%~1"=="" (
  echo Usage: VERIFY_BACKUP.bat "data\backups\DiSt_full_backup_YYYY-MM-DD_HH-MM-SS.zip"
  exit /b 2
)
node "%~dp0VERIFY_BACKUP.js" "%~1"
exit /b %ERRORLEVEL%
