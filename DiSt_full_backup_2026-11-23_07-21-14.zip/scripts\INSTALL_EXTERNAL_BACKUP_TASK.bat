@echo off
setlocal
cd /d "%~dp0"
set "JOB=DiSt_ExternalBackup"
set "BAT=%~dp0BACKUP_EXTERNAL.bat"
if not exist "%BAT%" echo ERROR: BACKUP_EXTERNAL.bat missing&pause&exit /b 1
schtasks /Create /F /TN "%JOB%" /SC HOURLY /MO 6 /RL LIMITED /TR "\"%BAT%\""
if errorlevel 1 (
  echo FAILED. Run this file as Administrator.
  pause
  exit /b 1
)
echo.
echo OK: %JOB% will run every 6 hours.
echo Configure scripts\BACKUP_TARGET.txt before the first run.
echo.
pause
