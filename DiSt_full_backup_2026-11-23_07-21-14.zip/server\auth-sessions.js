'use strict';

/**
 * server/auth-sessions.js — Фаза 2б модулност
 * Сесии: създаване, getSession, requireAdmin/Auth, cookie, heartbeat online window.
 * Поведението е същото като преди изнасянето — само структурата е разделена.
 *
 * deps: {
 *   stmtSessionUpsert, stmtSessionGet, stmtSessionDelete,
 *   stmtSessionDeleteExpired, stmtSessionAll,
 *   sendJSON, crypto
 * }
 */

function createAuthSessionsModule(deps) {
  const {
    stmtSessionUpsert,
    stmtSessionGet,
    stmtSessionDelete,
    stmtSessionDeleteExpired,
    stmtSessionAll,
    sendJSON,
    crypto
  } = deps;
  const writeSystemLog = typeof deps.writeSystemLog === 'function'
    ? deps.writeSystemLog
    : function () {};

  function logSessionExpired(sess, token) {
    try {
      const u = (sess && sess.username) || '?';
      const r = (sess && sess.role) || '?';
      const msg = 'Сесията изтече: ' + u + ' (' + r + ') — необходим е нов вход';
      writeSystemLog('info', 'auth', msg, { username: u, meta: { role: r, reason: 'ttl_expired' } });
      console.log('ℹ️  ' + msg);
    } catch (_) {}
  }

  const SUBMITTER_SESSION_TTL_MS = 30 * 60 * 1000;
  const STAFF_SESSION_TTL_MS = 12 * 60 * 60 * 1000;
  const STAFF_SESSION_ROLES = new Set(['admin', 'technician', 'warehouse']);
  // observer: като заявител — 30 мин + sliding при активност
  const SESSION_SLIDE_MIN_MS = 60 * 1000;
  const HEARTBEAT_ONLINE_MS = 3 * 60 * 1000;

  const sessions = new Map();
  const disconnectedSessions = new Set();

  function sessionTtlForRole(role) {
    return STAFF_SESSION_ROLES.has(role) ? STAFF_SESSION_TTL_MS : SUBMITTER_SESSION_TTL_MS;
  }

  function persistSession(token, sess) {
    try {
      stmtSessionUpsert.run(
        token,
        sess.userId || '',
        sess.username || '',
        sess.name || '',
        sess.role || '',
        sess.expiresAt === null || sess.expiresAt === undefined ? null : Number(sess.expiresAt)
      );
    } catch (e) {
      console.error('⚠ Неуспешен запис на сесия в базата:', e.message);
    }
  }

  function removePersistedSession(token) {
    try { stmtSessionDelete.run(token); } catch (_) {}
  }

  function loadSessionsFromDb() {
    const now = Date.now();
    let loaded = 0;
    let expired = 0;
    try {
      const rows = stmtSessionAll.all();
      for (const row of rows) {
        const expiresAt = row.expires_at === null || row.expires_at === undefined ? null : Number(row.expires_at);
        if (expiresAt !== null && now >= expiresAt) {
          logSessionExpired({ username: row.username, role: row.role }, row.token);
          try { stmtSessionDelete.run(row.token); } catch (_) {}
          expired++;
          continue;
        }
        sessions.set(row.token, {
          userId: row.user_id,
          username: row.username,
          name: row.name || '',
          role: row.role,
          expiresAt,
          lastSeenAt: now
        });
        loaded++;
      }
    } catch (e) {
      console.error('⚠ Неуспешно зареждане на сесии от базата:', e.message);
    }
    if (loaded || expired) {
      console.log('ℹ️  Сесии от базата: ' + loaded + ' активни' + (expired ? ', ' + expired + ' изтекли (изчистени)' : '') + '.');
    }
  }

  function createSession(user) {
    const token = crypto.randomBytes(24).toString('hex');
    const now = Date.now();
    const sess = {
      userId: user.id,
      username: user.username,
      name: user.name || '',
      role: user.role,
      createdAt: now,
      lastSeenAt: now,
      expiresAt: now + sessionTtlForRole(user.role)
    };
    sessions.set(token, sess);
    disconnectedSessions.delete(token);
    persistSession(token, sess);
    return token;
  }

  function parseCookies(req) {
    const raw = String(req.headers.cookie || '');
    const out = {};
    raw.split(';').forEach(part => {
      const i = part.indexOf('=');
      if (i <= 0) return;
      const k = part.slice(0, i).trim();
      const v = part.slice(i + 1).trim();
      try { out[k] = decodeURIComponent(v); } catch (_) { out[k] = v; }
    });
    return out;
  }

  function getSessionToken(req) {
    const auth = req.headers['authorization'] || '';
    if (auth.startsWith('Bearer ')) return auth.slice(7);
    const cookies = parseCookies(req);
    if (cookies.zayavki_session) return cookies.zayavki_session;
    return null;
  }

  function getSession(req, opts) {
    const slide = !opts || opts.slide !== false;
    const token = getSessionToken(req);
    if (!token) return null;

    let sess = sessions.get(token);
    if (!sess) {
      try {
        const row = stmtSessionGet.get(token);
        if (row) {
          const expiresAt = row.expires_at === null || row.expires_at === undefined ? null : Number(row.expires_at);
          if (expiresAt !== null && Date.now() >= expiresAt) {
            logSessionExpired({ username: row.username, role: row.role }, token);
            removePersistedSession(token);
            return null;
          }
          sess = {
            userId: row.user_id,
            username: row.username,
            name: row.name || '',
            role: row.role,
            expiresAt,
            lastSeenAt: Date.now()
          };
          sessions.set(token, sess);
        }
      } catch (_) {}
    }
    if (!sess) return null;

    if (sess.expiresAt === null || sess.expiresAt === undefined) {
      sess.expiresAt = Date.now() + sessionTtlForRole(sess.role);
      sessions.set(token, sess);
      persistSession(token, sess);
    }

    if (sess.expiresAt !== null && Date.now() >= sess.expiresAt) {
      logSessionExpired(sess, token);
      sessions.delete(token);
      disconnectedSessions.delete(token);
      removePersistedSession(token);
      return null;
    }

    // Заявител/наблюдател: удължаване САМО при изричен хедър X-User-Activity: 1
    // (реално действие от клиента). Фоново опресняване / heartbeat / peek НЕ
    // подновяват 30-мин сесията — отворен таб без действие води до изтичане.
    const isShortRole = !STAFF_SESSION_ROLES.has(sess.role);
    const userActivity = !!(req && req.headers && String(req.headers['x-user-activity'] || '') === '1');
    const canSlideExpiry = slide && (!isShortRole || userActivity);

    if (canSlideExpiry && sess.expiresAt !== null && isShortRole) {
      const ttl = sessionTtlForRole(sess.role);
      const remaining = sess.expiresAt - Date.now();
      if (remaining < ttl - SESSION_SLIDE_MIN_MS) {
        sess.expiresAt = Date.now() + ttl;
        sessions.set(token, sess);
        persistSession(token, sess);
        if (req && req._resForSessionSlide) {
          setSessionCookie(req._resForSessionSlide, token, sess.expiresAt, req);
        }
      }
    }
    // lastSeen: staff при slide; short role — само при реална активност (за онлайн статус)
    if (slide && (!isShortRole || userActivity)) {
      sess.lastSeenAt = Date.now();
      sessions.set(token, sess);
    }
    return sess;
  }

  function envFlagTrue(name) {
    const v = String(process.env[name] || '').trim().toLowerCase();
    return v === '1' || v === 'true' || v === 'yes' || v === 'on';
  }

  /** Secure cookie: COOKIE_SECURE=1 или TRUST_PROXY=1 + X-Forwarded-Proto: https */
  function cookieShouldBeSecure(req) {
    if (envFlagTrue('COOKIE_SECURE')) return true;
    if (!envFlagTrue('TRUST_PROXY')) return false;
    const r = req || null;
    if (!r || !r.headers) return false;
    const xp = String(r.headers['x-forwarded-proto'] || '').split(',')[0].trim().toLowerCase();
    return xp === 'https';
  }

  function buildSessionCookieHeader(token, maxAge, secure) {
    let h = 'zayavki_session=' + encodeURIComponent(token || '') +
      '; Path=/; HttpOnly; SameSite=Lax; Max-Age=' + maxAge;
    if (secure) h += '; Secure';
    return h;
  }

  function setSessionCookie(res, token, expiresAt, req) {
    const maxAge = expiresAt === null || expiresAt === undefined
      ? Math.ceil(STAFF_SESSION_TTL_MS / 1000)
      : Math.max(1, Math.ceil((expiresAt - Date.now()) / 1000));
    const secure = cookieShouldBeSecure(req || (res && res._req) || null);
    res.setHeader('Set-Cookie', buildSessionCookieHeader(token, maxAge, secure));
  }

  function clearSessionCookie(res, req) {
    const secure = cookieShouldBeSecure(req || (res && res._req) || null);
    res.setHeader('Set-Cookie', buildSessionCookieHeader('', 0, secure));
    // При изход инструктираме браузъра да изчисти данни, кеширани за origin-а.
    res.setHeader('Clear-Site-Data', '"cache", "cookies", "storage"');
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
  }

  function requireAdmin(req, res) {
    req._resForSessionSlide = res;
    const sess = getSession(req);
    if (!sess || sess.role !== 'admin') {
      sendJSON(res, 401, { error: 'Нужен е администраторски вход.' });
      return null;
    }
    return sess;
  }

  function requireAuth(req, res) {
    req._resForSessionSlide = res;
    // Фоновите auto-refresh заявки (45-сек опресняване на таб, докато потребителят
    // не пипа нищо) идват с хедър X-Background-Refresh и НЕ трябва да плъзгат
    // 30-минутната неактивна сесия на заявител/наблюдател — иначе отворен таб
    // държи сесията "жива" безкрайно, независимо от реална активност (виж
    // панел "Активни сесии": хронометърът се връщаше на пълно при всяка проверка).
    const isBackground = req && req.headers && req.headers['x-background-refresh'] === '1';
    const sess = getSession(req, isBackground ? { slide: false } : undefined);
    if (!sess) {
      sendJSON(res, 401, { error: 'Нужен е вход в приложението.' });
      return null;
    }
    return sess;
  }

  function touchHeartbeat(token, sess) {
    if (!token || !sess) return;
    if (disconnectedSessions.has(token)) {
      disconnectedSessions.delete(token);
      writeSystemLog('info', 'auth', 'Връзката на потребителя е възстановена: ' + (sess.username || '?'), {
        username: sess.username || '', meta: { role: sess.role || '', reason: 'heartbeat_resumed' }
      });
    }
    sess.lastSeenAt = Date.now();
    sessions.set(token, sess);
  }

  function listActiveSessions(now, currentToken) {
    const byToken = new Map();
    for (const [token, se] of sessions.entries()) {
      if (!se) continue;
      if (se.expiresAt != null && now >= Number(se.expiresAt)) continue;
      byToken.set(token, se);
    }
    try {
      const rows = stmtSessionAll.all();
      for (const row of rows) {
        if (!row || !row.token) continue;
        const exp = row.expires_at == null ? null : Number(row.expires_at);
        if (exp != null && now >= exp) continue;
        if (!byToken.has(row.token)) {
          byToken.set(row.token, {
            userId: row.user_id,
            username: row.username,
            name: row.name || '',
            role: row.role,
            expiresAt: exp,
            lastSeenAt: null
          });
        }
      }
    } catch (_) {}

    const list = [];
    for (const [token, se] of byToken.entries()) {
      const exp = se.expiresAt == null ? null : Number(se.expiresAt);
      const created = se.createdAt == null ? null : Number(se.createdAt);
      const lastSeen = se.lastSeenAt == null ? null : Number(se.lastSeenAt);
      const online = lastSeen != null && (now - lastSeen) <= HEARTBEAT_ONLINE_MS;
      list.push({
        token: token,
        username: se.username || '',
        name: se.name || '',
        role: se.role || '',
        createdAt: created,
        lastSeenAt: lastSeen,
        online: online,
        expiresAt: exp,
        remainingMs: exp != null ? Math.max(0, exp - now) : null,
        isCurrent: !!(currentToken && token === currentToken)
      });
    }
    list.sort((a, b) => {
      if (a.isCurrent !== b.isCurrent) return a.isCurrent ? -1 : 1;
      if (!!a.online !== !!b.online) return a.online ? -1 : 1;
      return String(a.username).localeCompare(String(b.username), 'bg');
    });
    return list;
  }

  function destroySession(token) {
    if (!token) return;
    sessions.delete(token);
    disconnectedSessions.delete(token);
    removePersistedSession(token);
  }

  function startConnectionMonitor() {
    const timer = setInterval(() => {
      const now = Date.now();
      for (const [token, sess] of sessions) {
        const lastSeenAt = Number(sess && sess.lastSeenAt) || 0;
        if (!lastSeenAt || now - lastSeenAt < HEARTBEAT_ONLINE_MS || disconnectedSessions.has(token)) continue;
        disconnectedSessions.add(token);
        writeSystemLog('warn', 'auth', 'Връзката на потребителя е прекъсната: ' + (sess.username || '?') + ' — липсва heartbeat повече от 3 минути', {
          username: sess.username || '',
          meta: { role: sess.role || '', reason: 'heartbeat_timeout', lastHeartbeatAt: new Date(lastSeenAt).toISOString() }
        });
      }
    }, 60 * 1000);
    if (timer && typeof timer.unref === 'function') timer.unref();
  }

  function startCleanupInterval() {
    setInterval(() => {
      const now = Date.now();
      for (const [token, sess] of sessions) {
        if (sess.expiresAt !== null && now >= sess.expiresAt) {
          logSessionExpired(sess, token);
          sessions.delete(token);
          disconnectedSessions.delete(token);
          removePersistedSession(token);
        }
      }
      try { stmtSessionDeleteExpired.run(now); } catch (_) {}
    }, 15 * 60 * 1000);
  }

  loadSessionsFromDb();
  startCleanupInterval();
  startConnectionMonitor();

  return {
    SUBMITTER_SESSION_TTL_MS,
    STAFF_SESSION_TTL_MS,
    HEARTBEAT_ONLINE_MS,
    sessions,
    createSession,
    getSessionToken,
    getSession,
    setSessionCookie,
    clearSessionCookie,
    requireAdmin,
    requireAuth,
    touchHeartbeat,
    listActiveSessions,
    destroySession,
    sessionTtlForRole,
    STAFF_SESSION_ROLES
  };
}

module.exports = { createAuthSessionsModule };
