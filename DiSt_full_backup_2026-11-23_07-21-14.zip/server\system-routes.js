'use strict';
/**
 * verification / unlock / license
 * Unlock: еднакво 401 съобщение при грешна парола и грешен код.
 */
function createSystemRoutes(deps) {
  const {
    requireAdmin, sendJSON, readJsonFromRequest, getClientIp,
    checkLoginLock, registerLoginFailure, registerLoginSuccess,
    getUserByUsernameServer, verifyUserPasswordAsync, verifyProgramCode,
    createSession, sessions, setSessionCookie, writeSystemLog,
    getVerificationState, changeVerificationCode, getLicenseContact, kvSet
  } = deps;
  return async function handleSystemRoute(req, res, parsed, pathname) {
    if (pathname === '/api/system/verification-status' && req.method === 'GET') {
      sendJSON(res, 200, getVerificationState(true));
      return true;
    }


    // ---- API: отключване при заключена инсталация (админ + код, без предварителна сесия) ----
    if (pathname === '/api/system/unlock' && req.method === 'POST') {
      const unlockIp = getClientIp(req);
      const parsedBody = await readJsonFromRequest(req, res, { emptyOk: true });
      if (!parsedBody) return true;
      const username = String(parsedBody.username || '').trim();
      const password = String(parsedBody.password || '');
      const code = String(parsedBody.code || '');
      if (!username || !password || !code) {
        sendJSON(res, 400, { error: 'Попълнете потребител, парола и верификационен код.' });
        return true;
      }
      const unlockLock = checkLoginLock(unlockIp, username);
      if (unlockLock.locked) {
        writeSystemLog('warn', 'auth', 'Блокиран опит за отключване (твърде много опити): ' + username, { username, ip: unlockIp });
        sendJSON(res, 429, { error: 'Твърде много грешни опити. Опитайте отново след ' + Math.ceil(unlockLock.secondsLeft / 60) + ' мин.' });
        return true;
      }
      const user = getUserByUsernameServer(username);
      const pwOk = await verifyUserPasswordAsync(user, password);
      if (!user || user.role !== 'admin' || !pwOk) {
        registerLoginFailure(unlockIp, username);
        writeSystemLog('warn', 'auth', 'Неуспешен опит за отключване: ' + username, { username, ip: unlockIp });
        sendJSON(res, 401, { error: 'Невалидни данни или нямате администраторски права.' });
        return true;
      }
      if (!verifyProgramCode(code)) {
        registerLoginFailure(unlockIp, username);
        writeSystemLog('warn', 'auth', 'Неуспешен опит за отключване (грешен код): ' + username, { username, ip: unlockIp });
        sendJSON(res, 401, { error: 'Невалидни данни или нямате администраторски права.' });
        return true;
      }
      registerLoginSuccess(unlockIp, username);
      const token = createSession(user);
      const session = sessions.get(token);
      setSessionCookie(res, token, session ? session.expiresAt : null);
      writeSystemLog('info', 'system', 'Инсталацията е отключена/активирана чрез верификационен код', {
        username: user.username,
        ip: getClientIp(req)
      });
      sendJSON(res, 200, {
        ok: true,
        token,
        username: user.username,
        name: user.name || '',
        role: user.role,
        struktura: user.struktura || '',
        expiresAt: session ? session.expiresAt : null,
        allowedMenus: user.role === 'observer' ? observerMenusForUser(user) : undefined,
        verification: getVerificationState(true)
      });
      return true;
    }

    // ---- API: потвърждаване на нов 60-дневен период ----
    if (pathname === '/api/system/verify' && req.method === 'POST') {
      const sess = requireAdmin(req, res);
      if (!sess) return true;
      const parsedBody = await readJsonFromRequest(req, res, { emptyOk: true });
      if (!parsedBody) return true;
      const code = String(parsedBody.code || '');
      if (!code) { sendJSON(res, 400, { error: 'Въведете верификационен код.' }); return true; }
      if (!verifyProgramCode(code)) { sendJSON(res, 401, { error: 'Невалиден верификационен код.' }); return true; }
      sendJSON(res, 200, { ok: true, verification: getVerificationState(true) });
      return true;
    }

    // ---- API: смяна на верификационен код (само admin + текущ код) ----
    if (pathname === '/api/system/change-verification-code' && req.method === 'POST') {
      const sess = requireAdmin(req, res);
      if (!sess) return true;
      const parsedBody = await readJsonFromRequest(req, res, { emptyOk: true });
      if (!parsedBody) return true;
      const currentCode = String(parsedBody.currentCode || '');
      const newCode = String(parsedBody.newCode || '');
      const confirmCode = String(parsedBody.confirmCode || '');
      if (!currentCode || !newCode) {
        sendJSON(res, 400, { error: 'Попълнете текущия и новия код.' });
        return true;
      }
      if (newCode !== confirmCode) {
        sendJSON(res, 400, { error: 'Новият код и потвърждението не съвпадат.' });
        return true;
      }
      const result = changeVerificationCode(currentCode, newCode);
      if (!result.ok) {
        sendJSON(res, 401, { error: result.error || 'Неуспешна смяна.' });
        return true;
      }
      writeSystemLog('warn', 'system', 'Администратор смени верификационния код', {
        username: sess.username,
        ip: getClientIp(req)
      });
      sendJSON(res, 200, { ok: true, message: 'Верификационният код е сменен. Запазете новия код на сигурно място.' });
      return true;
    }


    // ---- API: лиценз / контакт с автора ----
    if (pathname === '/api/system/license-contact' && req.method === 'GET') {
      sendJSON(res, 200, { text: getLicenseContact() });
      return true;
    }
    if (pathname === '/api/system/license-contact' && req.method === 'PUT') {
      const sess = requireAdmin(req, res);
      if (!sess) return true;
      const parsedBody = await readJsonFromRequest(req, res, { emptyOk: true });
      if (!parsedBody) return true;
      const text = String(parsedBody.text == null ? '' : parsedBody.text).trim().slice(0, 500);
      kvSet('settings:licenseContact', text);
      writeSystemLog('info', 'system', 'Обновен текст за лиценз/контакт с автора', { username: sess.username, ip: getClientIp(req) });
      sendJSON(res, 200, { ok: true, text: getLicenseContact() });
      return true;
    }

    // Глобално заключване на API след изтичане на верификационния период.
    return false;
  };
}
module.exports = { createSystemRoutes };
