'use strict';

const KEY = 'maintenance_materials';
const MAX_ITEMS = 1000;

function createMaintenanceMaterialsRoutes(deps) {
  const { requireAuth, sendJSON, readJsonFromRequest, kvGet, kvSet, crypto } = deps;

  function readCatalog() {
    try {
      const raw = kvGet(KEY);
      const parsed = raw == null ? [] : JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      return parsed.filter(x => x && typeof x === 'object').map(x => ({
        id: String(x.id || ''),
        name: String(x.name || '').trim(),
        merka: String(x.merka || '').trim(),
        active: x.active === true || x.active === 1
      })).filter(x => x.id && x.name).slice(0, MAX_ITEMS);
    } catch (_) {
      return [];
    }
  }

  function saveCatalog(items) {
    kvSet(KEY, JSON.stringify(items));
  }

  function cleanText(value, maxLength) {
    return String(value == null ? '' : value).trim().slice(0, maxLength);
  }

  return async function handleMaintenanceMaterialsRoute(req, res, parsed, pathname) {
    if (pathname !== '/api/maintenance-materials' && !pathname.startsWith('/api/maintenance-materials/')) return false;

    const sess = requireAuth(req, res);
    if (!sess) return true;
    if (sess.role !== 'admin' && sess.role !== 'technician') {
      sendJSON(res, 403, { error: 'Нямате достъп до каталога за материали за поддръжка.' });
      return true;
    }

    if (pathname === '/api/maintenance-materials' && req.method === 'GET') {
      const includeArchived = parsed.searchParams.get('includeArchived') === '1';
      if (includeArchived && sess.role !== 'admin') {
        sendJSON(res, 403, { error: 'Само администратор може да преглежда архивираните материали.' });
        return true;
      }
      const materials = readCatalog().filter(x => includeArchived || x.active);
      sendJSON(res, 200, { materials });
      return true;
    }

    if (pathname === '/api/maintenance-materials/import' && req.method === 'POST') {
      if (sess.role !== 'admin') {
        sendJSON(res, 403, { error: 'Само администратор може да импортира материали.' });
        return true;
      }
      const body = await readJsonFromRequest(req, res, { maxBytes: 1024 * 1024 });
      if (!body) return true;
      if (!Array.isArray(body.materials)) {
        sendJSON(res, 400, { error: 'Липсва списък с материали за импорт.' });
        return true;
      }
      if (body.materials.length > MAX_ITEMS) {
        sendJSON(res, 413, { error: 'Импортът е ограничен до ' + MAX_ITEMS + ' реда.' });
        return true;
      }
      const materials = readCatalog();
      const known = new Set(materials.map(x => x.name.toLocaleLowerCase('bg')));
      let added = 0, skipped = 0;
      for (const row of body.materials) {
        const name = cleanText(row && row.name, 120);
        const merka = cleanText(row && row.merka, 32);
        if (!name || known.has(name.toLocaleLowerCase('bg'))) { skipped++; continue; }
        if (materials.length >= MAX_ITEMS) {
          sendJSON(res, 413, { error: 'Каталогът е достигнал максималния брой материали.', added, skipped });
          return true;
        }
        materials.push({
          id: 'mm_' + Date.now().toString(36) + '_' + crypto.randomBytes(5).toString('hex'),
          name, merka, active: !(row && (row.active === false || row.active === 0))
        });
        known.add(name.toLocaleLowerCase('bg'));
        added++;
      }
      if (added) saveCatalog(materials);
      sendJSON(res, 200, { added, skipped });
      return true;
    }

    if (pathname === '/api/maintenance-materials' && req.method === 'POST') {
      if (sess.role !== 'admin') {
        sendJSON(res, 403, { error: 'Само администратор може да добавя материали.' });
        return true;
      }
      const body = await readJsonFromRequest(req, res, { maxBytes: 64 * 1024 });
      if (!body) return true;
      const name = cleanText(body.name, 120);
      const merka = cleanText(body.merka, 32);
      if (!name) {
        sendJSON(res, 400, { error: 'Въведете име на материала.' });
        return true;
      }
      const materials = readCatalog();
      if (materials.length >= MAX_ITEMS) {
        sendJSON(res, 413, { error: 'Каталогът е достигнал максималния брой материали.' });
        return true;
      }
      if (materials.some(x => x.name.toLocaleLowerCase('bg') === name.toLocaleLowerCase('bg'))) {
        sendJSON(res, 409, { error: 'Вече има материал с това име. Проверете и архивираните записи.' });
        return true;
      }
      const material = {
        id: 'mm_' + Date.now().toString(36) + '_' + crypto.randomBytes(5).toString('hex'),
        name,
        merka,
        active: true
      };
      materials.push(material);
      saveCatalog(materials);
      sendJSON(res, 201, { material });
      return true;
    }

    const match = pathname.match(/^\/api\/maintenance-materials\/([a-z0-9_-]+)$/i);
    if (match && (req.method === 'PUT' || req.method === 'DELETE')) {
      if (sess.role !== 'admin') {
        sendJSON(res, 403, { error: 'Само администратор може да променя каталога.' });
        return true;
      }
      const materials = readCatalog();
      const index = materials.findIndex(x => x.id === match[1]);
      if (index < 0) {
        sendJSON(res, 404, { error: 'Материалът не е намерен.' });
        return true;
      }
      if (req.method === 'DELETE') {
        if (parsed.searchParams.get('permanent') === '1') materials.splice(index, 1);
        else materials[index].active = false;
      } else {
        const body = await readJsonFromRequest(req, res, { maxBytes: 64 * 1024 });
        if (!body) return true;
        const name = cleanText(body.name, 120);
        if (!name) {
          sendJSON(res, 400, { error: 'Името на материала е задължително.' });
          return true;
        }
        if (materials.some((x, i) => i !== index && x.name.toLocaleLowerCase('bg') === name.toLocaleLowerCase('bg'))) {
          sendJSON(res, 409, { error: 'Вече има материал с това име.' });
          return true;
        }
        materials[index] = {
          ...materials[index],
          name,
          merka: cleanText(body.merka, 32),
          active: body.active === true || body.active === 1
        };
      }
      saveCatalog(materials);
      const permanentlyDeleted = req.method === 'DELETE' && parsed.searchParams.get('permanent') === '1';
      sendJSON(res, 200, { material: permanentlyDeleted ? null : materials[index], deleted: permanentlyDeleted });
      return true;
    }

    sendJSON(res, 405, { error: 'Методът не е разрешен.' });
    return true;
  };
}

module.exports = { createMaintenanceMaterialsRoutes };
