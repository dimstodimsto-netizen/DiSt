/**
 * warehouse-store.js — warehouse request storage helpers (modularity stage)
 * Load AFTER records-store.js (needs S), BEFORE or with app.js.
 */
function __whAuthFetch(url, options) {
  if (typeof authFetch === 'function') return authFetch(url, options);
  if (typeof window !== 'undefined' && typeof window.authFetch === 'function') return window.authFetch(url, options);
  return fetch(url, Object.assign({ credentials: 'same-origin', cache: 'no-store' }, options || {}));
}

async function getWhIds() {
  const r = await S.get('wh-index');
  if (!r || !r.value) return [];
  try {
    const parsed = JSON.parse(r.value);
    return Array.isArray(parsed) ? parsed : [];
  } catch(e) { return []; }
}

async function saveWhIds(ids) { await S.set('wh-index', JSON.stringify(ids)); }

// Отделен, самостоятелен брояч само за "Заявки за материали" - НЕ споделя
// номерацията с nextId() (заявки за ремонт). Номерът е поредният номер
// по ред на подаване в собствената база "wh-index", а не в records-index.
// Поддържа и стари id-та от типа "wh_5" (изважда числото от края), за да
// не се получи сблъсък при преминаване от стария към новия формат.
async function nextWhId() {
  const idx = await getWhIds();
  let max = 0;
  idx.forEach(id => {
    const m = String(id).match(/(\d+)$/);
    const n = m ? parseInt(m[1], 10) : NaN;
    if (!isNaN(n) && n > max) max = n;
  });
  return String(max + 1);
}

async function getWhById(id) {
  const r = await S.get('wh:' + id);
  if (!r || !r.value) return null;
  try { return JSON.parse(r.value); }
  catch(e){ return null; }
}

// Съвместимост със старите заявки: предишното поле zabelezka съдържаше
// „Отпуснато количество“. При новия формат двете полета са разделени.
function getReleasedQuantity(m) {
  if (!m) return '';
  // Само отделното поле „Отпуснато количество“ — НЕ ползваме забележката
  return String(m.otpusnatoKolichestvo == null ? '' : m.otpusnatoKolichestvo).trim();
}
function isValidReleasedQuantity(raw) {
  const v = String(raw == null ? '' : raw).trim();
  if (!v) return true; // празно е позволено (попълва се при Изпълни)
  return /^\d+([.,]\d+)?$/.test(v);
}
function normalizeWarehouseMaterial(m) {
  const out = Object.assign({}, m || {});
  // Винаги осигуряваме и двете полета.
  if (!Object.prototype.hasOwnProperty.call(out, 'zabelezka')) {
    out.zabelezka = '';
  }
  if (!Object.prototype.hasOwnProperty.call(out, 'otpusnatoKolichestvo')) {
    // Миграция САМО ако старото „zabelezka“ изглежда като количество (число).
    // Текстови бележки НЕ се местят в „Отпуснато количество“.
    const legacy = String(out.zabelezka == null ? '' : out.zabelezka).trim();
    if (legacy && /^\d+([.,]\d+)?$/.test(legacy)) {
      out.otpusnatoKolichestvo = legacy;
      out.zabelezka = '';
    } else {
      out.otpusnatoKolichestvo = '';
      // запазваме legacy текста в забележка
      out.zabelezka = legacy;
    }
  } else {
    out.otpusnatoKolichestvo = String(out.otpusnatoKolichestvo == null ? '' : out.otpusnatoKolichestvo).trim();
    out.zabelezka = String(out.zabelezka == null ? '' : out.zabelezka).trim();
  }
  return out;
}

function queryWhReleasedInputs() {
  return Array.from(document.querySelectorAll(
    '#whViewMaterialsBody .whview-released, #whViewMaterialsTable .whview-released, ' +
    '#whViewMaterialsBody .wh-view-released, #whViewMaterialsTable .wh-view-released'
  ));
}
function queryWhNoteInputs() {
  return Array.from(document.querySelectorAll(
    '#whViewMaterialsBody .whview-zabelezka, #whViewMaterialsTable .whview-zabelezka, ' +
    '#whViewMaterialsBody .wh-view-zabelezka, #whViewMaterialsTable .wh-view-zabelezka'
  ));
}

/** Прочита Отпуснато + Забележка от модала в rec.materials (без размесване). */

/**
 * Чете материалите от модала по КОЛОНИ (не по class разминаване):
 * 0=№ 1=Код 2=Материал 3=Мярка 4=Заявено 5=Отпуснато 6=Забележка
 */
window.readWhMaterialsFromModalRows = function readWhMaterialsFromModalRows() {
  const tbody = document.getElementById('whViewMaterialsBody');
  const out = [];
  if (!tbody) return out;
  Array.from(tbody.querySelectorAll('tr')).forEach(function (tr) {
    const c = tr.children;
    if (!c || c.length < 5) return;
    const text = function (el) { return el ? String(el.textContent || '').trim() : ''; };
    const inputVal = function (cell) {
      if (!cell) return '';
      const inp = cell.querySelector('input');
      return inp ? String(inp.value || '').trim() : text(cell);
    };
    const code = text(c[1]);
    out.push({
      code: (code === '—' ? '' : code),
      name: text(c[2]),
      merka: text(c[3]),
      kolichestvo: inputVal(c[4]),
      otpusnatoKolichestvo: inputVal(c[5]),
      zabelezka: inputVal(c[6])
    });
  });
  return out;
};

/** Записва Отпуснато + Забележка (и заявено за админ) от модала в rec.materials */
window.applyWhModalInputsToMaterials = function applyWhModalInputsToMaterials(rec) {
  if (!rec) return rec;
  const rows = readWhMaterialsFromModalRows();
  if (!Array.isArray(rec.materials)) rec.materials = [];
  rows.forEach(function (row, i) {
    if (!rec.materials[i]) rec.materials[i] = {};
    const m = rec.materials[i];
    if (row.code !== undefined) m.code = row.code;
    if (row.name) m.name = row.name;
    if (row.merka !== undefined) m.merka = row.merka;
    if (currentRole === 'admin' && row.kolichestvo !== undefined) m.kolichestvo = row.kolichestvo;
    // Критично: винаги от колона 5 / 6
    m.otpusnatoKolichestvo = row.otpusnatoKolichestvo;
    m.zabelezka = row.zabelezka;
  });
  return rec;
};

/** Празно „Отпуснато“ ← „Заявено“. Забележката НЕ се пипа. */
window.fillEmptyReleasedFromRequested = function fillEmptyReleasedFromRequested(materials) {
  if (!Array.isArray(materials)) return materials;
  materials.forEach(function (m) {
    if (!m) return;
    if (!String(m.otpusnatoKolichestvo == null ? '' : m.otpusnatoKolichestvo).trim()) {
      m.otpusnatoKolichestvo = String(m.kolichestvo == null ? '' : m.kolichestvo).trim();
    }
  });
  return materials;
};


function validateWhReleasedInputsOrToast() {
  const inputs = queryWhReleasedInputs();
  for (const inp of inputs) {
    const v = String(inp.value || '').trim();
    if (!isValidReleasedQuantity(v)) {
      toast('❌ „Отпуснато количество“ трябва да е число (само цифри, напр. 5 или 2,5).');
      try { inp.style.borderColor = 'var(--danger, #c0392b)'; inp.focus(); inp.select(); } catch (_) {}
      return false;
    }
    try { inp.style.borderColor = ''; } catch (_) {}
  }
  return true;
}
function attachReleasedQuantityInputGuards(root) {
  const scope = root || document;
  const inputs = scope.querySelectorAll
    ? scope.querySelectorAll('.whview-released, .wh-view-released')
    : [];
  inputs.forEach(inp => {
    if (inp.__qtyGuard) return;
    inp.__qtyGuard = true;
    inp.setAttribute('inputmode', 'decimal');
    inp.setAttribute('autocomplete', 'off');
    inp.setAttribute('title', 'Само число (напр. 5 или 2,5)');
    inp.addEventListener('input', function () {
      // Позволяваме цифри и една точка/запетая
      let v = this.value.replace(/[^\d.,]/g, '');
      const parts = v.split(/[.,]/);
      if (parts.length > 2) v = parts[0] + (v.includes(',') ? ',' : '.') + parts.slice(1).join('');
      if (v !== this.value) this.value = v;
    });
  });
}

function normalizeWarehouseRecordMaterials(rec) {
  if (rec && Array.isArray(rec.materials)) rec.materials = rec.materials.map(normalizeWarehouseMaterial);
  return rec;
}

// Кеш на заявките за СКЛАД — зарежда се от сървъра само при първото отваряне
// и се използва повторно при промяна на локалните филтри.
let warehouseRequestsCache = null;
let warehouseRequestsCachePromise = null;

async function loadWarehouseRequestsCache(force = false) {
  if (!force && Array.isArray(warehouseRequestsCache)) return warehouseRequestsCache;
  if (!force && warehouseRequestsCachePromise) return warehouseRequestsCachePromise;

  warehouseRequestsCachePromise = getAllWhRecords()
    .then(recs => {
      warehouseRequestsCache = Array.isArray(recs) ? recs : [];
      warehouseRequestsCachePromise = null;
      return warehouseRequestsCache;
    })
    .catch(err => {
      warehouseRequestsCachePromise = null;
      throw err;
    });

  return warehouseRequestsCachePromise;
}

// Принудително опресняване се използва само когато действително искаме
// новите данни от сървъра, а не при всяка промяна на филтър.
async function refreshWarehouseRequestsCache() {
  return loadWarehouseRequestsCache(true);
}

async function saveWhRecord(rec) {
  if (!rec || rec.id == null || rec.id === '') throw new Error('Липсва ID на заявката за материали.');
  rec.id = String(rec.id);
  const payload = JSON.stringify(rec);
  const res = await __whAuthFetch('/api/kv/' + encodeURIComponent('wh:' + rec.id), {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ value: payload })
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || ('Грешка при запис (HTTP ' + res.status + ')'));
  // Ако сървърът е върнал обединен/финален value — ползваме него
  let saved = rec;
  try {
    if (data && typeof data.value === 'string') saved = JSON.parse(data.value);
  } catch (_) {}
  if (saved && saved.id != null) saved.id = String(saved.id);

  const ids = (await getWhIds()).map(String);
  if (!ids.includes(String(saved.id))) {
    ids.push(String(saved.id));
    await saveWhIds(ids);
  }

  if (Array.isArray(warehouseRequestsCache)) {
    const index = warehouseRequestsCache.findIndex(r => r && String(r.id) === String(saved.id));
    if (index >= 0) warehouseRequestsCache[index] = saved;
    else warehouseRequestsCache.push(saved);
    warehouseRequestsCache.sort((a,b) => (b.createdAt||'').localeCompare(a.createdAt||''));
  }
  return saved;
}

async function deleteWhRecord(id) {
  await S.delete('wh:' + id);
  const ids = await getWhIds();
  await saveWhIds(ids.filter(x => x !== id));

  // Премахваме записа и от кеша.
  if (Array.isArray(warehouseRequestsCache)) {
    warehouseRequestsCache = warehouseRequestsCache.filter(r => r && r.id !== id);
  }
}

async function getAllWhRecords() {
  const ids = await getWhIds();
  const results = await Promise.all(ids.map(id => getWhById(id)));
  const recs = results.filter(Boolean);
  // Най-новите най-отгоре (низходящо по дата на подаване).
  recs.sort((a,b) => (b.createdAt||'').localeCompare(a.createdAt||''));
  return recs;
}

/** Локално: ДД.ММ.ГГГГ ЧЧ:ММ:СС */
window.formatLocalDateTimeSeconds = function formatLocalDateTimeSeconds(d) {
  const dt = d instanceof Date ? d : (d ? new Date(d) : new Date());
  if (Number.isNaN(dt.getTime())) return String(d || '');
  const pad = (n) => String(n).padStart(2, '0');
  return pad(dt.getDate()) + '.' + pad(dt.getMonth() + 1) + '.' + dt.getFullYear() +
    ' ' + pad(dt.getHours()) + ':' + pad(dt.getMinutes()) + ':' + pad(dt.getSeconds());
}

function addHistoryEntry(rec, action) {
  if (!Array.isArray(rec.history)) rec.history = [];
  rec.history.push({
    at: formatLocalDateTimeSeconds(new Date()),
    by: currentUsername || '—',
    action: action
  });
}


// Public API consumed by the existing warehouse and report UI modules.
window.getWhIds = getWhIds;
window.saveWhIds = saveWhIds;
window.nextWhId = nextWhId;
window.getWhById = getWhById;
window.getReleasedQuantity = getReleasedQuantity;
window.isValidReleasedQuantity = isValidReleasedQuantity;
window.normalizeWarehouseMaterial = normalizeWarehouseMaterial;
window.queryWhReleasedInputs = queryWhReleasedInputs;
window.queryWhNoteInputs = queryWhNoteInputs;
window.validateWhReleasedInputsOrToast = validateWhReleasedInputsOrToast;
window.attachReleasedQuantityInputGuards = attachReleasedQuantityInputGuards;
window.normalizeWarehouseRecordMaterials = normalizeWarehouseRecordMaterials;
window.loadWarehouseRequestsCache = loadWarehouseRequestsCache;
window.refreshWarehouseRequestsCache = refreshWarehouseRequestsCache;
window.saveWhRecord = saveWhRecord;
window.deleteWhRecord = deleteWhRecord;
window.getAllWhRecords = getAllWhRecords;
window.addHistoryEntry = addHistoryEntry;
