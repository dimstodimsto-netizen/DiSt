/**
 * warehouse-submit-ui.js — app.js modularization phase 3
 * Форма и панел за заявки за санитарни/канцеларски материали.
 * Load AFTER app.js.
 */

function isWhStatusDone(rec) {
  const st = String(rec && rec.status || '').toLowerCase().trim();
  return st === 'izpalnena' || st === 'изпълнена';
}

function canSubmitterEditWhRequest(rec) {
  if (!rec) return false;
  if (currentRole !== 'submitter' && currentRole !== 'admin') return false; // observer: само преглед
  if (isWhStatusDone(rec)) return false;
  const type = rec.materialType || currentMaterialType;
  if ((type === 'office' || type === 'sanitary') && isMaterialTypeLocked(type)) return false;
  return true;
}

function ensureWhLastRequestPanel() {
  let panel = document.getElementById('whLastRequestPanel');
  if (panel) return panel;
  const formWrap = document.getElementById('whFormWrap');
  if (!formWrap) return null;
  panel = document.createElement('div');
  panel.id = 'whLastRequestPanel';
  panel.style.cssText = 'display:none;margin-top:18px;border-top:1px solid var(--line);padding-top:14px;';
  panel.innerHTML =
    '<div class="cardtitle" style="margin-bottom:8px;font-size:14px;">📋 Последна заявка за материали</div>' +
    '<div id="whLastRequestHint" class="hint" style="margin-bottom:8px;"></div>' +
    '<div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;font-size:13px;">' +
    '<thead><tr style="text-align:left;border-bottom:1px solid var(--line);">' +
    '<th style="padding:6px 8px;">№</th><th style="padding:6px 8px;">Дата</th>' +
    '<th style="padding:6px 8px;">Месец</th><th style="padding:6px 8px;">Година</th>' +
    '<th style="padding:6px 8px;">Статус</th><th style="padding:6px 8px;">Действие</th>' +
    '</tr></thead><tbody id="whLastRequestBody"></tbody></table></div>';
  formWrap.appendChild(panel);
  return panel;
}

function isOwnWhRequest(rec) {
  if (!rec) return false;
  const zName = String(currentUserFullName || '').trim().toLowerCase();
  const uName = String(currentUsername || '').trim().toLowerCase();
  const rz = String(rec.zayavitel || '').trim().toLowerCase();
  const ru = String(rec.username || rec.createdBy || rec.submittedBy || '').trim().toLowerCase();
  // Собствена заявка: същото име на заявител или същият потребител
  if (uName && (ru === uName || rz === uName)) return true;
  if (zName && rz === zName) return true;
  return false;
}

async function findLastWhRequestForStructure() {
  // Последна заявка САМО на текущия заявител + текущия вид (office/sanitary)
  const type = currentMaterialType;
  if (type !== 'office' && type !== 'sanitary') return null;
  if (!currentUserFullName && !currentUsername) return null;
  let recs = [];
  try {
    recs = await getAllWhRecords();
  } catch (e) {
    console.warn('findLastWhRequest:', e);
    return null;
  }
  const matched = (recs || []).filter(r => {
    if (!r) return false;
    if (String(r.materialType || '').trim() !== type) return false;
    return isOwnWhRequest(r);
  });
  if (!matched.length) return null;
  matched.sort((a, b) => {
    const ca = String(b.createdAt || '').localeCompare(String(a.createdAt || ''));
    if (ca) return ca;
    const na = parseInt(String(a.id).replace(/\D/g, ''), 10) || 0;
    const nb = parseInt(String(b.id).replace(/\D/g, ''), 10) || 0;
    return nb - na;
  });
  return matched[0];
}

async function renderWhLastRequestPanel(opts) {
  const panel = ensureWhLastRequestPanel();
  if (!panel) return;
  const body = document.getElementById('whLastRequestBody');
  const hint = document.getElementById('whLastRequestHint');
  if (!body) return;
  const show = (currentRole === 'submitter' || currentRole === 'admin') &&
    (currentMaterialType === 'office' || currentMaterialType === 'sanitary');
  if (!show) {
    panel.style.display = 'none';
    body.innerHTML = '';
    return;
  }
  panel.style.display = 'block';
  const typeLabel = currentMaterialType === 'office' ? 'канцеларски материали' :
    (currentMaterialType === 'sanitary' ? 'санитарни материали' : 'материали');
  const titleEl = panel.querySelector('.cardtitle');
  if (titleEl) {
    titleEl.textContent = '📋 Вашата последна заявка за ' + typeLabel;
  }
  setContentLoading(body, '<tr><td colspan="6" class="hint">Зареждане...</td></tr>', isSoftRefreshOpts(arguments[0]));
  const rec = await findLastWhRequestForStructure();
  if (!rec) {
    body.innerHTML = '<tr><td colspan="6" class="hint">Нямате подадена заявка за ' + typeLabel + '.</td></tr>';
    if (hint) hint.textContent = '';
    return;
  }
  const statusDone = isWhStatusDone(rec);
  const statusText = statusDone ? 'Изпълнена' : 'Чакаща';
  const statusClass = statusDone ? 'wh-status-izpalnena' : 'wh-status-chakashta';
  const locked = (currentMaterialType === 'office' || currentMaterialType === 'sanitary') && isMaterialTypeLocked(currentMaterialType);
  const canEdit = canSubmitterEditWhRequest(rec);
  if (hint) {
    if (statusDone) hint.textContent = 'Статусът е „Изпълнена“ — редакцията е заключена.';
    else if (locked) hint.textContent = 'Периодът за подаване е заключен — редакцията е заключена.';
    else hint.textContent = 'Можете да отворите заявката за редакция (преди изпълнение и извън забранения период).';
  }
  const mesecNames = ['','Януари','Февруари','Март','Април','Май','Юни','Юли','Август','Септември','Октомври','Ноември','Декември'];
  const mesecTxt = mesecNames[Number(rec.mesec)] || (rec.mesec || '—');
  const btnLabel = canEdit ? 'Редактирай' : 'Преглед';
  body.innerHTML =
    '<tr style="cursor:pointer;">' +
    '<td style="padding:6px 8px;">' + escapeHtml(String(rec.id)) + '</td>' +
    '<td style="padding:6px 8px;">' + escapeHtml(String(rec.datetime || '—')) + '</td>' +
    '<td style="padding:6px 8px;">' + escapeHtml(String(mesecTxt)) + '</td>' +
    '<td style="padding:6px 8px;">' + escapeHtml(String(rec.godina || '—')) + '</td>' +
    '<td style="padding:6px 8px;"><span class="' + statusClass + '">' + escapeHtml(statusText) + '</span></td>' +
    '<td style="padding:6px 8px;"><button type="button" class="ghost" id="btnWhLastEdit" style="margin:0;padding:4px 10px;font-size:12px;">' + btnLabel + '</button></td>' +
    '</tr>';
  const open = async () => {
    if (!canEdit) {
      if (statusDone) toast('❌ Заявката е изпълнена и не може да се редактира.');
      else if (locked) toast('❌ В периода на забрана не може да се редактира заявката.');
      else toast('❌ Редакцията не е разрешена.');
      try { await openWhViewModal(rec.id, true); } catch (_) {}
      return;
    }
    await loadWhRequestIntoFormForEdit(rec);
  };
  const btn = document.getElementById('btnWhLastEdit');
  if (btn) btn.addEventListener('click', (e) => { e.stopPropagation(); open(); });
  const tr = body.querySelector('tr');
  if (tr) tr.addEventListener('click', () => open());
}

async function loadWhRequestIntoFormForEdit(rec) {
  if (!rec || !rec.id) return;
  if (!canSubmitterEditWhRequest(rec)) {
    toast('❌ Тази заявка не може да се редактира.');
    return;
  }
  setWhEditingId(rec.id);
  lastWarehouseSelectedByType[currentMaterialType || 'other'] = '';
  document.getElementById('whMesec').value = String(rec.mesec || (new Date().getMonth() + 1));
  document.getElementById('whGodina').value = String(rec.godina || new Date().getFullYear());
  setSelectValueWithFallback($('whStruktura'), $('whStrukturaOther'), rec.struktura || currentUserStruktura || '');
  document.getElementById('whZayavitel').value = rec.zayavitel || currentUserFullName || '';
  document.getElementById('whMaterialsTableBody').innerHTML = '';
  whMaterialRowSeq = 0;
  const mats = Array.isArray(rec.materials) ? rec.materials : [];
  if (!mats.length) await addWhMaterialRow();
  else {
    for (const m of mats) {
      await addWhMaterialRow({
        code: m.code || '',
        name: m.name || '',
        merka: m.merka || '',
        kolichestvo: m.kolichestvo || '',
        zabelezka: ''
      });
    }
  }
  await populateMaterialSelects();
  const rows = Array.from(document.querySelectorAll('#whMaterialsTableBody tr'));
  for (let i = 0; i < mats.length && i < rows.length; i++) {
    const m = mats[i];
    const sel = rows[i].querySelector('.wh-mat-select');
    const custom = rows[i].querySelector('.wh-mat-name-custom');
    const code = rows[i].querySelector('.wh-mat-code');
    const merka = rows[i].querySelector('.wh-mat-merka');
    const kol = rows[i].querySelector('.wh-mat-kolichestvo');
    if (sel) {
      const exists = Array.from(sel.options).some(o => o.value === (m.name || ''));
      if (exists) {
        sel.value = m.name || '';
        if (typeof onWhMaterialSelectChange === 'function') onWhMaterialSelectChange(sel);
      } else if (m.name) {
        const opt = document.createElement('option');
        opt.value = m.name;
        opt.textContent = m.name;
        if (m.merka) opt.setAttribute('data-merka', m.merka);
        if (m.code) opt.setAttribute('data-code', m.code);
        sel.appendChild(opt);
        sel.value = m.name;
        if (typeof onWhMaterialSelectChange === 'function') onWhMaterialSelectChange(sel);
        if (custom) { custom.style.display = 'none'; custom.value = ''; }
        if (code) { code.readOnly = true; code.value = m.code || ''; code.style.background = 'var(--locked-bg)'; }
        if (merka) { merka.readOnly = true; merka.style.background = 'var(--locked-bg)'; }
      }
    }
    if (merka && m.merka) merka.value = m.merka;
    if (kol) kol.value = m.kolichestvo || '';
    if (code && m.code && code.readOnly) code.value = m.code;
  }
  const title = $('whFormTitle');
  const btn = $('btnWhSubmit');
  if (title) title.textContent = 'Редакция на заявка №' + rec.id;
  if (btn) btn.textContent = 'Запази промените';
  const confirmBox = document.getElementById('whConfirmBox');
  if (confirmBox) {
    confirmBox.innerHTML = '';
    confirmBox.style.display = 'none';
  }
  toast('Редакция на заявка №' + rec.id);
  try { window.scrollTo({ top: 0, behavior: 'smooth' }); } catch (_) {}
}

async function resetWhForm() {
  setWhEditingId(null);
  lastWarehouseSelectedByType[currentMaterialType || 'other'] = '';

  document.getElementById('whMesec').value = String(new Date().getMonth() + 1);
  document.getElementById('whGodina').value = String(new Date().getFullYear());
  document.getElementById('whStrukturaOther').style.display = 'none';
  document.getElementById('whStrukturaOther').value = '';
  // Структура и заявител се попълват автоматично от текущия влязъл
  // потребителски акаунт (ако има зададени), вместо да остават празни -
  // важи навсякъде, откъдето се извиква тази функция (при отваряне на
  // таба, при първоначално зареждане на страницата, и след подаване на
  // заявка, за да не се налага повторно въвеждане за следваща заявка).
  if (currentUserStruktura) {
    setSelectValueWithFallback($('whStruktura'), $('whStrukturaOther'), currentUserStruktura);
  } else {
    document.getElementById('whStruktura').value = '';
  }
  document.getElementById('whZayavitel').value = currentUserFullName || '';
  document.getElementById('whMaterialsTableBody').innerHTML = '';
  whMaterialRowSeq = 0;
  await addWhMaterialRow();
  // Обновяване на всички селектори за материали
  await populateMaterialSelects();
  
  // Полетата „Отпуснато количество“ и „Забележка“ са скрити в нова заявка
  const whZabelezkaHeader = document.getElementById('whZabelezkaHeader');
  if (whZabelezkaHeader) whZabelezkaHeader.style.display = 'none';

  // Обновяване на заглавието и бутона според избрания тип материал
  const whFormTitle = $('whFormTitle');
  const whSubmitBtn = $('btnWhSubmit');
  if (currentMaterialType === 'office') {
    whFormTitle.textContent = 'Нова заявка за канцеларски материали';
    whSubmitBtn.textContent = 'Подай заявка за канцеларски материали';
  } else if (currentMaterialType === 'sanitary') {
    whFormTitle.textContent = 'Нова заявка за санитарни материали';
    whSubmitBtn.textContent = 'Подай заявка за санитарни материали';
  } else {
    whFormTitle.textContent = 'Нова заявка за материали';
    whSubmitBtn.textContent = 'Подай заявка за материали';
  }
  try { await renderWhLastRequestPanel(); } catch (_) {}
}

// ---- EVENT LISTENER ЗА ДОБАВЯНЕ НА РЕД В ЗАЯВКА ЗА МАТЕРИАЛИ ----
document.getElementById('btnAddWhMaterialRow').addEventListener('click', async () => {
  await addWhMaterialRow();
});

// Само цифри в „Заявено количество“ (по време на писане)
(function wireWhQtyNumericOnly() {
  const tbody = document.getElementById('whMaterialsTableBody');
  if (!tbody || tbody._qtyNumericWired) return;
  tbody._qtyNumericWired = true;
  tbody.addEventListener('input', function(e) {
    const el = e.target;
    if (!el || !el.classList || !el.classList.contains('wh-mat-kolichestvo')) return;
    const before = el.value;
    // Разрешаваме цифри и една десетична точка/запетая
    let v = before.replace(/[^\d.,]/g, '');
    const sep = v.includes(',') ? ',' : (v.includes('.') ? '.' : '');
    if (sep) {
      const parts = v.split(sep);
      v = parts[0].replace(/\D/g, '') + sep + (parts.slice(1).join('').replace(/\D/g, ''));
    } else {
      v = v.replace(/\D/g, '');
    }
    if (v !== before) el.value = v;
    el.style.borderColor = '';
  });
})();


// Отказ: при редакция — без запис, връщане към нова заявка; иначе изчистване на материали
const btnWhCancel = document.getElementById('btnWhCancel');
if (btnWhCancel) {
  btnWhCancel.addEventListener('click', async function() {
    const editingId = getWhEditingId();
    if (editingId) {
      if (!(await confirmDialog('Отказ от редакцията на заявка №' + editingId + '?\nПромените няма да бъдат записани.'))) {
        return;
      }
      await resetWhForm();
      toast('Редакцията е отказана. Заявка №' + editingId + ' остава без промяна.');
      return;
    }

    const tbody = document.getElementById('whMaterialsTableBody');
    if (!tbody) return;
    const rows = Array.from(tbody.querySelectorAll('tr'));
    const hasContent = rows.some(tr => {
      const sel = tr.querySelector('.wh-mat-select');
      const custom = tr.querySelector('.wh-mat-name-custom');
      const kol = tr.querySelector('.wh-mat-kolichestvo');
      const code = tr.querySelector('.wh-mat-code');
      const merka = tr.querySelector('.wh-mat-merka');
      const zab = tr.querySelector('.wh-mat-zabelezka');
      const name = (sel && sel.value && sel.value !== '__other__')
        ? sel.value
        : (custom && custom.style.display !== 'none' ? custom.value.trim() : '');
      return !!(name || (kol && kol.value.trim()) || (code && code.value.trim()) ||
                (merka && merka.value.trim()) || (zab && zab.value.trim()));
    });
    if (hasContent && !(await confirmDialog('Да се изчистят въведените материали? Заявката няма да бъде изпратена.'))) {
      return;
    }

    rows.forEach((tr, idx) => {
      if (idx > 0) {
        tr.remove();
        return;
      }
      const sel = tr.querySelector('.wh-mat-select');
      const custom = tr.querySelector('.wh-mat-name-custom');
      const code = tr.querySelector('.wh-mat-code');
      const merka = tr.querySelector('.wh-mat-merka');
      const kol = tr.querySelector('.wh-mat-kolichestvo');
      const zab = tr.querySelector('.wh-mat-zabelezka');
      if (sel) sel.value = '';
      if (custom) {
        custom.value = '';
        custom.style.display = 'none';
      }
      if (code) {
        code.value = '';
        code.readOnly = true;
        code.style.background = 'var(--locked-bg)';
        code.placeholder = '—';
      }
      if (merka) merka.value = '';
      if (kol) kol.value = '';
      if (zab) zab.value = '';
    });

    if (!tbody.querySelector('tr')) {
      await addWhMaterialRow();
    }

    const confirmBox = document.getElementById('whConfirmBox');
    if (confirmBox) {
      confirmBox.innerHTML = '';
      confirmBox.style.display = 'none';
    }
    toast('Въведените материали са изчистени.');
  });
}

// ============================================================
//  ПОДАВАНЕ НА ЗАЯВКА ЗА РЕМОНТ
// ============================================================
document.getElementById('btnSubmit').addEventListener('click', async function() {
  const struktura = getSelectValueWithFallback($('sStruktura'), $('sStrukturaOther'));
  const zayavitel = document.getElementById('sZayavitel').value.trim();
  const korpus = getSelectValueWithFallback($('sKorpus'), $('sKorpusOther'));
  const etaz = document.getElementById('sEtaz').value.trim();
  const lokacia = document.getElementById('sLokacia').value.trim();
  const vid = document.getElementById('sVid').value.trim();
  const zabelezka = document.getElementById('sZabelezka').value.trim();
  const urgent = document.getElementById('btnUrgentToggle').getAttribute('data-active') === 'true';
  
  if (!struktura) {
    toast('❌ Въведете структура.');
    return;
  }
  if (!zayavitel) {
    toast('❌ Въведете заявител.');
    return;
  }
  if (!korpus) {
    toast('❌ Въведете корпус.');
    return;
  }
  if (!etaz) {
    toast('❌ Въведете етаж.');
    return;
  }
  if (!lokacia) {
    toast('❌ Въведете местоположение на ремонта.');
    return;
  }
  if (!vid) {
    toast('❌ Въведете вид на заявка.');
    return;
  }
  
  const btn = document.getElementById('btnSubmit');
  btn.disabled = true;
  btn.textContent = '⏳ Изпращане...';
  
  try {
    const now = new Date();
    const datetime = String(now.getDate()).padStart(2,'0') + '.' + 
                     String(now.getMonth()+1).padStart(2,'0') + '.' + 
                     now.getFullYear() + ' ' + 
                     String(now.getHours()).padStart(2,'0') + ':' + 
                     String(now.getMinutes()).padStart(2,'0');
    
    const rec = {
      datetime: datetime,
      korpus: korpus,
      etaz: etaz,
      struktura: struktura,
      lokacia: lokacia,
      vid: vid,
      zabelezka: zabelezka,
      zayavitel: zayavitel,
      status: 'Не е изпълнена',
      dataIzp: '',
      izpalnitel: '',
      komentar: '',
      urgent: urgent,
      seen: false
    };
    
    const savedRec = await saveRecord(rec);
    const id = (savedRec && savedRec.id != null) ? savedRec.id : rec.id;
    if (id == null || id === '') {
      throw new Error('Сървърът не върна номер на заявката.');
    }

    // Успех — банерът е валиден; грешки след това НЕ маскират успешния запис
    try {
      const confirmBox = document.getElementById('confirmBox');
      if (confirmBox) {
        confirmBox.innerHTML = '✅ Заявката е подадена успешно! №: ' + id;
        confirmBox.style.display = 'block';
        clearTimeout(window.__submitConfirmBoxTimer);
        window.__submitConfirmBoxTimer = setTimeout(() => {
          confirmBox.style.display = 'none';
        }, 20000);
      }
    } catch (_) {}

    try {
      const lok = document.getElementById('sLokacia'); if (lok) lok.value = '';
      const vid = document.getElementById('sVid'); if (vid) vid.value = '';
      const zab = document.getElementById('sZabelezka'); if (zab) zab.value = '';
      const urg = document.getElementById('btnUrgentToggle');
      if (urg) {
        urg.setAttribute('data-active', 'false');
        urg.style.background = '#fff';
        urg.style.color = '#c0392b';
      }
    } catch (_) {}

    try {
      if (typeof renderMonthlyPanel === 'function') await renderMonthlyPanel();
    } catch (panelErr) {
      console.warn('renderMonthlyPanel след подаване:', panelErr);
    }

  } catch (e) {
    console.error(e);
    toast('❌ Грешка при изпращане на заявката' + (e && e.message ? (': ' + e.message) : '.'));
  } finally {
    btn.disabled = false;
    btn.textContent = 'Изпрати заявка';
  }
});

// ---- EVENT LISTENER ЗА СПЕШНА ЗАЯВКА ----
document.getElementById('btnUrgentToggle').addEventListener('click', function() {
  const isActive = this.getAttribute('data-active') === 'true';
  this.setAttribute('data-active', isActive ? 'false' : 'true');
  if (isActive) {
    this.style.background = '#fff';
    this.style.color = '#c0392b';
  } else {
    this.style.background = '#c0392b';
    this.style.color = '#fff';
  }
});

// ---- EVENT LISTENER ЗА ПОДАВАНЕ НА ЗАЯВКА ЗА МАТЕРИАЛИ ----
document.getElementById('btnWhSubmit').addEventListener('click', async function() {
  const mesec = document.getElementById('whMesec').value;
  const godina = document.getElementById('whGodina').value.trim();
  const struktura = getSelectValueWithFallback($('whStruktura'), $('whStrukturaOther'));
  const zayavitel = document.getElementById('whZayavitel').value.trim();
  const materials = readWhMaterialsFromTable();
  
  if (!mesec || !godina) {
    toast('❌ Въведете месец и година.');
    return;
  }
  if (!struktura) {
    toast('❌ Въведете структура.');
    return;
  }
  if (!zayavitel) {
    toast('❌ Въведете заявител.');
    return;
  }
  if (!materials.length) {
    toast('❌ Добавете поне един материал.');
    return;
  }
  
  // Валидация за задължителни полета в материалите
  for (let i = 0; i < materials.length; i++) {
    const mat = materials[i];
    if (!mat.name || !mat.name.trim()) {
      toast('❌ Попълнете поле "Материал" за ред ' + (i + 1) + '.');
      return;
    }
    if (!mat.kolichestvo || !mat.kolichestvo.trim()) {
      toast('❌ Попълнете поле "Заявено количество" за материал: ' + mat.name);
      return;
    }
    // Само числа (цяло или десетично с . или ,)
    const qtyRaw = String(mat.kolichestvo).trim().replace(/\s/g, '');
    if (!/^\d+([.,]\d+)?$/.test(qtyRaw)) {
      toast('❌ „Заявено количество“ за „' + mat.name + '“ трябва да е число (само цифри). Коригирайте полето.');
      // Фокус върху грешното поле
      const rows = document.querySelectorAll('#whMaterialsTableBody tr');
      if (rows[i]) {
        const kol = rows[i].querySelector('.wh-mat-kolichestvo');
        if (kol) {
          kol.style.borderColor = 'var(--danger, #c0392b)';
          kol.focus();
          kol.select();
        }
      }
      return;
    }
  }
  
  const btn = document.getElementById('btnWhSubmit');
  const originalText = btn.textContent;
  btn.disabled = true;
  btn.textContent = '⏳ Изпращане...';
  
  try {
    await loadMaterialLocks();
    if (currentRole !== 'admin' && (currentMaterialType==='office'||currentMaterialType==='sanitary') &&
        isMaterialTypeLocked(currentMaterialType)) {
      await applyMaterialSubmissionLockUI();
      try { await renderWhLastRequestPanel(); } catch (_) {}
      toast('🔒 Подаването/редакцията на този тип заявка е заключено за текущия период.');
      return;
    }
    const materialType = currentMaterialType || 'general';

    // Редакция на съществуваща заявка — ЗАПАЗВА СЪЩИЯ ID
    const editingId = getWhEditingId();
    if (editingId) {
      const existing = await getWhById(editingId);
      if (!existing) {
        toast('❌ Заявката за редакция №' + editingId + ' не е намерена. Не се създава нова.');
        setWhEditingId(null);
        return;
      }
      if (!canSubmitterEditWhRequest(existing)) {
        toast('❌ Заявката не може да се редактира (изпълнена или периодът е заключен).');
        return;
      }
      // Запазване на оригиналния номер и служебните полета
      const originalId = existing.id;
      existing.id = originalId;
      existing.mesec = mesec;
      existing.godina = godina;
      existing.struktura = struktura;
      existing.zayavitel = zayavitel;
      existing.materials = materials;
      existing.materialType = materialType;
      if (!existing.username && currentUsername) existing.username = currentUsername;
      if (!existing.submittedBy && currentUsername) existing.submittedBy = currentUsername;
      // status, datetime, createdAt — без промяна
      try { addHistoryEntry(existing, 'Редакция от заявител'); } catch (_) {}
      await saveWhRecord(existing);
      const confirmBox = document.getElementById('whConfirmBox');
      if (confirmBox) {
        confirmBox.innerHTML = '';
        confirmBox.style.display = 'none';
      }
      toast('✅ Промените по заявка №' + originalId + ' са записани.');
      setWhEditingId(null);
      await resetWhForm();
      try { await refreshWarehouseRequestsCache(); } catch (_) {}
      try { renderWarehouseTable(); } catch (_) {}
      try { if (typeof renderMyMaterials === 'function') renderMyMaterials(); } catch (_) {}
      return;
    }

    const id = await nextWhId();
    const now = new Date();
    const datetime = String(now.getDate()).padStart(2,'0') + '.' + 
                     String(now.getMonth()+1).padStart(2,'0') + '.' + 
                     now.getFullYear() + ' ' + 
                     String(now.getHours()).padStart(2,'0') + ':' + 
                     String(now.getMinutes()).padStart(2,'0');
    
    const rec = {
      id: id,
      datetime: datetime,
      mesec: mesec,
      godina: godina,
      struktura: struktura,
      zayavitel: zayavitel,
      materials: materials,
      status: 'chakashta',
      createdAt: now.toISOString(),
      materialType: materialType,
      username: currentUsername || '',
      submittedBy: currentUsername || ''
    };
    
    await saveWhRecord(rec);
    
    const confirmBox = document.getElementById('whConfirmBox');
    if (confirmBox) {
      confirmBox.innerHTML = '';
      confirmBox.style.display = 'none';
    }
    const materialTypeText = materialType === 'office' ? 'канцеларски материали' : 
                           materialType === 'sanitary' ? 'санитарни материали' : 'материали';
    toast('✅ Заявката за ' + materialTypeText + ' е подадена успешно! №: ' + rec.id);
    
    await resetWhForm();
    renderWarehouseTable();
    
  } catch (e) {
    console.error(e);
    toast('❌ Грешка при изпращане на заявката.');
  } finally {
    btn.disabled = false;
    btn.textContent = originalText;
  }
});


// WH main table → public/js/warehouse-requests.js (фаза 2а)

/* window exports */
try {
  if (typeof canSubmitterEditWhRequest==='function') window.canSubmitterEditWhRequest=canSubmitterEditWhRequest;
  if (typeof ensureWhLastRequestPanel==='function') window.ensureWhLastRequestPanel=ensureWhLastRequestPanel;
  if (typeof findLastWhRequestForStructure==='function') window.findLastWhRequestForStructure=findLastWhRequestForStructure;
  if (typeof isOwnWhRequest==='function') window.isOwnWhRequest=isOwnWhRequest;
  if (typeof isWhStatusDone==='function') window.isWhStatusDone=isWhStatusDone;
  if (typeof loadWhRequestIntoFormForEdit==='function') window.loadWhRequestIntoFormForEdit=loadWhRequestIntoFormForEdit;
  if (typeof renderWhLastRequestPanel==='function') window.renderWhLastRequestPanel=renderWhLastRequestPanel;
  if (typeof resetWhForm==='function') window.resetWhForm=resetWhForm;
} catch(_){}
