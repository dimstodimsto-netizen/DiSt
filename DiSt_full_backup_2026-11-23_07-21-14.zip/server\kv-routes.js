'use strict';
/** /api/kv/* и /api/kv-list */
const { validateLoginBackgroundValue } = require('./login-background');
function createKvRoutes(deps) {
  const {
    requireAuth, sendJSON, kvGet, kvSet, kvDelete, kvListByPrefix,
    kvReadAllowedForRole, parseJsonOrNull, ownStrukturaOf, whRecordVisibleToUser,
    normalizeStrukturaName, getUserByIdServer, getUserByUsernameServer, getRecordServer,
    readJsonFromRequest, writeSystemLog, getClientIp
  } = deps;
  return async function handleKvRoute(req, res, parsed, pathname) {
    if (pathname.startsWith('/api/kv/')) {
      const key = pathname.slice('/api/kv/'.length);
      if (!key) { sendJSON(res, 400, { error: 'missing key' }); return true; }

      if (key === 'users-index' || key.startsWith('user:')) {
        sendJSON(res, 403, { error: 'forbidden — use /api/auth/* endpoints' });
        return true;
      }

      const sess = requireAuth(req, res);
      if (!sess) return true;

      if (!kvReadAllowedForRole(key, sess.role)) {
        sendJSON(res, 403, { error: 'Нямате достъп до този ключ.' });
        return true;
      }

      if (req.method === 'GET') {
        const value = kvGet(key);
        // Наблюдател вижда заявки за материали от ВСИЧКИ структури (само преглед).
        // Заявител — само своята структура.
        if (value !== null && key.startsWith('wh:') && sess.role === 'submitter') {
          if (!whRecordVisibleToUser(parseJsonOrNull(value), ownStrukturaOf(sess))) {
            sendJSON(res, 404, { error: 'not found' });
            return true;
          }
        }
        // Заявител — само своя структура. Наблюдател — преглед на всички ремонтни заявки.
        if (value !== null && key.startsWith('record:') && sess.role === 'submitter') {
          const rec = parseJsonOrNull(value);
          const user = getUserByIdServer(sess.userId) || getUserByUsernameServer(sess.username);
          const ownStructure = (user && user.struktura) || '';
          const recStr = normalizeStrukturaName(rec && rec.struktura);
          const ownN = normalizeStrukturaName(ownStructure);
          if (!rec || (ownN && recStr && recStr !== ownN)) {
            sendJSON(res, 403, { error: 'Нямате достъп до тази заявка.' });
            return true;
          }
        }
        if (value === null) { sendJSON(res, 404, { error: 'not found' }); return true; }
        sendJSON(res, 200, { key, value });
        return true;
      }
      if (req.method === 'PUT') {
        // Записите вече се управляват само през /api/records/*, където
        // има съървърна проверка на ролите, ID и историята.
        if (key.startsWith('record:')) {
          sendJSON(res, 403, { error: 'Използвайте /api/records/* за заявки.' });
          return true;
        }
        if (key === 'maintenance_materials' && sess.role !== 'admin') {
          sendJSON(res, 403, { error: 'Само администратор може да променя каталога за материали за поддръжка.' });
          return true;
        }
        // Allow-list за чувствителни KV ключове (не разчитаме само на UI).
        const MATERIAL_KEYS = new Set([
          'available_materials',
          'available_sanitary_materials',
          'available_office_materials'
        ]);
        if (MATERIAL_KEYS.has(key) && sess.role !== 'admin' && sess.role !== 'warehouse') {
          sendJSON(res, 403, { error: 'Само склад или администратор може да управлява наличните материали.' });
          return true;
        }
        if ((key === 'login_background' || key.startsWith('settings:') || key.startsWith('system:')) &&
            sess.role !== 'admin') {
          sendJSON(res, 403, { error: 'Само администратор може да променя тази настройка.' });
          return true;
        }
        // Индексът на ремонтните заявки се поддържа от /api/records/* — не през KV.
        if (key === 'records-index' && sess.role !== 'admin') {
          sendJSON(res, 403, { error: 'Индексът на заявките се управлява от сървъра.' });
          return true;
        }
        if (key === 'login_background' && sess.role !== 'admin') {
          sendJSON(res, 403, { error: 'Само администратор може да променя фоновата снимка.' });
          return true;
        }
        const parsedBody = await readJsonFromRequest(req, res);
      if (!parsedBody) return true;
        if (typeof parsedBody.value !== 'string') { sendJSON(res, 400, { error: 'value must be a string' }); return true; }
        if (key === 'login_background') {
          const invalidImage = validateLoginBackgroundValue(parsedBody.value);
          if (invalidImage) { sendJSON(res, invalidImage.status, { error: invalidImage.error }); return true; }
        }

        if (key.startsWith('record:') && (sess.role === 'submitter' || sess.role === 'observer')) {
          const sessUser = getUserByUsernameServer(sess.username);
          const ownStruktura = (sessUser && sessUser.struktura) || '';
          try {
            const rec = JSON.parse(parsedBody.value);
            rec.struktura = ownStruktura;
            parsedBody.value = JSON.stringify(rec);
          } catch (e) { /* невалиден JSON - оставяме както е */ }
        }

        // Защита на ниво сървър (не само заключени полета в браузъра):
        // технически потребител не може да променя частта от заявката,
        // попълнена от ЗАЯВИТЕЛЯ (структура, заявител, корпус, етаж,
        // локация, вид, забележка, спешност) - дори с директна API
        // заявка. Той може да пипа само статус/изпълнение/материали.
        if (key.startsWith('record:') && sess.role === 'technician') {
          const SUBMITTER_ONLY_FIELDS = ['korpus', 'etaz', 'struktura', 'lokacia', 'vid', 'zayavitel', 'zabelezka', 'urgent'];
          try {
            const existingRaw = kvGet(key);
            const existing = existingRaw !== null ? JSON.parse(existingRaw) : null;
            const incoming = JSON.parse(parsedBody.value);
            if (existing) {
              SUBMITTER_ONLY_FIELDS.forEach(f => { incoming[f] = existing[f]; });
            }
            parsedBody.value = JSON.stringify(incoming);
          } catch (e) { /* невалиден JSON - оставяме както е */ }
        }

        // Защита на ниво сървър за обекти ("object:*"):
        // - Само администратор може да маркира като завършен / да отвори отново
        //   (completedAt) и да променя възложител, основание, локация, вид дейност.
        // - Техник може да променя САМО materials (вложени материали) и то само
        //   ако обектът НЕ е завършен.
        // - Завършен обект: никакви промени от не-администратор.
        if (key.startsWith('object:') && sess.role !== 'admin') {
          try {
            const existingRaw = kvGet(key);
            const existing = existingRaw !== null ? JSON.parse(existingRaw) : null;
            if (!existing) {
              sendJSON(res, 403, { error: 'Само администратор може да създава обекти.' });
              return true;
            }
            const incoming = JSON.parse(parsedBody.value);
            if (existing.completedAt) {
              // Завършен — целият запис остава непроменен
              parsedBody.value = JSON.stringify(existing);
            } else if (sess.role === 'technician') {
              // Техник: запазваме всички полета от оригинала, сменяме само materials
              const merged = Object.assign({}, existing, {
                materials: Array.isArray(incoming.materials) ? incoming.materials : (existing.materials || [])
              });
              merged.completedAt = existing.completedAt || null;
              parsedBody.value = JSON.stringify(merged);
            } else {
              // Други не-админ роли: не пипат completedAt
              incoming.completedAt = existing.completedAt || null;
              parsedBody.value = JSON.stringify(incoming);
            }
          } catch (e) { /* невалиден JSON - оставяме както е */ }
        }

        // Защита на ниво сървър за заявки за материали ("wh:*"):
        // - Склад може да променя materials[].otpusnatoKolichestvo и materials[].zabelezka (при незаключен запис).
        // - След status=izpalnena Склад НЕ може да променя отпуснати/забележки.
        // - Склад може да маркира като изпълнена; празни отпуснати се попълват
        //   автоматично от заявеното количество (kolichestvo).
        // - Само администратор отваря отново / редактира след заключване.
        if (key.startsWith('wh:') && sess.role === 'observer') {
          // "Наблюдател" е само преглед — не може да подава/променя заявки за материали,
          // нито да създава нови (старата проверка по-долу пазеше само СЪЩЕСТВУВАЩИ записи).
          sendJSON(res, 403, { error: 'Ролята „Наблюдател“ е само за преглед.' });
          return true;
        }
        if (key.startsWith('wh:') && sess.role !== 'admin') {
          try {
            const existingRaw = kvGet(key);
            const existing = existingRaw !== null ? JSON.parse(existingRaw) : null;
            const incoming = JSON.parse(parsedBody.value);

            if (existing) {
              const merged = JSON.parse(JSON.stringify(existing));

              if (sess.role === 'warehouse') {
                const alreadyLocked = (existing.status === 'izpalnena'); // Чакаща = редактируема за Склад, дори при стар warehouseLocked
                const wantsFulfill =
                  incoming.status === 'izpalnena' &&
                  existing.status !== 'izpalnena';

                if (alreadyLocked && !wantsFulfill) {
                  // Заключен запис — Склад не променя нищо
                  parsedBody.value = JSON.stringify(existing);
                } else {
                  // Склад може да пише: otpusnatoKolichestvo + zabelezka (разделно)
                  if (Array.isArray(existing.materials)) {
                    merged.materials = existing.materials.map((oldMaterial, index) => {
                      const incomingMaterial =
                        Array.isArray(incoming.materials) ? incoming.materials[index] : null;
                      const out = Object.assign({}, oldMaterial);
                      // Миграция: осигуряваме поле otpusnatoKolichestvo
                      if (!Object.prototype.hasOwnProperty.call(out, 'otpusnatoKolichestvo')) {
                        out.otpusnatoKolichestvo = '';
                      }
                      if (!Object.prototype.hasOwnProperty.call(out, 'zabelezka')) {
                        out.zabelezka = '';
                      }
                      if (!alreadyLocked && incomingMaterial) {
                        if (Object.prototype.hasOwnProperty.call(incomingMaterial, 'otpusnatoKolichestvo')) {
                          out.otpusnatoKolichestvo = String(
                            incomingMaterial.otpusnatoKolichestvo == null ? '' : incomingMaterial.otpusnatoKolichestvo
                          ).trim();
                        }
                        if (Object.prototype.hasOwnProperty.call(incomingMaterial, 'zabelezka')) {
                          out.zabelezka = String(
                            incomingMaterial.zabelezka == null ? '' : incomingMaterial.zabelezka
                          ).trim();
                        }
                      }
                      return out;
                    });
                  }

                  if (incoming.warehouseLocked === true) {
                    merged.warehouseLocked = true;
                  }

                  if (wantsFulfill) {
                    // Празно „Отпуснато“ ← „Заявено“. „Забележка“ НЕ се пипа.
                    if (Array.isArray(merged.materials)) {
                      merged.materials = merged.materials.map(m => {
                        const rel = String(m.otpusnatoKolichestvo == null ? '' : m.otpusnatoKolichestvo).trim();
                        if (!rel) {
                          return Object.assign({}, m, {
                            otpusnatoKolichestvo: String(m.kolichestvo == null ? '' : m.kolichestvo).trim()
                          });
                        }
                        return m;
                      });
                    }
                    merged.status = 'izpalnena';
                    merged.warehouseLocked = true;
                    if (incoming.fulfilledAt) {
                      merged.fulfilledAt = incoming.fulfilledAt;
                    } else {
                      merged.fulfilledAt = formatLocalDateTimeSeconds(new Date());
                    }
                  }

                  parsedBody.value = JSON.stringify(merged);
                }
              } else if (sess.role === 'submitter') {
                // Заявител може да редактира СОБСТВЕНА чакаща заявка (същата структура),
                // докато не е изпълнена / заключена от склад.
                const alreadyDone = !!(existing.warehouseLocked || existing.status === 'izpalnena');
                const sessUser = getUserByUsernameServer(sess.username);
                const ownStruktura = String((sessUser && sessUser.struktura) || '').trim();
                const recStruktura = String(existing.struktura || '').trim();
                const sameStructure = !ownStruktura || !recStruktura || ownStruktura === recStruktura;

                if (alreadyDone || !sameStructure) {
                  // Без промени — заключена или чужда структура
                  parsedBody.value = JSON.stringify(existing);
                } else {
                  const merged = JSON.parse(JSON.stringify(existing));
                  // Позволени полета при редакция от заявител
                  if (incoming.mesec != null) merged.mesec = incoming.mesec;
                  if (incoming.godina != null) merged.godina = incoming.godina;
                  if (incoming.zayavitel != null) merged.zayavitel = String(incoming.zayavitel);
                  // Структура — само ако е в собствената (или админ зададена)
                  if (incoming.struktura != null && ownStruktura) {
                    merged.struktura = ownStruktura;
                  } else if (incoming.struktura != null && !ownStruktura) {
                    merged.struktura = String(incoming.struktura);
                  }
                  if (Array.isArray(incoming.materials)) {
                    merged.materials = incoming.materials.map(m => ({
                      code: String(m && m.code != null ? m.code : '').trim(),
                      name: String(m && m.name != null ? m.name : '').trim(),
                      merka: String(m && m.merka != null ? m.merka : '').trim(),
                      kolichestvo: String(m && m.kolichestvo != null ? m.kolichestvo : '').trim(),
                      zabelezka: ''
                    }));
                    // Запазване на вече попълнени отпуснати количества по индекс, ако има
                    if (Array.isArray(existing.materials)) {
                      merged.materials = merged.materials.map((m, i) => {
                        const oldM = existing.materials[i];
                        const oldZ = oldM ? String(oldM.zabelezka || oldM.otpusnatoKolichestvo || '').trim() : '';
                        if (oldZ) {
                          return Object.assign({}, m, {
                            zabelezka: oldZ,
                            otpusnatoKolichestvo: oldM.otpusnatoKolichestvo != null ? oldM.otpusnatoKolichestvo : oldZ
                          });
                        }
                        return m;
                      });
                    }
                  }
                  if (incoming.materialType) merged.materialType = String(incoming.materialType);
                  // status / warehouseLocked / datetime / createdAt / id — непроменени
                  merged.id = existing.id;
                  merged.status = existing.status;
                  merged.warehouseLocked = existing.warehouseLocked;
                  merged.datetime = existing.datetime;
                  merged.createdAt = existing.createdAt;
                  parsedBody.value = JSON.stringify(merged);
                }
              } else {
                // Други не-админ роли — без промени
                parsedBody.value = JSON.stringify(existing);
              }
            }
          } catch (e) { /* невалиден JSON - оставяме както е */ }
        }

        kvSet(key, parsedBody.value);
        sendJSON(res, 200, { key, value: parsedBody.value });
        return true;
      }
      if (req.method === 'DELETE') {
        if (key.startsWith('record:')) {
          sendJSON(res, 403, { error: 'Използвайте /api/records/* за заявки.' });
          return true;
        }
        if (key === 'maintenance_materials' && sess.role !== 'admin') {
          sendJSON(res, 403, { error: 'Само администратор може да изтрива каталога за материали за поддръжка.' });
          return true;
        }
        if ((key.startsWith('object:') || key.startsWith('wh:')) && sess.role !== 'admin') {
          sendJSON(res, 403, { error: 'Само администратор може да изтрива заявки/обекти.' });
          return true;
        }
        const MATERIAL_KEYS_DEL = new Set([
          'available_materials',
          'available_sanitary_materials',
          'available_office_materials'
        ]);
        if (MATERIAL_KEYS_DEL.has(key) && sess.role !== 'admin' && sess.role !== 'warehouse') {
          sendJSON(res, 403, { error: 'Само склад или администратор може да управлява наличните материали.' });
          return true;
        }
        if ((key === 'login_background' || key.startsWith('settings:') || key.startsWith('system:') ||
             key === 'records-index') && sess.role !== 'admin') {
          sendJSON(res, 403, { error: 'Само администратор може да изтрива тази настройка.' });
          return true;
        }
        if (key === 'login_background' && sess.role !== 'admin') {
          sendJSON(res, 403, { error: 'Само администратор може да премахва фоновата снимка.' });
          return true;
        }
        kvDelete(key);
        sendJSON(res, 200, { key, deleted: true });
        return true;
      }
      res.writeHead(405); res.end('Method not allowed'); return true;
    }

    // ---- API: списък по префикс /api/kv-list?prefix=... ----
    if (pathname === '/api/kv-list' && req.method === 'GET') {
      const prefix = parsed.searchParams.get('prefix') || '';
      const sess = requireAuth(req, res);
      if (!sess) return true;
      let items = kvListByPrefix(prefix);
      // Никога не връщаме потребителски записи / хеша на верификационния код,
      // независимо какъв префикс е поискан; system:* — само за администратор.
      items = items.filter(i => kvReadAllowedForRole(i.key, sess.role));
      if (sess.role === 'submitter' && prefix.startsWith('wh:')) {
        const ownStr = ownStrukturaOf(sess);
        items = items.filter(i => whRecordVisibleToUser(parseJsonOrNull(i.value), ownStr));
      }
      // Филтър по структура само за заявител. Наблюдател вижда всички ремонтни заявки (преглед).
      if (sess.role === 'submitter' && prefix === 'records-index') {
        const user = getUserByIdServer(sess.userId) || getUserByUsernameServer(sess.username);
        const ownStructure = (user && user.struktura) || '';
        const ids = items.length ? (parseJsonOrNull(items[0].value) || []) : [];
        const filteredIds = ids.filter(id => {
          const rec = getRecordServer(String(id));
          const ownN = normalizeStrukturaName(ownStructure);
          const recStr = normalizeStrukturaName(rec && rec.struktura);
          return rec && (!ownN || !recStr || recStr === ownN);
        });
        items = [{ key: 'records-index', value: JSON.stringify(filteredIds) }];
      } else if (sess.role === 'submitter' && prefix === 'record:') {
        const user = getUserByIdServer(sess.userId) || getUserByUsernameServer(sess.username);
        const ownStructure = (user && user.struktura) || '';
        const ownN = normalizeStrukturaName(ownStructure);
        items = items.filter(item => {
          const rec = parseJsonOrNull(item.value);
          const recStr = normalizeStrukturaName(rec && rec.struktura);
          return rec && (!ownN || !recStr || recStr === ownN);
        });
      }
      sendJSON(res, 200, items);
      return true;
    }

    // ---- API: информация за сървъра ----
    return false;
  };
}
module.exports = { createKvRoutes };
