@echo off
setlocal
cd /d "%~dp0.."
echo.
echo === DiSt - Dependency check ===
echo.
node "%~dp0depcheck.js" %*
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (echo RESULT: OK) else (echo RESULT: FAILED)
exit /b %RC%
