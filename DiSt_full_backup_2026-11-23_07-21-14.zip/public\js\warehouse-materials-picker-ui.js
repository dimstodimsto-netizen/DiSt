/**
 * warehouse-materials-picker-ui.js — app.js modularization step C
 * Падащ избор/таблица на материали при складова заявка.
 * Load AFTER app.js (uses currentMaterialType, getAvailable*, escapeHtml, toast, S, …).
 */

var whMaterialRowSeq = 0;
var lastWarehouseSelectedByType = { office: '', sanitary: '', other: '' };
var openWarehousePickerSelect = null;

function populateMaterialSelects() {
  // Зареждане на материали според текущия тип на заявката
  let materialsPromise;
  if (currentMaterialType === 'office') {
    materialsPromise = getAvailableOfficeMaterials();
  } else if (currentMaterialType === 'sanitary') {
    materialsPromise = getAvailableSanitaryMaterials();
  } else {
    materialsPromise = getAvailableMaterials(); // По подразбиране общите материали
  }
  
  materialsPromise.then(materials => {
    const ordered = sortWarehouseMaterialsAlphabetically(materials);
    document.querySelectorAll('.wh-mat-select').forEach(select => {
      select.dataset.materialType = currentMaterialType || 'other';
      const currentVal = select.value;
      const materialOptions = ordered.map(m => {
        // В падащото меню — само името; кодът се попълва в колона „Код“
        const label = escapeHtml(m.name || '');
        return '<option value="' + escapeHtml(m.name) + '" data-merka="' + escapeHtml(m.merka || '') + '" data-code="' + escapeHtml(m.code || '') + '">' + label + '</option>';
      }).join('');
      select.innerHTML = '<option value="">— изберете —</option>' + materialOptions;
      // Без опция „+ Друго“ — само материали от списъка
      if (currentVal && Array.from(select.options).some(o => o.value === currentVal)) {
        select.value = currentVal;
      } else if (currentVal && currentVal !== '__other__') {
        // запазена стойност извън списъка — добавяме я временно (за редакция на стара заявка)
        const opt = document.createElement('option');
        opt.value = currentVal;
        opt.textContent = currentVal;
        select.appendChild(opt);
        select.value = currentVal;
      }
      renderWarehouseMaterialPicker(select, getLastWarehouseMaterialBefore(select, select.dataset.materialType));
    });
    refreshWarehouseMaterialOptionColors();
  });
}

// ---- addWhMaterialRow ----
window.addWhMaterialRow = async function(data) {
  data = data || {};
  const rowId = 'whmrow' + (whMaterialRowSeq++);
  const tr = document.createElement('tr');
  tr.id = rowId;
  tr.style.borderBottom = '1px solid var(--line)';
  
  // Зареждане на материалите за падащото меню според типа на заявката
  let materialsPromise;
  if (currentMaterialType === 'office') {
    materialsPromise = getAvailableOfficeMaterials();
  } else if (currentMaterialType === 'sanitary') {
    materialsPromise = getAvailableSanitaryMaterials();
  } else {
    materialsPromise = getAvailableMaterials(); // По подразбиране общите материали
  }
  
  const materialType = currentMaterialType || 'other';
  const lastBefore = lastWarehouseSelectedByType[materialType] || getLastWarehouseMaterialBefore(null, materialType);
  const materials = sortWarehouseMaterialsAlphabetically(await materialsPromise);
  const materialOptions = materials.map(m => {
    // В падащото меню — само името; кодът се попълва в колона „Код“
    const label = escapeHtml(m.name || '');
    return `<option value="${escapeHtml(m.name)}" data-merka="${escapeHtml(m.merka || '')}" data-code="${escapeHtml(m.code || '')}">${label}</option>`;
  }).join('');
  
  const selectHtml = `<div class="wh-mat-picker" style="position:relative;width:100%;">
    <button type="button" class="ghost wh-mat-picker-trigger" aria-haspopup="listbox" aria-expanded="false" style="width:100%;margin:0;text-align:left;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">— изберете —</button>
    <div class="wh-mat-picker-menu" role="listbox" tabindex="-1" hidden style="position:absolute;z-index:10000;max-height:280px;overflow:auto;background:#fff;border:1px solid #aeb9c4;border-radius:6px;box-shadow:0 6px 18px rgba(0,0,0,.2);"></div>
    <select class="wh-mat-select" aria-hidden="true" tabindex="-1" style="display:none;" onchange="onWhMaterialSelectChange(this)">
      <option value="">— изберете —</option>${materialOptions}
    </select>
  </div>`;
  
  // В менютата за НОВА заявка полетата „Отпуснато количество“ и „Забележка“
  // не се показва — попълва се от Склад при обработка на вече подадена заявка.
  const isMyMaterialsView = currentTab === 'myMaterials';
  const showZabelezka = false;
  
  tr.innerHTML = `
    <td style="padding:4px 6px;">
      <input type="text" class="wh-mat-code" style="margin:0;width:100%;background:var(--locked-bg);font-size:12px;box-sizing:border-box;" placeholder="—" value="${escapeHtml(data.code||'')}" readonly title="Кодът се попълва автоматично при избор от менюто">
    </td>
    <td style="padding:4px 6px;">
      ${selectHtml}
      <input type="text" class="wh-mat-name-custom" style="display:none;margin-top:4px;width:100%;" placeholder="Въведете материал...">
    </td>
    <td style="padding:4px 6px;"><input type="text" class="wh-mat-merka" style="margin:0;width:100%;background:var(--locked-bg);" placeholder="—" value="${escapeHtml(data.merka||'')}" readonly title="Мярката се попълва автоматично при избор на материал"></td>
    <td style="padding:4px 6px;"><input type="text" class="wh-mat-kolichestvo" inputmode="decimal" autocomplete="off" style="margin:0;width:100%;" value="${escapeHtml(data.kolichestvo||'')}" placeholder="само число" title="Само цифри (напр. 5 или 2,5)"></td>
    <td style="padding:4px 6px;${showZabelezka ? '' : 'display:none;'}"><input type="text" class="wh-mat-zabelezka${currentRole === 'submitter' && !isMyMaterialsView ? ' lockedfield' : ''}" style="margin:0;width:100%;" value="${escapeHtml(data.zabelezka||'')}" ${currentRole === 'submitter' && !isMyMaterialsView ? 'disabled title="Попълва се от Склад след обработка на заявката."' : ''}></td>
    <td style="padding:4px 6px;text-align:center;"><button type="button" class="ghost" style="padding:4px 8px;font-size:12px;color:#c0392b;" onclick="document.getElementById('${rowId}').remove()">✕</button></td>
  `;
  document.getElementById('whMaterialsTableBody').appendChild(tr);
  const rowSelect = tr.querySelector('.wh-mat-select');
  if (rowSelect) rowSelect.dataset.materialType = materialType;
  
  if (data.name) {
    const select = tr.querySelector('.wh-mat-select');
    const customInput = tr.querySelector('.wh-mat-name-custom');
    const exists = materials.some(m => m.name === data.name);
    if (exists) {
      select.value = data.name;
      const option = Array.from(select.options).find(o => o.value === data.name);
      const codeInput = tr.querySelector('.wh-mat-code');
      if (option) {
        const merka = option.getAttribute('data-merka') || '';
        const code = option.getAttribute('data-code') || data.code || '';
        const merkaInput = tr.querySelector('.wh-mat-merka');
        if (merkaInput) merkaInput.value = data.merka || merka;
        if (codeInput) codeInput.value = code;
      } else if (codeInput && data.code) {
        codeInput.value = data.code;
      }
    } else if (data.name) {
      // Стара заявка с материал извън текущия списък — показваме името, без свободно въвеждане
      const opt = document.createElement('option');
      opt.value = data.name;
      opt.textContent = data.name;
      if (data.merka) opt.setAttribute('data-merka', data.merka);
      if (data.code) opt.setAttribute('data-code', data.code);
      select.appendChild(opt);
      select.value = data.name;
      if (customInput) { customInput.style.display = 'none'; customInput.value = ''; }
      const merkaInput = tr.querySelector('.wh-mat-merka');
      const codeInput = tr.querySelector('.wh-mat-code');
      if (merkaInput) {
        merkaInput.value = data.merka || '';
        merkaInput.readOnly = true;
        merkaInput.style.background = 'var(--locked-bg)';
      }
      if (codeInput) {
        codeInput.value = data.code || '';
        codeInput.readOnly = true;
        codeInput.style.background = 'var(--locked-bg)';
      }
    }
  }
  if (data.name) lastWarehouseSelectedByType[materialType] = data.name;
  if (rowSelect) renderWarehouseMaterialPicker(rowSelect, lastBefore);
  // Винаги заключваме мярката
  try {
    const merkaInput = tr.querySelector('.wh-mat-merka');
    if (merkaInput) {
      merkaInput.readOnly = true;
      merkaInput.style.background = 'var(--locked-bg)';
      merkaInput.title = 'Мярката се попълва автоматично при избор на материал';
    }
  } catch (_) {}
  refreshWarehouseMaterialOptionColors();
};

function sortWarehouseMaterialsAlphabetically(materials) {
  const list = Array.isArray(materials) ? materials.slice() : [];
  const collator = new Intl.Collator('bg', { sensitivity: 'base', numeric: true });
  return list.sort((a, b) => collator.compare(String(a && a.name || ''), String(b && b.name || '')));
}

function getLastWarehouseMaterialBefore(select, materialType) {
  const selects = Array.from(document.querySelectorAll('#whMaterialsTableBody .wh-mat-select'));
  let last = '';
  for (const candidate of selects) {
    if (candidate === select) break;
    if ((candidate.dataset.materialType || 'other') === (materialType || 'other') && candidate.value) {
      last = candidate.value;
    }
  }
  return last;
}

function renderWarehouseMaterialPicker(select, resumeName) {
  if (openWarehousePickerSelect === select) closeWarehouseMaterialPicker(select);
  const wrapper = select.closest('.wh-mat-picker');
  if (!wrapper) return;
  const trigger = wrapper.querySelector('.wh-mat-picker-trigger');
  const menu = select._warehousePickerMenu || wrapper.querySelector('.wh-mat-picker-menu');
  if (!trigger || !menu) return;
  select._warehousePickerMenu = menu;
  menu.innerHTML = '';
  Array.from(select.options).forEach(option => {
    const item = document.createElement('button');
    item.type = 'button';
    item.className = 'wh-mat-picker-option';
    item.setAttribute('role', 'option');
    item.dataset.value = option.value;
    item.textContent = option.textContent;
    item.style.cssText = 'display:block;width:100%;padding:7px 10px;border:0;background:#fff;color:#000;text-align:left;cursor:pointer;';
    item.addEventListener('mouseenter', () => { if (!item.dataset.previousChoice) item.style.backgroundColor = '#f1f4f7'; });
    item.addEventListener('mouseleave', () => { if (!item.dataset.previousChoice) item.style.backgroundColor = '#fff'; });
    item.addEventListener('click', function() {
      select.value = item.dataset.value;
      select.dispatchEvent(new Event('change', { bubbles: true }));
      closeWarehouseMaterialPicker(select);
      trigger.focus();
    });
    menu.appendChild(item);
  });
  const selected = select.options[select.selectedIndex];
  trigger.textContent = selected ? selected.textContent : '— изберете —';
  menu.dataset.resumeName = resumeName || '';
  trigger.onclick = function() {
    if (openWarehousePickerSelect === select) closeWarehouseMaterialPicker(select);
    else openWarehouseMaterialPicker(select);
  };
  trigger.onkeydown = function(e) {
    if (e.key === 'ArrowDown' || e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      openWarehouseMaterialPicker(select);
      const target = Array.from(menu.children).find(x => x.dataset.value === (select.value || menu.dataset.resumeName)) || menu.firstElementChild;
      if (target) target.focus();
    }
  };
  menu.onkeydown = function(e) {
    const items = Array.from(menu.querySelectorAll('.wh-mat-picker-option'));
    const index = items.indexOf(document.activeElement);
    if (e.key === 'Escape') { e.preventDefault(); closeWarehouseMaterialPicker(select); trigger.focus(); }
    else if (e.key === 'ArrowDown' && items.length) { e.preventDefault(); items[Math.min(items.length - 1, index + 1)].focus(); }
    else if (e.key === 'ArrowUp' && items.length) { e.preventDefault(); items[Math.max(0, index - 1)].focus(); }
  };
  if (!document._warehousePickerEventsBound) {
    document._warehousePickerEventsBound = true;
    document.addEventListener('pointerdown', function(e) {
      const active = openWarehousePickerSelect;
      if (!active) return;
      const w = active.closest('.wh-mat-picker');
      const m = active._warehousePickerMenu;
      if (w && !w.contains(e.target) && m && !m.contains(e.target)) closeWarehouseMaterialPicker(active);
    });
    window.addEventListener('resize', () => { if (openWarehousePickerSelect) closeWarehouseMaterialPicker(openWarehousePickerSelect); });
    window.addEventListener('scroll', () => { if (openWarehousePickerSelect) closeWarehouseMaterialPicker(openWarehousePickerSelect); });
  }
  refreshWarehouseMaterialOptionColors();
}

function openWarehouseMaterialPicker(select) {
  const wrapper = select.closest('.wh-mat-picker');
  const trigger = wrapper && wrapper.querySelector('.wh-mat-picker-trigger');
  const menu = select._warehousePickerMenu;
  if (!wrapper || !trigger || !menu) return;
  if (openWarehousePickerSelect && openWarehousePickerSelect !== select) closeWarehouseMaterialPicker(openWarehousePickerSelect);
  const rect = trigger.getBoundingClientRect();
  const maxHeight = Math.min(280, Math.max(120, window.innerHeight - 16));
  const below = window.innerHeight - rect.bottom - 8;
  const above = rect.top - 8;
  const placeBelow = below >= Math.min(180, maxHeight) || below >= above;
  const height = Math.max(80, Math.min(maxHeight, placeBelow ? below : above));
  menu.style.position = 'fixed';
  menu.style.left = Math.max(4, Math.min(rect.left, window.innerWidth - rect.width - 4)) + 'px';
  menu.style.width = rect.width + 'px';
  menu.style.maxHeight = height + 'px';
  menu.style.top = (placeBelow ? rect.bottom + 2 : Math.max(4, rect.top - height - 2)) + 'px';
  document.body.appendChild(menu);
  menu.hidden = false;
  trigger.setAttribute('aria-expanded', 'true');
  openWarehousePickerSelect = select;
  requestAnimationFrame(() => {
    const resume = menu.dataset.resumeName;
    const target = Array.from(menu.children).find(x => x.dataset.value === resume);
    menu.scrollTop = target ? Math.max(0, target.offsetTop - Math.round(menu.clientHeight / 3)) : 0;
  });
}

function closeWarehouseMaterialPicker(select) {
  const menu = select && select._warehousePickerMenu;
  const wrapper = select && select.closest('.wh-mat-picker');
  const trigger = wrapper && wrapper.querySelector('.wh-mat-picker-trigger');
  if (!menu || !wrapper) return;
  menu.hidden = true;
  menu.style.position = 'absolute';
  menu.style.left = '';
  menu.style.top = '';
  menu.style.width = '';
  menu.style.maxHeight = '280px';
  wrapper.appendChild(menu);
  if (trigger) trigger.setAttribute('aria-expanded', 'false');
  if (openWarehousePickerSelect === select) openWarehousePickerSelect = null;
}

function refreshWarehouseMaterialOptionColors() {
  const selects = Array.from(document.querySelectorAll('#whMaterialsTableBody .wh-mat-select'));
  const selectedEarlier = new Set();
  let currentType = null;
  selects.forEach(select => {
    const type = select.dataset.materialType || 'other';
    if (type !== currentType) {
      currentType = type;
      selectedEarlier.clear();
    }
    const menu = select._warehousePickerMenu;
    Array.from(menu ? menu.querySelectorAll('.wh-mat-picker-option') : select.options).forEach(option => {
      const value = option.dataset ? option.dataset.value : option.value;
      const alreadySelected = !!value && selectedEarlier.has(value);
      if (option.dataset) option.dataset.previousChoice = alreadySelected ? '1' : '';
      option.style.backgroundColor = alreadySelected ? '#dceeff' : '#fff';
      option.style.color = '#000000';
    });
    if (select.value) selectedEarlier.add(select.value);
  });
}

window.onWhMaterialSelectChange = function(select) {
  const tr = select.closest('tr');
  if (!tr) return;
  const customInput = tr.querySelector('.wh-mat-name-custom');
  const merkaInput = tr.querySelector('.wh-mat-merka');
  const codeInput = tr.querySelector('.wh-mat-code');
  // Без свободно въвеждане — само избор от списъка
  if (customInput) { customInput.style.display = 'none'; customInput.value = ''; }

  if (select.value) {
    const materialType = select.dataset.materialType || currentMaterialType || 'other';
    lastWarehouseSelectedByType[materialType] = select.value;
    const selectedOption = select.options[select.selectedIndex];
    const merka = selectedOption ? selectedOption.getAttribute('data-merka') || '' : '';
    const code = selectedOption ? selectedOption.getAttribute('data-code') || '' : '';
    if (merkaInput) {
      merkaInput.value = merka;
      merkaInput.readOnly = true;
      merkaInput.style.background = 'var(--locked-bg)';
      merkaInput.title = 'Мярката се попълва автоматично при избор на материал';
    }
    if (codeInput) {
      codeInput.value = code;
      codeInput.readOnly = true;
      codeInput.style.background = 'var(--locked-bg)';
      codeInput.placeholder = '—';
    }
  } else {
    if (merkaInput) {
      merkaInput.value = '';
      merkaInput.readOnly = true;
      merkaInput.style.background = 'var(--locked-bg)';
    }
    if (codeInput) {
      codeInput.value = '';
      codeInput.readOnly = true;
      codeInput.style.background = 'var(--locked-bg)';
    }
  }
  const trigger = tr.querySelector('.wh-mat-picker-trigger');
  const selected = select.options[select.selectedIndex];
  if (trigger) trigger.textContent = selected ? selected.textContent : '— изберете —';
  refreshWarehouseMaterialOptionColors();
};

function readWhMaterialsFromTable() {
  const rows = Array.from(document.getElementById('whMaterialsTableBody').querySelectorAll('tr'));
  return rows.map(tr => {
    const select = tr.querySelector('.wh-mat-select');
    const customInput = tr.querySelector('.wh-mat-name-custom');
    let name = '';
    if (select && select.value === '__other__' && customInput) {
      name = customInput.value.trim();
    } else if (select && select.value && select.value !== '__other__') {
      name = select.value;
    } else if (customInput && customInput.style.display !== 'none') {
      name = customInput.value.trim();
    }
    return {
      code: tr.querySelector('.wh-mat-code') ? tr.querySelector('.wh-mat-code').value.trim() : '',
      name: name,
      merka: tr.querySelector('.wh-mat-merka') ? tr.querySelector('.wh-mat-merka').value.trim() : '',
      kolichestvo: tr.querySelector('.wh-mat-kolichestvo') ? tr.querySelector('.wh-mat-kolichestvo').value.trim() : '',
      zabelezka: tr.querySelector('.wh-mat-zabelezka') ? tr.querySelector('.wh-mat-zabelezka').value.trim() : '',
      otpusnatoKolichestvo: ''
    };
  }).filter(m => m.name || m.merka || m.kolichestvo || m.zabelezka || m.code);
}

/* window exports */
try {
  window.whMaterialRowSeq = whMaterialRowSeq;
  window.lastWarehouseSelectedByType = lastWarehouseSelectedByType;
  window.populateMaterialSelects = populateMaterialSelects;
  window.sortWarehouseMaterialsAlphabetically = sortWarehouseMaterialsAlphabetically;
  window.getLastWarehouseMaterialBefore = getLastWarehouseMaterialBefore;
  window.renderWarehouseMaterialPicker = renderWarehouseMaterialPicker;
  window.openWarehouseMaterialPicker = openWarehouseMaterialPicker;
  window.closeWarehouseMaterialPicker = closeWarehouseMaterialPicker;
  window.refreshWarehouseMaterialOptionColors = refreshWarehouseMaterialOptionColors;
  window.readWhMaterialsFromTable = readWhMaterialsFromTable;
  // addWhMaterialRow / onWhMaterialSelectChange already assigned on window in body
} catch (_) {}
