'use strict';

/**
 * Static HTTP helpers: CORS, security headers, MIME, gzip static files.
 * Clean module — no auth/session code (that lives in auth-sessions and bootstrap).
 */
function createStaticService(deps) {
  const { fs, path, zlib, PUBLIC_DIR, PORT, LISTEN_HOST, getLanIPs, getUiVersion } = deps;
  const { createHttpHelpers } = require('./http-helpers');

function addCORS(res) {
  // Determine the incoming Origin (set per-request on res._origin by the server handler)
  const originHeader = (res && res._origin) ? String(res._origin) : '';

  // Build allowed origins list from env or default to localhost + LAN IPs + 'null' (file:// origins)
  const env = (process.env.CORS_ORIGINS || '').trim();
  let allowedList = [];
  if (env) {
    allowedList = env.split(',').map(s => s.trim()).filter(Boolean);
  } else {
    allowedList = ['http://localhost:' + PORT, 'null'].concat(getLanIPs().map(ip => 'http://' + ip + ':' + PORT));
  }

  const allowsAll = allowedList.includes('*');
  let allowOrigin = 'http://localhost:' + PORT;
  if (allowsAll) {
    allowOrigin = '*';
  } else if (originHeader && allowedList.includes(originHeader)) {
    allowOrigin = originHeader;
  } else if (allowedList.length > 0) {
    allowOrigin = allowedList[0];
  }

  // При credentials cookie auth не може Allow-Origin: *
  if (allowOrigin === '*') {
    res.setHeader('Access-Control-Allow-Origin', originHeader || 'http://localhost:' + PORT);
  } else {
    res.setHeader('Access-Control-Allow-Origin', allowOrigin);
  }
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.map': 'application/json; charset=utf-8'
};

function formatLocalDateTimeSeconds(d) {
  const dt = d instanceof Date ? d : (d ? new Date(d) : new Date());
  if (Number.isNaN(dt.getTime())) return String(d || '');
  const pad = (n) => String(n).padStart(2, '0');
  return pad(dt.getDate()) + '.' + pad(dt.getMonth() + 1) + '.' + dt.getFullYear() +
    ' ' + pad(dt.getHours()) + ':' + pad(dt.getMinutes()) + ':' + pad(dt.getSeconds());
}

  const httpHelpers = createHttpHelpers({ addCORS });
  const {
    applySecurityHeaders,
    cacheControlForExt,
    sendJSON,
    readBody,
    parseJsonOrError,
    readJsonFromRequest
  } = httpHelpers;

function serveStatic(req, res, pathname) {
  const safePath = path.normalize(pathname).replace(/^(\.\.[/\\])+/, '');
  let filePath = path.join(PUBLIC_DIR, safePath === '/' || safePath === '' ? 'index.html' : safePath);
  const resolvedPublic = path.resolve(PUBLIC_DIR);
  const resolvedFile = path.resolve(filePath);
  if (resolvedFile !== resolvedPublic && !resolvedFile.startsWith(resolvedPublic + path.sep)) {
    res.writeHead(403); res.end('Forbidden'); return;
  }
  const GZIP_EXT = new Set(['.js', '.css', '.html', '.json', '.svg', '.txt', '.md', '.map', '.xml']);
  function sendBuffer(data, ext, cacheCtl) {
    applySecurityHeaders(res);
    const type = MIME[ext] || 'application/octet-stream';
    const accept = String(req.headers['accept-encoding'] || '');
    const wantGzip = accept.includes('gzip') && GZIP_EXT.has(ext) && data && data.length > 1024;
    if (!wantGzip) {
      res.writeHead(200, { 'Content-Type': type, 'Cache-Control': cacheCtl });
      res.end(data);
      return;
    }
    zlib.gzip(data, (zErr, compressed) => {
      if (zErr || !compressed) {
        res.writeHead(200, { 'Content-Type': type, 'Cache-Control': cacheCtl });
        res.end(data);
        return;
      }
      res.writeHead(200, {
        'Content-Type': type,
        'Content-Encoding': 'gzip',
        'Vary': 'Accept-Encoding',
        'Cache-Control': cacheCtl,
        'Content-Length': compressed.length
      });
      res.end(compressed);
    });
  }
  function prepareHtml(buf) {
    let html = buf.toString('utf8');
    const version = encodeURIComponent(getUiVersion() || '0');
    if (html.indexOf('window.__UI_VERSION__') < 0) {
      html = html.replace(/<head>/i, '<head><script>window.__UI_VERSION__=' + JSON.stringify(getUiVersion() || '0') + ';</script>');
    }
    html = html.replace(/(<script\s+[^>]*src=["'])([^"']+)(["'][^>]*>)/gi, function (match, before, src, after) {
      if (/^https?:/i.test(src) || src.indexOf('?') >= 0) return match;
      if (/\/(js|css|lib)\//i.test(src) || /^(js|css|lib)\//i.test(src) || src.charAt(0) === '/') {
        return before + src + '?v=' + version + after;
      }
      return match;
    });
    html = html.replace(/(<link\s+[^>]*href=["'])([^"']+)(["'][^>]*>)/gi, function (match, before, href, after) {
      if (/^https?:/i.test(href) || href.indexOf('?') >= 0) return match;
      if (/\.css(?:\?|$)/i.test(href) || /css\//i.test(href)) {
        return before + href + '?v=' + version + after;
      }
      return match;
    });
    return Buffer.from(html, 'utf8');
  }
  fs.readFile(filePath, (err, data) => {
    if (err) {
      fs.readFile(path.join(PUBLIC_DIR, 'index.html'), (err2, data2) => {
        if (err2) { res.writeHead(404); res.end('Not found'); return; }
        sendBuffer(prepareHtml(data2), '.html', 'no-store');
      });
      return;
    }
    const ext = path.extname(filePath).toLowerCase();
    if (ext === '.html' || path.basename(filePath) === 'index.html') {
      sendBuffer(prepareHtml(data), '.html', 'no-store');
      return;
    }
    sendBuffer(data, ext, cacheControlForExt(ext));
  });
}

  return {
    addCORS,
    MIME,
    formatLocalDateTimeSeconds,
    applySecurityHeaders,
    cacheControlForExt,
    sendJSON,
    readBody,
    parseJsonOrError,
    readJsonFromRequest,
    serveStatic
  };
}

module.exports = { createStaticService };
