'use strict';
// Backward-compatible export; auth and user CRUD are implemented in users.js.
const { createUsersRoutes } = require('./users');
module.exports = { createAuthRoutes: createUsersRoutes, createUsersRoutes };
