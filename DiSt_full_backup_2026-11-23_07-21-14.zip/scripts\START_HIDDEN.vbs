Option Explicit
Dim sh, root
Set sh = CreateObject("WScript.Shell")
root = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = root
sh.Run "cmd /c """ & root & "\START_SERVER.bat""", 0, False
Set sh = Nothing
