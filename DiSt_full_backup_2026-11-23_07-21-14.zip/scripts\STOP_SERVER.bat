@echo off
setlocal
cd /d "%~dp0"
if exist "server.pid" (
  set /p PID=<"server.pid"
  powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -Command "try { Stop-Process -Id %PID% -Force -ErrorAction Stop; Write-Host 'DiSt stopped.' } catch { Write-Host $_.Exception.Message }"
) else (
  echo server.pid not found. DiSt may already be stopped.
)
