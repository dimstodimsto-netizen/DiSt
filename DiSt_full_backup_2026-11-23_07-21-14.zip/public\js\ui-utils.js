// Shared UI helpers and automatic refresh after a published UI version changes.

// ---------------------- 60-дневна верификация ----------------------
let verificationState = null;
let verificationTimer = null;

function formatVerificationDate(iso) {
  if (!iso) return '—';
  try { return new Date(iso).toLocaleDateString('bg-BG'); } catch (e) { return '—'; }
}
function formatVerificationDateTime(iso) {
  return formatDisplayDateTime(iso);
}

/** Човешки формат на дата/час (локален): дд.мм.гггг, чч:мм:сс — без ISO T…Z */
function formatDisplayDateTime(value) {
  if (value == null || value === '') return '—';
  let d;
  if (value instanceof Date) {
    d = value;
  } else if (typeof value === 'number' && Number.isFinite(value)) {
    d = new Date(value < 1e12 ? value * 1000 : value);
  } else {
    const s = String(value).trim();
    if (/^\d{10,13}$/.test(s)) {
      const n = Number(s);
      d = new Date(s.length <= 10 ? n * 1000 : n);
    } else {
      d = new Date(s);
    }
  }
  if (!d || Number.isNaN(d.getTime())) return String(value);
  const pad = function (n) { return String(n).padStart(2, '0'); };
  return pad(d.getDate()) + '.' + pad(d.getMonth() + 1) + '.' + d.getFullYear() +
    ' ' + pad(d.getHours()) + '.' + pad(d.getMinutes()) + '.' + pad(d.getSeconds());
}
function showVerificationNotice(state) {
  const el = $('verificationNotice');
  if (!el) return;
  if (!state || !state.warning || state.locked) { el.style.display = 'none'; return; }
  const remaining = Math.max(0, Number(state.daysRemaining || 0));
  el.innerHTML = '⚠️ Остават <b>' + remaining + ' ' + (remaining === 1 ? 'ден' : 'дни') + '</b> до края на верификационния период.';
  el.style.display = 'block';
}
function showVerificationLock(state) {
  const modal = $('verificationLock');
  if (!modal) return;
  verificationState = state || verificationState;
  if (!state || !state.locked) { modal.style.display = 'none'; return; }
  modal.style.display = 'flex';
  const text = $('verificationLockText');
  if (text) {
    const reason = state.lockReason || '';
    if (reason === 'clock_rollback') {
      text.textContent = 'Открито е връщане назад на системния часовник. Необходима е администраторска верификация.';
    } else if (reason === 'install_mismatch') {
      text.textContent = 'Тази инсталация е копирана или преместена на друг компютър/път. Нужен е верификационен код от оторизирания администратор.';
    } else if (reason === 'not_activated') {
      text.textContent = 'Нова инсталация: програмата трябва да бъде активирана с верификационен код преди ползване.';
    } else {
      text.textContent = 'Изминали са ' + state.elapsedDays + ' дни от последната верификация. Програмата е заключена до въвеждане на валиден код от администратор.';
    }
  }
  const contactEl = $('verificationLockContact');
  if (contactEl) {
    const msg = (state && state.licenseContact) ? String(state.licenseContact) : 'Оторизирана инсталация — свържете се с автора на системата.';
    contactEl.textContent = msg;
    contactEl.style.display = 'block';
  }
  const panel = $('verificationAdminPanel');
  if (panel) panel.style.display = 'block';
}
async function refreshVerificationStatus() {
  try {
    const res = await fetch('/api/system/verification-status', { cache: 'no-store' });
    if (!res.ok) return;
    const state = await res.json();
    verificationState = state;
    showVerificationNotice(state);
    showVerificationLock(state);
  } catch (e) { console.warn('Verification status:', e); }
}

async function saveLicenseContact() {
  if (currentRole !== 'admin') { toast('Само администратор.'); return; }
  const ta = document.getElementById('licenseContactText');
  const st = document.getElementById('licenseContactStatus');
  const text = ta ? String(ta.value || '').trim() : '';
  if (st) st.textContent = 'Запис...';
  try {
    const res = await authFetch('/api/system/license-contact', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || ('HTTP ' + res.status));
    if (st) st.textContent = 'Запазено.';
    if (ta && data.text) ta.value = data.text;
    toast('✅ Текстът за лиценз/контакт е записан');
    try { await loadVerificationInfo(); } catch (_) {}
  } catch (e) {
    if (st) st.textContent = '';
    toast('❌ ' + (e.message || e));
  }
}

async function submitChangeVerificationCode() {
  if (currentRole !== 'admin') { toast('Само администратор може да сменя кода.'); return; }
  const cur = document.getElementById('verifyCodeCurrent');
  const n1 = document.getElementById('verifyCodeNew');
  const n2 = document.getElementById('verifyCodeNew2');
  const err = document.getElementById('changeVerifyCodeError');
  const st = document.getElementById('changeVerifyCodeStatus');
  const currentCode = String(cur && cur.value || '').trim();
  const newCode = String(n1 && n1.value || '').trim();
  const confirmCode = String(n2 && n2.value || '').trim();
  if (err) { err.style.display = 'none'; err.textContent = ''; }
  if (!currentCode || !newCode) {
    if (err) { err.textContent = 'Попълнете текущия и новия код.'; err.style.display = 'block'; }
    return;
  }
  if (newCode.length < 8) {
    if (err) { err.textContent = 'Новият код трябва да е поне 8 символа.'; err.style.display = 'block'; }
    return;
  }
  if (newCode !== confirmCode) {
    if (err) { err.textContent = 'Новият код и потвърждението не съвпадат.'; err.style.display = 'block'; }
    return;
  }
  if (!(await confirmDialog('Сигурни ли сте, че искате да смените верификационния код?\nСтарият код вече няма да важи.'))) return;
  if (st) st.textContent = 'Запис...';
  try {
    const res = await authFetch('/api/system/change-verification-code', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ currentCode, newCode, confirmCode })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || ('HTTP ' + res.status));
    if (cur) cur.value = '';
    if (n1) n1.value = '';
    if (n2) n2.value = '';
    if (st) st.textContent = 'Готово.';
    toast('✅ Верификационният код е сменен. Запазете новия код!');
  } catch (e) {
    if (st) st.textContent = '';
    if (err) { err.textContent = e.message || String(e); err.style.display = 'block'; }
    toast('❌ ' + (e.message || e));
  }
}

async function submitUnlockInstallation() {
  const userEl = $('unlockAdminUser');
  const passEl = $('unlockAdminPass');
  const codeEl = $('unlockVerificationCode');
  const error = $('unlockVerificationError');
  const username = String(userEl && userEl.value || '').trim();
  const password = String(passEl && passEl.value || '');
  const code = String(codeEl && codeEl.value || '').trim();
  if (error) { error.style.display = 'none'; error.textContent = ''; }

  if (!username || !password || !code) {
    if (error) { error.textContent = 'Попълнете админ потребител, парола и верификационен код.'; error.style.display = 'block'; }
    return;
  }

  const btn = $('btnUnlockInstallation');
  if (btn) { btn.disabled = true; btn.textContent = 'Отключване...'; }
  try {
    const res = await fetch('/api/system/unlock', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify({ username, password, code }),
      cache: 'no-store'
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || ('HTTP ' + res.status));

    saveSessionToken(data.token || 'cookie-session');
    sessionExpiresAt = data.expiresAt ?? null;
    try { scheduleSessionExpiry(); } catch (_) {}
    try { localStorage.setItem(CURRENT_USER_KEY, data.username || username); } catch (_) {}
    notifyParentSession(data.token || null);

    verificationState = data.verification || null;
    showVerificationNotice(verificationState);
    showVerificationLock(verificationState);

    if (codeEl) codeEl.value = '';
    if (passEl) passEl.value = '';

    toast('✅ Инсталацията е отключена. Новият период е 60 дни.');
    applyRoleUI(data.role || 'admin', data.username || username, data.name || '', data.struktura || '', data.allowedMenus, { strukturaLocked: data.strukturaLocked, korpus: data.korpus, etazhi: data.etazhi });
    try {
      const loginStep = document.getElementById('loginStep');
      const roleStep = document.getElementById('roleSelectStep'); // може да липсва при единен вход
      if (loginStep) loginStep.style.display = 'none';
      if (roleStep) roleStep.style.display = 'none';
    } catch (_) {}
  } catch (e) {
    if (error) { error.textContent = e.message || 'Невалидни данни.'; error.style.display = 'block'; }
    toast('❌ ' + (e.message || e));
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = '🔓 Отключи / активирай инсталацията'; }
  }
}

async function submitProgramVerification() {
  if (currentRole !== 'admin') { toast('Само администратор може да извърши верификация.'); return; }
  const input = $('verificationCode');
  const error = $('verificationError');
  const code = String(input?.value || '').trim();
  if (!code) { if (error) { error.textContent='Въведете код.'; error.style.display='block'; } return; }
  try {
    const res = await authFetch('/api/system/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code }), cache: 'no-store'
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Грешка при верификацията.');
    if (input) input.value = '';
    if (error) error.style.display = 'none';
    verificationState = data.verification;
    showVerificationNotice(verificationState);
    showVerificationLock(verificationState);
    try { await loadVerificationInfo(); } catch (_) {}
    toast('✅ Верификацията е успешна. Новият период е 60 дни.');
  } catch (e) {
    if (error) { error.textContent = e.message || 'Невалиден код.'; error.style.display = 'block'; }
  }
}

function escapeHtml(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  })[c]);
}

let __toastHideTimer = null;
function toast(msg, type) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.remove('ok', 'error', 'info');
  if (type === 'ok' || type === 'error' || type === 'info') t.classList.add(type);
  t.classList.add('show');
  if (__toastHideTimer) clearTimeout(__toastHideTimer);
  __toastHideTimer = setTimeout(() => t.classList.remove('show'), 2200);
}

// ---- Стилизиран потвърждаващ диалог (заменя браузърния confirm()) ----
// Използване: if (!(await confirmDialog('Текст?'))) return;
let __confirmResolve = null;
function confirmDialog(message) {
  return new Promise((resolve) => {
    const modal = document.getElementById('confirmModal');
    const textEl = document.getElementById('confirmModalText');
    if (!modal || !textEl) { resolve(window.confirm(message)); return; }
    textEl.textContent = message;
    __confirmResolve = resolve;
    modal.style.display = 'flex';
    const okBtn = document.getElementById('confirmModalOk');
    if (okBtn) okBtn.focus();
  });
}
function __closeConfirmDialog(result) {
  const modal = document.getElementById('confirmModal');
  if (modal) modal.style.display = 'none';
  if (__confirmResolve) { const r = __confirmResolve; __confirmResolve = null; r(result); }
}
(function wireConfirmDialog() {
  const modal = document.getElementById('confirmModal');
  const okBtn = document.getElementById('confirmModalOk');
  const cancelBtn = document.getElementById('confirmModalCancel');
  if (okBtn) okBtn.addEventListener('click', () => __closeConfirmDialog(true));
  if (cancelBtn) cancelBtn.addEventListener('click', () => __closeConfirmDialog(false));
  if (modal) modal.addEventListener('click', (e) => { if (e.target === modal) __closeConfirmDialog(false); });
})();
// Escape затваря потвърждаващия диалог или прегледа на заявка за материали (ако са отворени).
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return;
  const confirmModal = document.getElementById('confirmModal');
  if (confirmModal && confirmModal.style.display === 'flex') { __closeConfirmDialog(false); return; }
  const whModal = document.getElementById('whViewModal');
  if (whModal && whModal.style.display && whModal.style.display !== 'none' && typeof window.closeWhViewModal === 'function') {
    window.closeWhViewModal();
  }
});

function statusClass(status) {
  if (status === 'Изпълнена') return 'st-ok';
  if (status === 'Изпълнява се') return 'st-progress';
  if (status === 'Изчаква материали' || status === 'Чака материали' || status === 'За докладна') return 'st-warn';
  if (status === 'Не е изпълнена') return 'st-bad';
  return 'st-neutral';
}

function formatDate(iso) {
  if (!iso) return '—';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return '—';
  return String(d.getDate()).padStart(2,'0') + '.' + String(d.getMonth()+1).padStart(2,'0') + '.' + d.getFullYear() + ' ' + String(d.getHours()).padStart(2,'0') + ':' + String(d.getMinutes()).padStart(2,'0');
}

function formatWhDate(iso) { return formatDate(iso); }

function parseStamp(stamp) {
  if (!stamp) return null;
  const [datePart, timePart] = stamp.split(' ');
  if (!datePart) return null;
  const [dd, mm, yyyy] = datePart.split('.').map(Number);
  let hh = 0, min = 0;
  if (timePart) { const [h,m] = timePart.split(':').map(Number); hh = h||0; min = m||0; }
  if (!dd || !mm || !yyyy) return null;
  return new Date(yyyy, mm-1, dd, hh, min);
}

function getAudioCtx() {
  if (!audioCtx) {
    try { audioCtx = new (window.AudioContext || window.webkitAudioContext)(); }
    catch(e){ return null; }
  }
  if (audioCtx.state === 'suspended') { audioCtx.resume().catch(()=>{}); }
  return audioCtx;
}

function playGongSound() {
  const ctx = getAudioCtx();
  if (!ctx) return;
  const now = ctx.currentTime;
  [220, 330, 440].forEach((freq, i) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.linearRampToValueAtTime(0.28 / (i + 1), now + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 1.8);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 1.9);
  });
}

function startAlertSound() {
  if (alertSoundInterval) return;
  playGongSound();
  alertSoundInterval = setInterval(playGongSound, 3500);
}

function stopAlertSound() {
  if (alertSoundInterval) { clearInterval(alertSoundInterval); alertSoundInterval = null; }
}


// Expose the stable shared helper API for classic-script UI modules.
window.formatVerificationDate=formatVerificationDate;
window.formatVerificationDateTime=formatVerificationDateTime;
window.formatDisplayDateTime=formatDisplayDateTime;
window.showVerificationNotice=showVerificationNotice;
window.showVerificationLock=showVerificationLock;
window.refreshVerificationStatus=refreshVerificationStatus;
window.saveLicenseContact=saveLicenseContact;
window.submitChangeVerificationCode=submitChangeVerificationCode;
window.submitUnlockInstallation=submitUnlockInstallation;
window.submitProgramVerification=submitProgramVerification;
window.toast=toast;
window.confirmDialog=confirmDialog;
window.__closeConfirmDialog=__closeConfirmDialog;
window.statusClass=statusClass;
window.formatDate=formatDate;
window.formatWhDate=formatWhDate;
window.parseStamp=parseStamp;
window.getAudioCtx=getAudioCtx;
window.playGongSound=playGongSound;
window.startAlertSound=startAlertSound;
window.stopAlertSound=stopAlertSound;

(function installUiVersionWatcher() {
  const initial = String(window.__UI_VERSION__ || '');
  if (!initial || window.__uiVersionWatcherInstalled) return;
  window.__uiVersionWatcherInstalled = true;
  let reloading = false;
  async function check() {
    if (reloading || document.visibilityState === 'hidden' || !navigator.onLine) return;
    try {
      const r = await fetch('/api/server-info?versionCheck=' + Date.now(), { cache: 'no-store', credentials: 'same-origin' });
      if (!r.ok) return;
      const info = await r.json();
      if (!info.uiVersion || String(info.uiVersion) === initial) return;
      reloading = true;
      try { sessionStorage.setItem('dist_ui_updated_notice', '1'); } catch (_) {}
      try {
        if (window.parent && window.parent !== window) {
          window.parent.postMessage({ type: 'zayavki-ui-updated', uiVersion: String(info.uiVersion) }, location.origin);
        }
      } catch (_) {}
      const u = new URL(location.href);
      u.searchParams.set('_ui', String(info.uiVersion));
      location.replace(u.toString());
    } catch (_) { /* offline or temporary network failure: retry next interval */ }
  }
  window.setInterval(check, 45000);
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible') check(); });
  window.addEventListener('online', check);
})();

(function showUiUpdatedNotice() {
  let show = false;
  try { show = sessionStorage.getItem('dist_ui_updated_notice') === '1'; sessionStorage.removeItem('dist_ui_updated_notice'); } catch (_) {}
  if (!show) return;
  const announce = function () {
    if (typeof window.toast === 'function') window.toast('✅ Системата е обновена и страницата е презаредена.', 'info');
    else window.setTimeout(announce, 250);
  };
  announce();
})();

// ---- От app.js (стъпка B): размер и uptime ----

/** Размер във байтове → четим низ (B / KB / MB). */
function formatBytes(n) {
  n = Number(n) || 0;
  if (n < 1024) return n + ' B';
  if (n < 1024 * 1024) return (n / 1024).toFixed(1) + ' KB';
  return (n / (1024 * 1024)).toFixed(2) + ' MB';
}

/** Секунди uptime → „Xд Yч Zм Wс“. */
function formatUptime(sec) {
  sec = Math.max(0, Number(sec) || 0);
  const d = Math.floor(sec / 86400);
  const h = Math.floor((sec % 86400) / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  const parts = [];
  if (d) parts.push(d + 'д');
  if (h || d) parts.push(h + 'ч');
  parts.push(m + 'м');
  parts.push(s + 'с');
  return parts.join(' ');
}

try {
  window.formatBytes = formatBytes;
  window.formatUptime = formatUptime;
} catch (_) {}
