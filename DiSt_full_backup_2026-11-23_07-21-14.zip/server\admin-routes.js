'use strict';

/**
 * Admin HTTP routes (/api/admin/*, /api/auth/heartbeat).
 * Extracted for safer partial updates.
 */
function createAdminRoutes(deps) {
  const {
    requireAuth, requireAdmin, sendJSON, readJsonFromRequest, readBody,
    getClientIp, writeSystemLog, db, kvGet, kvSet, kvDelete,
    agentSuite,
    createDownloadableBackup, applyProgramUpdate, scheduleServerRestart,
    getSession, getSessionToken, sessions, destroySession, touchHeartbeat, listActiveSessions,
    stmtSessionAll,
    verifyBackupZip, sha256File, getLastCrashLog, cleanupOldServerFiles,
    migrateWhMaterialTypes, cleanupOrphanRecordsServer,
    getStabilityStats, formatLogTimestampLocal, formatCrashLineForLog, formatHeartbeatLine,
    formatLocalDateTimeSeconds,
    HEARTBEAT_ONLINE_MS, getLanIPs, PORT, UI_VERSION, SERVER_STARTED_AT, APP_VERSION, DB_PATH,
    DATA_DIR, os, fs, path, spawnSync, ROOT_DIR,
    UPDATE_MAX_BYTES, parseJsonOrError,
    getAllUsersServer, getUserByIdServer, getUserByUsernameServer, getUserIdsServer,
    saveUserServer, hashPasswordPBKDF2, observerMenusForUser, sanitizeObserverMenus,
    DEFAULT_OBSERVER_MENUS, getRecordsIndexSafe, isEmailNotifyEnabled, crypto
  } = deps;

  return async function handleAdminRoute(req, res, parsed, pathname) {
    if (!pathname.startsWith('/api/admin/') && pathname !== '/api/auth/heartbeat') {
      return false;
    }
    if (pathname === '/api/admin/logs' && req.method === 'GET') {
      const sess = requireAuth(req, res);
      if (!sess) return true;
      if (sess.role !== 'admin') { sendJSON(res, 403, { error: 'Само администратор' }); return true; }
      const u = new URL(req.url, 'http://localhost');
      const limit = Math.min(500, Math.max(1, parseInt(u.searchParams.get('limit') || '200', 10) || 200));
      const category = (u.searchParams.get('category') || '').trim();
      const level = (u.searchParams.get('level') || '').trim();
      const q = (u.searchParams.get('q') || '').trim().toLowerCase();
      let rows;
      try {
        if (category && level) {
          rows = db.prepare('SELECT id, ts, level, category, message, username, ip, meta FROM system_log WHERE category = ? AND level = ? ORDER BY ts DESC LIMIT ?').all(category, level, limit);
        } else if (category) {
          rows = db.prepare('SELECT id, ts, level, category, message, username, ip, meta FROM system_log WHERE category = ? ORDER BY ts DESC LIMIT ?').all(category, limit);
        } else if (level) {
          rows = db.prepare('SELECT id, ts, level, category, message, username, ip, meta FROM system_log WHERE level = ? ORDER BY ts DESC LIMIT ?').all(level, limit);
        } else {
          rows = db.prepare('SELECT id, ts, level, category, message, username, ip, meta FROM system_log ORDER BY ts DESC LIMIT ?').all(limit);
        }
      } catch (e) {
        sendJSON(res, 500, { error: e.message });
        return true;
      }
      if (q) {
        rows = rows.filter(r =>
          (r.message || '').toLowerCase().includes(q) ||
          (r.username || '').toLowerCase().includes(q) ||
          (r.ip || '').toLowerCase().includes(q) ||
          (r.category || '').toLowerCase().includes(q)
        );
      }
      sendJSON(res, 200, { ok: true, logs: rows });
      return true;
    }

    // ---- API: обновяване на програмата (zip, само админ) ----
    if (pathname === '/api/admin/update' && req.method === 'POST') {
      const sess = requireAdmin(req, res);
      if (!sess) return true;
      let body;
      try {
        const maxB = (typeof UPDATE_MAX_BYTES === 'number' && UPDATE_MAX_BYTES > 0) ? UPDATE_MAX_BYTES : (80 * 1024 * 1024);
        body = await readBody(req, maxB);
      } catch (e) {
        const msg = String((e && e.message) || e || '');
        if (/too large/i.test(msg) || /Body too large/i.test(msg)) {
          sendJSON(res, 413, { error: 'Файлът е твърде голям (макс. ~80 MB).' });
        } else {
          sendJSON(res, 500, { error: 'Грешка при четене на обновлението: ' + msg });
        }
        return true;
      }
      const parsed = parseJsonOrError(body, res, { emptyError: 'Празен body', badError: 'Невалиден JSON' });
      if (!parsed) return true;
      const b64 = String(parsed.zipBase64 || '').replace(/^data:application\/zip;base64,/, '').replace(/\s/g, '');
      if (!b64) { sendJSON(res, 400, { error: 'Липсва zipBase64' }); return true; }
      let zipBuffer;
      try { zipBuffer = Buffer.from(b64, 'base64'); } catch (e) {
        sendJSON(res, 400, { error: 'Невалиден base64' }); return true;
      }
      if (!zipBuffer.length) { sendJSON(res, 400, { error: 'Празен архив' }); return true; }
      // basic ZIP magic
      if (zipBuffer[0] !== 0x50 || zipBuffer[1] !== 0x4b) {
        sendJSON(res, 400, { error: 'Файлът не е валиден ZIP архив.' }); return true;
      }
      try {
        const result = applyProgramUpdate(zipBuffer, { username: sess.username });
        const appliedAt = new Date().toISOString();
        const updateInfo = {
          version: result.version || 'неизвестна версия',
          appliedAt,
          appliedBy: sess.username || '',
          appliedCount: Array.isArray(result.applied) ? result.applied.length : 0,
          deletedCount: Array.isArray(result.deleted) ? result.deleted.length : 0
        };
        try { kvSet('system:lastAppliedUpdate', JSON.stringify(updateInfo)); } catch (_) {}
        writeSystemLog('info', 'update', 'Приложено обновление: ' + result.applied.length + ' файла, изтрити: ' + result.deleted.length, {
          username: sess.username,
          ip: getClientIp(req),
          meta: { ...updateInfo, applied: result.applied, deleted: result.deleted, restartRequired: result.restartRequired, backupDir: result.backupDir }
        });
        // Phase 1: автоматични smoke проверки след успешно обновление
        let agentReport = null;
        try {
          if (agentSuite && typeof agentSuite.shouldRunAfterUpdate === 'function' && agentSuite.shouldRunAfterUpdate()
              && typeof agentSuite.runSuite === 'function') {
            agentReport = agentSuite.runSuite({
              username: sess.username,
              ip: getClientIp(req),
              trigger: 'post-update',
              updateVersion: updateInfo.version
            });
          }
        } catch (agentErr) {
          try {
            writeSystemLog('warn', 'agent', 'Post-update agent suite failed: ' + (agentErr && agentErr.message ? agentErr.message : agentErr), {
              username: sess.username,
              ip: getClientIp(req)
            });
          } catch (_) {}
        }
        if (agentReport) {
          sendJSON(res, 200, Object.assign({}, result, { agentReport: agentReport }));
        } else {
          sendJSON(res, 200, result);
        }
      } catch (e) {
        writeSystemLog('error', 'update', 'Неуспешно обновление: ' + (e.message || e), {
          username: sess.username,
          ip: getClientIp(req)
        });
        sendJSON(res, 400, { error: e.message || String(e) });
      }
      return true;
    }


    // ---- API: рестарт на сървъра (само admin) ----
    if (pathname === '/api/admin/restart' && req.method === 'POST') {
      const sess = requireAdmin(req, res);
      if (!sess) return true;
      let parsedBody = {};
      parsedBody = await readJsonFromRequest(req, res, { emptyOk: true });
      if (!parsedBody) return true;
      if (parsedBody.confirm !== true && parsedBody.confirm !== 'true' && parsedBody.confirm !== 1) {
        sendJSON(res, 400, { error: 'За рестарт е нужно confirm: true.' });
        return true;
      }
      // Допълнителна защита: текст RESTART
      const phrase = String(parsedBody.phrase || '').trim().toUpperCase();
      if (phrase !== 'RESTART') {
        sendJSON(res, 400, {
          error: 'За отдалечен рестарт въведете RESTART за потвърждение. Имайте предвид, че ако рестартът се провали, сървърът може да остане спрян до ръчно пускане.'
        });
        return true;
      }
      // Минимален интервал 90 сек между рестарти
      try {
        const last = parseInt(kvGet('settings:lastRestartRequest') || '0', 10) || 0;
        if (last && Date.now() - last < 90000) {
          sendJSON(res, 429, { error: 'Изчакайте поне 90 секунди между рестарти.' });
          return true;
        }
      } catch (_) {}
      try { kvSet('settings:lastRestartRequest', String(Date.now())); } catch (_) {}
      const ok = scheduleServerRestart(1200, 'ръчен рестарт от администратор', sess.username);
      if (!ok) {
        sendJSON(res, 409, { error: 'Рестарт вече е планиран.' });
        return true;
      }
      writeSystemLog('warn', 'system', 'Администраторът заяви рестарт на сървъра', {
        username: sess.username,
        ip: getClientIp(req)
      });
      sendJSON(res, 200, {
        ok: true,
        restarting: true,
        message: 'Сървърът ще се рестартира след около 1–2 секунди. Ако след 30–60 сек няма връзка — помолете IT да пусне START_SERVER.bat / WATCHDOG.'
      });
      return true;
    }


    // ---- API: изтегляне на бекъп (данни + настройки) ----
    if (pathname === '/api/admin/backup' && req.method === 'GET') {
      const sess = requireAdmin(req, res);
      if (!sess) return true;
      try {
        const info = createDownloadableBackup();
        writeSystemLog('info', 'backup', 'Изтеглен бекъп: ' + info.fileName + ' (' + info.size + ' bytes)', {
          username: sess.username,
          ip: getClientIp(req),
          meta: { fileName: info.fileName, size: info.size }
        });
        const data = fs.readFileSync(info.path);
        const isZip = /\.zip$/i.test(info.fileName);
        res.writeHead(200, {
          'Content-Type': isZip ? 'application/zip' : 'application/octet-stream',
          'Content-Disposition': 'attachment; filename="' + info.fileName + '"',
          'Content-Length': String(data.length),
          'Cache-Control': 'no-store',
          'X-Backup-Format': info.format || (isZip ? 'zip' : 'db')
        });
        res.end(data);
      } catch (e) {
        writeSystemLog('error', 'backup', 'Неуспешен бекъп: ' + (e.message || e), {
          username: sess.username,
          ip: getClientIp(req)
        });
        const code = e.status || 500;
        sendJSON(res, code, { error: e.message || 'Грешка при създаване на бекъп.' });
      }
      return true;
    }






    // ---- API: предупреждение за unclean shutdown (админ банер) ----
    if (pathname === '/api/admin/stability-alert' && req.method === 'GET') {
      const sess = requireAdmin(req, res);
      if (!sess) return true;
      try {
        const stab = getStabilityStats();
        const last = stab.lastUncleanShutdown;
        const lastAt = last && last.at ? Number(last.at) : 0;
        const recentKv = !!(last && lastAt && (Date.now() - lastAt) < 48 * 60 * 60 * 1000);
        const recentLog = (stab.uncleanShutdowns24h || 0) > 0;
        const show = recentKv || recentLog;
        sendJSON(res, 200, {
          show: show,
          uncleanShutdowns24h: stab.uncleanShutdowns24h,
          lastUncleanShutdown: last,
          lastSuccessfulStart: stab.lastSuccessfulStart,
          uptimeSec: stab.uptimeSec,
          pid: stab.pid
        });
      } catch (e) {
        sendJSON(res, 500, { error: e.message || 'stability-alert failed' });
      }
      return true;
    }


    // ---- API: активни сесии (админ) ----
    // slide:false — прегледът НЕ удължава сесията на админа (иначе „Остава“ скача на пълен TTL)

    // ---- Heartbeat: клиентът съобщава, че е онлайн ----
    if (pathname === '/api/auth/heartbeat' && req.method === 'POST') {
      const token = getSessionToken(req);
      if (!token) {
        sendJSON(res, 401, { error: 'Не сте влезли.' });
        return true;
      }
      // Без slide — само lastSeenAt
      const sess = getSession(req, { slide: false });
      if (!sess) {
        sendJSON(res, 401, { error: 'Сесията е изтекла.' });
        return true;
      }
      touchHeartbeat(token, sess);
      sendJSON(res, 200, {
        ok: true,
        lastSeenAt: sess.lastSeenAt,
        expiresAt: sess.expiresAt,
        onlineWindowMs: HEARTBEAT_ONLINE_MS
      });
      return true;
    }

    if (pathname === '/api/admin/sessions' && req.method === 'GET') {
      req._resForSessionSlide = res;
      const sess = getSession(req, { slide: false });
      if (!sess || sess.role !== 'admin') {
        sendJSON(res, 401, { error: 'Нужен е администраторски вход.' });
        return true;
      }
      try {
        const now = Date.now();
        const currentToken = getSessionToken(req);
        const byToken = new Map();

        // От паметта
        for (const [token, se] of sessions.entries()) {
          if (!se) continue;
          if (se.expiresAt != null && now >= Number(se.expiresAt)) continue;
          byToken.set(token, se);
        }
        // От БД (след рестарт / други инстанции)
        try {
          const rows = stmtSessionAll.all();
          for (const row of rows) {
            if (!row || !row.token) continue;
            const exp = row.expires_at == null ? null : Number(row.expires_at);
            if (exp != null && now >= exp) continue;
            if (!byToken.has(row.token)) {
              byToken.set(row.token, {
                userId: row.user_id,
                username: row.username,
                name: row.name || '',
                role: row.role,
                expiresAt: exp
              });
            }
          }
        } catch (_) {}

        const list = [];
        for (const [token, se] of byToken.entries()) {
          const exp = se.expiresAt == null ? null : Number(se.expiresAt);
          const created = se.createdAt == null ? null : Number(se.createdAt);
          const lastSeen = se.lastSeenAt == null ? null : Number(se.lastSeenAt);
          const online = lastSeen != null && (now - lastSeen) <= HEARTBEAT_ONLINE_MS;
          list.push({
            token: token,
            username: se.username || '',
            name: se.name || '',
            role: se.role || '',
            createdAt: created,
            lastSeenAt: lastSeen,
            online: online,
            expiresAt: exp,
            remainingMs: exp != null ? Math.max(0, exp - now) : null,
            isCurrent: !!(currentToken && token === currentToken)
          });
        }
        list.sort((a, b) => {
          if (a.isCurrent !== b.isCurrent) return a.isCurrent ? -1 : 1;
          if (!!a.online !== !!b.online) return a.online ? -1 : 1;
          return String(a.username).localeCompare(String(b.username), 'bg');
        });
        sendJSON(res, 200, {
          sessions: list,
          count: list.length,
          serverNow: now
        });
      } catch (e) {
        sendJSON(res, 500, { error: e.message || 'Грешка при списък сесии.' });
      }
      return true;
    }

    if (pathname === '/api/admin/sessions/revoke' && req.method === 'POST') {
      const sess = requireAdmin(req, res);
      if (!sess) return true;
      try {
        const parsed = await readJsonFromRequest(req, res, { emptyOk: true });
        if (!parsed) return true;
        const token = String(parsed.token || '').trim();
        if (!token) {
          sendJSON(res, 400, { error: 'Липсва token.' });
          return true;
        }
        const currentToken = getSessionToken(req);
        if (currentToken && token === currentToken) {
          sendJSON(res, 400, { error: 'Не можете да изгоните собствената си сесия оттук.' });
          return true;
        }
        let targetUser = '';
        let targetRole = '';
        try {
          const se = sessions.get(token);
          if (se) { targetUser = se.username || ''; targetRole = se.role || ''; }
        } catch (_) {}
        if (!targetUser) {
          try {
            const row = stmtSessionGet.get(token);
            if (row) { targetUser = row.username || ''; targetRole = row.role || ''; }
          } catch (_) {}
        }
        destroySession(token);
        writeSystemLog('warn', 'auth', 'Админ прекрати сесия: ' + (targetUser || token.slice(0, 8)), {
          username: sess.username,
          ip: getClientIp(req), meta: { targetUser, targetRole, reason: 'admin_terminated_session' }
        });
        sendJSON(res, 200, { ok: true, targetUser: targetUser });
      } catch (e) {
        sendJSON(res, 500, { error: e.message || 'Грешка при изгонване.' });
      }
      return true;
    }

    // ---- API: дистанционно изпълнение на фиксиран DEPCHECK.bat (само админ) ----
    if (pathname === '/api/admin/run-depcheck' && req.method === 'POST') {
      const sess = requireAdmin(req, res);
      if (!sess) return true;
      try {
        // depcheck.js runs under the same Node binary as the server (any OS)
        const now = Date.now();
        let lastRun = 0;
        try { lastRun = Number(kvGet('system:lastDepcheckRun') || 0) || 0; } catch (_) {}
        if (lastRun && now - lastRun < 15000) {
          sendJSON(res, 429, { error: 'Изчакайте поне 15 секунди преди следваща проверка.' });
          return true;
        }
        const root = path.resolve(ROOT_DIR);
        // Direct node — avoids cmd.exe quoting bugs with paths like C:\DiSt_v1.5\...
        const scriptJs = path.resolve(root, 'scripts', 'depcheck.js');
        const expectedJs = path.resolve(root, 'scripts', 'depcheck.js');
        if (scriptJs !== expectedJs || !scriptJs.startsWith(root + path.sep) || !fs.existsSync(scriptJs) || !fs.lstatSync(scriptJs).isFile()) {
          sendJSON(res, 404, { error: 'Липсва scripts\\depcheck.js или файлът не е достъпен.' });
          return true;
        }
        try {
          const st = fs.lstatSync(scriptJs);
          if (typeof st.isSymbolicLink === 'function' && st.isSymbolicLink()) {
            sendJSON(res, 404, { error: 'scripts\\depcheck.js не трябва да е symbolic link.' });
            return true;
          }
        } catch (_) {}
        try { kvSet('system:lastDepcheckRun', String(now)); } catch (_) {}
        const result = spawnSync(process.execPath, [scriptJs], {
          cwd: root,
          encoding: 'utf8',
          windowsHide: true,
          timeout: 90000,
          maxBuffer: 2 * 1024 * 1024,
          env: process.env
        });
        const output = String((result.stdout || '') + (result.stderr ? '\n' + result.stderr : '')).trim().slice(-20000);
        const timedOut = !!(result.error && (result.error.code === 'ETIMEDOUT' || /timed out/i.test(result.error.message || '')));
        const ok = !result.error && result.status === 0;
        const report = {
          ok,
          exitCode: Number.isInteger(result.status) ? result.status : null,
          timedOut,
          startedAt: new Date(now).toISOString(),
          completedAt: new Date().toISOString(),
          output,
          error: result.error ? String(result.error.message || result.error).slice(0, 500) : null
        };
        writeSystemLog(ok ? 'info' : 'error', 'diagnostics', 'DEPCHECK ' + (ok ? 'успешен' : 'неуспешен'), {
          username: sess.username,
          ip: getClientIp(req),
          meta: { exitCode: report.exitCode, timedOut, output: output.slice(-4000) }
        });
        sendJSON(res, ok ? 200 : 500, report);
      } catch (e) {
        writeSystemLog('error', 'diagnostics', 'Грешка при DEPCHECK: ' + (e.message || e), {
          username: sess.username, ip: getClientIp(req)
        });
        sendJSON(res, 500, { error: e.message || 'Грешка при изпълнение на DEPCHECK.' });
      }
      return true;
    }

    // ---- API: диагностика за отдалечен админ ----
    if (pathname === '/api/admin/diagnostics' && req.method === 'GET') {
      const sess = requireAdmin(req, res);
      if (!sess) return true;
      try {
        let dbSize = 0;
        try { if (fs.existsSync(DB_PATH)) dbSize = fs.statSync(DB_PATH).size; } catch (_) {}
        let lastStart = null, lastRestartReq = null;
        try { lastStart = kvGet('settings:lastSuccessfulStartIso') || kvGet('settings:lastSuccessfulStart'); } catch (_) {}
        try { lastRestartReq = kvGet('settings:lastRestartRequest'); } catch (_) {}
        let whMissingType = 0;
        try {
          const raw = kvGet('wh-index');
          const idx = raw ? JSON.parse(raw) : [];
          for (const id of (Array.isArray(idx) ? idx : [])) {
            try {
              const rec = JSON.parse(kvGet('wh:' + id) || 'null');
              if (rec && !['office', 'sanitary'].includes(String(rec.materialType || '').trim())) whMissingType++;
            } catch (_) {}
          }
        } catch (_) {}
        const crashes = getLastCrashLog(8);
        const mem = process.memoryUsage();
        const stab = getStabilityStats();
        sendJSON(res, 200, {
          ok: true,
          online: true,
          port: PORT,
          pid: process.pid,
          uptimeSec: Math.floor((Date.now() - SERVER_STARTED_AT) / 1000),
          dbSize,
          lastSuccessfulStart: lastStart,
          lastRestartRequest: lastRestartReq ? new Date(parseInt(lastRestartReq, 10)).toISOString() : null,
          whRecordsMissingMaterialType: whMissingType,
          recentCrashes: crashes.map(c => ({
            ts: c.ts,
            time: formatLocalDateTimeSeconds(c.ts),
            level: c.level,
            category: c.category,
            message: String(c.message || '').slice(0, 400)
          })),
          memory: { rss: mem.rss, heapUsed: mem.heapUsed },
          watchdogHint: 'Инсталирайте WATCHDOG.bat / INSTALL_WATCHDOG_TASK.bat на сървърната машина (IT).',
          stability: stab,
          lastUncleanShutdown: stab.lastUncleanShutdown,
          uncleanShutdowns24h: stab.uncleanShutdowns24h,
          now: new Date().toISOString()
        });
      } catch (e) {
        sendJSON(res, 500, { error: e.message || 'diagnostics failed' });
      }
      return true;
    }

    // ---- API: почистване само на временни/остарели файлове ----
    if (pathname === '/api/admin/cleanup-temp-files' && req.method === 'POST') {
      const sess = requireAdmin(req, res);
      if (!sess) return true;
      try {
        const result = cleanupOldServerFiles({ keepUpdateDirs: 3, keepDbBackups: 15 });
        writeSystemLog('info', 'system', 'Почистване временни файлове: ' + result.removedCount, {
          username: sess.username,
          ip: getClientIp(req),
          meta: { removed: (result.removed || []).slice(0, 40) }
        });
        sendJSON(res, 200, result);
      } catch (e) {
        sendJSON(res, 500, { error: e.message || 'cleanup failed' });
      }
      return true;
    }

    // ---- API: миграция materialType за WH ----
    if (pathname === '/api/admin/migrate-wh-types' && req.method === 'POST') {
      const sess = requireAdmin(req, res);
      if (!sess) return true;
      try {
        const result = migrateWhMaterialTypes();
        writeSystemLog('info', 'system', 'Миграция WH materialType: обновени ' + result.updatedCount, {
          username: sess.username,
          ip: getClientIp(req),
          meta: { ambiguous: (result.ambiguous || []).length }
        });
        sendJSON(res, 200, result);
      } catch (e) {
        sendJSON(res, 500, { error: e.message || 'migration failed' });
      }
      return true;
    }

    // ---- API: здраве / статус за отдалечено администриране ----
    if (pathname === '/api/admin/health' && req.method === 'GET') {
      const sess = requireAdmin(req, res);
      if (!sess) return true;
      try {
        let dbSize = 0;
        try { if (fs.existsSync(DB_PATH)) dbSize = fs.statSync(DB_PATH).size; } catch (_) {}
        let backupCount = 0;
        let verifiedBackupCount = 0;
        let lastBackup = null;
        let lastVerifiedBackup = null;
        try {
          const bdir = path.join(DATA_DIR, 'backups');
          if (fs.existsSync(bdir)) {
            const files = fs.readdirSync(bdir)
              .filter(f => /\.(db|zip)$/i.test(f))
              .map(f => {
                try {
                  const st = fs.statSync(path.join(bdir, f));
                  const verified = /\.zip$/i.test(f) && fs.existsSync(path.join(bdir, f + '.sha256'));
                  return { name: f, size: st.size, mtime: st.mtimeMs, verified };
                } catch (_) { return null; }
              })
              .filter(Boolean)
              .sort((a, b) => b.mtime - a.mtime);
            backupCount = files.length;
            verifiedBackupCount = files.filter(x => x.verified).length;
            lastBackup = files[0] || null;
            lastVerifiedBackup = files.find(x => x.verified) || null;
          }
        } catch (_) {}
        let recordsCount = 0;
        let whCount = 0;
        let usersCount = 0;
        try { recordsCount = getRecordsIndexSafe().length; } catch (_) {}
        try {
          const raw = kvGet('wh-index');
          const arr = raw ? JSON.parse(raw) : [];
          whCount = Array.isArray(arr) ? arr.length : 0;
        } catch (_) {}
        try { usersCount = getUserIdsServer().length; } catch (_) {}
        let recentErrors = 0;
        try {
          const since = Date.now() - 24 * 60 * 60 * 1000;
          const row = db.prepare("SELECT COUNT(*) AS c FROM system_log WHERE level IN ('error','warn') AND ts >= ?").get(since);
          recentErrors = row && row.c != null ? row.c : 0;
        } catch (_) {}
        const mem = process.memoryUsage();
        const uptimeSec = Math.floor((Date.now() - SERVER_STARTED_AT) / 1000);
        let stab = {};
        try { stab = getStabilityStats(); } catch (_) { stab = {}; }
        let lastAppliedUpdate = null;
        try {
          const rawUpdateInfo = kvGet('system:lastAppliedUpdate');
          if (rawUpdateInfo) lastAppliedUpdate = JSON.parse(rawUpdateInfo);
        } catch (_) {}
        if (!lastAppliedUpdate) {
          try {
            const oldUpdate = db.prepare("SELECT ts, username, meta FROM system_log WHERE category = 'update' AND level = 'info' AND message LIKE 'Приложено обновление:%' ORDER BY ts DESC LIMIT 1").get();
            if (oldUpdate) {
              let oldMeta = {};
              try { oldMeta = JSON.parse(oldUpdate.meta || '{}'); } catch (_) {}
              lastAppliedUpdate = {
                version: oldMeta.version || '',
                appliedAt: new Date(Number(oldUpdate.ts)).toISOString(),
                appliedBy: oldUpdate.username || '',
                appliedCount: Array.isArray(oldMeta.applied) ? oldMeta.applied.length : null,
                files: Array.isArray(oldMeta.applied) ? oldMeta.applied : [],
                legacy: true
              };
            }
          } catch (_) {}
        }
        sendJSON(res, 200, {
          ok: true,
          version: typeof APP_VERSION !== 'undefined' ? APP_VERSION : 'DiSt',
          port: PORT,
          pid: process.pid,
          node: process.version,
          platform: process.platform,
          uptimeSec,
          startedAt: new Date(SERVER_STARTED_AT).toISOString(),
          db: { path: 'data/zayavki.db', size: dbSize },
          counts: { records: recordsCount, warehouse: whCount, users: usersCount },
          lastAppliedUpdate,
          backups: { count: backupCount, verifiedCount: verifiedBackupCount, last: lastBackup, lastVerified: lastVerifiedBackup },
          emailNotifyEnabled: (typeof isEmailNotifyEnabled === 'function') ? isEmailNotifyEnabled() : null,
          memory: {
            rss: mem.rss,
            heapUsed: mem.heapUsed
          },
          logs: { warningsAndErrors24h: recentErrors },
          uncleanShutdowns24h: stab.uncleanShutdowns24h != null ? stab.uncleanShutdowns24h : 0,
          lastUncleanShutdown: stab.lastUncleanShutdown || null,
          now: new Date().toISOString()
        });
      } catch (e) {
        sendJSON(res, 500, { error: e.message || 'Грешка при health.' });
      }
      return true;
    }

    // ---- API: списък бекъпи ----
    if (pathname === '/api/admin/backups' && req.method === 'GET') {
      if (!requireAdmin(req, res)) return true;
      try {
        const bdir = path.join(DATA_DIR, 'backups');
        if (!fs.existsSync(bdir)) {
          sendJSON(res, 200, { backups: [] });
          return true;
        }
        const files = fs.readdirSync(bdir)
          .filter(f => /\.(db|zip)$/i.test(f) && !f.includes('..') && !f.includes('/') && !f.includes('\\'))
          .map(f => {
            try {
              const st = fs.statSync(path.join(bdir, f));
              return { name: f, size: st.size, mtime: st.mtimeMs, verified: /\.zip$/i.test(f) && fs.existsSync(path.join(bdir, f + '.sha256')) };
            } catch (_) { return null; }
          })
          .filter(Boolean)
          .sort((a, b) => b.mtime - a.mtime)
          .slice(0, 50);
        sendJSON(res, 200, { backups: files });
      } catch (e) {
        sendJSON(res, 500, { error: e.message || 'Грешка при списък на бекъпи.' });
      }
      return true;
    }

    if (pathname.startsWith('/api/admin/backups/') && req.method === 'DELETE') {
      const sess = requireAdmin(req, res);
      if (!sess) return true;
      try {
        const name = decodeURIComponent(pathname.slice('/api/admin/backups/'.length));
        if (!name || name.includes('..') || name.includes('/') || name.includes('\\') || !/\.(db|zip)$/i.test(name)) {
          sendJSON(res, 400, { error: 'Невалидно име на бекъп.' });
          return true;
        }
        const bdir = path.resolve(path.join(DATA_DIR, 'backups'));
        const full = path.resolve(bdir, name);
        if (!full.startsWith(bdir + path.sep)) {
          sendJSON(res, 400, { error: 'Невалиден път до бекъпа.' });
          return true;
        }
        if (!fs.existsSync(full)) { sendJSON(res, 404, { error: 'Бекъпът не е намерен.' }); return true; }
        const stat = fs.lstatSync(full);
        if (!stat.isFile() || stat.isSymbolicLink()) { sendJSON(res, 400, { error: 'Посоченият бекъп не е обикновен файл.' }); return true; }
        fs.unlinkSync(full);
        const removed = [name];
        for (const sidecar of [name + '.sha256']) {
          const sidecarPath = path.join(bdir, sidecar);
          try { if (fs.existsSync(sidecarPath) && fs.lstatSync(sidecarPath).isFile()) { fs.unlinkSync(sidecarPath); removed.push(sidecar); } } catch (_) {}
        }
        const match = name.match(/^DiSt_full_backup_(.+)\.zip$/i);
        if (match) {
          const manifestName = 'backup-manifest_' + match[1] + '.json';
          const manifestPath = path.join(bdir, manifestName);
          try { if (fs.existsSync(manifestPath) && fs.lstatSync(manifestPath).isFile()) { fs.unlinkSync(manifestPath); removed.push(manifestName); } } catch (_) {}
        }
        writeSystemLog('warn', 'backup', 'Администратор изтри бекъп от сървъра: ' + name, {
          username: sess.username, ip: getClientIp(req), meta: { deletedFiles: removed }
        });
        sendJSON(res, 200, { deleted: true, name, removed });
      } catch (e) {
        sendJSON(res, 500, { error: e.message || 'Грешка при изтриване на бекъп.' });
      }
      return true;
    }

    // ---- API: изтегляне на SHA-256 sidecar за пълен backup ----
    if (pathname === '/api/admin/backup-sha256' && req.method === 'GET') {
      const sess = requireAdmin(req, res);
      if (!sess) return true;
      try {
        const name = String((parsed.searchParams && parsed.searchParams.get('name')) || '');
        if (!/^DiSt_full_backup_.*\.zip$/i.test(name) || name.includes('..') || name.includes('/') || name.includes('\\')) {
          sendJSON(res, 400, { error: 'Невалидно име на backup.' });
          return true;
        }
        const bdir = path.resolve(path.join(DATA_DIR, 'backups'));
        const full = path.resolve(bdir, name);
        if (!full.startsWith(bdir + path.sep)) {
          sendJSON(res, 400, { error: 'Невалиден път до backup.' });
          return true;
        }
        if (!fs.existsSync(full)) { sendJSON(res, 404, { error: 'Backup-ът не е намерен.' }); return true; }
        const backupStat = fs.lstatSync(full);
        if (!backupStat.isFile() || backupStat.isSymbolicLink()) {
          sendJSON(res, 400, { error: 'Backup-ът не е обикновен файл.' });
          return true;
        }
        const sidecarName = name + '.sha256';
        const sidecarPath = path.join(bdir, sidecarName);
        if (!fs.existsSync(sidecarPath)) { sendJSON(res, 404, { error: 'За този backup няма SHA-256 файл на сървъра.' }); return true; }
        const sidecarStat = fs.lstatSync(sidecarPath);
        if (!sidecarStat.isFile() || sidecarStat.isSymbolicLink()) {
          sendJSON(res, 400, { error: 'SHA-256 файлът не е обикновен файл.' });
          return true;
        }
        const digest = String(sha256File(full) || '').toLowerCase();
        const sidecar = fs.readFileSync(sidecarPath, 'utf8');
        const match = sidecar.trim().match(/^([a-f0-9]{64})\s+(.+)$/i);
        if (!match || match[1].toLowerCase() !== digest || match[2].trim() !== name) {
          sendJSON(res, 422, { error: 'SHA-256 файлът не съвпада с backup архива.' });
          return true;
        }
        writeSystemLog('info', 'backup', 'Изтеглен SHA-256 файл за backup: ' + name, {
          username: sess.username, ip: getClientIp(req)
        });
        res.writeHead(200, {
          'Content-Type': 'text/plain; charset=utf-8',
          'Content-Disposition': 'attachment; filename="' + sidecarName + '"',
          'Content-Length': String(Buffer.byteLength(sidecar, 'utf8')),
          'Cache-Control': 'no-store'
        });
        res.end(sidecar);
      } catch (e) {
        sendJSON(res, 500, { error: e.message || 'Грешка при изтегляне на SHA-256 файла.' });
      }
      return true;
    }

    // ---- API: проверка на конкретен пълен backup ----
    if (pathname === '/api/admin/backup-verify' && req.method === 'GET') {
      const sess = requireAdmin(req, res);
      if (!sess) return true;
      try {
        const name = parsed.searchParams.get('name') || '';
        if (!/^DiSt_full_backup_.*\.zip$/i.test(name) || name.includes('..') || name.includes('/') || name.includes('\\')) {
          sendJSON(res, 400, { error: 'Невалидно име на backup.' });
          return true;
        }
        const bdir = path.join(DATA_DIR, 'backups');
        const full = path.join(bdir, name);
        if (!fs.existsSync(full)) { sendJSON(res, 404, { error: 'Backup-ът не е намерен.' }); return true; }
        const result = verifyBackupZip(full);
        writeSystemLog(result.ok ? 'info' : 'error', 'backup', 'Проверка на backup: ' + name + ' → ' + (result.ok ? 'OK' : 'FAILED'), {
          username: sess.username, ip: getClientIp(req), meta: result
        });
        sendJSON(res, result.ok ? 200 : 422, result);
      } catch (e) {
        sendJSON(res, 500, { error: e.message || 'Грешка при проверка на backup.' });
      }
      return true;
    }

    // ---- API: изтегляне на архивен бекъп ----
    if (pathname.startsWith('/api/admin/backups/') && req.method === 'GET') {
      const sess = requireAdmin(req, res);
      if (!sess) return true;
      try {
        const name = decodeURIComponent(pathname.slice('/api/admin/backups/'.length));
        if (!name || name.includes('..') || name.includes('/') || name.includes('\\') || !/\.(db|zip)$/i.test(name)) {
          sendJSON(res, 400, { error: 'Невалидно име на файл.' });
          return true;
        }
        const bdir = path.join(DATA_DIR, 'backups');
        const full = path.join(bdir, name);
        const resolved = path.resolve(full);
        if (!resolved.startsWith(path.resolve(bdir) + path.sep)) {
          sendJSON(res, 400, { error: 'Невалиден път.' });
          return true;
        }
        if (!fs.existsSync(resolved)) {
          sendJSON(res, 404, { error: 'Бекъпът не е намерен.' });
          return true;
        }
        const data = fs.readFileSync(resolved);
        writeSystemLog('info', 'backup', 'Изтеглен архивен бекъп: ' + name, {
          username: sess.username,
          ip: getClientIp(req)
        });
        res.writeHead(200, {
          'Content-Type': 'application/octet-stream',
          'Content-Disposition': 'attachment; filename="' + name + '"',
          'Content-Length': String(data.length),
          'Cache-Control': 'no-store'
        });
        res.end(data);
      } catch (e) {
        sendJSON(res, 500, { error: e.message || 'Грешка при изтегляне.' });
      }
      return true;
    }

    // ---- API: експорт на системни логове (текст) ----
    if (pathname === '/api/admin/logs-export' && req.method === 'GET') {
      const sess = requireAdmin(req, res);
      if (!sess) return true;
      try {
        const limit = Math.min(2000, Math.max(50, parseInt(String((parsed.searchParams && parsed.searchParams.get('limit')) || '500'), 10) || 500));
        const rows = db.prepare(
          'SELECT ts, level, category, message, username, ip, meta FROM system_log ORDER BY ts DESC LIMIT ?'
        ).all(limit);
        const lines = rows.map(r => {
          const t = formatLogTimestampLocal(r.ts);
          return [t, new Date(Number(r.ts) || 0).toISOString(), r.level, r.category, r.username || '', r.ip || '', String(r.message || '').replace(/\r?\n/g, ' '), String(r.meta || '').replace(/[\r\n\t]/g, ' ')].join('\t');
        });
        const body = 'ts_local\tts_iso\tlevel\tcategory\tusername\tip\tmessage\tmeta\n' + lines.join('\n');
        writeSystemLog('info', 'system', 'Експортирани системни логове (' + rows.length + ')', {
          username: sess.username,
          ip: getClientIp(req)
        });
        const fname = 'dist_logs_' + new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-') + '.txt';
        res.writeHead(200, {
          'Content-Type': 'text/plain; charset=utf-8',
          'Content-Disposition': 'attachment; filename="' + fname + '"',
          'Content-Length': Buffer.byteLength(body, 'utf8'),
          'Cache-Control': 'no-store'
        });
        res.end(body, 'utf8');
      } catch (e) {
        sendJSON(res, 500, { error: e.message || 'Грешка при експорт на логове.' });
      }
      return true;
    }

    // ---- API: списък на потребителите ----
    // ---- API: почистване на счупени/липсващи записи в индекса (само admin) ----
    if (pathname === '/api/admin/cleanup-orphans' && req.method === 'POST') {
      if (!requireAdmin(req, res)) return true;
      try {
        const result = cleanupOrphanRecordsServer();
        sendJSON(res, 200, { ok: true, ...result });
      } catch (e) {
        sendJSON(res, 500, { error: e.message || 'Грешка при почистване.' });
      }
      return true;
    }


    // ---- API: Agent suite (phase 0/1) ----
    if (pathname === '/api/admin/agent/report' && req.method === 'GET') {
      if (!requireAdmin(req, res)) return true;
      try {
        const report = agentSuite ? agentSuite.getLastReport() : null;
        const cfg = agentSuite && agentSuite.getConfig ? agentSuite.getConfig() : null;
        sendJSON(res, 200, { ok: true, report: report, config: cfg });
      } catch (e) {
        sendJSON(res, 500, { error: e.message || 'Грешка.' });
      }
      return true;
    }

    if (pathname === '/api/admin/agent/history' && req.method === 'GET') {
      if (!requireAdmin(req, res)) return true;
      try {
        const limit = Math.min(30, parseInt(String((parsed.searchParams && parsed.searchParams.get('limit')) || '15'), 10) || 15);
        const history = agentSuite ? agentSuite.getHistory(limit) : [];
        sendJSON(res, 200, { ok: true, history: history });
      } catch (e) {
        sendJSON(res, 500, { error: e.message || 'Грешка.' });
      }
      return true;
    }

    if (pathname === '/api/admin/agent/run' && req.method === 'POST') {
      const sess = requireAdmin(req, res);
      if (!sess) return true;
      try {
        if (!agentSuite) {
          sendJSON(res, 503, { error: 'Agent suite не е активен.' });
          return true;
        }
        const report = agentSuite.runSuite({
          username: sess.username,
          ip: getClientIp(req),
          trigger: 'manual'
        });
        sendJSON(res, 200, { ok: true, report: report });
      } catch (e) {
        sendJSON(res, 500, { error: e.message || 'Грешка.' });
      }
      return true;
    }

    if (pathname === '/api/admin/agent/digest' && req.method === 'GET') {
      const sess = requireAdmin(req, res);
      if (!sess) return true;
      try {
        if (!agentSuite || typeof agentSuite.getDigest !== 'function') {
          sendJSON(res, 503, { error: 'Agent suite не е активен.' });
          return true;
        }
        const force = String((parsed.searchParams && parsed.searchParams.get('force')) || '') === '1';
        const digest = agentSuite.getDigest({
          username: sess.username,
          trigger: force ? 'manual-digest' : 'morning-login',
          force: force
        });
        sendJSON(res, 200, digest);
      } catch (e) {
        sendJSON(res, 500, { error: e.message || 'Грешка.' });
      }
      return true;
    }

    if (pathname === '/api/admin/agent/action' && req.method === 'POST') {
      const sess = requireAdmin(req, res);
      if (!sess) return true;
      try {
        const body = await readJsonFromRequest(req);
        const actionName = body && body.action ? String(body.action) : '';
        if (!actionName) {
          sendJSON(res, 400, { error: 'Липсва action.' });
          return true;
        }
        if (actionName === 'clear-history') {
          if (!agentSuite || typeof agentSuite.clearHistory !== 'function') {
            sendJSON(res, 503, { error: 'clearHistory не е наличен.' });
            return true;
          }
          const result = agentSuite.clearHistory();
          try {
            writeSystemLog('info', 'agent', 'Изчистена история на проверките', { username: sess.username });
          } catch (_) {}
          sendJSON(res, 200, result);
          return true;
        }
        if (actionName === 'run-backup') {
          if (typeof createDownloadableBackup !== 'function') {
            sendJSON(res, 503, { error: 'Бекъп функцията не е налична.' });
            return true;
          }
          const info = createDownloadableBackup();
          try {
            writeSystemLog('info', 'agent', 'Бекъп от агент: ' + (info && info.fileName ? info.fileName : ''), { username: sess.username });
          } catch (_) {}
          sendJSON(res, 200, { ok: true, backup: info });
          return true;
        }
        if (actionName === 'crash-log') {
          const lines = typeof getLastCrashLog === 'function' ? getLastCrashLog(12) : [];
          sendJSON(res, 200, { ok: true, lines: lines || [] });
          return true;
        }
        if (actionName === 'cleanup-temp') {
          if (typeof cleanupOldServerFiles !== 'function') {
            sendJSON(res, 503, { error: 'cleanup не е наличен.' });
            return true;
          }
          const result = cleanupOldServerFiles({ keepUpdateDirs: 3, keepDbBackups: 15 });
          try {
            writeSystemLog('info', 'agent', 'Cleanup от агент', { username: sess.username, result: result });
          } catch (_) {}
          sendJSON(res, 200, { ok: true, result: result });
          return true;
        }
        sendJSON(res, 400, { error: 'Непознато действие: ' + actionName });
      } catch (e) {
        sendJSON(res, 500, { error: e.message || 'Грешка.' });
      }
      return true;
    }


    // ---- API: настройки на падащите менюта ----
    return false;
  };
}

module.exports = { createAdminRoutes };
