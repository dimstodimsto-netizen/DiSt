#!/usr/bin/env node
'use strict';

// Composition root. State and data services are initialized in server/bootstrap.js.
const core = require('./server/bootstrap');
const { createAgentSuite } = require('./server/agent-suite');
const { createMailService } = require('./server/mail-service');
const { createStaticService } = require('./server/static-service');
const { createSettingsRoutes } = require('./server/settings-routes');
const { createHttpServer } = require('./server/http-server');
const {
  http, fs, path, os, crypto, spawn, spawnSync, URL, zlib, sendSmtpMail,
  createRecordsRoutes, createLoginBackgroundRoutes, createKvRoutes,
  createUsersModule, createUsersRoutes, createKvStore, createWarehouseModule,
  createRecordsModule, createHttpHelpers, createUpdateModule, createBackupModule,
  createRestartModule, createSystemRoutes, createMaintenanceMaterialsRoutes,
  createRequiredMaterialsRoutes, createAdminRoutes, createSystemLogModule,
  createMaterialsReportRoutes, reportDatePartsServer, reportRecordDateParts,
  parseRepairMaterialsServer, parseReportQuantityServer, formatReportQuantityServer,
  buildMaterialsReportServer, DatabaseSync,
  VERIFICATION_PERIOD_DAYS, VERIFICATION_WARNING_DAY, VERIFICATION_LOCK_DAY,
  VERIFICATION_INITIAL_CODE, PORT, LISTEN_HOST, SERVER_STARTED_AT, APP_VERSION,
  ROOT_DIR, PUBLIC_DIR, DATA_DIR, DB_PATH, PID_PATH, MAIL_SCRIPT_PATH,
  UI_VERSION, computeUiVersion, db,
  stmtSessionUpsert, stmtSessionGet, stmtSessionDelete, stmtSessionDeleteExpired, stmtSessionAll,
  kvGet, kvSet, kvDelete, kvListByPrefix, isSecretKvKey, kvReadAllowedForRole,
  hashPasswordPBKDF2, hashPasswordLegacySha256, safeEqualHex, verifyUserPassword,
  hashPasswordPBKDF2Async, verifyUserPasswordAsync,
  getUserIdsServer, getUserByIdServer, getAllUsersServer, getUserByUsernameServer,
  sanitizeObserverMenus, observerMenusForUser, saveUserServer, DEFAULT_OBSERVER_MENUS,
  getClientIp, checkLoginLock, registerLoginFailure, registerLoginSuccess, getLoginLockSnapshot,
  ownStrukturaOf, normalizeStrukturaName, whRecordVisibleToUser,
  materialNameSetFromKv, migrateWhMaterialTypes,
  withTransaction, parseJsonOrNull, getRecordServer, normalizeRecordInput,
  getNextRecordIdTx, advanceNextRecordId, getRecordsIndexSafe, createRecordServer,
  updateRecordServer, markRecordsSeenServer, deleteRecordServer, listRecordsServer,
  cleanupOrphanRecordsServer, sha256File, copyDirRecursiveForBackup,
  snapshotDatabaseTo, verifyDatabaseFile, getBackupMetadata, writeBackupManifest,
  extractZipToDirForVerification, verifyBackupZip, createZipFromDirectory,
  createDownloadableBackup, cleanupOldServerFiles, writeSystemLog, getLastCrashLog,
  initializeVerification, getLicenseContact, getVerificationState,
  checkVerificationCodeOnly, verifyProgramCode, changeVerificationCode,
  computeInstallFingerprint
} = core;
let serverRef = null;
const {
  getStabilityStats, formatLogTimestampLocal, formatCrashLineForLog, formatHeartbeatLine
} = require('./server/admin-health').createAdminHealthModule({
  kvGet, db, SERVER_STARTED_AT, processRef: process
});
const lifecycle = require('./server/lifecycle').createLifecycle({
  fs, path, os, ROOT_DIR, DATA_DIR, DB_PATH, PID_PATH, PORT, LISTEN_HOST,
  db, kvSet, writeSystemLog, createDownloadableBackup,
  getServer: () => serverRef, formatCrashLineForLog, formatHeartbeatLine
});
const {
  getLanIPs, BACKUP_DIR, backupDatabase, scheduleDailyBackup, startHttpServer,
  writeCrashArtifact, markGracefulStop, writeHeartbeat, reportPreviousSessionEnd,
  cleanupAndExit, installProcessHandlers
} = lifecycle;
const mailService = createMailService({ fs, path, os, spawn, DATA_DIR, MAIL_SCRIPT_PATH, kvGet, writeSystemLog, sendSmtpMail });
const {
  getNotifyEmails, isEmailNotifyEnabled, mailOneLine, getSmtpSettings,
  isSmtpConfigured, sendMail, notifyNewRepairRequest,
  translateMailError, logMailEvent, sendOutlookMail
} = mailService;
const staticService = createStaticService({ fs, path, zlib, PUBLIC_DIR, PORT, LISTEN_HOST, getLanIPs, getUiVersion: () => UI_VERSION });
const {
  addCORS, applySecurityHeaders, cacheControlForExt, sendJSON, readBody,
  parseJsonOrError, readJsonFromRequest, serveStatic, formatLocalDateTimeSeconds
} = staticService;
// Session/auth state belongs in the composition root, not in the static-file service.
const {
  SUBMITTER_SESSION_TTL_MS,
  STAFF_SESSION_TTL_MS,
  HEARTBEAT_ONLINE_MS,
  sessions,
  createSession,
  getSessionToken,
  getSession,
  setSessionCookie,
  clearSessionCookie,
  requireAdmin,
  requireAuth,
  touchHeartbeat,
  listActiveSessions,
  destroySession,
  sessionTtlForRole,
  STAFF_SESSION_ROLES
} = require('./server/auth-sessions').createAuthSessionsModule({
  stmtSessionUpsert,
  stmtSessionGet,
  stmtSessionDelete,
  stmtSessionDeleteExpired,
  stmtSessionAll,
  sendJSON,
  crypto,
  writeSystemLog
});
const updateModule = createUpdateModule({ fs, path, os, crypto, spawnSync, ROOT_DIR, DATA_DIR, computeUiVersion, getUiVersion: () => UI_VERSION });
const { UPDATE_MAX_BYTES, UPDATE_ALLOWED_EXACT, UPDATE_ALLOWED_PREFIXES, UPDATE_FORBIDDEN_PREFIXES, normalizeUpdateRelPath, isUpdatePathAllowed, extractZipToDir, walkFiles, findExtractRoot, applyProgramUpdate } = updateModule;

const restartModule = createRestartModule({ fs, path, os, spawn, ROOT_DIR, PID_PATH, PORT, db, writeSystemLog, markGracefulStop, getServer: () => serverRef });
const { scheduleServerRestart } = restartModule;


/** Миграция: попълва materialType на WH записи без тип (office/sanitary). */





// ---- Модулни HTTP маршрути (records / login-background / materials report) ----
const handleRecordsRoute = createRecordsRoutes({
  requireAuth,
  readJsonFromRequest,
  sendJSON,
  listRecordsServer,
  createRecordServer,
  markRecordsSeenServer,
  updateRecordServer,
  deleteRecordServer,
  notifyNewRepairRequest,
  withTransaction,
  getNextRecordIdTx
});
const handleLoginBackgroundRoute = createLoginBackgroundRoutes({
  kvGet,
  sendJSON,
  addCORS,
  applySecurityHeaders,
  crypto
});
const handleMaintenanceMaterialsRoute = createMaintenanceMaterialsRoutes({
  requireAuth, sendJSON, readJsonFromRequest, kvGet, kvSet, crypto
});
const handleRequiredMaterialsRoute = createRequiredMaterialsRoutes({
  requireAuth, sendJSON, readJsonFromRequest, kvGet, kvSet, kvListByPrefix, crypto
});
const handleMaterialsReportRoute = createMaterialsReportRoutes({
  requireAdmin,
  sendJSON,
  getRecordsIndexSafe,
  getRecordServer
});
const handleKvRoute = createKvRoutes({
  requireAuth, sendJSON, kvGet, kvSet, kvDelete, kvListByPrefix,
  kvReadAllowedForRole, parseJsonOrNull, ownStrukturaOf, whRecordVisibleToUser,
  normalizeStrukturaName, getUserByIdServer, getUserByUsernameServer, getRecordServer,
  readJsonFromRequest, writeSystemLog, getClientIp
});
const handleAuthRoute = createUsersRoutes({
  getSession, getSessionToken, destroySession, clearSessionCookie,
  sendJSON, readJsonFromRequest, getClientIp, checkLoginLock,
  registerLoginFailure, registerLoginSuccess, getUserByUsernameServer,
  verifyUserPasswordAsync, hashPasswordPBKDF2Async, saveUserServer,
  createSession, sessions, setSessionCookie, writeSystemLog,
  observerMenusForUser, crypto,
  requireAdmin, getAllUsersServer, getUserByIdServer, getUserIdsServer,
  hashPasswordPBKDF2, sanitizeObserverMenus, DEFAULT_OBSERVER_MENUS, kvSet, kvDelete
});
const handleSystemRoute = createSystemRoutes({
  requireAdmin, sendJSON, readJsonFromRequest, getClientIp,
  checkLoginLock, registerLoginFailure, registerLoginSuccess,
  getUserByUsernameServer, verifyUserPasswordAsync, verifyProgramCode,
  createSession, sessions, setSessionCookie, writeSystemLog,
  getVerificationState, changeVerificationCode, getLicenseContact, kvSet
});

// ---- Модул: admin-health + admin-routes ----
const agentSuite = createAgentSuite({
  db, kvGet, kvSet, writeSystemLog,
  getAllUsersServer, listActiveSessions, getRecordsIndexSafe,
  getLoginLockSnapshot: typeof getLoginLockSnapshot === 'function' ? getLoginLockSnapshot : null,
  fs, path, ROOT_DIR, PUBLIC_DIR, DATA_DIR, DB_PATH,
  APP_VERSION, UI_VERSION, SERVER_STARTED_AT, PORT
});

const handleAdminRoute = createAdminRoutes({
  requireAuth, requireAdmin, sendJSON, readJsonFromRequest, readBody,
  getClientIp, writeSystemLog, db, kvGet, kvSet, kvDelete,
  agentSuite,
  createDownloadableBackup, applyProgramUpdate, scheduleServerRestart,
  getSession, getSessionToken, sessions, destroySession, touchHeartbeat, listActiveSessions,
  stmtSessionAll,
  verifyBackupZip, sha256File, getLastCrashLog, cleanupOldServerFiles,
  migrateWhMaterialTypes, cleanupOrphanRecordsServer,
  getStabilityStats, formatLogTimestampLocal, formatCrashLineForLog, formatHeartbeatLine,
  formatLocalDateTimeSeconds,
  HEARTBEAT_ONLINE_MS, getLanIPs, PORT, UI_VERSION, SERVER_STARTED_AT, APP_VERSION, DB_PATH,
  DATA_DIR, os, fs, path, spawnSync, ROOT_DIR,
  UPDATE_MAX_BYTES, parseJsonOrError,
  getAllUsersServer, getUserByIdServer, getUserByUsernameServer, getUserIdsServer,
  saveUserServer, hashPasswordPBKDF2, observerMenusForUser, sanitizeObserverMenus,
  DEFAULT_OBSERVER_MENUS, getRecordsIndexSafe, isEmailNotifyEnabled, crypto
});



const settingsRoutes = createSettingsRoutes({
  addCORS, sendJSON, getLanIPs, PORT, os, getUiVersion: () => UI_VERSION,
  getVerificationState, requireAdmin, readJsonFromRequest,
  kvGet, kvSet, getSmtpSettings, getNotifyEmails,
  isEmailNotifyEnabled, isSmtpConfigured, writeSystemLog, sendMail
});
const server = createHttpServer({
  http, URL, addCORS, applySecurityHeaders, serveStatic,
  handleRecordsRoute, handleLoginBackgroundRoute,
  handleMaintenanceMaterialsRoute, handleRequiredMaterialsRoute,
  handleMaterialsReportRoute, handleAuthRoute, handleSystemRoute,
  handleAdminRoute, handleKvRoute, ...settingsRoutes
});
serverRef = server;


// Lifecycle, backup scheduling, and crash reporting live in server/lifecycle.js.
initializeVerification();
installProcessHandlers();
startHttpServer(8);

