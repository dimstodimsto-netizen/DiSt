/**
 * required-materials-ui.js — app.js modularization
 * Необходими материали.
 * Load AFTER app.js.
 */

// ---- Месечен списък „Необходими материали“ ----
const REQUIRED_MATERIALS_API = '/api/required-materials';
let requiredMaterialEditingId = null;
function localYearMonth() {
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
}
async function requiredMaterialsRequest(url, options) {
  const res = await authFetch(url, options);
  let data = {};
  try { data = await res.json(); } catch (_) {}
  if (!res.ok) throw new Error(data.error || 'Грешка при работа с месечната таблица.');
  return data;
}
function resetRequiredMaterialEditor() {
  requiredMaterialEditingId = null;
  ['requiredMaterialName','requiredMaterialQuantity','requiredMaterialUnit','requiredMaterialNote','requiredMaterialApplicant'].forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; });
  const save = document.getElementById('btnAddRequiredMaterial');
  if (save) save.textContent = '+ Добави';
  const cancel = document.getElementById('btnCancelRequiredMaterialEdit');
  if (cancel) cancel.style.display = 'none';
}
function beginRequiredMaterialEdit(item) {
  requiredMaterialEditingId = item.id;
  refreshRequiredMaterialApplicantOptions(item.requestedBy || '');
  document.getElementById('requiredMaterialName').value = item.name || '';
  document.getElementById('requiredMaterialQuantity').value = item.quantity || '';
  document.getElementById('requiredMaterialUnit').value = item.unit || '';
  document.getElementById('requiredMaterialNote').value = item.note || '';
  document.getElementById('requiredMaterialApplicant').value = item.requestedBy || '';
  document.getElementById('btnAddRequiredMaterial').textContent = '💾 Запази';
  document.getElementById('btnCancelRequiredMaterialEdit').style.display = '';
  document.getElementById('requiredMaterialName').focus();
}
function refreshRequiredMaterialApplicantOptions(selectedValue) {
  const select = document.getElementById('requiredMaterialApplicant');
  if (!select) return;
  const selected = String(selectedValue || '');
  select.replaceChildren(new Option('— изберете —', ''));
  const technicians = Array.isArray(dropdownTechnicianList) ? dropdownTechnicianList : [];
  for (const name of technicians) select.add(new Option(name, name));
  if (selected && !technicians.includes(selected)) select.add(new Option(selected + ' (неактивен техник)', selected));
  select.value = selected;
}
function bindRequiredMaterialInputRules() {
  const quantity = document.getElementById('requiredMaterialQuantity');
  if (quantity && !quantity.dataset.digitsOnlyBound) {
    quantity.dataset.digitsOnlyBound = '1';
    quantity.addEventListener('input', () => { quantity.value = quantity.value.replace(/\D/g, ''); });
  }
  const unit = document.getElementById('requiredMaterialUnit');
  if (unit && !unit.dataset.noDigitsBound) {
    unit.dataset.noDigitsBound = '1';
    unit.addEventListener('input', () => { unit.value = unit.value.replace(/\p{N}/gu, ''); });
  }
}
function exportRequiredMaterialsXlsx() {
  return exportWithXlsx(async function () {
  const status = document.getElementById('requiredMaterialsStatus');
  const month = document.getElementById('requiredMaterialsMonth')?.value || localYearMonth();
  if (typeof XLSX === 'undefined') { if (status) status.textContent = 'Библиотеката за Excel не е заредена.'; return; }
  requiredMaterialsRequest(REQUIRED_MATERIALS_API + '?month=' + encodeURIComponent(month)).then(data => {
    const items = Array.isArray(data.items) ? data.items : [];
    const rows = [['Материал', 'Мярка', 'Количество', 'Бележка', 'Заявил'], ...items.map(item => [item.name || '', item.unit || '', item.quantity || '', item.note || '', item.requestedBy || ''])];
    const ws = XLSX.utils.aoa_to_sheet(rows);
    ws['!cols'] = [{ wch: 44 }, { wch: 16 }, { wch: 18 }, { wch: 42 }, { wch: 28 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, month.slice(0, 31));
    XLSX.writeFile(wb, 'Neobhodimi_materiali_' + month + '.xlsx');
    if (status) status.textContent = 'Експортирани са ' + items.length + ' реда за ' + month + '.';
  }).catch(e => { if (status) status.textContent = e.message || 'Грешка при експортиране.'; });

  });
}
async function importRequiredMaterialsXlsx(file) {
  await ensureXlsxLoaded();

  const status = document.getElementById('requiredMaterialsStatus');
  const month = document.getElementById('requiredMaterialsMonth')?.value || localYearMonth();
  if (!file) return;
  if (typeof XLSX === 'undefined') { if (status) status.textContent = 'Библиотеката за Excel не е заредена.'; return; }
  try {
    const wb = XLSX.read(await file.arrayBuffer(), { type: 'array' });
    const sheet = wb.Sheets[wb.SheetNames[0]];
    if (!sheet) throw new Error('Excel файлът няма лист с данни.');
    const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '', raw: false });
    if (!rows.length) throw new Error('Excel файлът е празен.');
    const norm = value => String(value || '').trim().toLocaleLowerCase('bg').replace(/[\s_]+/g, ' ');
    const headers = rows[0].map(norm);
    const nameIndex = headers.findIndex(x => ['материал', 'наименование', 'име', 'name', 'material'].includes(x));
    if (nameIndex < 0) throw new Error('Не е намерена колона „Материал“. Използвайте файл, експортиран от това меню.');
    const quantityIndex = headers.findIndex(x => ['количество', 'кол', 'quantity', 'qty'].includes(x));
    const unitIndex = headers.findIndex(x => ['мярка', 'мерна единица', 'единица', 'unit', 'measure'].includes(x));
    const noteIndex = headers.findIndex(x => ['бележка', 'забележка', 'описание', 'note', 'remark'].includes(x));
    const applicantIndex = headers.findIndex(x => ['заявил', 'заявител', 'заявила', 'applicant', 'requested by'].includes(x));
    const items = rows.slice(1).map(row => ({
      name: String(row[nameIndex] || '').trim(),
      quantity: quantityIndex >= 0 ? String(row[quantityIndex] || '').trim() : '',
      unit: unitIndex >= 0 ? String(row[unitIndex] || '').trim() : '',
      note: noteIndex >= 0 ? String(row[noteIndex] || '').trim() : '',
      requestedBy: applicantIndex >= 0 ? String(row[applicantIndex] || '').trim() : ''
    })).filter(item => item.name);
    if (!items.length) throw new Error('Не са намерени редове с материали за импорт.');
    if (items.some(item => !item.unit || !item.quantity || !item.requestedBy)) throw new Error('За всеки материал попълнете Материал, Мярка, Количество и Заявил. Бележка е по желание.');
    if (items.some(item => item.quantity && !/^\d+$/.test(item.quantity))) throw new Error('Колоната „Количество“ може да съдържа само цифри.');
    if (items.some(item => /\p{N}/u.test(item.unit))) throw new Error('Колоната „Мярка“ не може да съдържа цифри.');
    const result = await requiredMaterialsRequest(REQUIRED_MATERIALS_API + '/import?month=' + encodeURIComponent(month), {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ items })
    });
    await renderRequiredMaterials();
    if (status) status.textContent = 'Импорт за ' + month + ': добавени ' + result.added + ', пропуснати ' + result.skipped + ' дублиращи се или празни редове.';
  } catch (e) { if (status) status.textContent = e.message || 'Грешка при импорт на Excel.'; }
}
async function renderRequiredMaterials() {
  const monthInput = document.getElementById('requiredMaterialsMonth');
  const tableEl = document.getElementById('requiredMaterialsTable');
  const status = document.getElementById('requiredMaterialsStatus');
  const monthStatus = document.getElementById('requiredMaterialsMonthStatus');
  if (!monthInput || !tableEl) return;
  if (!monthInput.value) monthInput.value = localYearMonth();
  const nextMonthDate = new Date(Number(localYearMonth().slice(0, 4)), Number(localYearMonth().slice(5, 7)), 1);
  monthInput.max = nextMonthDate.getFullYear() + '-' + String(nextMonthDate.getMonth() + 1).padStart(2, '0');
  const month = monthInput.value;
  tableEl.textContent = 'Зареждане...';
  if (status) status.textContent = '';
  try {
    const data = await requiredMaterialsRequest(REQUIRED_MATERIALS_API + '?month=' + encodeURIComponent(month));
    bindRequiredMaterialInputRules();
    refreshRequiredMaterialApplicantOptions(document.getElementById('requiredMaterialApplicant')?.value || '');
    const d = new Date(Number(month.slice(0,4)), Number(month.slice(5,7)) - 1, 1);
    if (monthStatus) monthStatus.textContent = 'Таблица за ' + d.toLocaleDateString('bg-BG', { month: 'long', year: 'numeric' });
    tableEl.textContent = '';
    if (!Array.isArray(data.items) || !data.items.length) {
      tableEl.textContent = 'За този месец все още няма добавени материали.';
      return;
    }
    const table = document.createElement('table'); table.className = 'data-tbl required-materials-table';
    const thead = document.createElement('thead');
    const head = document.createElement('tr');
    ['Материал','Мярка','Количество','Бележка','Заявил','Действие'].forEach(label => { const th = document.createElement('th'); th.textContent = label; head.appendChild(th); });
    thead.appendChild(head); table.appendChild(thead);
    const tbody = document.createElement('tbody');
    data.items.forEach(item => {
      const tr = document.createElement('tr');
      if (item.status === 'requested') tr.classList.add('rm-requested');
      if (item.status === 'transferred') tr.classList.add('rm-transferred');
      [item.name, item.unit || '—', item.quantity || '—', item.note || '—', item.requestedBy || '—'].forEach(value => { const td = document.createElement('td'); td.textContent = value; tr.appendChild(td); });
      const actions = document.createElement('td');
      actions.className = 'rm-actions';
      const edit = document.createElement('button'); edit.type = 'button'; edit.className = 'ghost'; edit.textContent = 'Редактирай'; edit.addEventListener('click', () => beginRequiredMaterialEdit(item));
      const del = document.createElement('button'); del.type = 'button'; del.className = 'ghost'; del.style.marginLeft = '6px'; del.textContent = 'Изтрий';
      del.addEventListener('click', async () => {
        if (!(await confirmDialog('Да се изтрие ли редът за „' + item.name + '“ от таблицата за ' + month + '?'))) return;
        try {
          await requiredMaterialsRequest(REQUIRED_MATERIALS_API + '/items/' + encodeURIComponent(item.id) + '?month=' + encodeURIComponent(month), { method: 'DELETE' });
          if (requiredMaterialEditingId === item.id) resetRequiredMaterialEditor();
          await renderRequiredMaterials();
          if (status) status.textContent = 'Редът е изтрит.';
        } catch (e) { if (status) status.textContent = e.message || 'Грешка при изтриване.'; }
      });
      actions.append(edit, del);
      if (currentRole === 'admin') {
        const requested = document.createElement('button'); requested.type = 'button'; requested.className = 'ghost'; requested.textContent = item.status === 'requested' ? 'Отмени заявено' : 'Заявено';
        requested.disabled = item.status === 'transferred';
        requested.title = item.status === 'requested' ? 'Премахни маркировката „Заявено“' : 'Маркирай материала като заявен';
        requested.addEventListener('click', async () => {
          try {
            await requiredMaterialsRequest(REQUIRED_MATERIALS_API + '/items/' + encodeURIComponent(item.id) + '/request?month=' + encodeURIComponent(month), {
              method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ requested: item.status !== 'requested' })
            });
            await renderRequiredMaterials();
            if (status) status.textContent = item.status === 'requested' ? 'Маркировката „Заявено“ е премахната.' : 'Материалът е маркиран като заявен.';
          } catch (e) { if (status) status.textContent = e.message || 'Грешка при промяна на статуса.'; }
        });
        const transfer = document.createElement('button'); transfer.type = 'button'; transfer.className = 'ghost'; transfer.textContent = item.status === 'transferred' ? 'Прехвърлен' : 'Прехвърли';
        transfer.disabled = item.status === 'transferred' || month > localYearMonth();
        transfer.title = item.transferredTo ? 'Прехвърлен в ' + item.transferredTo : 'Добави материала в таблицата за следващия месец';
        transfer.addEventListener('click', async () => {
          try {
            const result = await requiredMaterialsRequest(REQUIRED_MATERIALS_API + '/items/' + encodeURIComponent(item.id) + '/transfer?month=' + encodeURIComponent(month), { method: 'POST' });
            await renderRequiredMaterials();
            if (status) status.textContent = 'Материалът е прехвърлен в таблицата за ' + result.targetMonth + '. Изберете този месец от полето „Месец“, за да го прегледате.';
          } catch (e) { if (status) status.textContent = e.message || 'Грешка при прехвърляне.'; }
        });
        actions.append(requested, transfer);
      }
      tr.appendChild(actions); tbody.appendChild(tr);
    });
    table.appendChild(tbody); tableEl.appendChild(table);
  } catch (e) {
    tableEl.textContent = e.message || 'Грешка при зареждане на месечната таблица.';
  }
}
async function saveRequiredMaterialFromUI() {
  const month = document.getElementById('requiredMaterialsMonth').value || localYearMonth();
  const status = document.getElementById('requiredMaterialsStatus');
  const payload = {
    name: document.getElementById('requiredMaterialName').value.trim(),
    quantity: document.getElementById('requiredMaterialQuantity').value.trim(),
    unit: document.getElementById('requiredMaterialUnit').value.trim(),
    note: document.getElementById('requiredMaterialNote').value.trim(),
    requestedBy: document.getElementById('requiredMaterialApplicant').value.trim()
  };
  if (!payload.name) { if (status) status.textContent = 'Въведете наименование на материала.'; return; }
  if (!payload.unit || !payload.quantity || !payload.requestedBy) { if (status) status.textContent = 'Попълнете Материал, Мярка, Количество и Заявил. Бележка е по желание.'; return; }
  if (payload.quantity && !/^\d+$/.test(payload.quantity)) { if (status) status.textContent = 'Количеството може да съдържа само цифри.'; return; }
  if (/\p{N}/u.test(payload.unit)) { if (status) status.textContent = 'Полето „Мярка“ не може да съдържа цифри.'; return; }
  try {
    const editingId = requiredMaterialEditingId;
    const url = editingId
      ? REQUIRED_MATERIALS_API + '/items/' + encodeURIComponent(editingId) + '?month=' + encodeURIComponent(month)
      : REQUIRED_MATERIALS_API + '/items?month=' + encodeURIComponent(month);
    await requiredMaterialsRequest(url, {
      method: editingId ? 'PUT' : 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
    });
    resetRequiredMaterialEditor();
    await renderRequiredMaterials();
    if (status) status.textContent = editingId ? 'Промяната е запазена.' : 'Материалът е добавен за поръчка.';
  } catch (e) { if (status) status.textContent = e.message || 'Грешка при запис.'; }
}



  try {
    document.getElementById('btnExportRequiredMaterials')?.addEventListener('click', function() {
      if (typeof exportRequiredMaterialsXlsx === 'function') exportRequiredMaterialsXlsx();
    });
    document.getElementById('btnChooseRequiredMaterialsImport')?.addEventListener('click', function() {
      document.getElementById('fileImportRequiredMaterials')?.click();
    });
    document.getElementById('fileImportRequiredMaterials')?.addEventListener('change', async function() {
      var file = this.files && this.files[0];
      this.value = '';
      if (file && typeof importRequiredMaterialsXlsx === 'function') await importRequiredMaterialsXlsx(file);
    });
    document.getElementById('btnAddRequiredMaterial')?.addEventListener('click', function() {
      if (typeof saveRequiredMaterialFromUI === 'function') saveRequiredMaterialFromUI();
    });
    document.getElementById('btnCancelRequiredMaterialEdit')?.addEventListener('click', function() {
      if (typeof resetRequiredMaterialEditor === 'function') resetRequiredMaterialEditor();
    });
    document.getElementById('requiredMaterialsMonth')?.addEventListener('change', function() {
      if (typeof resetRequiredMaterialEditor === 'function') resetRequiredMaterialEditor();
      if (typeof renderRequiredMaterials === 'function') renderRequiredMaterials();
    });
  } catch (e) { try { console.warn('required-materials-ui bind:', e); } catch (_) {} }

/* window exports */
try {
  if (typeof beginRequiredMaterialEdit==='function') window.beginRequiredMaterialEdit=beginRequiredMaterialEdit;
  if (typeof bindRequiredMaterialInputRules==='function') window.bindRequiredMaterialInputRules=bindRequiredMaterialInputRules;
  if (typeof exportRequiredMaterialsXlsx==='function') window.exportRequiredMaterialsXlsx=exportRequiredMaterialsXlsx;
  if (typeof importRequiredMaterialsXlsx==='function') window.importRequiredMaterialsXlsx=importRequiredMaterialsXlsx;
  if (typeof localYearMonth==='function') window.localYearMonth=localYearMonth;
  if (typeof refreshRequiredMaterialApplicantOptions==='function') window.refreshRequiredMaterialApplicantOptions=refreshRequiredMaterialApplicantOptions;
  if (typeof renderRequiredMaterials==='function') window.renderRequiredMaterials=renderRequiredMaterials;
  if (typeof requiredMaterialsRequest==='function') window.requiredMaterialsRequest=requiredMaterialsRequest;
  if (typeof resetRequiredMaterialEditor==='function') window.resetRequiredMaterialEditor=resetRequiredMaterialEditor;
  if (typeof saveRequiredMaterialFromUI==='function') window.saveRequiredMaterialFromUI=saveRequiredMaterialFromUI;
} catch(_){}
