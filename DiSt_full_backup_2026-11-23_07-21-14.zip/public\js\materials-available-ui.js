/**
 * materials-available-ui.js — app.js modularization phase 3
 * Списък „Налични материали“ (repair materials list).
 * Load AFTER app.js.
 */

// ============================================================
//  РЕНДИРАНЕ НА НАЛИЧНИ МАТЕРИАЛИ
// ============================================================
async function renderMaterialsList(opts) {
  const soft = isSoftRefreshOpts(opts);
  const container = document.getElementById('materialsListItems');
  const loading = document.getElementById('materialsListLoading');
  if (!soft) {
    if (loading) loading.style.display = 'block';
    if (container) container.innerHTML = '';
  } else if (container) {
    ensureDimLoadingStyle();
    container.classList.add('dim-loading');
  }
  
  try {
    const materials = await getAvailableMaterials();
    if (loading) loading.style.display = 'none';
    if (container) { container.classList.remove('dim-loading'); container.innerHTML = ''; }
    
    if (!materials.length) {
      if (container) container.innerHTML = '<div class="hint">Все още няма добавени материали.</div>';
      return;
    }
    
    materials.forEach((mat, index) => {
      const item = document.createElement('div');
      item.className = 'materials-list-item';
      item.innerHTML = `
        <div class="mat-name">${escapeHtml(mat.name)}</div>
        <div class="mat-merka">${escapeHtml(mat.merka || '—')}</div>
        <div class="mat-actions">
          <button class="ghost" style="padding:4px 8px;font-size:12px;color:#c0392b;" onclick="deleteMaterial(${index})">✕</button>
        </div>
      `;
      container.appendChild(item);
    });
  } catch (e) {
    loading.style.display = 'none';
    container.innerHTML = '<div class="hint">Грешка при зареждане на материалите.</div>';
  }
}

window.deleteMaterial = async function(index) {
  if (!(await confirmDialog('Сигурни ли сте, че искате да изтриете този материал?'))) return;
  
  try {
    const materials = await getAvailableMaterials();
    materials.splice(index, 1);
    await saveAvailableMaterials(materials);
    toast('✅ Материалът е изтрит.');
    await renderMaterialsList();
    populateMaterialSelects();
  } catch (e) {
    toast('❌ Грешка при изтриване.');
  }
};

// ---- EVENT LISTENER ЗА ДОБАВЯНЕ НА МАТЕРИАЛ ----
document.getElementById('btnAddMaterial').addEventListener('click', async function() {
  const nameInput = document.getElementById('newMaterialName');
  const merkaInput = document.getElementById('newMaterialMerka');
  const name = nameInput.value.trim();
  const merka = merkaInput.value.trim();
  
  if (!name) {
    toast('❌ Въведете име на материала.');
    return;
  }
  
  try {
    const materials = await getAvailableMaterials();
    materials.push({ name, merka });
    await saveAvailableMaterials(materials);
    
    nameInput.value = '';
    merkaInput.value = '';
    nameInput.focus();
    
    toast('✅ Материалът е добавен.');
    await renderMaterialsList();
    await populateMaterialSelects(); // Обновяване на селектите в заявките за материали
  } catch (e) {
    toast('❌ Грешка при добавяне.');
  }
});

/* window exports */
try {
  if (typeof deleteMaterial==='function') window.deleteMaterial=deleteMaterial;
  if (typeof renderMaterialsList==='function') window.renderMaterialsList=renderMaterialsList;
} catch(_){}
