/**
 * users-admin-ui.js — app.js modularization phase 3
 * Админ: добавяне/експорт/списък/редакция на потребители.
 * Load AFTER app.js.
 */

// ---- ДОБАВЯНЕ НА ПОТРЕБИТЕЛ ----
(function wireNewUserObserverMenus() {
  const roleEl = document.getElementById('newUserRole');
  const menusEl = document.getElementById('newUserObsMenus');
  if (!roleEl || !menusEl) return;
  function sync() {
    const isObs = roleEl.value === 'observer';
    menusEl.style.display = isObs ? 'block' : 'none';
    if (isObs) renderObserverMenusCheckboxes(menusEl, DEFAULT_OBSERVER_MENUS);
    else menusEl.innerHTML = '';
  }
  roleEl.addEventListener('change', sync);
  sync();
})();

document.getElementById('btnAddUser').addEventListener('click', async function() {
  
  const username = document.getElementById('newUserUsername').value.trim();
  const name = document.getElementById('newUserName').value.trim();
  const struktura = document.getElementById('newUserStruktura').value;
  const role = document.getElementById('newUserRole').value;
  const pw1 = document.getElementById('newUserPassword').value;
  const pw2 = document.getElementById('newUserPassword2').value;
  const errEl = document.getElementById('newUserError');
  errEl.style.display = 'none';
  errEl.textContent = '';

  if (!username) { 
    errEl.textContent = 'Въведете потребителско име.'; 
    errEl.style.display = 'block'; 
    return; 
  }
  if (!pw1 || pw1.length < 8) { 
    errEl.textContent = 'Паролата трябва да е поне 8 символа.'; 
    errEl.style.display = 'block'; 
    return; 
  }
  if (pw1 !== pw2) { 
    errEl.textContent = 'Паролите не съвпадат.'; 
    errEl.style.display = 'block'; 
    return; 
  }

  const btn = document.getElementById('btnAddUser');
  btn.disabled = true;
  btn.textContent = '⏳ Запазване...';

  try {
    const menusEl = document.getElementById('newUserObsMenus');
    const strukturaLocked = !!(document.getElementById('newUserStrukturaLocked') && document.getElementById('newUserStrukturaLocked').checked);
    const korpusEl = document.getElementById('newUserKorpus');
    const korpus = korpusEl ? String(korpusEl.value || '').trim() : '';
    const etazhiText = document.getElementById('newUserEtazhi') ? document.getElementById('newUserEtazhi').value : '';
    const payload = { username, name, struktura, role, password: pw1, strukturaLocked, korpus, etazhiText };
    if (role === 'observer') payload.allowedMenus = readObserverMenusFrom(menusEl);
    const r = await authFetch('/api/auth/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await r.json();
    
    if (!r.ok || !data.ok) {
      errEl.textContent = data.error || 'Грешка при добавяне.';
      errEl.style.display = 'block';
      btn.disabled = false;
      btn.textContent = '+ Добави потребител';
      return;
    }

    // Еднократна бележка с новосъздадените данни за вход - паролата
    // никога не се пази на сървъра в четим вид, затова единствената
    // безопасна възможност е да се предаде СЕГА, докато е известна тук
    // (в самата форма), веднага след създаването.
    downloadUserCredentialsSlip({ username, name, struktura, role, password: pw1 });

    document.getElementById('newUserUsername').value = '';
    document.getElementById('newUserName').value = '';
    document.getElementById('newUserStruktura').value = '';
    const _sl = document.getElementById('newUserStrukturaLocked'); if (_sl) _sl.checked = true;
    const _k = document.getElementById('newUserKorpus'); if (_k) _k.value = '';
    const _e = document.getElementById('newUserEtazhi'); if (_e) _e.value = '';
    document.getElementById('newUserPassword').value = '';
    document.getElementById('newUserPassword2').value = '';
    
    toast('✅ Потребител "' + username + '" е добавен успешно. Бележката с паролата се изтегли.');
    await renderUsersTab();
    
  } catch (e) {
    console.error(e);
    errEl.textContent = 'Грешка при връзка със сървъра.';
    errEl.style.display = 'block';
  } finally {
    btn.disabled = false;
    btn.textContent = '+ Добави потребител';
  }
});

// ---- Експорт на потребители в Excel (XLSX) ----
document.getElementById('btnExportUsers').addEventListener('click', async function() {
  await ensureXlsxLoaded();
  const btn = this;
  const originalText = btn.textContent;
  btn.disabled = true;
  btn.textContent = '⏳ Експортиране...';
  try {
    const r = await authFetch('/api/auth/users');
    if (!r.ok) throw new Error('http ' + r.status);
    const data = await r.json();
    const users = data.users || [];
    if (!users.length) {
      toast('Няма потребители за износ.');
      return;
    }
    const header = ['Потребителско име', 'Име', 'Роля', 'Структура'];
    const rows = users.map(u => [
      u.username || '',
      u.name || '',
      ROLE_NAMES[u.role] || u.role || '',
      u.struktura || ''
    ]);
    const ws = XLSX.utils.aoa_to_sheet([header, ...rows]);
    ws['!cols'] = [{ wch: 20 }, { wch: 24 }, { wch: 18 }, { wch: 22 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Потребители');
    const dateStr = new Date().toISOString().slice(0, 10);
    XLSX.writeFile(wb, 'Potrebiteli_' + dateStr + '.xlsx');
    toast('✅ Файлът е изтеглен.');
  } catch (e) {
    console.error(e);
    toast('❌ Грешка при износ на потребителите.');
  } finally {
    btn.disabled = false;
    btn.textContent = originalText;
  }
});


// ---- Списък / редакция на потребители (от app.js) ----
async function renderUsersTab() {
  const listEl = document.getElementById('usersList');
  listEl.innerHTML = '<div class="hint">Зареждане...</div>';

  let users = [];
  try {
    const r = await authFetch('/api/auth/users');
    let data = null;
    try { data = await r.json(); } catch (_) {}
    if (!r.ok) {
      const msg = (data && data.error) ? data.error : ('HTTP ' + r.status);
      listEl.innerHTML = '<div class="hint">Грешка при зареждане на потребителите: ' + escapeHtml(String(msg)) + '</div>';
      return;
    }
    users = (data && data.users) || [];
  } catch (e) {
    listEl.innerHTML = '<div class="hint">Грешка при зареждане на потребителите: ' + escapeHtml(String(e && e.message ? e.message : e)) + '</div>';
    return;
  }

  const adminCount = users.filter(u => u.role === 'admin').length;
  listEl.innerHTML = '';
  if (!users.length) {
    listEl.innerHTML = '<div class="hint">Все още няма потребители.</div>';
    return;
  }

  users.forEach(u => {
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;flex-direction:column;gap:6px;padding:10px 12px;background:var(--locked-bg);border-radius:8px;margin-bottom:8px;';
    
    // Информация за потребителя
    const info = document.createElement('div');
    info.style.cssText = 'display:flex;align-items:center;gap:10px;flex-wrap:wrap;';
    info.innerHTML = `
      <div style="font-weight:600;font-size:14px;">${escapeHtml(u.username)}</div>
      <span style="font-size:12px;color:var(--ink-soft);">${ROLE_NAMES[u.role] || u.role}</span>
      <span style="font-size:12px;color:var(--ink-soft);">🏷️ <b>${escapeHtml(u.struktura || '— без структура —')}</b>${u.strukturaLocked !== false ? ' 🔒' : ' 🔓'}</span>
      <span style="font-size:12px;color:var(--ink-soft);">🏢 ${escapeHtml(u.korpus || '—')}</span>
      <span style="font-size:12px;color:var(--ink-soft);"> entr ${escapeHtml(Array.isArray(u.etazhi) && u.etazhi.length ? u.etazhi.join(', ') : '—')}</span>
      <span style="font-size:12px;color:var(--ink-soft);">👤 ${escapeHtml(u.name || '—')}</span>
    `;
    row.appendChild(info);
    
    // Редактиране
    const editRow = document.createElement('div');
    editRow.style.cssText = 'display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:4px;';
    editRow.innerHTML = `
      <input type="text" class="edit-name" placeholder="Име" value="${escapeHtml(u.name || '')}" style="width:120px;padding:4px 8px;font-size:12px;border:1px solid var(--line-strong);border-radius:4px;">
      <select class="edit-struktura" style="padding:4px 8px;font-size:12px;border:1px solid var(--line-strong);border-radius:4px;width:140px;">
        <option value="">— без —</option>
        ${dropdownStrukturaList.map(s => `<option value="${escapeHtml(s)}" ${s === u.struktura ? 'selected' : ''}>${escapeHtml(s)}</option>`).join('')}
        <option value="__other__" ${u.struktura && !dropdownStrukturaList.includes(u.struktura) ? 'selected' : ''}>+ Друго...</option>
      </select>
      <input type="text" class="edit-struktura-other" placeholder="Друга структура" value="${u.struktura && !dropdownStrukturaList.includes(u.struktura) ? escapeHtml(u.struktura) : ''}" style="width:120px;padding:4px 8px;font-size:12px;border:1px solid var(--line-strong);border-radius:4px;display:${u.struktura && !dropdownStrukturaList.includes(u.struktura) ? 'block' : 'none'};">
      <label style="font-size:12px;display:inline-flex;align-items:center;gap:4px;white-space:nowrap;padding:4px 6px;background:#fff;border:1px solid var(--line-strong);border-radius:4px;" title="Когато е отметнато, заявителят не може да сменя структурата при заявка">
        <input type="checkbox" class="edit-struktura-locked" ${u.strukturaLocked !== false ? 'checked' : ''}> Заключи структура
      </label>
      <select class="edit-korpus" style="padding:4px 8px;font-size:12px;border:1px solid var(--line-strong);border-radius:4px;width:140px;" title="Корпус за автоматично попълване в заявката">
        <option value="">— корпус —</option>
        ${(Array.isArray(dropdownCorpusList) ? dropdownCorpusList : []).map(s => `<option value="${escapeHtml(s)}" ${s === (u.korpus || '') ? 'selected' : ''}>${escapeHtml(s)}</option>`).join('')}
        <option value="__other__" ${u.korpus && !(Array.isArray(dropdownCorpusList) && dropdownCorpusList.includes(u.korpus)) ? 'selected' : ''}>+ Друго...</option>
      </select>
      <input type="text" class="edit-korpus-other" placeholder="Друг корпус" value="${u.korpus && !(Array.isArray(dropdownCorpusList) && dropdownCorpusList.includes(u.korpus)) ? escapeHtml(u.korpus) : ''}" style="width:110px;padding:4px 8px;font-size:12px;border:1px solid var(--line-strong);border-radius:4px;display:${u.korpus && !(Array.isArray(dropdownCorpusList) && dropdownCorpusList.includes(u.korpus)) ? 'block' : 'none'};">
      <input type="text" class="edit-etazhi" placeholder="Етажи: 1, 2, Партер" value="${escapeHtml(Array.isArray(u.etazhi) ? u.etazhi.join(', ') : (u.etazhi || ''))}" style="width:160px;padding:4px 8px;font-size:12px;border:1px solid var(--line-strong);border-radius:4px;" title="Етажи, от които потребителят може да избира при заявка">
      <select class="edit-role" style="padding:4px 8px;font-size:12px;border:1px solid var(--line-strong);border-radius:4px;">
        <option value="submitter" ${u.role === 'submitter' ? 'selected' : ''}>Подаване</option>
        <option value="observer" ${u.role === 'observer' ? 'selected' : ''}>Наблюдател</option>
        <option value="technician" ${u.role === 'technician' ? 'selected' : ''}>Техник</option>
        <option value="warehouse" ${u.role === 'warehouse' ? 'selected' : ''}>Склад</option>
        <option value="admin" ${u.role === 'admin' ? 'selected' : ''}>Администратор</option>
      </select>
      <div class="edit-obs-menus" style="width:100%;display:${u.role === 'observer' ? 'block' : 'none'};"></div>
      <input type="password" class="edit-password" placeholder="Нова парола" style="width:120px;padding:4px 8px;font-size:12px;border:1px solid var(--line-strong);border-radius:4px;">
      <button class="btn-save-user" style="padding:4px 10px;font-size:12px;background:var(--accent);color:#fff;border:none;border-radius:4px;cursor:pointer;">💾 Запази</button>
      <button class="btn-delete-user" style="padding:4px 10px;font-size:12px;color:#c0392b;background:none;border:1px solid #c0392b;border-radius:4px;cursor:pointer;">✕ Изтрий</button>
    `;
    row.appendChild(editRow);
    const menusWrap = editRow.querySelector('.edit-obs-menus');
    if (menusWrap) {
      renderObserverMenusCheckboxes(menusWrap, u.allowedMenus);
      const roleSel = editRow.querySelector('.edit-role');
      if (roleSel) {
        roleSel.addEventListener('change', function () {
          menusWrap.style.display = roleSel.value === 'observer' ? 'block' : 'none';
          if (roleSel.value === 'observer' && !menusWrap.querySelector('.obs-menu-cb')) {
            renderObserverMenusCheckboxes(menusWrap, DEFAULT_OBSERVER_MENUS);
          }
        });
      }
    }

    
    // Обработка на "Друго" за структура
    const strukturaSelect = editRow.querySelector('.edit-struktura');
    const strukturaOther = editRow.querySelector('.edit-struktura-other');
    strukturaSelect.addEventListener('change', () => {
      if (strukturaSelect.value === '__other__') {
        strukturaOther.style.display = 'block';
        strukturaOther.focus();
      } else {
        strukturaOther.style.display = 'none';
        strukturaOther.value = '';
      }
    });
    
    // Запази потребител
    editRow.querySelector('.btn-save-user').addEventListener('click', async () => {
      const name = editRow.querySelector('.edit-name').value.trim();
      let struktura = strukturaSelect.value;
      if (struktura === '__other__') {
        struktura = strukturaOther.value.trim();
      }
      const role = editRow.querySelector('.edit-role').value;
      const password = editRow.querySelector('.edit-password').value;
      
      if (u.role === 'admin' && role !== 'admin' && adminCount <= 1) {
        toast('Не може да премахнете ролята на последния администратор.');
        return;
      }
      
      try {
        let korpus = '';
        const korpusSel = editRow.querySelector('.edit-korpus');
        const korpusOther = editRow.querySelector('.edit-korpus-other');
        if (korpusSel) {
          korpus = korpusSel.value === '__other__'
            ? ((korpusOther && korpusOther.value) || '').trim()
            : (korpusSel.value || '').trim();
        }
        const etazhiRaw = (editRow.querySelector('.edit-etazhi') && editRow.querySelector('.edit-etazhi').value) || '';
        const strukturaLocked = !!(editRow.querySelector('.edit-struktura-locked') && editRow.querySelector('.edit-struktura-locked').checked);
        const menusWrap = editRow.querySelector('.edit-obs-menus');
        const allowedMenus = (role === 'observer') ? readObserverMenusFrom(menusWrap) : undefined;
        if (password && password.length > 0 && password.length < 8) {
          throw new Error('Паролата трябва да е поне 8 символа.');
        }
        const payload = {
          name, struktura, role,
          strukturaLocked, korpus, etazhiText: etazhiRaw,
          password: (password && password.length >= 8) ? password : undefined
        };
        if (role === 'observer') payload.allowedMenus = allowedMenus;
        const r3 = await authFetch('/api/auth/users/' + encodeURIComponent(u.id), {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        if (!r3.ok) {
          const errData = await r3.json().catch(() => ({}));
          throw new Error(errData.error || 'Грешка при обновяване на потребителя');
        }
        
        toast('✅ Потребителят е обновен успешно.');
        downloadUserCredentialsSlip({
          username: u.username,
          name,
          struktura,
          role,
          password: (password && password.length >= 8) ? password : null
        });
        await renderUsersTab();
      } catch (e) {
        toast('❌ ' + e.message);
      }
    });
    
    // Изтрий потребител
    editRow.querySelector('.btn-delete-user').addEventListener('click', async () => {
      if (u.role === 'admin' && adminCount <= 1) {
        toast('Не може да изтриете последния администратор.');
        return;
      }
      if (!(await confirmDialog('Сигурни ли сте, че искате да изтриете потребител "' + u.username + '"?'))) return;
      try {
        const r = await authFetch('/api/auth/users/' + encodeURIComponent(u.id), { method: 'DELETE' });
        let data = null;
        try { data = await r.json(); } catch (_) {}
        if (!r.ok) throw new Error((data && data.error) ? data.error : ('Грешка при изтриване (HTTP ' + r.status + ')'));
        toast('✅ Потребителят е изтрит.');
        await renderUsersTab();
      } catch (e) {
        toast('❌ ' + (e && e.message ? e.message : e));
      }
    });
    
    listEl.appendChild(row);
  });
}

// ---- Обща помощна функция: изтегляне на еднократна бележка с данни
// за вход на потребител. Паролата се предава само ако е РЕАЛНО известна
// в момента (при създаване, или при изрична смяна на парола) - тя
// никога не се пази на сървъра в четим вид, затова не може да бъде
// показана при обикновена промяна на други данни (име/структура/роля).
function downloadUserCredentialsSlip({ username, name, struktura, role, password }) {
  const slipText =
    'DiSt — данни за вход\n' +
    '----------------------------\n' +
    'Потребителско име: ' + username + '\n' +
    (password ? 'Парола: ' + password + '\n' : 'Парола: (непроменена — не се пази в четим вид на сървъра)\n') +
    (name ? 'Име: ' + name + '\n' : '') +
    (struktura ? 'Структура: ' + struktura + '\n' : '') +
    'Роля: ' + (ROLE_NAMES[role] || role) + '\n' +
    '----------------------------\n' +
    'Пазете тази бележка на сигурно място.' +
    (password ? ' Препоръчваме потребителят\nда смени паролата си при първи вход.' : '');
  const blob = new Blob([slipText], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'DiSt_dostap_' + username + '.txt';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}


/* window exports — switchTab() и export бутоните разчитат на глобални имена */
try {
  window.renderUsersTab = renderUsersTab;
  window.downloadUserCredentialsSlip = downloadUserCredentialsSlip;
} catch (_) {}
