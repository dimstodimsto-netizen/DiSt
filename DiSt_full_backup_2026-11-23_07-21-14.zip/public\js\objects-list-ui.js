/**
 * objects-list-ui.js — app.js modularization phase 3
 * Рендиране на списък обекти (остатък).
 * Load AFTER app.js.
 */

// ============================================================
//  РЕНДИРАНЕ НА ОБЕКТИ
// ============================================================
async function renderObjectsList() {
  const container = document.getElementById('objectsList');
  const searchInput = document.getElementById('objectsSearchInput');
  container.innerHTML = '<div class="hint">Зареждане...</div>';
  const activeBtn = document.getElementById('tabObjectsActive');
  const completedBtn = document.getElementById('tabObjectsCompleted');
  if (activeBtn) activeBtn.classList.toggle('active', __objectsStatusFilter === 'active');
  if (completedBtn) completedBtn.classList.toggle('active', __objectsStatusFilter === 'completed');
  try {
    const objects = await getAllObjects();
    const searchTerm = searchInput ? searchInput.value.toLowerCase().trim() : '';
    const byStatus = objects.filter(obj => __objectsStatusFilter === 'completed' ? !!obj.completedAt : !obj.completedAt);
    const filtered = searchTerm ? byStatus.filter(obj =>
      (obj.vazlozhitel || '').toLowerCase().includes(searchTerm) ||
      (obj.osnovanie || '').toLowerCase().includes(searchTerm) ||
      (obj.korpus || '').toLowerCase().includes(searchTerm) ||
      (obj.etaz || '').toLowerCase().includes(searchTerm) ||
      (obj.struktura || '').toLowerCase().includes(searchTerm) ||
      (obj.lokacia || '').toLowerCase().includes(searchTerm) ||
      (obj.vidDeinost || '').toLowerCase().includes(searchTerm)
    ) : byStatus;
    container.innerHTML = '';
    if (!filtered.length) {
      const emptyText = searchTerm ? 'Няма намерени обекти.' : (__objectsStatusFilter === 'completed' ? 'Няма завършени обекти.' : 'Няма активни обекти.');
      container.innerHTML = '<div class="hint">' + emptyText + '</div>';
      return;
    }
    filtered.forEach(obj => {
      const item = document.createElement('div');
      item.className = 'resultitem';
      const statusBadge = obj.completedAt ? '<span class="status-badge st-ok">Завършен</span>' : '<span class="status-badge st-progress">Активен</span>';
      item.innerHTML = '<div style="flex:1;min-width:0;">' +
        '<div class="rmeta" style="margin-bottom:4px;"><b>Корпус:</b> ' + escapeHtml(obj.korpus || '—') + ' &nbsp; <b>Етаж:</b> ' + escapeHtml(obj.etaz || '—') + ' &nbsp; <b>Структура:</b> ' + escapeHtml(obj.struktura || '—') + '</div>' +
        '<div class="rmeta" style="margin-bottom:4px;"><b>Локация:</b> <strong>' + escapeHtml(obj.lokacia || '—') + '</strong></div>' +
        '<div class="rmeta" style="margin-bottom:4px;"><b>Вид дейност:</b> ' + escapeHtml(obj.vidDeinost || '—') + '</div>' +
        '<div class="rid"><b>Възложител:</b> ' + escapeHtml(obj.vazlozhitel || '—') + '</div></div><div>' + statusBadge + '</div>';
      item.onclick = () => openObjectForm(obj.id);
      container.appendChild(item);
    });
  } catch (e) {
    console.error(e);
    container.innerHTML = '<div class="hint">Грешка при зареждане на обектите.</div>';
  }
}

/* window exports */
try {
  if (typeof renderObjectsList==='function') window.renderObjectsList=renderObjectsList;
} catch(_){}
