'use strict';

/**
 * Отчет „Вложени материали“ — помощни + GET /api/reports/materials
 */
function reportDatePartsServer(value) {
  const raw = String(value || '').trim();
  if (!raw) return { year: '', month: '' };
  // DD.MM.YYYY или DD.MM.YYYY HH:mm
  const m = raw.match(/^(\d{1,2})\.(\d{1,2})\.(\d{4})/);
  if (m) return { year: m[3], month: String(Number(m[2])) };
  // YYYY-MM-DD (поле "Дата на изпълнение" type=date)
  const iso = raw.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (iso) return { year: iso[1], month: String(Number(iso[2])) };
  const d = new Date(raw);
  if (Number.isNaN(d.getTime())) return { year: '', month: '' };
  return { year: String(d.getFullYear()), month: String(d.getMonth() + 1) };
}
/** Реперна дата за отчет „Вложени материали“: дата на изпълнение, не на подаване. */
function reportRecordDateParts(rec) {
  return reportDatePartsServer(rec && (rec.dataIzp || rec.data_izp));
}
function parseRepairMaterialsServer(value) {
  if (Array.isArray(value)) return value.map(m => ({
    name: String(m?.name ?? m?.vid ?? '').trim(),
    merka: String(m?.merka ?? '').trim(),
    kolichestvo: String(m?.kolichestvo ?? m?.quantity ?? '').trim()
  })).filter(m => m.name || m.merka || m.kolichestvo);
  const raw = String(value || '').trim();
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) return parseRepairMaterialsServer(parsed);
  } catch (_) {}
  return raw.split(/\r?\n|;/).map(x => x.trim()).filter(Boolean).map(name => ({name, merka:'', kolichestvo:''}));
}
function parseReportQuantityServer(value) {
  const raw = String(value ?? '').trim().replace(/\s/g, '').replace(',', '.');
  if (!raw) return null;
  const n = Number(raw);
  return Number.isFinite(n) ? n : null;
}
function formatReportQuantityServer(n) {
  if (!Number.isFinite(n)) return '';
  return Number.isInteger(n) ? String(n) : String(Number(n.toFixed(3)));
}
function buildMaterialsReportServer(records, selectedColumns) {
  // Групиране: структура + вид + мярка; + корпус/локация само ако са в selectedColumns.
  // Година/месец не разделят — филтрите вече са приложени върху records.
  const showLocation = selectedColumns.includes('lokacia');
  const showKorpus = selectedColumns.includes('korpus');
  const showStruktura = selectedColumns.includes('struktura');
  const groups = new Map();
  for (const rec of records) {
    const dp = reportRecordDateParts(rec);
    for (const mat of parseRepairMaterialsServer(rec.materiali ?? rec.materials)) {
      const strukturaFull = String(rec.struktura || '').trim();
      const korpus = String(rec.korpus || '').trim();
      const lokacia = String(rec.lokacia || '').trim();
      const vid = String(mat.name || '').trim();
      const merka = String(mat.merka || '').trim();
      if (!vid && !merka) continue;
      const struktura = showStruktura ? strukturaFull : '';
      const key = [struktura, showKorpus ? korpus : '', vid.toLowerCase(), merka.replace(/\s+/g, ' ').replace(/\.$/, '').toLowerCase(), showLocation ? lokacia : ''].join('\u001f');
      const g = groups.get(key) || {
        year: '', month: '', struktura, korpus: showKorpus ? korpus : '', vid, merka,
        lokacia: showLocation ? lokacia : '',
        kolichestvo: 0, _hasNumeric: false, _textQty: [],
        _years: new Set(), _months: new Set()
      };
      if (dp.year) g._years.add(String(dp.year));
      if (dp.month) g._months.add(String(dp.month));
      const q = parseReportQuantityServer(mat.kolichestvo);
      if (q !== null) { g.kolichestvo += q; g._hasNumeric = true; }
      else if (mat.kolichestvo && !g._textQty.includes(mat.kolichestvo)) g._textQty.push(mat.kolichestvo);
      groups.set(key, g);
    }
  }
  return [...groups.values()].map(g => {
    g.kolichestvo = g._hasNumeric ? formatReportQuantityServer(g.kolichestvo) : g._textQty.join(', ');
    g.year = g._years.size === 1 ? [...g._years][0] : '';
    g.month = g._months.size === 1 ? [...g._months][0] : '';
    delete g._hasNumeric; delete g._textQty; delete g._years; delete g._months;
    if (!showLocation) g.lokacia = '';
    if (!showKorpus) g.korpus = '';
    if (!showStruktura) g.struktura = '';
    return g;
  }).sort((a, b) =>
    a.struktura.localeCompare(b.struktura, 'bg') ||
    String(a.korpus || '').localeCompare(String(b.korpus || ''), 'bg') ||
    a.lokacia.localeCompare(b.lokacia, 'bg') ||
    a.vid.localeCompare(b.vid, 'bg') ||
    a.merka.localeCompare(b.merka, 'bg')
  );
}



function createMaterialsReportRoutes(deps) {
  const {
    requireAdmin,
    sendJSON,
    getRecordsIndexSafe,
    getRecordServer
  } = deps;

  return function handleMaterialsReportRoute(req, res, parsed, pathname) {
    if (pathname !== '/api/reports/materials' || req.method !== 'GET') return false;
    const sess = requireAdmin(req, res);
    if (!sess) return true;
    const year = String(parsed.searchParams.get('year') || '');
    const month = String(parsed.searchParams.get('month') || '');
    const struktura = String(parsed.searchParams.get('struktura') || '');
    const vid = String(parsed.searchParams.get('vid') || '');
    let columns = String(parsed.searchParams.get('columns') || 'year,month,struktura,vid,merka,kolichestvo,lokacia').split(',').filter(Boolean);
    const allowed = new Set(['year','month','struktura','korpus','vid','merka','kolichestvo','lokacia']);
    columns = columns.filter(c => allowed.has(c));
    if (!columns.length) columns = ['kolichestvo'];
    const idx = getRecordsIndexSafe();
    const records = [];
    const allRecords = [];
    for (const id of idx) {
      const rec = getRecordServer(id);
      if (!rec) continue;
      allRecords.push(rec);
      const dp = reportRecordDateParts(rec);
      if (year && dp.year !== year) continue;
      if (month && dp.month !== month) continue;
      if (struktura && String(rec.struktura || '') !== struktura) continue;
      if (vid && !parseRepairMaterialsServer(rec.materiali ?? rec.materials).some(m => m.name === vid)) continue;
      records.push(rec);
    }
    const rows = buildMaterialsReportServer(records, columns);
    const years = [...new Set(allRecords.map(r => reportRecordDateParts(r).year).filter(Boolean))].sort((a,b)=>b.localeCompare(a));
    const structures = [...new Set(allRecords.map(r=>String(r.struktura||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'bg'));
    const vids = [...new Set(allRecords.flatMap(r=>parseRepairMaterialsServer(r.materiali ?? r.materials).map(m=>m.name).filter(Boolean)))].sort((a,b)=>a.localeCompare(b,'bg'));
    sendJSON(res, 200, { rows, columns, options:{ years, structures, vids } });
    return true;
  };
}

module.exports = {
  createMaterialsReportRoutes,
  reportDatePartsServer,
  reportRecordDateParts,
  parseRepairMaterialsServer,
  parseReportQuantityServer,
  formatReportQuantityServer,
  buildMaterialsReportServer
};
