/**
 * technicians-ui.js — app.js modularization phase 3
 * Табло техници.
 * Load AFTER app.js.
 */

// ============================================================
//  РЕНДИРАНЕ НА ТАБЛО ЗА ТЕХНИЦИ
// ============================================================
async function renderTechniciansTable(opts) {
  // opts.softRefresh = true → без пълен invalidate (за авто-обновяване)
  const soft = !!(opts && opts.softRefresh);
  if (!soft) {
    invalidateRecordsCache();
  }

  const tbody = document.getElementById('techTableBody');
  if (!tbody) return;
  // При soft refresh НЕ чистим таблицата — избягва мигане
  if (!soft) {
    setContentLoading(tbody, '<tr><td colspan="11" class="hint">Зареждане...</td></tr>', false);
  } else {
    ensureDimLoadingStyle();
    tbody.classList.add('dim-loading');
    const lu = document.getElementById('techLastUpdate');
    if (lu) lu.textContent = 'Обновяване...';
  }

  const mySeq = (++__techRenderSeq);
  try {
    let recs = [];
    // Предпочитаме един batch API вместо N+1 заявки
    try {
      const r = await authFetch('/api/records?pageSize=500&page=1');
      if (r.ok) {
        const data = await r.json();
        if (data && Array.isArray(data.records)) recs = data.records;
      }
    } catch (_) {}
    if (!recs.length) {
      const idx = await getIndex();
      const fetched = await Promise.all((idx || []).map(id => getRecord(id).catch(() => null)));
      recs = fetched.filter(Boolean);
    }
    if (mySeq !== __techRenderSeq) return; // остарял soft refresh
    
    // Сортиране по дата (най-новите първи)
    recs.sort((a, b) => {
      const dateA = parseStamp(a.datetime) || new Date(0);
      const dateB = parseStamp(b.datetime) || new Date(0);
      return dateB - dateA;
    });
    
    tbody.innerHTML = '';
    
    if (!recs.length) {
      tbody.innerHTML = '<tr><td colspan="11" class="hint">Няма подадени заявки за ремонт.</td></tr>';
      document.getElementById('techNewCount').textContent = '0';
      document.getElementById('techInProgressCount').textContent = '0';
      document.getElementById('techDoneCount').textContent = '0';
      document.getElementById('techLastUpdate').textContent = 'Последно обновяване: ' + new Date().toLocaleTimeString('bg-BG');
      return;
    }
    
    let newCount = 0;
    let inProgressCount = 0;
    let doneCount = 0;
    const unseenIds = [];
    
    recs.forEach(rec => {
      const isUrgent = isUrgentActive(rec);
      const isUnresolved = !rec.status || rec.status === 'Не е изпълнена' || rec.status === 'Изпълнява се';
      const isDone = rec.status === 'Изпълнена';
      
      const isHiddenFromTech = !!rec.hiddenFromTech;
      if (!isHiddenFromTech && isUnresolved && !rec.seen) newCount++;
      if (!isHiddenFromTech && rec.status === 'Изпълнява се') inProgressCount++;
      if (isDone) doneCount++;
      
      // Събираме невидени — маркираме с един batch заявки в края (не по една)
      if (!isHiddenFromTech && isUnresolved && !rec.seen) {
        unseenIds.push(String(rec.id));
        rec.seen = true; // локално за UI / броячи
      }

      // В самото табло се показват само неприключените заявки
      // ("Не е изпълнена" / "Изпълнява се") - завършените остават само
      // в бройката горе ("Изпълнени: N"), за да не се затрупва списъкът
      // с активна работа с вече приключени заявки.
      if (isDone) return;
      // Снети от админ заявки не се показват на техниците (статусът остава непроменен)
      if (rec.hiddenFromTech) return;

      const rowClass = isUrgent ? 'urgent-row' : '';
      const urgentBadge = isUrgent ? '<span class="urgent-badge">🚨</span>' : '';
      
      const tr = document.createElement('tr');
      tr.className = rowClass;
      const recIdStr = String(rec.id);
      const safeIdJs = recIdStr.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
      // Админ действия (изтрий / снеми от панел) — САМО в „Всички заявки“, не тук
      const adminDeleteBtn = '';
      const adminHideBtn = '';
      const noteText = String(rec.zabelezka || '').trim();
      const noteShort = noteText.length > 120 ? (noteText.slice(0, 117) + '…') : noteText;
      tr.style.cursor = 'pointer';
      tr.title = 'Кликнете за преглед / редакция';
      tr.innerHTML = `
        <td style="padding:6px 4px;word-break:break-word;">${urgentBadge}${escapeHtml(recIdStr)}</td>
        <td style="padding:6px 10px;word-break:break-word;">${escapeHtml(rec.datetime ? rec.datetime.split(' ')[0] : '')}</td>
        <td style="padding:6px 4px;word-break:break-word;">${escapeHtml(rec.datetime ? rec.datetime.split(' ')[1] || '' : '')}</td>
        <td style="padding:6px 10px;word-break:break-word;">${escapeHtml(rec.lokacia)}</td>
        <td style="padding:6px 10px;word-break:break-word;width:22%;">${escapeHtml(rec.vid)}</td>
        <td style="padding:6px 10px;word-break:break-word;">${escapeHtml(rec.korpus)}</td>
        <td style="padding:6px 4px;word-break:break-word;">${escapeHtml(rec.etaz)}</td>
        <td style="padding:6px 10px;word-break:break-word;">${escapeHtml(rec.struktura)}</td>
        <td style="padding:6px 10px;word-break:break-word;">${escapeHtml(rec.zayavitel)}</td>
        <td style="padding:6px 10px;word-break:break-word;"><span class="status-badge ${statusClass(rec.status)}">${escapeHtml(rec.status || '—')}</span></td>
        <td style="padding:6px 10px;word-break:break-word;max-width:220px;" title="${escapeHtml(noteText)}">
          <span style="display:inline-block;max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;vertical-align:middle;">${escapeHtml(noteShort || '—')}</span>
          ${adminHideBtn}${adminDeleteBtn}
        </td>
      `;
      tr.addEventListener('click', function (e) {
        if (e.target && (e.target.closest && e.target.closest('button'))) return;
        openRecord(recIdStr);
      });
      tbody.appendChild(tr);
    });

    // Един batch към сървъра вместо N × saveRecord
    if (unseenIds.length) {
      markRecordsSeenBatch(unseenIds);
    }
    
    document.getElementById('techNewCount').textContent = newCount;
    document.getElementById('techInProgressCount').textContent = inProgressCount;
    document.getElementById('techDoneCount').textContent = doneCount;
    document.getElementById('techLastUpdate').textContent = 'Последно обновяване: ' + new Date().toLocaleTimeString('bg-BG');
    
  } catch (e) {
    console.error(e);
    tbody.innerHTML = '<tr><td colspan="11" class="hint">Грешка при зареждане на заявките.</td></tr>';
  }
}

document.getElementById('btnTechRefresh').addEventListener('click', function() {
  renderTechniciansTable();
});

/* window exports */
try {
  if (typeof renderTechniciansTable==='function') window.renderTechniciansTable=renderTechniciansTable;
} catch(_){}
