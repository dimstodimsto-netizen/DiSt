'use strict';

/**
 * Модул: стабилност / health помощни функции.
 * Фаза 1 модулност — изнесено от server.js.
 */

function createAdminHealthModule(deps) {
  const { kvGet, db, SERVER_STARTED_AT, processRef } = deps;
  const proc = processRef || process;

  function formatLogTimestampLocal(ts) {
    try {
      const d = new Date(ts);
      if (Number.isNaN(d.getTime())) return String(ts == null ? '' : ts);
      const pad = (n) => String(n).padStart(2, '0');
      return pad(d.getDate()) + '.' + pad(d.getMonth() + 1) + '.' + d.getFullYear() +
        ' ' + pad(d.getHours()) + '.' + pad(d.getMinutes()) + '.' + pad(d.getSeconds());
    } catch (_) {
      return String(ts == null ? '' : ts);
    }
  }

  function formatCrashLineForLog(raw) {
    const s = String(raw || '');
    return s.replace(/^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z?)/, function (_, iso) {
      return formatLogTimestampLocal(iso);
    });
  }

  function formatHeartbeatLine(raw) {
    const s = String(raw || '').trim();
    if (!s) return '';
    const m = s.match(/^(\S+)(?:\s+pid=(\d+))?/);
    if (!m) return s;
    const when = formatLogTimestampLocal(m[1]);
    return m[2] ? (when + ' (pid=' + m[2] + ')') : when;
  }

  function getStabilityStats() {
    let lastUnclean = null;
    try {
      const raw = kvGet('settings:lastUncleanShutdown');
      if (raw) lastUnclean = JSON.parse(raw);
    } catch (_) {}
    let unclean24h = 0;
    try {
      const since = Date.now() - 24 * 60 * 60 * 1000;
      const rows = db.prepare(
        "SELECT COUNT(*) AS c FROM system_log WHERE category = 'crash' AND level = 'error' AND ts >= ? AND message LIKE ?"
      ).get(since, '%без нормален shutdown%');
      unclean24h = rows && rows.c != null ? Number(rows.c) : 0;
    } catch (_) {
      try {
        const since = Date.now() - 24 * 60 * 60 * 1000;
        const rows = db.prepare(
          "SELECT COUNT(*) AS c FROM system_log WHERE category = 'crash' AND ts >= ?"
        ).get(since);
        unclean24h = rows && rows.c != null ? Number(rows.c) : 0;
      } catch (__) {}
    }
    let lastStart = null;
    try { lastStart = kvGet('settings:lastSuccessfulStartIso') || kvGet('settings:lastSuccessfulStart'); } catch (_) {}
    return {
      lastUncleanShutdown: lastUnclean,
      uncleanShutdowns24h: unclean24h,
      lastSuccessfulStart: lastStart,
      uptimeSec: Math.floor((Date.now() - SERVER_STARTED_AT) / 1000),
      pid: proc.pid,
      startedAt: new Date(SERVER_STARTED_AT).toISOString()
    };
  }

  return {
    formatLogTimestampLocal,
    formatCrashLineForLog,
    formatHeartbeatLine,
    getStabilityStats
  };
}

module.exports = { createAdminHealthModule };
