/**
 * admin-settings-ui.js — app.js modularization
 * Верификация info, адреси на сървър, имейл настройки UI helpers.
 * Load AFTER app.js.
 */

// ---- Верификационна информация ----
async function loadVerificationInfo() {
  console.log('🔍 Зареждане на верификационна информация...');
  const infoDiv = document.getElementById('verificationInfo');
  if (!infoDiv) {
    console.error('❌ Елементът verificationInfo не е намерен!');
    return;
  }
  infoDiv.innerHTML = '<div class="hint">Зареждане...</div>';

  try {
    const r = await fetch('/api/system/verification-status', { cache: 'no-store' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const data = await r.json();

    verificationState = data; // Сървърът връща директно state, не { verification: state }
    showVerificationNotice(verificationState);

    const state = verificationState;
    const periodDays = Number(state.periodDays) || 60;
    const elapsedDays = Math.max(0, Number(state.elapsedDays) || 0);
    const daysRemaining = Number.isFinite(Number(state.daysRemaining))
      ? Math.max(0, Number(state.daysRemaining))
      : Math.max(0, periodDays - elapsedDays);
    const daysWord = daysRemaining === 1 ? 'ден' : 'дни';
    const daysColor = daysRemaining <= 10 ? 'var(--danger)' : (daysRemaining <= 20 ? '#e6b800' : 'var(--ok)');

    let html = '<div style="font-size:13px;">';
    if (state.installId) html += '<div class="hint" style="margin-bottom:8px;">Инсталация ID: <code>' + escapeHtml(String(state.installId)) + '</code></div>';
    if (state.licenseContact) html += '<div class="hint" style="margin-bottom:8px;"><b>Лиценз / контакт:</b> ' + escapeHtml(String(state.licenseContact)) + '</div>';
    try {
      const ta = document.getElementById('licenseContactText');
      if (ta && state.licenseContact) ta.value = String(state.licenseContact);
    } catch (_) {}
    if (state.fingerprintMismatch) html += '<div style="color:var(--danger);margin-bottom:8px;">⚠ Отпечатъкът не съвпада (копие/друг път).</div>';
    if (state.activated === false) html += '<div style="color:var(--danger);margin-bottom:8px;">⚠ Инсталацията не е активирана.</div>';


    if (state.locked) {
      html += `<div style="color:var(--danger);font-weight:600;margin-bottom:8px;">🔒 Програмата е заключена</div>`;
      const reasonLabel = state.lockReason === 'clock_rollback' ? 'Отмяна на системния часовник'
        : (state.lockReason === 'install_mismatch' ? 'Копие/преместване на друга машина или папка'
        : (state.lockReason === 'not_activated' ? 'Неактивирана инсталация'
        : 'Изтекъл верификационен период'));
      html += '<div>Причина: ' + reasonLabel + '</div>';
    } else if (state.warning) {
      html += `<div style="color:#e6b800;font-weight:600;margin-bottom:8px;">⚠️ Предупреждение за верификация</div>`;
    } else {
      html += `<div style="color:var(--ok);font-weight:600;margin-bottom:8px;">✅ Верификацията е активна</div>`;
    }

    html += `<div style="margin-top:12px;padding:14px;background:var(--ok-soft);border:1px solid var(--ok);border-radius:8px;">`;
    html += `<div style="font-size:12px;color:var(--ink-soft);margin-bottom:4px;">Оставащи дни до края на ${periodDays}-дневния верификационен период</div>`;
    html += `<div style="font-size:28px;font-weight:700;line-height:1.2;color:${daysColor};">${daysRemaining} ${daysWord}</div>`;
    html += `</div>`;

    html += `<div style="margin-top:12px;padding:12px;background:var(--locked-bg);border-radius:8px;">`;
    html += `<div style="font-weight:600;margin-bottom:8px;">⏱️ Статус на верификацията:</div>`;
    html += `<div style="display:flex;justify-content:space-between;margin-bottom:6px;">`;
    html += `<span>Изминали дни:</span>`;
    html += `<span style="font-weight:600;">${elapsedDays} / ${periodDays}</span>`;
    html += `</div>`;
    html += `<div style="display:flex;justify-content:space-between;margin-bottom:6px;">`;
    html += `<span>Оставащи дни:</span>`;
    html += `<span style="font-weight:600;color:${daysColor};">${daysRemaining} ${daysWord}</span>`;
    html += `</div>`;
    html += `<div style="font-size:12px;color:var(--ink-soft);margin-top:8px;">Последна верификация: ${formatVerificationDateTime(state.lastVerificationAt)}</div>`;
    html += `<div style="font-size:12px;color:var(--ink-soft);margin-top:4px;">Край на периода: ${formatVerificationDateTime(state.nextVerificationAt)}</div>`;
    html += `</div>`;
    html += '</div>';

    infoDiv.innerHTML = html;
    document.getElementById('verificationStatus').textContent = state.locked ? 'Необходима е верификация' : 'Активна';
  } catch (e) {
    console.error('❌ Грешка при зареждане на верификационна информация:', e);
    infoDiv.innerHTML = '<div class="hint" style="color:var(--danger);">Грешка при зареждане на верификационна информация.</div>';
  }
}

// ---- Ръчно добавени адреси на сървъра (пазят се локално на компютъра) ----
const CUSTOM_ADDR_KEY = 'zayavki_customAddresses';
function getCustomAddresses() {
  try {
    const raw = localStorage.getItem(CUSTOM_ADDR_KEY);
    const arr = raw ? JSON.parse(raw) : [];
    return Array.isArray(arr) ? arr : [];
  } catch (e) { return []; }
}
function saveCustomAddresses(list) {
  try { localStorage.setItem(CUSTOM_ADDR_KEY, JSON.stringify(list)); } catch (e) {}
}
function renderCustomServerAddresses() {
  const wrap = document.getElementById('serverCustomAddresses');
  const list = getCustomAddresses();
  if (!list.length) {
    wrap.innerHTML = '<div class="hint">Няма ръчно добавени адреси.</div>';
    return;
  }
  wrap.innerHTML = '';
  list.forEach((item, idx) => {
    const div = document.createElement('div');
    div.style.cssText = 'display:flex;align-items:center;gap:8px;margin-bottom:6px;';
    div.innerHTML = `
      <a href="${escapeHtml(item.url)}" target="_blank" style="color:var(--accent);text-decoration:none;font-weight:600;">
        ${escapeHtml(item.label || item.url)}
      </a>
      <span class="hint" style="margin:0;">${escapeHtml(item.url)}</span>
      <button class="ghost" style="padding:4px 8px;font-size:12px;" onclick="copyToClipboard('${escapeHtml(item.url)}')">📋</button>
      <button class="ghost" style="padding:4px 8px;font-size:12px;color:#c0392b;" data-idx="${idx}" onclick="removeCustomServerAddress(${idx})">✕</button>
    `;
    wrap.appendChild(div);
  });
}
window.removeCustomServerAddress = function(idx) {
  const list = getCustomAddresses();
  list.splice(idx, 1);
  saveCustomAddresses(list);
  renderCustomServerAddresses();
};
document.getElementById('btnAddServerAddress').addEventListener('click', function() {
  const label = document.getElementById('srvNewLabel').value.trim();
  const url = document.getElementById('srvNewUrl').value.trim();
  if (!url) { toast('Въведете адрес (URL).'); return; }
  const list = getCustomAddresses();
  list.push({ label, url });
  saveCustomAddresses(list);
  document.getElementById('srvNewLabel').value = '';
  document.getElementById('srvNewUrl').value = '';
  renderCustomServerAddresses();
  toast('✅ Адресът е добавен.');
});

// ---- Имейл известия ----
document.getElementById('btnSaveNotifyEmails').addEventListener('click', async function() {
  const btn = this;
  const statusEl = document.getElementById('notifyEmailStatus');
  const emails = document.getElementById('notifyEmailsInput').value
    .split(',').map(s => s.trim()).filter(Boolean);
  const enabledEl = document.getElementById('emailNotifyEnabled');
  const enabled = enabledEl ? !!enabledEl.checked : true;
  btn.disabled = true;
  statusEl.textContent = 'Записване...';
  try {
    const r = await authFetch('/api/notify-settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        emails,
        enabled,
        mailTransport: (document.getElementById('mailTransportSelect') || {}).value || 'auto',
        smtpMode: (document.getElementById('smtpModeSelect') || {}).value || 'starttls',
        smtpHost: (document.getElementById('smtpHostInput') || {}).value || '',
        smtpPort: (document.getElementById('smtpPortInput') || {}).value || 587,
        smtpUser: (document.getElementById('smtpUserInput') || {}).value || '',
        smtpFrom: (document.getElementById('smtpFromInput') || {}).value || '',
        smtpPass: (document.getElementById('smtpPassInput') || {}).value || ''
      })
    });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    statusEl.textContent = '✅ Запазено (' + (enabled ? 'известия ВКЛ' : 'известия ИЗКЛ') + ', ' + emails.length + ' адреса).';
  } catch (e) {
    console.error(e);
    statusEl.textContent = '❌ Грешка при запис.';
  } finally {
    btn.disabled = false;
  }
});
document.getElementById('btnTestNotifyEmail').addEventListener('click', async function() {
  const btn = this;
  const statusEl = document.getElementById('notifyEmailStatus');
  btn.disabled = true;
  const originalText = btn.textContent;
  btn.textContent = '⏳ Изпращане...';
  statusEl.textContent = '';
  try {
    const r = await authFetch('/api/notify-test', { method: 'POST' });
    const data = await r.json();
    statusEl.textContent = data.ok ? '✅ Тестовият имейл е изпратен.' : '❌ ' + (data.error || 'Неуспешно изпращане.');
  } catch (e) {
    console.error(e);
    statusEl.textContent = '❌ Грешка при връзка със сървъра.';
  } finally {
    btn.disabled = false;
    btn.textContent = originalText;
  }
});

// ---- Съдържание на падащите менюта ----
document.getElementById('btnCleanupOrphans').addEventListener('click', async function() {
  if (currentRole !== 'admin') {
    toast('Само администратор може да почиства индекса.');
    return;
  }
  if (!(await confirmDialog('Почистване на индекса и стари файлове?\n\n• Премахват се ID без валиден запис; липсващите се добавят.\n• Изтриват се стари папки в data/update-backups (остават последните 3).\n• Изтриват се стари бекъпи в data/backups (остават последните 15).'))) {
    return;
  }
  const btn = document.getElementById('btnCleanupOrphans');
  const statusEl = document.getElementById('cleanupOrphansStatus');
  btn.disabled = true;
  const prev = btn.textContent;
  btn.textContent = 'Почистване...';
  if (statusEl) statusEl.textContent = '';
  try {
    const r = await authFetch('/api/admin/cleanup-orphans', { method: 'POST' });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.error || 'Грешка при почистване');
    invalidateRecordsCache();
    const msg = 'Готово: в индекса ' + (data.indexSize || 0) +
      ', премахнати ' + (data.removedCount || 0) +
      ', добавени ' + (data.addedCount || 0) +
      ', изтрити файлове ' + (data.filesRemovedCount || 0) + '.';
    if (statusEl) statusEl.textContent = msg;
    toast('✅ ' + msg);
    if (currentTab === 'technicians') renderTechniciansTable();
    else if (currentTab === 'all') renderAllTable();
  } catch (e) {
    console.error(e);
    if (statusEl) statusEl.textContent = e.message || 'Грешка';
    toast('❌ ' + (e.message || 'Грешка при почистване'));
  } finally {
    btn.disabled = false;
    btn.textContent = prev;
  }
});


document.getElementById('btnCleanupTempFiles') && document.getElementById('btnCleanupTempFiles').addEventListener('click', async function() {
  if (currentRole !== 'admin') {
    toast('Само администратор може да почиства файлове.');
    return;
  }
  if (!(await confirmDialog('Почистване на логове и временни файлове?\n\n• dist_logs_*.txt, стари mail-log / .tmp / .log\n• стари папки update-backups (остават 3)\n• стари DB бекъпи (остават 15)\n\nБазата zayavki.db НЕ се пипа.'))) {
    return;
  }
  const btn = document.getElementById('btnCleanupTempFiles');
  const statusEl = document.getElementById('cleanupOrphansStatus');
  btn.disabled = true;
  const prev = btn.textContent;
  btn.textContent = 'Почистване...';
  try {
    const r = await authFetch('/api/admin/cleanup-temp-files', { method: 'POST' });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.error || 'Грешка при почистване');
    const list = (data.removed || []).slice(0, 12).join(', ');
    const msg = 'Изтрити файлове/папки: ' + (data.removedCount || 0) +
      (list ? (' — ' + list + ((data.removed || []).length > 12 ? '…' : '')) : '') +
      ((data.errors || []).length ? ('; грешки: ' + data.errors.length) : '');
    if (statusEl) statusEl.textContent = msg;
    toast('✅ ' + msg);
  } catch (e) {
    console.error(e);
    if (statusEl) statusEl.textContent = e.message || 'Грешка';
    toast('❌ ' + (e.message || 'Грешка при почистване'));
  } finally {
    btn.disabled = false;
    btn.textContent = prev;
  }
});

document.getElementById('btnSaveDropdownLists').addEventListener('click', async function() {
  const btn = this;
  const statusEl = document.getElementById('dropdownListsStatus');
  const corpus = document.getElementById('corpusListInput').value.split('\n').map(s => s.trim()).filter(Boolean);
  const struktura = document.getElementById('strukturaListInput').value.split('\n').map(s => s.trim()).filter(Boolean);
  const technicians = document.getElementById('technicianListInput').value.split('\n').map(s => s.trim()).filter(Boolean);
  const statusInput = document.getElementById('statusListInput');
  const statuses = statusInput
    ? statusInput.value.split('\n').map(s => s.trim()).filter(Boolean)
    : DEFAULT_STATUS_LIST.slice();
  btn.disabled = true;
  statusEl.textContent = 'Записване...';
  try {
    const r = await authFetch('/api/dropdown-settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ corpus, struktura, technicians, statuses })
    });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    await loadDropdownSettings(); // опреснява падащите менюта навсякъде веднага
    statusEl.textContent = '✅ Запазено.';
  } catch (e) {
    console.error(e);
    statusEl.textContent = '❌ Грешка при запис.';
  } finally {
    btn.disabled = false;
  }
});

/* window exports */
try {
  if (typeof getCustomAddresses==='function') window.getCustomAddresses=getCustomAddresses;
  if (typeof loadVerificationInfo==='function') window.loadVerificationInfo=loadVerificationInfo;
  if (typeof renderCustomServerAddresses==='function') window.renderCustomServerAddresses=renderCustomServerAddresses;
  if (typeof saveCustomAddresses==='function') window.saveCustomAddresses=saveCustomAddresses;
} catch(_){}
