'use strict';

function normalizeEtazhiList(input) {
  if (input == null) return [];
  let arr = input;
  if (typeof input === 'string') {
    arr = input.split(/[\n,;]+/);
  }
  if (!Array.isArray(arr)) return [];
  const out = [];
  for (const raw of arr) {
    const s = String(raw || '').trim();
    if (s && !out.includes(s)) out.push(s);
  }
  return out.slice(0, 50);
}
function normalizeUserProfileFields(user) {
  if (!user || typeof user !== 'object') return user;
  user.strukturaLocked = user.strukturaLocked === true || user.strukturaLocked === 1 || user.strukturaLocked === '1';
  user.korpus = String(user.korpus || '').trim();
  user.etazhi = normalizeEtazhiList(user.etazhi);
  return user;
}
function profileFieldsFromBody(body) {
  const out = {};
  if (!body || typeof body !== 'object') return out;
  if (Object.prototype.hasOwnProperty.call(body, 'strukturaLocked')) {
    out.strukturaLocked = body.strukturaLocked === true || body.strukturaLocked === 1 || body.strukturaLocked === '1' || body.strukturaLocked === 'true';
  }
  if (typeof body.korpus === 'string') out.korpus = body.korpus.trim().slice(0, 80);
  if (Object.prototype.hasOwnProperty.call(body, 'etazhi')) out.etazhi = normalizeEtazhiList(body.etazhi);
  if (typeof body.etazhiText === 'string') out.etazhi = normalizeEtazhiList(body.etazhiText);
  return out;
}
function publicUserProfile(u) {
  return {
    strukturaLocked: !!(u && (u.strukturaLocked === true || u.strukturaLocked === 1 || u.strukturaLocked === '1')),
    korpus: (u && u.korpus) ? String(u.korpus) : '',
    etazhi: normalizeEtazhiList(u && u.etazhi)
  };
}

/** Password security, user lookup/CRUD, and login throttling. */
function createUsersModule({ crypto, kvGet, kvSet, kvDelete }) {
  const { promisify } = require('node:util');
  const pbkdf2Async = promisify(crypto.pbkdf2);
const PBKDF2_ITERATIONS = 210000;
const PBKDF2_KEYLEN = 32;
const PBKDF2_DIGEST = 'sha256';

const OBSERVER_MENU_KEYS = new Set([
  'submit', 'myRequests', 'myMaterials', 'warehouse',
  'warehouseSanitaryRequests', 'warehouseOfficeRequests',
  'sanitaryMaterialsList', 'officeMaterialsList',
  'technicians', 'objects', 'search', 'all', 'materialsReport', 'whMaterialsReport'
]);
const DEFAULT_OBSERVER_MENUS = [
  'submit', 'myRequests',
  'warehouseSanitaryRequests', 'warehouseOfficeRequests',
  'sanitaryMaterialsList', 'officeMaterialsList'
];
const LOGIN_MAX_ATTEMPTS = 5;
const LOGIN_LOCK_MS = 5 * 60 * 1000; // 5 минути
const loginAttempts = new Map(); // "ip::username" -> { count, lockUntil }

function hashPasswordPBKDF2(password, salt) {
  return crypto.pbkdf2Sync(password, salt, PBKDF2_ITERATIONS, PBKDF2_KEYLEN, PBKDF2_DIGEST).toString('hex');
}

function hashPasswordLegacySha256(password, salt) {
  return crypto.createHash('sha256').update(salt + ':' + password, 'utf8').digest('hex');
}

function safeEqualHex(a, b) {
  try {
    const x = Buffer.from(String(a), 'hex');
    const y = Buffer.from(String(b), 'hex');
    return x.length > 0 && x.length === y.length && crypto.timingSafeEqual(x, y);
  } catch (_) { return false; }
}

function verifyUserPassword(user, password) {
  if (user.algo === 'pbkdf2') {
    return safeEqualHex(hashPasswordPBKDF2(password, user.salt), user.passwordHash);
  }
  return safeEqualHex(hashPasswordLegacySha256(password, user.salt), user.passwordHash);
}

function hashPasswordPBKDF2Async(password, salt) {
  return pbkdf2Async(password, salt, PBKDF2_ITERATIONS, PBKDF2_KEYLEN, PBKDF2_DIGEST).then(b => b.toString('hex'));
}

async function verifyUserPasswordAsync(user, password) {
  if (!user) {
    try { await hashPasswordPBKDF2Async(String(password), '00000000000000000000000000000000'); } catch (_) {}
    return false;
  }
  if (user.algo === 'pbkdf2') {
    return safeEqualHex(await hashPasswordPBKDF2Async(String(password), user.salt), user.passwordHash);
  }
  return safeEqualHex(hashPasswordLegacySha256(password, user.salt), user.passwordHash);
}

function getUserIdsServer() {
  try {
    const raw = kvGet('users-index');
    const arr = raw ? JSON.parse(raw) : [];
    return Array.isArray(arr) ? arr : [];
  } catch (e) { return []; }
}

function getUserByIdServer(id) {
  try {
    const raw = kvGet('user:' + id);
    return raw ? JSON.parse(raw) : null;
  } catch (e) { return null; }
}

function getAllUsersServer() {
  return getUserIdsServer().map(getUserByIdServer).filter(Boolean);
}

function getUserByUsernameServer(username) {
  return getAllUsersServer().find(u => u.username === username) || null;
}

function sanitizeObserverMenus(input) {
  if (!Array.isArray(input)) return null;
  const out = [];
  for (const raw of input) {
    const k = String(raw || '').trim();
    if (OBSERVER_MENU_KEYS.has(k) && !out.includes(k)) out.push(k);
  }
  return out;
}

function observerMenusForUser(user) {
  if (!user || user.role !== 'observer') return undefined;
  const sanitized = sanitizeObserverMenus(user.allowedMenus);
  if (sanitized && sanitized.length) return sanitized;
  return DEFAULT_OBSERVER_MENUS.slice();
}


function saveUserServer(user) {
  kvSet('user:' + user.id, JSON.stringify(user));
}

function getClientIp(req) {
  return (req.socket && req.socket.remoteAddress) || 'unknown';
}

function checkLoginLock(ip, username) {
  const key = ip + '::' + username.toLowerCase();
  const entry = loginAttempts.get(key);
  if (entry && entry.lockUntil && Date.now() < entry.lockUntil) {
    const secondsLeft = Math.ceil((entry.lockUntil - Date.now()) / 1000);
    return { locked: true, secondsLeft };
  }
  return { locked: false };
}

function registerLoginFailure(ip, username) {
  const key = ip + '::' + username.toLowerCase();
  const entry = loginAttempts.get(key) || { count: 0, lockUntil: 0 };
  entry.count += 1;
  if (entry.count >= LOGIN_MAX_ATTEMPTS) {
    entry.lockUntil = Date.now() + LOGIN_LOCK_MS;
    entry.count = 0;
  }
  loginAttempts.set(key, entry);
}

function registerLoginSuccess(ip, username) {
  loginAttempts.delete(ip + '::' + username.toLowerCase());
}

function getLoginLockSnapshot() {
  const now = Date.now();
  const locked = [];
  let tracked = 0;
  try {
    for (const [key, entry] of loginAttempts.entries()) {
      tracked += 1;
      if (!entry) continue;
      if (entry.lockUntil && Number(entry.lockUntil) > now) {
        locked.push({
          key: String(key),
          lockUntil: Number(entry.lockUntil),
          secondsLeft: Math.ceil((Number(entry.lockUntil) - now) / 1000),
          count: Number(entry.count) || 0
        });
      }
    }
  } catch (_) {}
  return { locked: locked, tracked: tracked, maxAttempts: LOGIN_MAX_ATTEMPTS, lockMs: LOGIN_LOCK_MS };
}

  return { hashPasswordPBKDF2, hashPasswordLegacySha256, safeEqualHex, verifyUserPassword, hashPasswordPBKDF2Async, verifyUserPasswordAsync, getUserIdsServer, getUserByIdServer, getAllUsersServer, getUserByUsernameServer, sanitizeObserverMenus, observerMenusForUser, saveUserServer, DEFAULT_OBSERVER_MENUS, getClientIp, checkLoginLock, registerLoginFailure, registerLoginSuccess, getLoginLockSnapshot };
}

/** /api/auth/login, logout, me */
function createUsersRoutes(deps) {
  const {
    getSession, getSessionToken, destroySession, clearSessionCookie,
    sendJSON, readJsonFromRequest, getClientIp, checkLoginLock,
    registerLoginFailure, registerLoginSuccess, getUserByUsernameServer,
    verifyUserPasswordAsync, hashPasswordPBKDF2Async, saveUserServer,
    createSession, sessions, setSessionCookie, writeSystemLog,
    observerMenusForUser, crypto,
    requireAdmin, getAllUsersServer, getUserByIdServer, getUserIdsServer,
    hashPasswordPBKDF2, sanitizeObserverMenus, DEFAULT_OBSERVER_MENUS, kvSet, kvDelete
  } = deps;
  return async function handleAuthRoute(req, res, parsed, pathname) {
    if (pathname === '/api/auth/logout' && req.method === 'POST') {
      const token = getSessionToken(req);
      let uname = '';
      let role = '';
      if (token) {
        const sess = getSession(req, { slide: false }) || sessions.get(token);
        if (sess) { uname = sess.username || ''; role = sess.role || ''; }
        destroySession(token);
      }
      writeSystemLog('info', 'auth', 'Потребителят излезе от системата', {
        username: uname, ip: getClientIp(req), meta: { role, reason: 'explicit_logout' }
      });
      clearSessionCookie(res, req);
      sendJSON(res, 200, { ok: true });
      return true;
    }

    // ---- API: единичен ключ /api/kv/<key> ----
    if (pathname === '/api/auth/me' && req.method === 'GET') {
      // ?peek=1 — тиха проверка (напр. фонов таймер на клиента), която НЕ
      // трябва да брои като активност и НЕ трябва да удължава сесията.
      const peek = parsed.searchParams.get('peek') === '1';
      if (!peek) req._resForSessionSlide = res;
      const sess = getSession(req, { slide: !peek });
      if (!sess) { sendJSON(res, 401, { error: 'not logged in' }); return true; }
      const user = getUserByUsernameServer(sess.username);
      const prof = publicUserProfile(user);
      sendJSON(res, 200, { username: sess.username, name: sess.name || '', role: sess.role, struktura: (user && user.struktura) || '', strukturaLocked: prof.strukturaLocked, korpus: prof.korpus, etazhi: prof.etazhi, expiresAt: sess.expiresAt, allowedMenus: (user && user.role === 'observer') ? observerMenusForUser(user) : undefined });
      return true;
    }

    if (pathname === '/api/auth/login' && req.method === 'POST') {
      const ip = getClientIp(req);
      const parsedBody = await readJsonFromRequest(req, res);
      if (!parsedBody) return true;
      const username = String(parsedBody.username || '').trim();
      const password = String(parsedBody.password || '');
      if (!username || !password) { sendJSON(res, 400, { error: 'Моля, въведете потребителско име и парола.' }); return true; }

      const lock = checkLoginLock(ip, username);
      if (lock.locked) {
        writeSystemLog('warn', 'auth', 'Блокиран вход (твърде много опити): ' + username, { username, ip });
        sendJSON(res, 429, { error: 'Твърде много грешни опити. Опитайте отново след ' + Math.ceil(lock.secondsLeft / 60) + ' мин.' });
        return true;
      }

      const user = getUserByUsernameServer(username);
      if (!(await verifyUserPasswordAsync(user, password))) {
        registerLoginFailure(ip, username);
        writeSystemLog('warn', 'auth', 'Неуспешен вход: ' + username, { username, ip });
        sendJSON(res, 401, { error: 'Грешно потребителско име или парола.' });
        return true;
      }

      registerLoginSuccess(ip, username);
      writeSystemLog('info', 'auth', 'Успешен вход', { username: user.username, ip, meta: { role: user.role, name: user.name || '' } });

      if (user.algo !== 'pbkdf2') {
        const newSalt = crypto.randomBytes(16).toString('hex');
        user.salt = newSalt;
        user.passwordHash = await hashPasswordPBKDF2Async(password, newSalt);
        user.algo = 'pbkdf2';
        saveUserServer(user);
      }

      const token = createSession(user);
      const session = sessions.get(token);
      setSessionCookie(res, token, session ? session.expiresAt : null);
      // token в JSON е задължителен за Client (iframe/WebView2), където cookie често не се приема
      const prof = publicUserProfile(user);
      sendJSON(res, 200, {
        ok: true,
        token: token,
        username: user.username,
        name: user.name || '',
        role: user.role,
        struktura: user.struktura || '',
        strukturaLocked: prof.strukturaLocked,
        korpus: prof.korpus,
        etazhi: prof.etazhi,
        expiresAt: session ? session.expiresAt : null,
        allowedMenus: user.role === 'observer' ? observerMenusForUser(user) : undefined
      });
      return true;
    }

    if (pathname === '/api/auth/users' && req.method === 'GET') {
      if (!requireAdmin(req, res)) return true;
      try {
        const users = getAllUsersServer().map(u => ({
          id: u.id,
          username: u.username,
          name: u.name || '',
          role: u.role,
          struktura: u.struktura || '',
          strukturaLocked: !!(u.strukturaLocked === true || u.strukturaLocked === 1 || u.strukturaLocked === '1'),
          korpus: u.korpus || '',
          etazhi: normalizeEtazhiList(u.etazhi),
          allowedMenus: u.role === 'observer' ? observerMenusForUser(u) : undefined
        }));
        sendJSON(res, 200, { users });
      } catch (e) {
        console.error('GET /api/auth/users:', e);
        sendJSON(res, 500, { error: 'Грешка при зареждане на потребителите: ' + (e && e.message ? e.message : e) });
      }
      return true;
    }

    // ---- API: създаване на потребител ----
    if (pathname === '/api/auth/users' && req.method === 'POST') {
      if (!requireAdmin(req, res)) return true;
      const parsedBody = await readJsonFromRequest(req, res);
      if (!parsedBody) return true;
      const username = String(parsedBody.username || '').trim();
      const name = String(parsedBody.name || '').trim();
      const struktura = String(parsedBody.struktura || '').trim();
      const role = String(parsedBody.role || '');
      const password = String(parsedBody.password || '');
      
      console.log('📝 Създаване на потребител:', { username, name, struktura, role });
      
      if (!username) { 
        sendJSON(res, 400, { error: 'Въведете потребителско име.' }); 
        return true; 
      }
      
      const validRoles = ['submitter', 'technician', 'admin', 'warehouse', 'observer'];
      if (!validRoles.includes(role)) { 
        console.log('❌ Невалидна роля:', role, 'Допустими:', validRoles);
        sendJSON(res, 400, { error: 'Невалидна роля. Допустими: submitter, technician, admin, warehouse, observer' }); 
        return true; 
      }
      
      if (!password || password.length < 8) { 
        sendJSON(res, 400, { error: 'Паролата трябва да е поне 8 символа.' }); 
        return true; 
      }
      
      if (getUserByUsernameServer(username)) { 
        sendJSON(res, 409, { error: 'Вече има потребител с това име.' }); 
        return true; 
      }

      const salt = crypto.randomBytes(16).toString('hex');
      const id = 'u' + Date.now() + Math.floor(Math.random() * 1000);
      const profIn = profileFieldsFromBody(parsedBody);
      const user = { 
        id, 
        username, 
        name, 
        struktura, 
        role, 
        salt, 
        passwordHash: hashPasswordPBKDF2(password, salt), 
        algo: 'pbkdf2',
        strukturaLocked: Object.prototype.hasOwnProperty.call(profIn, 'strukturaLocked') ? profIn.strukturaLocked : true,
        korpus: profIn.korpus || '',
        etazhi: profIn.etazhi || []
      };
      if (role === 'observer') {
        const menus = sanitizeObserverMenus(parsedBody.allowedMenus);
        user.allowedMenus = (menus && menus.length) ? menus : DEFAULT_OBSERVER_MENUS.slice();
      }
      
      saveUserServer(user);
      const ids = getUserIdsServer();
      ids.push(id);
      kvSet('users-index', JSON.stringify(ids));
      
      console.log('✅ Потребител създаден успешно:', { id, username, role });
      sendJSON(res, 200, { ok: true, id, username, name, struktura, role });
      return true;
    }

    // ---- API: смяна на име ----
    if (pathname.startsWith('/api/auth/users/') && pathname.endsWith('/name') && req.method === 'PUT') {
      if (!requireAdmin(req, res)) return true;
      const id = decodeURIComponent(pathname.slice('/api/auth/users/'.length, -'/name'.length));
      const user = getUserByIdServer(id);
      if (!user) { sendJSON(res, 404, { error: 'Няма такъв потребител.' }); return true; }
      const parsedBody = await readJsonFromRequest(req, res);
      if (!parsedBody) return true;
      user.name = String(parsedBody.name || '').trim();
      saveUserServer(user);
      sendJSON(res, 200, { ok: true, name: user.name });
      return true;
    }

    // ---- API: смяна на парола ----
    if (pathname.startsWith('/api/auth/users/') && pathname.endsWith('/password') && req.method === 'PUT') {
      if (!requireAdmin(req, res)) return true;
      const id = decodeURIComponent(pathname.slice('/api/auth/users/'.length, -'/password'.length));
      const user = getUserByIdServer(id);
      if (!user) { sendJSON(res, 404, { error: 'Няма такъв потребител.' }); return true; }
      const parsedBody = await readJsonFromRequest(req, res);
      if (!parsedBody) return true;
      const newPassword = String(parsedBody.password || '');
      if (!newPassword || newPassword.length < 8) { sendJSON(res, 400, { error: 'Паролата трябва да е поне 8 символа.' }); return true; }
      const salt = crypto.randomBytes(16).toString('hex');
      user.salt = salt;
      user.passwordHash = hashPasswordPBKDF2(newPassword, salt);
      user.algo = 'pbkdf2';
      saveUserServer(user);
      sendJSON(res, 200, { ok: true });
      return true;
    }

    // ---- API: смяна на структура ----
    if (pathname.startsWith('/api/auth/users/') && pathname.endsWith('/struktura') && req.method === 'PUT') {
      if (!requireAdmin(req, res)) return true;
      const id = decodeURIComponent(pathname.slice('/api/auth/users/'.length, -'/struktura'.length));
      const user = getUserByIdServer(id);
      if (!user) { sendJSON(res, 404, { error: 'Няма такъв потребител.' }); return true; }
      const parsedBody = await readJsonFromRequest(req, res);
      if (!parsedBody) return true;
      user.struktura = String(parsedBody.struktura || '').trim();
      saveUserServer(user);
      sendJSON(res, 200, { ok: true, struktura: user.struktura });
      return true;
    }

    // ---- API: комбинирана редакция на потребител (име/структура/роля/парола наведнъж) ----
    if (pathname.startsWith('/api/auth/users/') && pathname.split('/').length === 5 && req.method === 'PUT') {
      if (!requireAdmin(req, res)) return true;
      const id = decodeURIComponent(pathname.slice('/api/auth/users/'.length));
      const user = getUserByIdServer(id);
      if (!user) { sendJSON(res, 404, { error: 'Няма такъв потребител.' }); return true; }
      const parsedBody = await readJsonFromRequest(req, res);
      if (!parsedBody) return true;

      if (typeof parsedBody.name === 'string') user.name = parsedBody.name.trim();
      if (typeof parsedBody.struktura === 'string') user.struktura = parsedBody.struktura.trim();
      const profIn = profileFieldsFromBody(parsedBody);
      if (Object.prototype.hasOwnProperty.call(profIn, 'strukturaLocked')) user.strukturaLocked = profIn.strukturaLocked;
      if (Object.prototype.hasOwnProperty.call(profIn, 'korpus')) user.korpus = profIn.korpus;
      if (Object.prototype.hasOwnProperty.call(profIn, 'etazhi')) user.etazhi = profIn.etazhi;

      if (typeof parsedBody.role === 'string' && parsedBody.role !== user.role) {
        if (!['submitter', 'technician', 'admin', 'warehouse', 'observer'].includes(parsedBody.role)) {
          sendJSON(res, 400, { error: 'Невалидна роля.' });
          return true;
        }
        if (user.role === 'admin' && parsedBody.role !== 'admin') {
          const adminCount = getAllUsersServer().filter(u => u.role === 'admin').length;
          if (adminCount <= 1) {
            sendJSON(res, 400, { error: 'Не може да премахнете ролята на последния администратор.' });
            return true;
          }
        }
        user.role = parsedBody.role;
      }

      if (parsedBody.password) {
        const pw = String(parsedBody.password);
        if (pw.length < 8) { sendJSON(res, 400, { error: 'Паролата трябва да е поне 8 символа.' }); return true; }
        const salt = crypto.randomBytes(16).toString('hex');
        user.salt = salt;
        user.passwordHash = hashPasswordPBKDF2(pw, salt);
        user.algo = 'pbkdf2';
      }

      if (user.role === 'observer') {
        if (Object.prototype.hasOwnProperty.call(parsedBody, 'allowedMenus')) {
          const menus = sanitizeObserverMenus(parsedBody.allowedMenus);
          user.allowedMenus = (menus && menus.length) ? menus : DEFAULT_OBSERVER_MENUS.slice();
        } else if (!Array.isArray(user.allowedMenus) || !user.allowedMenus.length) {
          user.allowedMenus = DEFAULT_OBSERVER_MENUS.slice();
        }
      } else if (Object.prototype.hasOwnProperty.call(user, 'allowedMenus')) {
        delete user.allowedMenus;
      }

      saveUserServer(user);
      sendJSON(res, 200, {
        ok: true,
        name: user.name,
        struktura: user.struktura,
        strukturaLocked: !!(user.strukturaLocked === true || user.strukturaLocked === 1),
        korpus: user.korpus || '',
        etazhi: normalizeEtazhiList(user.etazhi),
        role: user.role,
        allowedMenus: user.role === 'observer' ? observerMenusForUser(user) : undefined
      });
      return true;
    }

    // ---- API: изтриване на потребител ----
    if (pathname.startsWith('/api/auth/users/') && req.method === 'DELETE') {
      if (!requireAdmin(req, res)) return true;
      try {
        const id = decodeURIComponent(pathname.slice('/api/auth/users/'.length));
        const user = getUserByIdServer(id);
        if (!user) { sendJSON(res, 404, { error: 'Няма такъв потребител.' }); return true; }
        const allUsers = getAllUsersServer();
        const adminCount = allUsers.filter(u => u.role === 'admin').length;
        if (user.role === 'admin' && adminCount <= 1) {
          sendJSON(res, 400, { error: 'Не може да изтриете последния администратор.' });
          return true;
        }
        kvDelete('user:' + id);
        const ids = getUserIdsServer().filter(x => String(x) !== String(id));
        kvSet('users-index', JSON.stringify(ids));
        sendJSON(res, 200, { ok: true });
      } catch (e) {
        console.error('DELETE /api/auth/users:', e);
        sendJSON(res, 500, { error: 'Грешка при изтриване: ' + (e && e.message ? e.message : e) });
      }
      return true;
    }


    return false;
  };
}


module.exports = { createUsersModule, createUsersRoutes, createAuthRoutes: createUsersRoutes };
