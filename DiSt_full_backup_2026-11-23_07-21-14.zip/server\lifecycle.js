'use strict';

function createLifecycle(deps) {
  const { fs, path, os, ROOT_DIR, DATA_DIR, DB_PATH, PID_PATH, PORT, LISTEN_HOST, db, kvSet, writeSystemLog, createDownloadableBackup, getServer, formatCrashLineForLog, formatHeartbeatLine } = deps;
function getLanIPs() {
  const nets = os.networkInterfaces();
  const ips = [];
  for (const name of Object.keys(nets)) {
    for (const net of nets[name] || []) {
      if (net.family === 'IPv4' && !net.internal) ips.push(net.address);
    }
  }
  return ips;
}

// ---------------------- Автоматичен бекъп на базата данни ----------------------
const BACKUP_DIR = path.join(DATA_DIR, 'backups');
const DAY_MS = 24 * 60 * 60 * 1000;
const BACKUP_KEEP_COUNT = 30; // 30 пълни дневни Recovery backup-а
let backupTimer = null;
let backupRunning = false;
let backupSchedulerStopped = false;
let lastBackupAttemptAt = 0;
let heartbeatTimer = null;

function clearBackupTimer() {
  if (backupTimer) clearTimeout(backupTimer);
  backupTimer = null;
}

function stopScheduledTasks() {
  backupSchedulerStopped = true;
  clearBackupTimer();
  if (heartbeatTimer) clearInterval(heartbeatTimer);
  heartbeatTimer = null;
}

function backupDatabase() {
  if (backupSchedulerStopped || backupRunning) return false;
  backupRunning = true;
  lastBackupAttemptAt = Date.now();
  try {
    if (!fs.existsSync(DB_PATH)) return false;
    if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });
    const info = createDownloadableBackup({ source: 'automatic' });
    writeSystemLog('info', 'backup', 'Автоматичен пълен backup: ' + info.fileName, {
      meta: { verified: true, sha256: info.sha256, size: info.size }
    });
    console.log('  🗄 Автоматичен пълен Recovery backup: ' + info.fileName + ' [VERIFIED]');

    const files = fs.readdirSync(BACKUP_DIR)
      .filter(f => /^DiSt_full_backup_.*\.zip$/i.test(f))
      .sort();
    while (files.length > BACKUP_KEEP_COUNT) {
      const oldest = files.shift();
      for (const suffix of ['', '.sha256']) {
        try { fs.unlinkSync(path.join(BACKUP_DIR, oldest + suffix)); } catch (_) {}
      }
      const stamp = oldest.replace(/^DiSt_full_backup_/i, '').replace(/\.zip$/i, '');
      for (const n of ['backup-manifest_' + stamp + '.json']) {
        try { fs.unlinkSync(path.join(BACKUP_DIR, n)); } catch (_) {}
      }
    }
    return true;
  } catch (e) {
    console.error('⚠ Неуспешен автоматичен пълен backup:', e.message);
    try { writeSystemLog('error', 'backup', 'Неуспешен автоматичен backup: ' + (e.message || e)); } catch (_) {}
    return false;
  } finally {
    backupRunning = false;
  }
}

function scheduleDailyBackup() {
  if (backupSchedulerStopped) return;
  clearBackupTimer();
  const nowMs = Date.now();
  let latestVerifiedAt = 0;
  try {
    if (fs.existsSync(BACKUP_DIR)) {
      for (const name of fs.readdirSync(BACKUP_DIR)) {
        if (!/^DiSt_full_backup_.*\.zip$/i.test(name)) continue;
        const zipPath = path.join(BACKUP_DIR, name);
        if (!fs.existsSync(zipPath + '.sha256')) continue;
        const mtime = fs.statSync(zipPath).mtimeMs;
        if (mtime > latestVerifiedAt) latestVerifiedAt = mtime;
      }
    }
  } catch (e) {
    try { writeSystemLog('warn', 'backup', 'Неуспешно прочитване на наличните бекъпи: ' + (e.message || e)); } catch (_) {}
  }

  // One startup catch-up is allowed when no verified backup exists within the last day.
  // A failed attempt is not retried in a tight loop; it is retried at the next daily slot.
  const isStale = !latestVerifiedAt || nowMs - latestVerifiedAt >= DAY_MS;
  const hasAttemptedToday = lastBackupAttemptAt && nowMs - lastBackupAttemptAt < DAY_MS;
  let nextAt;
  if (isStale && !hasAttemptedToday) {
    nextAt = nowMs + 15000;
    console.log('  🗄 Няма свеж VERIFIED backup — ще бъде създаден автоматично след старта.');
  } else {
    const nextDaily = new Date(nowMs);
    nextDaily.setHours(2, 0, 0, 0);
    if (nextDaily.getTime() <= nowMs) nextDaily.setDate(nextDaily.getDate() + 1);
    // Never schedule a second backup less than 24 hours after the last backup attempt.
    nextAt = Math.max(nextDaily.getTime(), (lastBackupAttemptAt || latestVerifiedAt || nowMs) + DAY_MS);
  }

  const delay = Math.max(1000, nextAt - nowMs);
  backupTimer = setTimeout(() => {
    backupTimer = null;
    if (backupSchedulerStopped) return;
    backupDatabase();
    scheduleDailyBackup();
  }, delay);
  if (backupTimer && typeof backupTimer.unref === 'function') backupTimer.unref();
  console.log('  🕑 Следващ планиран Recovery backup: ' + new Date(nextAt).toLocaleString('bg-BG'));
}

function startHttpServer(retriesLeft) {
  const server = getServer();
  retriesLeft = retriesLeft == null ? 8 : retriesLeft;
  server.once('error', (err) => {
    if (err && err.code === 'EADDRINUSE' && retriesLeft > 0) {
      console.error('⚠️  Порт ' + PORT + ' е зает — нов опит след 1.5 сек (остават ' + retriesLeft + ')...');
      try {
        writeSystemLog('warn', 'system', 'EADDRINUSE на порт ' + PORT + ', повторен опит...');
      } catch (_) {}
      setTimeout(() => startHttpServer(retriesLeft - 1), 1500);
      return;
    }
    console.error('❌ Грешка при слушане на порт ' + PORT + ':', err && err.message ? err.message : err);
    try {
      writeSystemLog('error', 'system', 'uncaught listen: ' + (err && err.stack ? err.stack : String(err)));
    } catch (_) {}
    process.exit(1);
  });
  server.listen(PORT, LISTEN_HOST, () => {

  try { reportPreviousSessionEnd(); } catch (_) {}
  writeSystemLog('info', 'system', 'Сървърът е стартиран на ' + LISTEN_HOST + ':' + PORT);
  try { kvSet('settings:lastSuccessfulStart', String(Date.now())); kvSet('settings:lastSuccessfulStartIso', new Date().toISOString()); } catch (_) {}
  try { fs.writeFileSync(PID_PATH, String(process.pid)); } catch (e) {}
  const line = '═'.repeat(56);
  console.log(line);
  console.log('  Заявки за ремонт — сървър стартиран успешно');
  console.log(line);
  console.log('');
  console.log('  Слуша на: ' + LISTEN_HOST + ':' + PORT);
  console.log('  На ТОЗИ компютър отворете:');
  console.log('     http://localhost:' + PORT);
  console.log('');
  if (LISTEN_HOST === '127.0.0.1' || LISTEN_HOST === 'localhost') {
    console.log('  ℹ LISTEN_HOST=127.0.0.1 — достъп само локално / през обратен прокси (HTTPS).');
    console.log('    Клиентите в мрежата трябва да ползват адреса на проксито, не :' + PORT + ' директно.');
  } else {
    const ips = getLanIPs();
    if (ips.length) {
      console.log('  От ВСИЧКИ ДРУГИ компютри в същата мрежа отворете:');
      ips.forEach(ip => console.log('     http://' + ip + ':' + PORT));
    } else {
      console.log('  ⚠ Не е открита мрежова връзка. Проверете дали компютърът е');
      console.log('    свързан с мрежата (кабел или Wi-Fi), за да могат другите');
      console.log('    компютри да достигат до сървъра.');
    }
  }
  console.log('');
  console.log('  Данните се пазят във файла:');
  console.log('     ' + DB_PATH);
  console.log('  Автоматичен бекъп: на всеки 24 часа → ' + BACKUP_DIR);
  console.log('');
  console.log('  Оставете този прозорец отворен, докато системата се използва.');
  console.log('  За спиране: затворете прозореца или натиснете Ctrl+C.');
  console.log(line);

  scheduleDailyBackup();
  });
}const CRASH_LAST_PATH = path.join(DATA_DIR, 'crash-last.txt');
const CRASH_LOG_PATH = path.join(DATA_DIR, 'crash-log.txt');
const GRACEFUL_STOP_PATH = path.join(DATA_DIR, 'graceful-stop.flag');
const HEARTBEAT_PATH = path.join(DATA_DIR, 'server-heartbeat.txt');

function writeCrashArtifact(kind, detail) {
  const msg = String(detail == null ? '' : detail).slice(0, 8000);
  const line = new Date().toISOString() + ' [' + kind + '] pid=' + process.pid + ' ' + msg.replace(/[\r\n]+/g, ' | ') + '\n';
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.appendFileSync(CRASH_LOG_PATH, line, 'utf8');
    fs.writeFileSync(CRASH_LAST_PATH, line, 'utf8');
  } catch (_) {}
  try { writeSystemLog('error', 'crash', kind + ': ' + msg.slice(0, 1800)); } catch (_) {}
  try { console.error(kind, msg.slice(0, 500)); } catch (_) {}
}

function markGracefulStop(reason) {
  try {
    fs.writeFileSync(GRACEFUL_STOP_PATH, new Date().toISOString() + ' ' + String(reason || '') + '\n', 'utf8');
  } catch (_) {}
}

function writeHeartbeat() {
  try {
    fs.writeFileSync(HEARTBEAT_PATH, new Date().toISOString() + ' pid=' + process.pid + '\n', 'utf8');
  } catch (_) {}
}

function reportPreviousSessionEnd() {
  try {
    if (fs.existsSync(CRASH_LAST_PATH)) {
      const prev = fs.readFileSync(CRASH_LAST_PATH, 'utf8').trim();
      if (prev) {
        writeSystemLog('error', 'crash', 'Предишна сесия — записан срив: ' + formatCrashLineForLog(prev).slice(0, 1500));
        console.error('⚠ Предишен срив:', prev.slice(0, 300));
      }
      try { fs.unlinkSync(CRASH_LAST_PATH); } catch (_) {}
    }
  } catch (_) {}

  try {
    const hadPid = fs.existsSync(PID_PATH);
    const graceful = fs.existsSync(GRACEFUL_STOP_PATH);
    if (hadPid && !graceful) {
      let lastHb = '';
      try {
        if (fs.existsSync(HEARTBEAT_PATH)) lastHb = fs.readFileSync(HEARTBEAT_PATH, 'utf8').trim();
      } catch (_) {}
      const msg = 'Предишната сесия е спряла без нормален shutdown (възможен срив, Task Manager, загуба на ток или taskkill).' +
        (lastHb ? ' Последен heartbeat: ' + formatHeartbeatLine(lastHb) : '');
      writeSystemLog('error', 'crash', msg);
      console.error('⚠', msg);
      try {
        const payload = JSON.stringify({
          at: Date.now(),
          atIso: new Date().toISOString(),
          heartbeat: lastHb || '',
          message: msg
        });
        kvSet('settings:lastUncleanShutdown', payload);
        kvSet('settings:lastUncleanShutdownAt', String(Date.now()));
      } catch (_) {}
      try {
        fs.appendFileSync(CRASH_LOG_PATH, new Date().toISOString() + ' [unclean_shutdown] ' + msg + '\n', 'utf8');
      } catch (_) {}
    }
  } catch (_) {}

  try { if (fs.existsSync(GRACEFUL_STOP_PATH)) fs.unlinkSync(GRACEFUL_STOP_PATH); } catch (_) {}
}


function cleanupAndExit(code) {
  code = code == null ? 0 : code;
  console.log('\nСпиране на сървъра...');
  stopScheduledTasks();
  markGracefulStop('cleanupAndExit code=' + code);
  try { if (fs.existsSync(PID_PATH)) fs.unlinkSync(PID_PATH); } catch (e) {}
  try { db.close(); } catch (e) {}
  process.exit(code);
}

function installProcessHandlers() {
process.on('SIGINT', () => {
  try { writeSystemLog('info', 'system', 'Сървърът се спира (SIGINT / Ctrl+C)'); } catch (_) {}
  markGracefulStop('SIGINT');
  cleanupAndExit(0);
});
process.on('SIGTERM', () => {
  try { writeSystemLog('info', 'system', 'Сървърът се спира (SIGTERM)'); } catch (_) {}
  markGracefulStop('SIGTERM');
  cleanupAndExit(0);
});
process.on('SIGHUP', () => {
  try { writeSystemLog('warn', 'system', 'Получен SIGHUP'); } catch (_) {}
});
process.on('uncaughtException', (err) => {
  const detail = err && err.stack ? err.stack : String(err);
  writeCrashArtifact('uncaughtException', detail);
  stopScheduledTasks();
  try {
    setTimeout(() => {
      try { if (fs.existsSync(PID_PATH)) fs.unlinkSync(PID_PATH); } catch (_) {}
      process.exit(1);
    }, 800);
  } catch (_) {
    process.exit(1);
  }
});
process.on('unhandledRejection', (reason) => {
  const detail = reason && reason.stack ? reason.stack : String(reason);
  writeCrashArtifact('unhandledRejection', detail);
});
process.on('exit', (code) => {
  try {
    fs.appendFileSync(CRASH_LOG_PATH, new Date().toISOString() + ' [process.exit] code=' + code + ' pid=' + process.pid + '\n', 'utf8');
  } catch (_) {}
});

try {
  writeHeartbeat();
  heartbeatTimer = setInterval(writeHeartbeat, 2 * 60 * 1000);
  if (heartbeatTimer && typeof heartbeatTimer.unref === 'function') heartbeatTimer.unref();
} catch (_) {}
}
  return { getLanIPs, BACKUP_DIR, backupDatabase, scheduleDailyBackup, startHttpServer, writeCrashArtifact, markGracefulStop, writeHeartbeat, reportPreviousSessionEnd, cleanupAndExit, installProcessHandlers };
}

module.exports = { createLifecycle };

