'use strict';

/** System log module — writes to system_log table, rotates to 5000 rows. */
function createSystemLogModule({ db }) {

  function writeSystemLog(level, category, message, opts) {
    opts = opts || {};
    try {
      const ts = Date.now();
      const username = String(opts.username || '');
      const ip = String(opts.ip || '');
      let meta = '';
      if (opts.meta != null) {
        try { meta = typeof opts.meta === 'string' ? opts.meta : JSON.stringify(opts.meta); } catch (e) { meta = String(opts.meta); }
      }
      db.prepare(
        'INSERT INTO system_log (ts, level, category, message, username, ip, meta) VALUES (?, ?, ?, ?, ?, ?, ?)'
      ).run(ts, String(level || 'info'), String(category || 'system'), String(message || ''), username, ip, meta);
      try {
        const cnt = db.prepare('SELECT COUNT(*) AS c FROM system_log').get();
        // system_log: пази последните 5000 записа (ротация)
        if (cnt && cnt.c > 5000) {
          db.prepare('DELETE FROM system_log WHERE id IN (SELECT id FROM system_log ORDER BY ts ASC LIMIT ?)').run(cnt.c - 5000);
        }
      } catch (e) {}
    } catch (e) {
      try { console.error('system_log write failed:', e.message); } catch (_) {}
    }
  }

  function getLastCrashLog(limit) {
    limit = limit || 5;
    try {
      return db.prepare(
        "SELECT ts, level, category, message, username FROM system_log WHERE level = 'error' OR category = 'crash' ORDER BY ts DESC LIMIT ?"
      ).all(limit);
    } catch (_) {
      return [];
    }
  }

  return { writeSystemLog, getLastCrashLog };
}

module.exports = { createSystemLogModule };
