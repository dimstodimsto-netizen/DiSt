const reportsDataState = AppState.bind(['allTableState','__kvCache','__kvCacheLoaded']);
async function getAllRecords() {
  try {
    const all = [];
    let page = 1;
    let pages = 1;
    do {
      const res = await authFetch('/api/records?page=' + page + '&pageSize=500');
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();
      const batch = Array.isArray(data.records) ? data.records : [];
      batch.forEach(rec => {
        if (rec && rec.id != null) {
          all.push(rec);
          reportsDataState.__kvCache.set('record:' + rec.id, JSON.stringify(rec));
        }
      });
      pages = Math.max(1, Number(data.pages) || 1);
      page++;
    } while (page <= pages && page <= 20);
    reportsDataState.__kvCacheLoaded = true;
    return all;
  } catch (e) {
    console.warn('getAllRecords via /api/records failed, fallback', e);
    const idx = await getIndex();
    const results = await Promise.all(idx.map(id => getRecord(id)));
    return results.filter(Boolean);
  }
}

function getRecordSearchText(rec) {
  return [
    rec.id, rec.datetime, rec.korpus, rec.etaz, rec.struktura,
    rec.lokacia, rec.vid, rec.zabelezka, rec.zayavitel,
    rec.status, rec.dataIzp, rec.izpalnitel, rec.materiali, rec.komentar
  ].map(v => String(v == null ? '' : v)).join(' ').toLowerCase();
}

function getColumnValue(rec, key) {
  const map = {
    id: rec.id,
    datetime: rec.datetime,
    korpus: rec.korpus,
    etaz: rec.etaz,
    struktura: rec.struktura,
    lokacia: rec.lokacia,
    vid: rec.vid,
    zabelezka: rec.zabelezka,
    zayavitel: rec.zayavitel,
    status: rec.status,
    dataIzp: rec.dataIzp,
    izpalnitel: rec.izpalnitel,
    materiali: rec.materiali,
    komentar: rec.komentar
  };
  return map[key] == null ? '' : map[key];
}

function getSelectedColumns() {
  const raw = localStorage.getItem(TABLE_COLUMNS_KEY);
  if (!raw) return [...DEFAULT_TABLE_COLUMNS];
  try {
    const parsed = JSON.parse(raw);
    const valid = parsed.filter(k => ALL_TABLE_COLUMNS.some(c => c.key === k));
    return valid.length ? valid : [...DEFAULT_TABLE_COLUMNS];
  } catch {
    return [...DEFAULT_TABLE_COLUMNS];
  }
}

function saveSelectedColumns(columns) {
  reportsDataState.allTableState.columns = [...columns];
  try { localStorage.setItem(TABLE_COLUMNS_KEY, JSON.stringify(columns)); } catch {}
}

function renderColumnsPanel() {
  const wrap = $('columnsCheckboxes');
  if (!wrap) return;

  const selected = new Set(reportsDataState.allTableState.columns);
  wrap.innerHTML = ALL_TABLE_COLUMNS.map(col => `
    <label style="display:flex;align-items:center;gap:6px;font-size:12px;cursor:pointer;">
      <input type="checkbox" data-column-key="${escapeHtml(col.key)}" ${selected.has(col.key) ? 'checked' : ''} style="width:auto;">
      ${escapeHtml(col.label)}
    </label>
  `).join('');

  // Обновяваме брояча на бутона: „⚙ Колони (7/14)"
  const btn = $('btnToggleColumnsPanel');
  if (btn) {
    btn.textContent = '⚙ Колони (' + selected.size + '/' + ALL_TABLE_COLUMNS.length + ')';
  }
}

function applyAllFilters(records) {
  const showAllMonths = $('allShowAllMonths').checked;
  const monthFilter = $('allMonthFilter').value;
  const statusFilter = $('allStatusFilter').value;
  const strukturaFilter = ($('allStrukturaFilter') ? $('allStrukturaFilter').value : '').trim();
  const textFilter = $('allFilter').value.trim().toLowerCase();

  const filtered = records.filter(rec => {
    if (!showAllMonths && monthFilter) {
      const d = parseStamp(rec.datetime);
      if (!d) return false;
      const ym = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
      if (ym !== monthFilter) return false;
    }

    if (statusFilter && rec.status !== statusFilter) return false;
    if (strukturaFilter && String(rec.struktura || '').trim() !== strukturaFilter) return false;
    if (textFilter && !getRecordSearchText(rec).includes(textFilter)) return false;

    return true;
  });
  return sortAllTableRecords(filtered);
}

function sortAllTableRecords(records) {
  const key = reportsDataState.allTableState.sortKey || 'datetime';
  const dir = reportsDataState.allTableState.sortDir === 'asc' ? 1 : -1;
  const list = (records || []).slice();
  list.sort((a, b) => {
    if (key === 'datetime' || key === 'dataIzpalnenie') {
      const da = parseStamp(a[key] || (key === 'datetime' ? a.datetime : '')) || new Date(0);
      const db = parseStamp(b[key] || (key === 'datetime' ? b.datetime : '')) || new Date(0);
      return (da - db) * dir;
    }
    if (key === 'id') {
      const na = Number(a.id) || 0;
      const nb = Number(b.id) || 0;
      if (na !== nb) return (na - nb) * dir;
    }
    const va = String(getColumnValue(a, key) == null ? '' : getColumnValue(a, key)).toLowerCase();
    const vb = String(getColumnValue(b, key) == null ? '' : getColumnValue(b, key)).toLowerCase();
    if (va < vb) return -1 * dir;
    if (va > vb) return 1 * dir;
    const da = parseStamp(a.datetime) || new Date(0);
    const db = parseStamp(b.datetime) || new Date(0);
    return db - da;
  });
  return list;
}

function onAllTableSortClick(key) {
  if (!key) return;
  if (reportsDataState.allTableState.sortKey === key) {
    reportsDataState.allTableState.sortDir = reportsDataState.allTableState.sortDir === 'asc' ? 'desc' : 'asc';
  } else {
    reportsDataState.allTableState.sortKey = key;
    reportsDataState.allTableState.sortDir = (key === 'datetime' || key === 'id') ? 'desc' : 'asc';
  }
  try { saveAllTableSort(); } catch (_) {}
  reportsDataState.allTableState.filtered = applyAllFilters(reportsDataState.allTableState.records || []);
  reportsDataState.allTableState.page = 1;
  renderAllTableRows();
}

function renderAllTableRows() {
  const head = $('allTableHead');
  const body = $('allTableBody');
  const pageInfo = $('allPageInfo');
  const count = $('allCount');

  if (!head || !body) return;

  const columns = ALL_TABLE_COLUMNS.filter(c => reportsDataState.allTableState.columns.includes(c.key));
  head.innerHTML = columns.map(c => {
    const isSorted = reportsDataState.allTableState.sortKey === c.key;
    const arrow = isSorted ? (reportsDataState.allTableState.sortDir === 'asc' ? ' ↑' : ' ↓') : '';
    return `<th data-sort-key="${escapeHtml(c.key)}" class="all-th-sortable" style="padding:6px 8px;white-space:nowrap;cursor:pointer;user-select:none;" title="Сортирай по ${escapeHtml(c.label)}">${escapeHtml(c.label)}${arrow}</th>`;
  }).join('') + (currentRole === 'admin'
    ? '<th style="padding:6px 8px;white-space:nowrap;">Действия</th>'
    : '');
  head.querySelectorAll('th.all-th-sortable').forEach(th => {
    th.addEventListener('click', (e) => {
      e.stopPropagation();
      onAllTableSortClick(th.getAttribute('data-sort-key'));
    });
  });

  const pageSize = reportsDataState.allTableState.pageSize;
  const totalPages = Math.max(1, Math.ceil(reportsDataState.allTableState.filtered.length / pageSize));
  reportsDataState.allTableState.page = Math.min(Math.max(1, reportsDataState.allTableState.page), totalPages);

  const start = (reportsDataState.allTableState.page - 1) * pageSize;
  const pageRows = reportsDataState.allTableState.filtered.slice(start, start + pageSize);

  body.innerHTML = '';

  const showAdminActions = currentRole === 'admin';
  const colCount = columns.length + (showAdminActions ? 1 : 0);

  if (!pageRows.length) {
    body.innerHTML = `<tr><td colspan="${Math.max(colCount, 1)}" class="hint">Няма заявки по зададените филтри.</td></tr>`;
  } else {
    const fragment = document.createDocumentFragment();

    pageRows.forEach(rec => {
      const tr = document.createElement('tr');
      if (isUrgentActive(rec)) tr.className = 'urgent-row';
      tr.style.cursor = 'pointer';

      columns.forEach(col => {
        const td = document.createElement('td');
        td.style.cssText = 'padding:6px 8px;vertical-align:top;word-break:break-word;';
        let value = getColumnValue(rec, col.key);

        if (col.key === 'id' && isUrgentActive(rec)) {
          td.innerHTML = `<span class="urgent-badge">🚨</span>${escapeHtml(value)}`;
        } else if (col.key === 'status') {
          td.innerHTML = `<span class="status-badge ${statusClass(value)}">${escapeHtml(value || '—')}</span>`;
        } else {
          td.textContent = String(value == null ? '' : value);
        }

        tr.appendChild(td);
      });

      if (showAdminActions) {
        const tdAct = document.createElement('td');
        tdAct.style.cssText = 'padding:6px 8px;vertical-align:top;white-space:nowrap;';
        const hideBtn = document.createElement('button');
        hideBtn.type = 'button';
        hideBtn.className = 'wh-action-btn';
        if (rec.hiddenFromTech) {
          hideBtn.title = 'Върни в панел За техници';
          hideBtn.style.color = '#1e7e34';
          hideBtn.textContent = '📤';
          hideBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            restoreRepairToTechPanel(String(rec.id)).then(function () {
              try { renderAllTableRows(); } catch (_) {}
            });
          });
        } else {
          hideBtn.title = 'Снеми от панел За техници (без да се маркира Изпълнена)';
          hideBtn.style.color = '#8e44ad';
          hideBtn.textContent = '📥';
          hideBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            hideRepairFromTechPanel(String(rec.id)).then(function () {
              try { renderAllTableRows(); } catch (_) {}
            });
          });
        }
        tdAct.appendChild(hideBtn);
        const delBtn = document.createElement('button');
        delBtn.type = 'button';
        delBtn.className = 'wh-action-btn';
        delBtn.title = 'Изтрий заявката';
        delBtn.style.color = '#c0392b';
        delBtn.textContent = '✕';
        delBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          deleteRepairRequest(rec.id);
        });
        tdAct.appendChild(delBtn);
        tr.appendChild(tdAct);
      }

      tr.addEventListener('click', () => openRecord(rec.id));
      fragment.appendChild(tr);
    });

    body.appendChild(fragment);
  }

  count.textContent = reportsDataState.allTableState.filtered.length + ' заявки';
  pageInfo.textContent = 'Страница ' + reportsDataState.allTableState.page + ' от ' + totalPages;
  $('btnAllPrevPage').disabled = reportsDataState.allTableState.page <= 1;
  $('btnAllNextPage').disabled = reportsDataState.allTableState.page >= totalPages;
}

async function renderAllTable(opts) {
  const soft = isSoftRefreshOpts(opts);
  const body = $('allTableBody');
  if (!body) return;

  setContentLoading(body, '<tr><td colspan="20" class="hint">Зареждане...</td></tr>', soft);

  try {
    reportsDataState.allTableState.columns = getSelectedColumns();
    reportsDataState.allTableState.pageSize = Number($('allPageSize').value) || 50;
    reportsDataState.allTableState.records = await getAllRecords();
    reportsDataState.allTableState.filtered = applyAllFilters(reportsDataState.allTableState.records);
    reportsDataState.allTableState.page = 1;

    renderColumnsPanel();
    renderAllTableRows();
  } catch (e) {
    console.error('renderAllTable:', e);
    body.innerHTML = '<tr><td colspan="20" class="hint">Грешка при зареждане на заявките.</td></tr>';
  }
}

function updateAllTableFilters() {
  reportsDataState.allTableState.pageSize = Number($('allPageSize').value) || 50;
  reportsDataState.allTableState.filtered = applyAllFilters(reportsDataState.allTableState.records);
  reportsDataState.allTableState.page = 1;
  renderAllTableRows();
}

async function runSearch() {
  const input = $('searchInput');
  const results = $('searchResults');
  const query = input.value.trim().toLowerCase();

  results.innerHTML = '<div class="hint">Търсене...</div>';

  try {
    const records = await getAllRecords();
    const found = query
      ? records.filter(rec => getRecordSearchText(rec).includes(query))
      : [];

    found.sort((a, b) => (parseStamp(b.datetime) || new Date(0)) - (parseStamp(a.datetime) || new Date(0)));

    if (!query) {
      results.innerHTML = '<div class="empty">Въведете критерий за търсене.</div>';
      return;
    }

    if (!found.length) {
      results.innerHTML = '<div class="empty">Няма намерени заявки.</div>';
      return;
    }

    const fragment = document.createDocumentFragment();

    found.forEach(rec => {
      const item = document.createElement('div');
      item.className = 'resultitem' + (isUrgentActive(rec) ? ' urgent-row' : '');

      const left = document.createElement('div');
      const right = document.createElement('div');
      right.style.display = 'flex';
      right.style.alignItems = 'center';
      right.style.gap = '8px';

      left.innerHTML =
        `<div class="rid">${isUrgentActive(rec) ? '<span class="urgent-badge">🚨</span>' : ''}№ ${escapeHtml(rec.id)}</div>` +
        `<div class="rmeta">${escapeHtml(rec.datetime || '—')} • ${escapeHtml(rec.struktura || '—')} • ${escapeHtml(rec.lokacia || '—')}</div>`;

      right.innerHTML = `<span class="status-badge ${statusClass(rec.status)}">${escapeHtml(rec.status || '—')}</span>`;

      if (currentRole === 'admin') {
        const delBtn = document.createElement('button');
        delBtn.type = 'button';
        delBtn.className = 'wh-action-btn';
        delBtn.title = 'Изтрий заявката';
        delBtn.style.color = '#c0392b';
        delBtn.textContent = '✕';
        delBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          deleteRepairRequest(rec.id).then(ok => { if (ok) runSearch(); });
        });
        right.appendChild(delBtn);
      }

      item.appendChild(left);
      item.appendChild(right);
      item.addEventListener('click', () => openRecord(rec.id));
      fragment.appendChild(item);
    });

    results.innerHTML = '';
    results.appendChild(fragment);
  } catch (e) {
    console.error('runSearch:', e);
    results.innerHTML = '<div class="empty">Грешка при търсене.</div>';
  }
}

function exportRecordsXlsx(records, fileName, sheetName = 'Заявки') {
  return exportWithXlsx(async function () {
  if (!records.length) {
    toast('Няма данни за експорт.');
    return;
  }

  const columns = ALL_TABLE_COLUMNS.filter(c => reportsDataState.allTableState.columns.includes(c.key));
  const rows = records.map(rec => columns.map(c => getColumnValue(rec, c.key)));
  const ws = XLSX.utils.aoa_to_sheet([columns.map(c => c.label), ...rows]);

  ws['!cols'] = columns.map(c => ({
    wch: Math.min(45, Math.max(10, c.label.length + 4))
  }));

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, sheetName.slice(0, 31));
  XLSX.writeFile(wb, fileName);

  });
}

function getMonthFilteredRecords(records, monthValue) {
  if (!monthValue) return records;
  return records.filter(rec => {
    const d = parseStamp(rec.datetime);
    if (!d) return false;
    const ym = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
    return ym === monthValue;
  });
}

// Search / export events
let __searchDebounce = null;
$('btnSearch').addEventListener('click', runSearch);
$('searchInput').addEventListener('input', function () {
  clearTimeout(__searchDebounce);
  __searchDebounce = setTimeout(runSearch, 300);
});
$('searchInput').addEventListener('keydown', e => {
  if (e.key === 'Enter') {
    e.preventDefault();
    clearTimeout(__searchDebounce);
    runSearch();
  }
});

$('btnExport').addEventListener('click', async () => {
  try {
    const query = $('searchInput').value.trim().toLowerCase();
    const records = await getAllRecords();
    const found = query ? records.filter(r => getRecordSearchText(r).includes(query)) : records;
    reportsDataState.allTableState.columns = getSelectedColumns();
    exportRecordsXlsx(found, 'Zayavki_' + new Date().toISOString().slice(0,10) + '.xlsx');
  } catch (e) {
    console.error(e);
    toast('❌ Грешка при експортиране.');
  }
});

// All-table filters / pagination
$('allShowAllMonths').addEventListener('change', () => {
  $('allMonthFilter').disabled = $('allShowAllMonths').checked;
  updateAllTableFilters();
});
$('allMonthFilter').addEventListener('change', updateAllTableFilters);
$('allStatusFilter').addEventListener('change', updateAllTableFilters);
if ($('allStrukturaFilter')) $('allStrukturaFilter').addEventListener('change', updateAllTableFilters);
let __allFilterDebounce = null;
$('allFilter').addEventListener('input', function () {
  clearTimeout(__allFilterDebounce);
  __allFilterDebounce = setTimeout(updateAllTableFilters, 280);
});
$('allPageSize').addEventListener('change', updateAllTableFilters);

$('btnAllPrevPage').addEventListener('click', () => {
  if (reportsDataState.allTableState.page > 1) {
    reportsDataState.allTableState.page--;
    renderAllTableRows();
  }
});
$('btnAllNextPage').addEventListener('click', () => {
  const totalPages = Math.max(1, Math.ceil(reportsDataState.allTableState.filtered.length / reportsDataState.allTableState.pageSize));
  if (reportsDataState.allTableState.page < totalPages) {
    reportsDataState.allTableState.page++;
    renderAllTableRows();
  }
});

$('btnToggleColumnsPanel').addEventListener('click', () => {
  const panel = $('columnsPanel');
  panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
  renderColumnsPanel();
});

$('btnApplyColumns').addEventListener('click', () => {
  const selected = Array.from(document.querySelectorAll('#columnsCheckboxes input[data-column-key]:checked'))
    .map(el => el.getAttribute('data-column-key'));

  if (!selected.length) {
    toast('Изберете поне една колона.');
    return;
  }

  saveSelectedColumns(selected);
  $('columnsPanel').style.display = 'none';
  renderAllTableRows();
});

$('btnResetColumns').addEventListener('click', () => {
  saveSelectedColumns([...DEFAULT_TABLE_COLUMNS]);
  renderColumnsPanel();
  renderAllTableRows();
  toast('Колоните са върнати по подразбиране.');
});

const btnColAll = $('btnColumnsSelectAll');
if (btnColAll) btnColAll.addEventListener('click', () => {
  const wrap = $('columnsCheckboxes');
  if (!wrap) return;
  wrap.querySelectorAll('input[type="checkbox"][data-column-key]').forEach(cb => { cb.checked = true; });
});
const btnColNone = $('btnColumnsSelectNone');
if (btnColNone) btnColNone.addEventListener('click', () => {
  const wrap = $('columnsCheckboxes');
  if (!wrap) return;
  wrap.querySelectorAll('input[type="checkbox"][data-column-key]').forEach(cb => { cb.checked = false; });
});

const btnExportFiltered = $('btnExportFiltered');
if (btnExportFiltered) btnExportFiltered.addEventListener('click', async () => {
  try {
    reportsDataState.allTableState.columns = getSelectedColumns();
    // ако таблицата още не е заредена – зареди
    if (!reportsDataState.allTableState.records.length) {
      reportsDataState.allTableState.records = await getAllRecords();
      reportsDataState.allTableState.filtered = applyAllFilters(reportsDataState.allTableState.records);
    }
    const rows = reportsDataState.allTableState.filtered || [];
    if (!rows.length) {
      toast('Няма филтрирани заявки за експорт.');
      return;
    }
    const stamp = new Date().toISOString().slice(0, 10);
    exportRecordsXlsx(rows, 'Zayavki_filtrirani_' + stamp + '.xlsx', 'Филтрирани');
  } catch (e) {
    console.error(e);
    toast('❌ Грешка при експортиране на филтрираните.');
  }
});

function formatExportMonthPeriod(monthValue) {
  // monthValue: YYYY-MM
  if (!monthValue || !/^\d{4}-\d{2}$/.test(monthValue)) return monthValue || '';
  const [y, m] = monthValue.split('-');
  const mi = Number(m);
  const name = (mi >= 1 && mi <= 12) ? (WH_MONTH_NAMES[mi] || m) : m;
  return name + ' ' + y + ' г.';
}

function estimateReportPages(recordCount, columnsCount) {
  // Заглавна част ~1/3 страница + таблица
  const rowsPerPage = Math.max(8, Math.floor(28 - Math.min(columnsCount, 10)));
  const tablePages = Math.max(1, Math.ceil(Math.max(recordCount, 1) / rowsPerPage));
  return tablePages; // целият документ вкл. заглавието
}

function buildObyasnitelnaZapiskaHtml(records, monthValue) {
  const period = formatExportMonthPeriod(monthValue);
  const count = records.length;
  reportsDataState.allTableState.columns = getSelectedColumns();
  const columns = ALL_TABLE_COLUMNS.filter(c => reportsDataState.allTableState.columns.includes(c.key));
  const cols = columns.length ? columns : ALL_TABLE_COLUMNS.filter(c => DEFAULT_TABLE_COLUMNS.includes(c.key));
  const pages = estimateReportPages(count, cols.length);
  const today = new Date();
  const todayStr = String(today.getDate()).padStart(2,'0') + '.' + String(today.getMonth()+1).padStart(2,'0') + '.' + today.getFullYear();

  const head = cols.map(c =>
    '<th style="border:1px solid #000;padding:5px 6px;background:#eee;text-align:left;font-size:11px;">' +
    escapeHtml(c.label) + '</th>'
  ).join('');

  const body = records.length
    ? records.map(rec =>
        '<tr>' + cols.map(c =>
          '<td style="border:1px solid #000;padding:4px 6px;font-size:11px;vertical-align:top;">' +
          escapeHtml(String(getColumnValue(rec, c.key) == null ? '' : getColumnValue(rec, c.key))) +
          '</td>'
        ).join('') + '</tr>'
      ).join('')
    : '<tr><td colspan="' + cols.length + '" style="border:1px solid #000;padding:8px;text-align:center;">Няма постъпили заявки за периода.</td></tr>';

  return `<!DOCTYPE html>
<html lang="bg">
<head>
  <meta charset="utf-8">
  <title>Обобщена обяснителна записка относно постъпили заявки за ремонт</title>
  <style>
    @page { size: A4 landscape; margin: 12mm; }
    body { font-family: "Times New Roman", Times, serif; color: #000; font-size: 13px; margin: 0; }
    h1 { text-align: center; font-size: 16px; margin: 0 0 6px; text-transform: uppercase; }
    .meta { margin: 14px 0 18px; line-height: 1.55; }
    .meta b { display: inline-block; min-width: 160px; }
    table { width: 100%; border-collapse: collapse; margin-top: 10px; }
    .footer { margin-top: 18px; font-size: 12px; }
    .noprint { margin: 12px 0; }
    @media print { .noprint { display: none !important; } }
  </style>
</head>
<body>
  <div class="noprint">
    <button onclick="window.print()" style="padding:8px 16px;font-size:14px;cursor:pointer;">🖨 Печат / Запази като PDF</button>
    <span style="margin-left:10px;color:#555;">В диалога изберете „Запази като PDF“ / „Save as PDF“.</span>
  </div>
  <h1>Обобщена обяснителна записка<br>относно постъпили заявки за ремонт</h1>
  <div class="meta">
    <div><b>Период на справката:</b> ${escapeHtml(period)}</div>
    <div><b>Брой на заявките:</b> ${count}</div>
    <div><b>Брой страници:</b> ${pages}</div>
    <div><b>Дата на изготвяне:</b> ${escapeHtml(todayStr)}</div>
  </div>
  <p style="margin:0 0 8px;">Справката обхваща постъпилите заявки за ремонт за посочения период, както следва:</p>
  <table>
    <thead><tr>${head}</tr></thead>
    <tbody>${body}</tbody>
  </table>
  <div class="footer">
    Общо заявки: <b>${count}</b> &nbsp;|&nbsp; Страници: <b>${pages}</b> &nbsp;|&nbsp; Период: <b>${escapeHtml(period)}</b>
  </div>
  <script>
    document.title = 'Обобщена обяснителна записка относно постъпили заявки за ремонт';
  <\/script>
</body>
</html>`;
}

$('btnExportMonth').addEventListener('click', async () => {
  const monthValue = $('exportMonthInput').value;
  if (!monthValue) {
    toast('❌ Изберете месец за експортиране.');
    return;
  }

  try {
    const records = await getAllRecords();
    reportsDataState.allTableState.columns = getSelectedColumns();
    const filtered = getMonthFilteredRecords(records, monthValue);
    // Сортиране по дата
    filtered.sort((a, b) => {
      const da = parseStamp(a.datetime) || new Date(0);
      const db = parseStamp(b.datetime) || new Date(0);
      return da - db;
    });
    const html = buildObyasnitelnaZapiskaHtml(filtered, monthValue);
    const win = window.open('', '_blank');
    if (!win) {
      toast('Браузърът блокира прозореца. Разрешете pop-up за PDF.');
      return;
    }
    win.document.open();
    win.document.write(html);
    win.document.close();
    try { win.focus(); } catch (_) {}
    setTimeout(() => { try { win.print(); } catch (_) {} }, 400);
    toast('Отворена е обяснителната записка — запишете я като PDF.');
  } catch (e) {
    console.error(e);
    toast('❌ Грешка при генериране на PDF.');
  }
});
